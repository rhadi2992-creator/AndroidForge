package com.islamic.deenquiz;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import java.util.Date;

/**
 * MainActivity for Islamic Knowledge Challenge - Deen Quiz
 * Full Android application with high-performance WebView and real Google Mobile Ads SDK:
 * 1. Banner Ad:       ca-app-pub-3133971041724338/8121465266
 * 2. App Open Ad:     ca-app-pub-3133971041724338/3363962603
 * 3. Interstitial Ad: ca-app-pub-3133971041724338/3613188701
 * 4. Native Ad:       ca-app-pub-3133971041724338/2076745751
 * 5. Rewarded Ad:     ca-app-pub-3133971041724338/2300107036
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "DeenQuizAdMob";

    // Production Google AdMob Unit IDs (Updated to latest user credentials)
    public static final String ADMOB_APP_ID = "ca-app-pub-3133971041724338~5461456996";
    public static final String BANNER_AD_UNIT = "ca-app-pub-3133971041724338/8121465266";
    public static final String APP_OPEN_AD_UNIT = "ca-app-pub-3133971041724338/3363962603";
    public static final String INTERSTITIAL_AD_UNIT = "ca-app-pub-3133971041724338/3613188701";
    public static final String NATIVE_AD_UNIT = "ca-app-pub-3133971041724338/2076745751";
    public static final String REWARDED_AD_UNIT = "ca-app-pub-3133971041724338/2300107036";

    // UI and Web Components
    private WebView webView;
    private FrameLayout bannerContainer;
    private AdView bannerAdView;
    private LinearLayout loadingOverlay;
    private TextView errorTextView;
    private Button retryButton;

    // Ad Instances
    private InterstitialAd mInterstitialAd;
    private RewardedAd mRewardedAd;
    private AppOpenAd mAppOpenAd;
    private long appOpenLoadTime = 0;
    private boolean isShowingAppOpen = false;
    private boolean isWebGameLoaded = false;

    // Consent
    private ConsentInformation consentInformation;

    // Asset Loader for secure origin local asset resolution
    private WebViewAssetLoader assetLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Build native root layout with dark emerald background, WebView, loading indicator and banner
        buildUiLayout();

        // 2. Initialize UMP (User Messaging Platform) for GDPR/Consent Compliance
        initConsentAndMobileAds();

        // 3. Load the HTML5 Islamic Quiz Game assets with fallback and error protection
        loadWebGame();
    }

    private void buildUiLayout() {
        RelativeLayout rootLayout = new RelativeLayout(this);
        rootLayout.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        rootLayout.setBackgroundColor(0xFF042017); // Dark emerald theme background

        // Setup WebView
        webView = new WebView(this);
        RelativeLayout.LayoutParams webParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT);
        webView.setLayoutParams(webParams);
        // Explicitly set dark background to eliminate white canvas flash
        webView.setBackgroundColor(0xFF042017);
        rootLayout.addView(webView);

        // Setup Bottom Banner Container
        bannerContainer = new FrameLayout(this);
        RelativeLayout.LayoutParams bannerParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        bannerParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        bannerContainer.setLayoutParams(bannerParams);
        bannerContainer.setVisibility(View.GONE);
        rootLayout.addView(bannerContainer);

        // Setup Native Loading Overlay (guarantees user never sees a blank white screen)
        loadingOverlay = new LinearLayout(this);
        RelativeLayout.LayoutParams loaderParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT);
        loadingOverlay.setLayoutParams(loaderParams);
        loadingOverlay.setOrientation(LinearLayout.VERTICAL);
        loadingOverlay.setGravity(Gravity.CENTER);
        loadingOverlay.setBackgroundColor(0xFF042017);

        TextView titleView = new TextView(this);
        titleView.setText("Islamic Quiz Deen");
        titleView.setTextColor(0xFFFEF3C7);
        titleView.setTextSize(22);
        titleView.setGravity(Gravity.CENTER);
        titleView.setPadding(0, 0, 0, 8);
        loadingOverlay.addView(titleView);

        TextView subtitleView = new TextView(this);
        subtitleView.setText("بِسْمِ ٱللَّٰهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ");
        subtitleView.setTextColor(0xFFA7F3D0);
        subtitleView.setTextSize(14);
        subtitleView.setGravity(Gravity.CENTER);
        subtitleView.setPadding(0, 0, 0, 24);
        loadingOverlay.addView(subtitleView);

        ProgressBar progressBar = new ProgressBar(this);
        loadingOverlay.addView(progressBar);

        errorTextView = new TextView(this);
        errorTextView.setTextColor(0xFFFCA5A5);
        errorTextView.setTextSize(12);
        errorTextView.setGravity(Gravity.CENTER);
        errorTextView.setPadding(32, 16, 32, 16);
        errorTextView.setVisibility(View.GONE);
        loadingOverlay.addView(errorTextView);

        retryButton = new Button(this);
        retryButton.setText("Retry Loading");
        retryButton.setBackgroundColor(0xFFD97706);
        retryButton.setTextColor(Color.WHITE);
        retryButton.setVisibility(View.GONE);
        retryButton.setOnClickListener(v -> {
            errorTextView.setVisibility(View.GONE);
            retryButton.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);
            loadWebGame();
        });
        loadingOverlay.addView(retryButton);

        rootLayout.addView(loadingOverlay);

        setContentView(rootLayout);
    }

    private void hideLoadingOverlay() {
        runOnUiThread(() -> {
            if (loadingOverlay != null && loadingOverlay.getVisibility() == View.VISIBLE) {
                loadingOverlay.animate()
                        .alpha(0f)
                        .setDuration(300)
                        .withEndAction(() -> loadingOverlay.setVisibility(View.GONE))
                        .start();
            }
        });
    }

    private void showErrorOverlay(String message) {
        runOnUiThread(() -> {
            if (loadingOverlay != null) {
                loadingOverlay.setVisibility(View.VISIBLE);
                loadingOverlay.setAlpha(1f);
                if (errorTextView != null) {
                    errorTextView.setText(message);
                    errorTextView.setVisibility(View.VISIBLE);
                }
                if (retryButton != null) {
                    retryButton.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void loadWebGame() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMediaPlaybackRequiresUserGesture(false); // Seamless background Naat playback
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Configure official WebViewAssetLoader for modern ES module loading over HTTPS origin
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d("WebConsole", consoleMessage.message() + " -- Line "
                        + consoleMessage.lineNumber() + " of "
                        + consoleMessage.sourceId());
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse response = assetLoader.shouldInterceptRequest(request.getUrl());
                if (response != null) {
                    return response;
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Log.d(TAG, "WebView page started: " + url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "WebView page finished: " + url);
                isWebGameLoaded = true;
                hideLoadingOverlay();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    Log.e(TAG, "WebView main frame error: " + error.getDescription());
                    // Fallback to local file:// URL if asset loader hit a snag
                    if (request.getUrl().toString().contains("appassets.androidplatform.net")) {
                        Log.i(TAG, "Retrying with direct file:///android_asset/ URL...");
                        view.loadUrl("file:///android_asset/public/index.html");
                    } else {
                        showErrorOverlay("Loading Error: " + error.getDescription());
                    }
                }
            }
        });

        // Add JavaScript Interface Bridge for Web -> Native AdMob communication
        webView.addJavascriptInterface(new AdMobBridge(), "AndroidAdMob");

        // Timeout safety: hide native loading spinner after 6 seconds even if onPageFinished delayed
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!isWebGameLoaded) {
                hideLoadingOverlay();
            }
        }, 6000);

        // Load the game via modern secure origin (bypasses file:// CORS restrictions for ES modules)
        webView.loadUrl("https://appassets.androidplatform.net/assets/public/index.html");
    }

    public class AdMobBridge {
        @JavascriptInterface
        public void showBanner() {
            runOnUiThread(() -> {
                if (bannerAdView != null) {
                    bannerContainer.setVisibility(View.VISIBLE);
                } else {
                    loadBannerAd();
                }
            });
        }

        @JavascriptInterface
        public void hideBanner() {
            runOnUiThread(() -> {
                bannerContainer.setVisibility(View.GONE);
            });
        }

        @JavascriptInterface
        public void showInterstitial() {
            runOnUiThread(() -> {
                showInterstitialAd(() -> {
                    notifyWeb("onAndroidAdDismissed", "");
                });
            });
        }

        @JavascriptInterface
        public void showRewarded(final String rewardType) {
            runOnUiThread(() -> {
                showRewardedAd(() -> {
                    notifyWeb("onAndroidRewardGranted", rewardType);
                }, () -> {
                    notifyWeb("onAndroidAdDismissed", "");
                });
            });
        }

        @JavascriptInterface
        public void showAppOpen() {
            runOnUiThread(() -> {
                // Ensure main game screen is loaded before showing app open ad
                if (isWebGameLoaded) {
                    showAppOpenAdIfAvailable();
                }
            });
        }

        @JavascriptInterface
        public boolean isNativeAndroid() {
            return true;
        }

        @JavascriptInterface
        public void onAppReady() {
            runOnUiThread(() -> {
                isWebGameLoaded = true;
                hideLoadingOverlay();
            });
        }
    }

    private void notifyWeb(String functionName, String param) {
        if (webView != null) {
            String script = "if (window." + functionName + ") { window." + functionName + "('" + param + "'); }";
            webView.evaluateJavascript(script, null);
        }
    }

    private void initConsentAndMobileAds() {
        ConsentRequestParameters params = new ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false)
                .build();

        consentInformation = UserMessagingPlatform.getConsentInformation(this);
        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                () -> {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                            this,
                            formError -> {
                                if (formError != null) {
                                    Log.w(TAG, "Consent form error: " + formError.getMessage());
                                }
                                if (consentInformation.canRequestAds()) {
                                    initializeMobileAdsSdk();
                                }
                            }
                    );
                },
                requestConsentError -> {
                    Log.w(TAG, "Consent request error: " + requestConsentError.getMessage());
                    initializeMobileAdsSdk();
                }
        );

        if (consentInformation.canRequestAds()) {
            initializeMobileAdsSdk();
        }
    }

    private void initializeMobileAdsSdk() {
        RequestConfiguration configuration = new RequestConfiguration.Builder()
                .setTagForChildDirectedTreatment(RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE)
                .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_G)
                .build();
        MobileAds.setRequestConfiguration(configuration);

        MobileAds.initialize(this, initializationStatus -> {
            Log.d(TAG, "Google Mobile Ads SDK Initialized.");
            runOnUiThread(() -> {
                loadBannerAd();
                loadAppOpenAd();
                preloadInterstitialAd();
                preloadRewardedAd();
            });
        });
    }

    /* ---------------- BANNER AD IMPLEMENTATION ---------------- */
    private void loadBannerAd() {
        if (bannerAdView == null) {
            bannerAdView = new AdView(this);
            bannerAdView.setAdUnitId(BANNER_AD_UNIT);
            bannerAdView.setAdSize(AdSize.BANNER);
            bannerContainer.removeAllViews();
            bannerContainer.addView(bannerAdView);

            bannerAdView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    bannerContainer.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    Log.w(TAG, "Banner Ad Failed: " + loadAdError.getMessage());
                }
            });
        }

        AdRequest adRequest = new AdRequest.Builder().build();
        bannerAdView.loadAd(adRequest);
    }

    /* ---------------- APP OPEN AD IMPLEMENTATION ---------------- */
    public void loadAppOpenAd() {
        if (isAppOpenAdAvailable()) return;

        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(
                this,
                APP_OPEN_AD_UNIT,
                request,
                new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd appOpenAd) {
                        mAppOpenAd = appOpenAd;
                        appOpenLoadTime = (new Date()).getTime();
                        Log.d(TAG, "App Open Ad Loaded.");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        Log.w(TAG, "App Open Ad Failed: " + loadAdError.getMessage());
                        mAppOpenAd = null;
                    }
                }
        );
    }

    public boolean isAppOpenAdAvailable() {
        return mAppOpenAd != null && wasAppOpenLoadedLessThan4HoursAgo();
    }

    private boolean wasAppOpenLoadedLessThan4HoursAgo() {
        long dateDifference = (new Date()).getTime() - this.appOpenLoadTime;
        long numMilliSecondsPerHour = 3600000;
        return (dateDifference < (numMilliSecondsPerHour * 4));
    }

    public void showAppOpenAdIfAvailable() {
        if (!isShowingAppOpen && isAppOpenAdAvailable()) {
            mAppOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    mAppOpenAd = null;
                    isShowingAppOpen = false;
                    loadAppOpenAd();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    mAppOpenAd = null;
                    isShowingAppOpen = false;
                    loadAppOpenAd();
                }

                @Override
                public void onAdShowedFullScreenContent() {
                    isShowingAppOpen = true;
                }
            });
            mAppOpenAd.show(this);
        } else {
            loadAppOpenAd();
        }
    }

    /* ---------------- INTERSTITIAL AD IMPLEMENTATION ---------------- */
    public void preloadInterstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(
                this,
                INTERSTITIAL_AD_UNIT,
                adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        Log.d(TAG, "Interstitial Ad Preloaded.");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        Log.w(TAG, "Interstitial Failed: " + loadAdError.getMessage());
                        mInterstitialAd = null;
                    }
                }
        );
    }

    public void showInterstitialAd(Runnable onDismissed) {
        if (mInterstitialAd != null) {
            mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    mInterstitialAd = null;
                    preloadInterstitialAd();
                    if (onDismissed != null) onDismissed.run();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    mInterstitialAd = null;
                    preloadInterstitialAd();
                    if (onDismissed != null) onDismissed.run();
                }
            });
            mInterstitialAd.show(this);
        } else {
            preloadInterstitialAd();
            if (onDismissed != null) onDismissed.run();
        }
    }

    /* ---------------- REWARDED AD IMPLEMENTATION ---------------- */
    public void preloadRewardedAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        RewardedAd.load(
                this,
                REWARDED_AD_UNIT,
                adRequest,
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                        mRewardedAd = rewardedAd;
                        Log.d(TAG, "Rewarded Ad Preloaded.");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        Log.w(TAG, "Rewarded Ad Failed: " + loadAdError.getMessage());
                        mRewardedAd = null;
                    }
                }
        );
    }

    public void showRewardedAd(Runnable onRewardGranted, Runnable onDismissed) {
        if (mRewardedAd != null) {
            mRewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    mRewardedAd = null;
                    preloadRewardedAd();
                    if (onDismissed != null) onDismissed.run();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    mRewardedAd = null;
                    preloadRewardedAd();
                    if (onDismissed != null) onDismissed.run();
                }
            });

            mRewardedAd.show(this, rewardItem -> {
                Log.d(TAG, "Verified User Reward: " + rewardItem.getAmount() + " " + rewardItem.getType());
                if (onRewardGranted != null) {
                    runOnUiThread(onRewardGranted);
                }
            });
        } else {
            preloadRewardedAd();
            if (onDismissed != null) onDismissed.run();
        }
    }

    /* ---------------- ANDROID LIFECYCLE MANAGEMENT ---------------- */
    @Override
    protected void onResume() {
        super.onResume();
        if (bannerAdView != null) {
            bannerAdView.resume();
        }
        if (webView != null) {
            webView.onResume();
        }
        if (isWebGameLoaded) {
            showAppOpenAdIfAvailable();
        }
    }

    @Override
    protected void onPause() {
        if (bannerAdView != null) {
            bannerAdView.pause();
        }
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (bannerAdView != null) {
            bannerAdView.destroy();
        }
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
