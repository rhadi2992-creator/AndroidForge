# Islamic Knowledge Challenge – Deen Quiz ☪️

Directly compatible with **AndroidForge** and **Android Studio**.

## 🚀 AndroidForge Build Instructions

This ZIP is pre-configured with the Gradle root placed directly at the top level of the workspace.

When AndroidForge extracts this archive into:
`/__w/AndroidForge/AndroidForge/.androidforge/workspace`

It will immediately locate:
- `settings.gradle`
- `build.gradle`
- `gradle.properties`
- `gradlew`
- `app/build.gradle`

To assemble the release APK in AndroidForge, run:
```bash
gradle assembleRelease
```
Or using the Gradle wrapper:
```bash
./gradlew assembleRelease
```

The built APK will be produced at:
`app/build/outputs/apk/release/app-release.apk`

---

## 📱 Google AdMob Production IDs Configured
- **App ID**: `ca-app-pub-3133971041724338~5461456996`
- **Adaptive Banner**: `ca-app-pub-3133971041724338/8121465266`
- **App Open**: `ca-app-pub-3133971041724338/3363962603`
- **Interstitial**: `ca-app-pub-3133971041724338/3613188701`
- **Native Advanced**: `ca-app-pub-3133971041724338/2076745751`
- **Rewarded**: `ca-app-pub-3133971041724338/2300107036`

---

## 🌐 Web Development
```bash
npm install
npm run dev
```
