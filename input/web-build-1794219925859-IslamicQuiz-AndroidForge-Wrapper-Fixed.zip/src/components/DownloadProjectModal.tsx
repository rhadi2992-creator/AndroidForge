import React, { useState } from 'react';
import {
  X,
  Download,
  FolderArchive,
  CheckCircle2,
  FileCode,
  Music,
  Smartphone,
  Sparkles,
  Terminal,
  Loader2,
  AlertCircle,
  ShieldCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { projectZipService, PackagingProgress, PackagingResult } from '../services/projectZipService';
import { soundService } from '../services/soundService';

interface DownloadProjectModalProps {
  onClose: () => void;
}

export const DownloadProjectModal: React.FC<DownloadProjectModalProps> = ({ onClose }) => {
  const [isPackaging, setIsPackaging] = useState(false);
  const [progress, setProgress] = useState<PackagingProgress>({ percentage: 0, stepMessage: '' });
  const [result, setResult] = useState<PackagingResult | null>(null);

  const handleStartDownload = async () => {
    soundService.playButtonClick();
    setIsPackaging(true);
    setResult(null);

    const res = await projectZipService.downloadCompleteProject((p) => {
      setProgress(p);
    });

    setIsPackaging(false);
    setResult(res);

    if (res.success) {
      soundService.playDailyReward();
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#fbbf24', '#f59e0b', '#10b981', '#34d399']
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-[#063b2a] via-[#032217] to-[#01140e] border border-amber-500/40 p-5 sm:p-7 shadow-2xl text-amber-50">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-emerald-800/40 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <FolderArchive className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg text-amber-100">
                Download AndroidForge-Ready ZIP
              </h3>
              <span className="text-xs text-emerald-300/80">
                Root Gradle Build • assembleRelease Compatible • Full Source & Naat
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              soundService.playButtonClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-emerald-950/70 border border-emerald-700/40 text-stone-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Showcase */}
        <div className="space-y-4 text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
          {/* File Breakdown Grid */}
          <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
            <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-700/40 flex items-center gap-2.5">
              <FileCode className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <span className="font-bold text-amber-200 block text-xs">React 19 & TypeScript</span>
                <span className="text-[11px] text-stone-400">Complete components & questions</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-700/40 flex items-center gap-2.5">
              <Music className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <span className="font-bold text-amber-200 block text-xs">Background Naat MP3</span>
                <span className="text-[11px] text-stone-400">Meri Baat Ban Gayi Hai (8MB)</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-700/40 flex items-center gap-2.5">
              <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <span className="font-bold text-amber-200 block text-xs">Google AdMob Setup</span>
                <span className="text-[11px] text-stone-400">All 6 exact Ad Unit IDs</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-700/40 flex items-center gap-2.5">
              <Smartphone className="w-5 h-5 text-cyan-400 shrink-0" />
              <div>
                <span className="font-bold text-amber-200 block text-xs">Android Integration</span>
                <span className="text-[11px] text-stone-400">Capacitor & Manifest configured</span>
              </div>
            </div>
          </div>

          {/* Progress Indicator when packaging */}
          {isPackaging && (
            <div className="p-4 rounded-2xl bg-emerald-950/80 border border-amber-500/40 shadow-lg space-y-2.5 animate-fade-in">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-amber-300 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                  {progress.stepMessage || 'Packaging project...'}
                </span>
                <span className="font-mono font-bold text-amber-400">{progress.percentage}%</span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-stone-900 rounded-full h-2.5 overflow-hidden border border-emerald-800/40">
                <div
                  className="bg-gradient-to-r from-amber-400 via-amber-500 to-emerald-400 h-2.5 transition-all duration-300 rounded-full"
                  style={{ width: `${progress.percentage}%` }}
                />
              </div>
            </div>
          )}

          {/* Success Banner */}
          {result && result.success && (
            <div className="p-4 rounded-2xl bg-emerald-900/40 border border-emerald-500/50 shadow-md space-y-2 animate-fade-in">
              <div className="flex items-center gap-2 text-emerald-300 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>ZIP Generated & Download Started!</span>
              </div>
              <p className="text-xs text-stone-300 leading-relaxed">
                Downloaded <strong className="text-amber-300 font-mono">{result.fileName}</strong> ({result.fileSizeMb}).
                If your browser did not automatically start the download, click the button below:
              </p>
              <a
                href="/IslamicQuiz-AndroidForge-Wrapper-Fixed.zip"
                download="IslamicQuiz-AndroidForge-Wrapper-Fixed.zip"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs hover:bg-amber-400 transition"
              >
                <Download className="w-4 h-4" />
                <span>Download IslamicQuiz-AndroidForge-Wrapper-Fixed.zip</span>
              </a>
            </div>
          )}

          {/* AndroidForge & Local Build Instructions */}
          <div className="p-3.5 rounded-2xl bg-stone-950/80 border border-emerald-800/40">
            <h4 className="font-bold text-amber-300 text-xs flex items-center gap-1.5 mb-2">
              <Terminal className="w-4 h-4 text-amber-400" />
              AndroidForge & Gradle Build Command:
            </h4>
            <pre className="p-2.5 rounded-xl bg-black font-mono text-[11px] text-amber-300/90 overflow-x-auto leading-relaxed">
{`# In AndroidForge workspace (Root Gradle build is configured):
gradle assembleRelease

# The release APK is generated at:
# app/build/outputs/apk/release/app-release.apk

# Or for local web development:
npm install && npm run dev`}
            </pre>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-5 flex gap-2.5">
          <button
            onClick={() => {
              soundService.playButtonClick();
              onClose();
            }}
            className="flex-1 py-3 rounded-xl bg-emerald-950/70 border border-emerald-700/40 text-stone-300 font-semibold text-xs hover:bg-emerald-900/60 transition cursor-pointer"
          >
            Close
          </button>

          <button
            disabled={isPackaging}
            onClick={handleStartDownload}
            className={`flex-2 py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xl transition-all cursor-pointer ${
              isPackaging
                ? 'bg-amber-600/50 text-stone-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-stone-950 hover:scale-[1.02] active:scale-95 shadow-amber-900/40'
            }`}
          >
            {isPackaging ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-stone-950" />
                <span>Packaging ZIP ({progress.percentage}%)...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 text-stone-950" />
                <span>Download Complete Project ZIP (15 MB)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
