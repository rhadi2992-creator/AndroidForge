import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HomeScreen } from './components/HomeScreen';
import { QuizView } from './components/QuizView';
import { ResultsView } from './components/ResultsView';
import { LevelsView } from './components/LevelsView';
import { CategoriesView } from './components/CategoriesView';
import { DailyChallengeView } from './components/DailyChallengeView';
import { LeaderboardView } from './components/LeaderboardView';
import { SettingsModal } from './components/SettingsModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { AdMobBanner } from './components/AdMobBanner';
import { AdMobInterstitial } from './components/AdMobInterstitial';
import { AdMobAppOpen } from './components/AdMobAppOpen';
import { AdMobGuideModal } from './components/AdMobGuideModal';
import { PrivacyPolicyModal } from './components/PrivacyPolicyModal';
import { DownloadProjectModal } from './components/DownloadProjectModal';
import { AdMobDiagnosticsModal } from './components/AdMobDiagnosticsModal';
import { IslamicBackground } from './components/IslamicBackground';
import { PWAInstallButton } from './components/PWAInstallButton';

import { Question, Language, GameMode, QuizSummary, Difficulty } from './types/quiz';
import { storageService } from './services/storageService';
import { soundService } from './services/soundService';
import { adMobService } from './services/adMobService';
import {
  getQuestionsByCategory,
  getDailyQuestions,
  getQuickPlayQuestions
} from './data/questions';
import { getQuestionsForLevel } from './data/levels';
import { categories } from './data/categories';

type ScreenState = 'HOME' | 'QUIZ' | 'RESULTS' | 'LEVELS' | 'CATEGORIES' | 'DAILY' | 'LEADERBOARD';

export default function App() {
  const [screen, setScreen] = useState<ScreenState>('HOME');
  const [stats, setStats] = useState(storageService.getStats());
  const [preferences, setPreferences] = useState(storageService.getPreferences());
  const [audioSettings, setAudioSettings] = useState(soundService.getSettings());

  // Active Quiz State
  const [activeQuestions, setActiveQuestions] = useState<Question[]>([]);
  const [activeQuizMode, setActiveQuizMode] = useState<GameMode>('quick');
  const [activeCategoryTitle, setActiveCategoryTitle] = useState<string | undefined>(undefined);
  const [activeLevelNumber, setActiveLevelNumber] = useState<number | undefined>(undefined);
  const [lastSummary, setLastSummary] = useState<QuizSummary | null>(null);

  // Modals
  const [showSettings, setShowSettings] = useState(false);
  const [showHowToPlay, setShowHowToPlay] = useState(false);
  const [showApkGuide, setShowApkGuide] = useState(false);
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [showDiagnosticsModal, setShowDiagnosticsModal] = useState(false);

  // AdMob State
  const [adInterstitialOpen, setAdInterstitialOpen] = useState(false);
  const [isRewardedAd, setIsRewardedAd] = useState(false);
  const [rewardLifelineType, setRewardLifelineType] = useState<'fiftyFifty' | 'hint' | 'extraTime'>('hint');
  const [showAppOpenAd, setShowAppOpenAd] = useState(false);

  // Start background Naat on mount and show App Open Ad if cooldown elapsed
  useEffect(() => {
    soundService.startMusic();

    // Signal native Android container that web app has mounted and ready
    if (typeof (window as unknown as { AndroidAdMob?: { onAppReady?: () => void } }).AndroidAdMob?.onAppReady === 'function') {
      (window as unknown as { AndroidAdMob: { onAppReady: () => void } }).AndroidAdMob.onAppReady();
    }

    // Check App Open Ad (Part 6 of requirements)
    if (adMobService.shouldShowAppOpen()) {
      setShowAppOpenAd(true);
    }
  }, []);

  // Sync RTL attribute on document body
  useEffect(() => {
    document.documentElement.dir = preferences.language === 'ur' ? 'rtl' : 'ltr';
    document.documentElement.lang = preferences.language;
  }, [preferences.language]);

  const refreshStats = () => {
    setStats(storageService.getStats());
  };

  const handleLanguageChange = (newLang: Language) => {
    storageService.savePreferences({ language: newLang });
    setPreferences(prev => ({ ...prev, language: newLang }));
  };

  const handleThemeChange = (newTheme: 'emerald' | 'gold' | 'midnight') => {
    storageService.savePreferences({ theme: newTheme });
    setPreferences(prev => ({ ...prev, theme: newTheme }));
  };

  // Launch Quick Play (10 questions with shuffled options)
  const handleStartQuickPlay = () => {
    const qList = getQuickPlayQuestions(10);
    setActiveQuestions(qList);
    setActiveQuizMode('quick');
    setActiveCategoryTitle(undefined);
    setActiveLevelNumber(undefined);
    setScreen('QUIZ');
  };

  // Launch Category Quiz (with shuffled options)
  const handlePlayCategory = (categoryId: number, difficulty: Difficulty) => {
    const cat = categories.find(c => c.id === categoryId);
    const catTitle = cat ? (cat.name[preferences.language] || cat.name.en) : undefined;
    const qList = getQuestionsByCategory(categoryId, difficulty);
    setActiveQuestions(qList.slice(0, 10));
    setActiveQuizMode('category');
    setActiveCategoryTitle(catTitle);
    setActiveLevelNumber(undefined);
    setScreen('QUIZ');
  };

  // Launch Level (with shuffled options)
  const handlePlayLevel = (levelNum: number) => {
    const levelQuestions = getQuestionsForLevel(levelNum);
    setActiveQuestions(levelQuestions as Question[]);
    setActiveQuizMode('level');
    setActiveLevelNumber(levelNum);
    setActiveCategoryTitle(undefined);
    setScreen('QUIZ');
  };

  // Launch Daily Challenge (with shuffled options)
  const handleStartDailyQuiz = () => {
    const today = new Date().toISOString().split('T')[0];
    const dailyQs = getDailyQuestions(today);
    setActiveQuestions(dailyQs);
    setActiveQuizMode('daily');
    setActiveCategoryTitle("Daily Challenge");
    setActiveLevelNumber(undefined);
    setScreen('QUIZ');
  };

  // Quiz Finish
  const handleFinishQuiz = (summary: QuizSummary) => {
    const recordResult = storageService.recordQuizCompletion(summary);
    summary.unlockedNextLevel = recordResult.unlockedNextLevel;
    setLastSummary(summary);
    refreshStats();
    setScreen('RESULTS');

    // AdMob Interstitial after quiz completion (Part 5 of requirements)
    if (adMobService.shouldShowInterstitial()) {
      setTimeout(() => {
        setIsRewardedAd(false);
        setAdInterstitialOpen(true);
      }, 700);
    }
  };

  // Rewarded Ad for Lifeline (Part 8 of requirements)
  const handleWatchAdForLifeline = (type: 'fiftyFifty' | 'hint' | 'extraTime') => {
    soundService.playButtonClick();
    setIsRewardedAd(true);
    setRewardLifelineType(type);
    setAdInterstitialOpen(true);
  };

  const handleRewardEarned = (type: 'fiftyFifty' | 'hint' | 'extraTime') => {
    storageService.addLifelines(type, 1);
    adMobService.recordRewardGranted();
    refreshStats();
  };

  // Handle Testing Ad Formats Individually (Requirement #11)
  const handleTriggerTestAd = (type: 'banner' | 'appOpen' | 'interstitial' | 'native' | 'rewarded') => {
    switch (type) {
      case 'banner':
        adMobService.preloadBanner();
        break;
      case 'appOpen':
        setShowAppOpenAd(true);
        break;
      case 'interstitial':
        setIsRewardedAd(false);
        setAdInterstitialOpen(true);
        break;
      case 'rewarded':
        setIsRewardedAd(true);
        setRewardLifelineType('hint');
        setAdInterstitialOpen(true);
        break;
      case 'native':
        setScreen('CATEGORIES');
        setShowDiagnosticsModal(false);
        break;
    }
  };

  // Retry Quiz
  const handleRetry = () => {
    if (activeQuizMode === 'level' && activeLevelNumber) {
      handlePlayLevel(activeLevelNumber);
    } else if (activeQuizMode === 'daily') {
      handleStartDailyQuiz();
    } else {
      handleStartQuickPlay();
    }
  };

  // Next Level
  const handleNextLevel = () => {
    if (activeLevelNumber && activeLevelNumber < 20) {
      handlePlayLevel(activeLevelNumber + 1);
    }
  };

  return (
    <div className={`min-h-screen flex flex-col relative font-sans text-amber-50 ${preferences.language === 'ur' ? 'font-urdu' : ''}`}>
      {/* Decorative Islamic Backdrop */}
      <IslamicBackground theme={preferences.theme} />

      {/* Top Navbar */}
      <Navbar
        language={preferences.language}
        onLanguageChange={handleLanguageChange}
        onOpenSettings={() => setShowSettings(true)}
        onOpenHowToPlay={() => setShowHowToPlay(true)}
        onGoHome={() => setScreen('HOME')}
        onOpenDownloadProject={() => setShowDownloadModal(true)}
        currentStreak={stats.currentStreak}
        coins={stats.coins}
        musicEnabled={audioSettings.musicEnabled}
        onToggleMusic={() => {
          const newState = soundService.toggleMusic();
          setAudioSettings(prev => ({ ...prev, musicEnabled: newState }));
        }}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 flex flex-col items-center justify-start pb-20 sm:pb-24 w-full">
        {/* PWA Install Button Floating Bar in Header */}
        <div className="w-full max-w-4xl px-4 pt-2 flex justify-end">
          <PWAInstallButton />
        </div>

        {screen === 'HOME' && (
          <HomeScreen
            language={preferences.language}
            stats={stats}
            onStartQuickPlay={handleStartQuickPlay}
            onOpenDailyChallenge={() => setScreen('DAILY')}
            onOpenLevels={() => setScreen('LEVELS')}
            onOpenCategories={() => setScreen('CATEGORIES')}
            onOpenLeaderboard={() => setScreen('LEADERBOARD')}
            onOpenHowToPlay={() => setShowHowToPlay(true)}
            onOpenSettings={() => setShowSettings(true)}
            onOpenApkGuide={() => setShowApkGuide(true)}
            onOpenDownloadProject={() => setShowDownloadModal(true)}
            onStatsUpdated={refreshStats}
          />
        )}

        {screen === 'QUIZ' && (
          <QuizView
            questions={activeQuestions}
            language={preferences.language}
            mode={activeQuizMode}
            categoryTitle={activeCategoryTitle}
            levelNumber={activeLevelNumber}
            onFinishQuiz={handleFinishQuiz}
            onExitQuiz={() => setScreen('HOME')}
            onWatchAdForLifeline={handleWatchAdForLifeline}
          />
        )}

        {screen === 'RESULTS' && lastSummary && (
          <ResultsView
            summary={lastSummary}
            language={preferences.language}
            onRetry={handleRetry}
            onNextLevel={activeQuizMode === 'level' ? handleNextLevel : undefined}
            onGoHome={() => setScreen('HOME')}
            hasNextLevel={activeQuizMode === 'level' && !!activeLevelNumber && activeLevelNumber < 20}
          />
        )}

        {screen === 'LEVELS' && (
          <LevelsView
            language={preferences.language}
            stats={stats}
            onPlayLevel={handlePlayLevel}
            onBack={() => setScreen('HOME')}
          />
        )}

        {screen === 'CATEGORIES' && (
          <CategoriesView
            language={preferences.language}
            onPlayCategory={handlePlayCategory}
            onBack={() => setScreen('HOME')}
            onOpenGuide={() => setShowApkGuide(true)}
          />
        )}

        {screen === 'DAILY' && (
          <DailyChallengeView
            language={preferences.language}
            stats={stats}
            onStartDailyQuiz={handleStartDailyQuiz}
            onBack={() => setScreen('HOME')}
          />
        )}

        {screen === 'LEADERBOARD' && (
          <LeaderboardView
            stats={stats}
            language={preferences.language}
            onBack={() => setScreen('HOME')}
          />
        )}
      </main>

      {/* AdMob Adaptive Banner (fixed bottom on menu and results screens, never covering active gameplay) */}
      {screen !== 'QUIZ' && (
        <footer className="fixed bottom-0 left-0 right-0 z-30 flex justify-center backdrop-blur-md bg-[#042017]/90 border-t border-amber-500/20 py-1">
          <AdMobBanner onOpenGuide={() => setShowApkGuide(true)} />
        </footer>
      )}

      {/* Modals */}
      {showSettings && (
        <SettingsModal
          language={preferences.language}
          onLanguageChange={handleLanguageChange}
          onThemeChange={handleThemeChange}
          currentTheme={preferences.theme}
          onClose={() => {
            setShowSettings(false);
            setAudioSettings(soundService.getSettings());
          }}
          onResetConfirmed={() => {
            refreshStats();
            setScreen('HOME');
          }}
          onOpenPrivacyPolicy={() => setShowPrivacyPolicy(true)}
          onOpenGuide={() => setShowApkGuide(true)}
          onOpenDownloadProject={() => setShowDownloadModal(true)}
          onOpenDiagnostics={() => setShowDiagnosticsModal(true)}
        />
      )}

      {showHowToPlay && (
        <HowToPlayModal
          language={preferences.language}
          onClose={() => setShowHowToPlay(false)}
        />
      )}

      {showApkGuide && (
        <AdMobGuideModal
          language={preferences.language}
          onClose={() => setShowApkGuide(false)}
          onOpenDownloadProject={() => setShowDownloadModal(true)}
        />
      )}

      {showPrivacyPolicy && (
        <PrivacyPolicyModal
          onClose={() => setShowPrivacyPolicy(false)}
        />
      )}

      {/* Download Complete Project ZIP Modal */}
      {showDownloadModal && (
        <DownloadProjectModal
          onClose={() => setShowDownloadModal(false)}
        />
      )}

      {/* AdMob Internal Diagnostics & Live Test Console */}
      {showDiagnosticsModal && (
        <AdMobDiagnosticsModal
          onClose={() => setShowDiagnosticsModal(false)}
          onTriggerTestAd={handleTriggerTestAd}
        />
      )}

      {/* Interstitial or Rewarded Ad */}
      {adInterstitialOpen && (
        <AdMobInterstitial
          isRewarded={isRewardedAd}
          rewardType={rewardLifelineType}
          onRewardEarned={handleRewardEarned}
          onClose={() => setAdInterstitialOpen(false)}
        />
      )}

      {/* App Open Ad on startup */}
      {showAppOpenAd && (
        <AdMobAppOpen
          onDismiss={() => setShowAppOpenAd(false)}
        />
      )}
    </div>
  );
}
