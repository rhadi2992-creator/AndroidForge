# Super Runner Adventure 3D – AndroidForge Package

A complete native Kotlin Android 3D endless runner game with full Google AdMob integration.

## AdMob IDs Configured:
- App ID: ca-app-pub-3133971041724338~1685793706
- Banner Ad Unit: ca-app-pub-3133971041724338/9198461373
- App Open Ad Unit: ca-app-pub-3133971041724338/9993714472
- Interstitial Ad Unit: ca-app-pub-3133971041724338/5148581904
- Rewarded Ad Unit: ca-app-pub-3133971041724338/6294142615
- Native Advanced Ad Unit: ca-app-pub-3133971041724338/3125053795

## Build & APK Generation:
1. Upload this zip file to AndroidForge to generate your signed APK.
2. In app/src/main/java/com/superrunner/adventure3d/ads/AdConfig.kt, toggle USE_TEST_ADS = false for production releases.
