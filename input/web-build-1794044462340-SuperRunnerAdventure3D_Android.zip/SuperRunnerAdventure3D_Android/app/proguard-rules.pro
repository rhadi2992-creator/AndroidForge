-keep class com.google.android.gms.ads.** { *; }
-dontwarn com.google.android.gms.ads.**
-keepattributes SourceFile,LineNumberTable
-keepattributes *Annotation*
-keepclassmembers class * {
    @com.google.android.gms.ads.** *;
}
