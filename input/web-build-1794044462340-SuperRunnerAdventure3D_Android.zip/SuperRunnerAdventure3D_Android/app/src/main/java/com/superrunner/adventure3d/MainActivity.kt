package com.superrunner.adventure3d

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import com.superrunner.adventure3d.ads.AdMobManager
import com.superrunner.adventure3d.game.GameState
import com.superrunner.adventure3d.game.GameView
import com.superrunner.adventure3d.ui.ReviveDialog

class MainActivity : AppCompatActivity() {

    private lateinit var gameView: GameView
    private lateinit var bannerContainer: FrameLayout
    private lateinit var nativeAdContainer: FrameLayout
    private lateinit var adMobManager: AdMobManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        hideSystemUI()

        gameView = findViewById(R.id.game_view)
        bannerContainer = findViewById(R.id.banner_container)
        nativeAdContainer = findViewById(R.id.native_ad_container)

        adMobManager = AdMobManager(this)
        adMobManager.setupBanner(bannerContainer)

        gameView.onShowReviveDialog = {
            showReviveDialog()
        }

        gameView.onGameOver = { score, coins ->
            handleGameOver(score, coins)
        }

        gameView.onScoreUpdated = { _, _ ->
            adMobManager.setBannerVisibility(false)
            nativeAdContainer.visibility = View.GONE
            (application as? SuperRunnerApp)?.appOpenAdManager?.isGameplayActive = true
        }
    }

    private fun showReviveDialog() {
        (application as? SuperRunnerApp)?.appOpenAdManager?.isGameplayActive = true

        val dialog = ReviveDialog(
            context = this,
            adMobManager = adMobManager,
            onReviveConfirmed = {
                gameView.revive()
                adMobManager.setBannerVisibility(false)
            },
            onDecline = {
                gameView.declineRevive()
            }
        )
        dialog.show()
    }

    private fun handleGameOver(score: Int, coins: Int) {
        (application as? SuperRunnerApp)?.appOpenAdManager?.isGameplayActive = false
        adMobManager.setBannerVisibility(true)
        adMobManager.loadNativeAd(nativeAdContainer)
        adMobManager.showInterstitialIfAllowed {}
    }

    override fun onResume() {
        super.onResume()
        hideSystemUI()
        adMobManager.resumeBanner()
    }

    override fun onPause() {
        super.onPause()
        adMobManager.pauseBanner()
    }

    override fun onDestroy() {
        super.onDestroy()
        adMobManager.destroy()
    }

    private fun hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
            )
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
}
