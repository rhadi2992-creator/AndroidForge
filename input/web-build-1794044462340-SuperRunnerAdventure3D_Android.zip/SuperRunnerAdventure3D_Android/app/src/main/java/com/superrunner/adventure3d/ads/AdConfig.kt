package com.superrunner.adventure3d.ads

object AdConfig {
    const val USE_TEST_ADS: Boolean = false

    const val PROD_APP_ID = "ca-app-pub-3133971041724338~1685793706"
    const val PROD_BANNER_ID = "ca-app-pub-3133971041724338/9198461373"
    const val PROD_APP_OPEN_ID = "ca-app-pub-3133971041724338/9993714472"
    const val PROD_INTERSTITIAL_ID = "ca-app-pub-3133971041724338/5148581904"
    const val PROD_REWARDED_ID = "ca-app-pub-3133971041724338/6294142615"
    const val PROD_NATIVE_ADVANCED_ID = "ca-app-pub-3133971041724338/3125053795"

    const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"
    const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"
    const val TEST_NATIVE_ADVANCED_ID = "ca-app-pub-3940256099942544/2247696110"

    val bannerAdUnitId: String
        get() = if (USE_TEST_ADS) TEST_BANNER_ID else PROD_BANNER_ID

    val appOpenAdUnitId: String
        get() = if (USE_TEST_ADS) TEST_APP_OPEN_ID else PROD_APP_OPEN_ID

    val interstitialAdUnitId: String
        get() = if (USE_TEST_ADS) TEST_INTERSTITIAL_ID else PROD_INTERSTITIAL_ID

    val rewardedAdUnitId: String
        get() = if (USE_TEST_ADS) TEST_REWARDED_ID else PROD_REWARDED_ID

    val nativeAdvancedAdUnitId: String
        get() = if (USE_TEST_ADS) TEST_NATIVE_ADVANCED_ID else PROD_NATIVE_ADVANCED_ID
}
