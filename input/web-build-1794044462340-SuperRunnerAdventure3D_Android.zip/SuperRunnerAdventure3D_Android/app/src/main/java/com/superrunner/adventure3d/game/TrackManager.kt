package com.superrunner.adventure3d.game

import kotlin.math.abs
import kotlin.random.Random

enum class SegmentType {
    STRAIGHT,
    TURN_LEFT,
    TURN_RIGHT,
    CHASM_GAP,
    ROPE_SWING,
    ELEVATED_BRIDGE
}

class TrackSegment(
    val index: Int,
    val z: Float,
    val type: SegmentType = SegmentType.STRAIGHT,
    val obstacles: MutableList<Obstacle> = mutableListOf(),
    val coins: MutableList<Coin> = mutableListOf(),
    val powerUps: MutableList<PowerUp> = mutableListOf(),
    // Specific properties for turns, gaps, and rope swings
    val turnTriggerZ: Float = z - 20f,
    val gapStartZ: Float = z - 12f,
    val gapEndZ: Float = z - 26f,
    val ropeAnchorZ: Float = z - 18f,
    val ropeLandingZ: Float = z - 30f,
    var turnCompleted: Boolean = false,
    var ropeCleared: Boolean = false
)

class TrackManager {
    val segments = mutableListOf<TrackSegment>()
    private var nextSegmentIndex = 0
    private var nextSegmentZ = 0f
    private var lastPowerUpZ = 50f
    private val minPowerUpDistance = 160f
    private var powerUpCycle = 0
    private var consecutiveStraightCount = 0

    fun reset() {
        segments.clear()
        nextSegmentIndex = 0
        nextSegmentZ = 0f
        lastPowerUpZ = 50f
        consecutiveStraightCount = 0

        for (i in 0 until GameConstants.ACTIVE_SEGMENTS) {
            spawnSegment(isSafe = i < 2)
        }
    }

    fun update(playerZ: Float) {
        if (segments.isNotEmpty()) {
            val oldest = segments.first()
            if (playerZ < oldest.z - GameConstants.SEGMENT_LENGTH - 25f) {
                segments.removeAt(0)
                spawnSegment(isSafe = false)
            }
        }
    }

    private fun spawnSegment(isSafe: Boolean) {
        val segZ = nextSegmentZ

        if (isSafe) {
            val seg = TrackSegment(nextSegmentIndex, segZ, SegmentType.STRAIGHT)
            // Starter coins right at beginning in center and left lane
            spawnCoinRow(seg, 1, segZ - 8f, segZ - 26f, 1.1f, 6)
            spawnCoinRow(seg, 0, segZ - 28f, segZ - 40f, 1.1f, 4)
            segments.add(seg)
            nextSegmentIndex++
            nextSegmentZ -= GameConstants.SEGMENT_LENGTH
            return
        }

        // Procedural path selection with adventure features
        val segType = selectNextSegmentType()
        val seg = when (segType) {
            SegmentType.TURN_LEFT -> TrackSegment(
                index = nextSegmentIndex,
                z = segZ,
                type = SegmentType.TURN_LEFT,
                turnTriggerZ = segZ - 18f
            )
            SegmentType.TURN_RIGHT -> TrackSegment(
                index = nextSegmentIndex,
                z = segZ,
                type = SegmentType.TURN_RIGHT,
                turnTriggerZ = segZ - 18f
            )
            SegmentType.CHASM_GAP -> TrackSegment(
                index = nextSegmentIndex,
                z = segZ,
                type = SegmentType.CHASM_GAP,
                gapStartZ = segZ - 12f,
                gapEndZ = segZ - 26f
            )
            SegmentType.ROPE_SWING -> TrackSegment(
                index = nextSegmentIndex,
                z = segZ,
                type = SegmentType.ROPE_SWING,
                gapStartZ = segZ - 10f,
                gapEndZ = segZ - 28f,
                ropeAnchorZ = segZ - 18f,
                ropeLandingZ = segZ - 30f
            )
            SegmentType.ELEVATED_BRIDGE -> TrackSegment(
                index = nextSegmentIndex,
                z = segZ,
                type = SegmentType.ELEVATED_BRIDGE
            )
            else -> TrackSegment(
                index = nextSegmentIndex,
                z = segZ,
                type = SegmentType.STRAIGHT
            )
        }

        populateSegmentContent(seg, segZ)
        segments.add(seg)
        nextSegmentIndex++
        nextSegmentZ -= GameConstants.SEGMENT_LENGTH
    }

    private fun selectNextSegmentType(): SegmentType {
        // Guarantee at least 2 straights between special adventure features
        if (consecutiveStraightCount < 2) {
            consecutiveStraightCount++
            return SegmentType.STRAIGHT
        }

        val roll = Random.nextFloat()
        return when {
            roll < 0.22f -> {
                consecutiveStraightCount = 0
                SegmentType.TURN_LEFT
            }
            roll < 0.44f -> {
                consecutiveStraightCount = 0
                SegmentType.TURN_RIGHT
            }
            roll < 0.64f -> {
                consecutiveStraightCount = 0
                SegmentType.CHASM_GAP
            }
            roll < 0.82f -> {
                consecutiveStraightCount = 0
                SegmentType.ROPE_SWING
            }
            roll < 0.92f -> {
                consecutiveStraightCount = 0
                SegmentType.ELEVATED_BRIDGE
            }
            else -> {
                consecutiveStraightCount++
                SegmentType.STRAIGHT
            }
        }
    }

    private fun populateSegmentContent(seg: TrackSegment, segZ: Float) {
        when (seg.type) {
            SegmentType.CHASM_GAP -> {
                // Gap jump: spawn rewarding coin arc over the broken road gap
                spawnGapCoinArc(seg, 1, seg.gapStartZ, seg.gapEndZ)
                // Clean coins on safe landing platform
                spawnCoinRow(seg, 1, seg.gapEndZ - 2f, seg.gapEndZ - 10f, 1.05f, 3)
            }

            SegmentType.ROPE_SWING -> {
                // Rope swing: clean suspended coin arc following the rope's pendulum path
                spawnRopeCoinArc(seg, 1, segZ - 12f, seg.ropeAnchorZ, seg.ropeLandingZ)
                // Coins on landing platform
                spawnCoinRow(seg, 1, seg.ropeLandingZ - 2f, seg.ropeLandingZ - 8f, 1.05f, 3)
            }

            SegmentType.TURN_LEFT, SegmentType.TURN_RIGHT -> {
                // Turn junction: coins leading straight into the turn approach
                val turnLane = if (seg.type == SegmentType.TURN_LEFT) 0 else 2
                spawnCoinRow(seg, 1, segZ - 2f, segZ - 10f, 1.05f, 3)
                spawnCoinRow(seg, turnLane, segZ - 12f, segZ - 18f, 1.05f, 3)
            }

            SegmentType.ELEVATED_BRIDGE -> {
                // Narrow bridge with wooden hurdles and swinging pendulum
                val blockedLane = Random.nextInt(3)
                seg.obstacles.add(
                    Obstacle(
                        type = ObstacleType.BROKEN_PLANKS,
                        lane = blockedLane,
                        x = GameConstants.LANE_X[blockedLane],
                        z = segZ - 15f,
                        minY = 0f,
                        maxY = 1.2f
                    )
                )
                val safeLane = (blockedLane + 1) % 3
                spawnCoinRow(seg, safeLane, segZ - 5f, segZ - 25f, 1.05f, 6)
            }

            SegmentType.STRAIGHT -> {
                populateHazards(seg, segZ)
            }
        }

        // Strictly filter out any coin that is unreachable or intersects lethal obstacles
        filterUnreachableCoins(seg)
    }

    private fun populateHazards(seg: TrackSegment, segZ: Float) {
        val zones = floatArrayOf(segZ + 10f, segZ - 10f)

        for ((idx, zoneZ) in zones.withIndex()) {
            val roll = Random.nextFloat()

            if (roll < 0.32f) {
                // Hurdle Barrier (Requires Jump)
                val blockedLane = Random.nextInt(3)
                seg.obstacles.add(
                    Obstacle(
                        type = ObstacleType.BARRIER_JUMP,
                        lane = blockedLane,
                        x = GameConstants.LANE_X[blockedLane],
                        z = zoneZ,
                        minY = 0f,
                        maxY = 1.15f
                    )
                )
                spawnCoinArc(seg, blockedLane, zoneZ)
                val openLane = (blockedLane + 1) % 3
                spawnCoinRow(seg, openLane, zoneZ + 5f, zoneZ - 5f, 1.05f, 4)
            } else if (roll < 0.58f) {
                // Overhead Arch (Requires Slide)
                val blockedLane = Random.nextInt(3)
                seg.obstacles.add(
                    Obstacle(
                        type = ObstacleType.OVERHEAD_SLIDE,
                        lane = blockedLane,
                        x = GameConstants.LANE_X[blockedLane],
                        z = zoneZ,
                        minY = 1.15f,
                        maxY = 2.8f
                    )
                )
                spawnCoinRow(seg, blockedLane, zoneZ + 4.5f, zoneZ - 4.5f, 0.55f, 4)
                val openLane = (blockedLane + 1) % 3
                spawnCoinRow(seg, openLane, zoneZ + 5f, zoneZ - 5f, 1.05f, 4)
            } else if (roll < 0.78f) {
                // Giant Boulder (Requires Lane Switch)
                val blockedLane = Random.nextInt(3)
                seg.obstacles.add(
                    Obstacle(
                        type = ObstacleType.ROCK_LANE,
                        lane = blockedLane,
                        x = GameConstants.LANE_X[blockedLane],
                        z = zoneZ,
                        minY = 0f,
                        maxY = 2.5f
                    )
                )
                val openLane = (blockedLane + 1) % 3
                spawnCoinRow(seg, openLane, zoneZ + 6f, zoneZ - 6f, 1.05f, 5)
            } else if (roll < 0.90f) {
                // Swinging Spiked Pendulum (Requires Timing or lane dodge)
                seg.obstacles.add(
                    Obstacle(
                        type = ObstacleType.SWINGING_PENDULUM,
                        lane = 1,
                        x = 0f,
                        z = zoneZ,
                        minY = 0.2f,
                        maxY = 2.4f,
                        width = 1.6f
                    )
                )
                spawnCoinRow(seg, 0, zoneZ + 6f, zoneZ - 6f, 1.05f, 4)
                spawnCoinRow(seg, 2, zoneZ + 6f, zoneZ - 6f, 1.05f, 4)
            } else {
                // Double obstacle
                val safeLane = Random.nextInt(3)
                for (lane in 0..2) {
                    if (lane != safeLane) {
                        seg.obstacles.add(
                            Obstacle(
                                type = ObstacleType.BARRIER_JUMP,
                                lane = lane,
                                x = GameConstants.LANE_X[lane],
                                z = zoneZ,
                                minY = 0f,
                                maxY = 1.5f
                            )
                        )
                    }
                }
                spawnCoinRow(seg, safeLane, zoneZ + 6f, zoneZ - 6f, 1.05f, 5)
            }

            // Limited power-up spawn
            if (abs(zoneZ - lastPowerUpZ) >= minPowerUpDistance && idx == 0) {
                lastPowerUpZ = zoneZ
                val types = PowerUpType.values()
                val pType = types[powerUpCycle % types.size]
                powerUpCycle++

                val pLane = Random.nextInt(3)
                seg.powerUps.add(
                    PowerUp(
                        type = pType,
                        lane = pLane,
                        x = GameConstants.LANE_X[pLane],
                        y = 1.25f,
                        z = zoneZ - 12f
                    )
                )
            }
        }
    }

    private fun filterUnreachableCoins(seg: TrackSegment) {
        seg.coins.removeAll { coin ->
            // 1. Must be in a valid lane
            if (coin.lane !in 0..2) return@removeAll true

            // 2. Must be aligned with lane X
            val expectedX = GameConstants.LANE_X[coin.lane]
            if (abs(coin.x - expectedX) > 0.15f) return@removeAll true

            // 3. Must be within realistic vertical bounds (0.35m - 2.5m)
            if (coin.y < 0.35f || coin.y > 2.5f) return@removeAll true

            // 4. Must NOT intersect impassable rock obstacles
            for (obs in seg.obstacles) {
                if (obs.type == ObstacleType.ROCK_LANE && obs.lane == coin.lane) {
                    if (abs(obs.z - coin.z) < 4.0f) {
                        return@removeAll true
                    }
                }
            }

            false
        }
    }

    private fun spawnCoinArc(seg: TrackSegment, lane: Int, obstacleZ: Float) {
        val laneX = GameConstants.LANE_X[lane]
        for (i in -2..2) {
            val cz = obstacleZ + i * 2.5f
            val height = 1.05f + maxOf(0f, 0.8f - (i * i) * 0.18f)
            seg.coins.add(Coin(lane, laneX, height, cz))
        }
    }

    private fun spawnGapCoinArc(seg: TrackSegment, lane: Int, gapStart: Float, gapEnd: Float) {
        val laneX = GameConstants.LANE_X[lane]
        val totalDist = gapEnd - gapStart
        val count = 5
        val step = totalDist / (count - 1)
        for (i in 0 until count) {
            val cz = gapStart + i * step
            // High parabolic arc across the gap
            val norm = (i - 2) / 2.0f
            val height = 1.2f + maxOf(0f, 1.2f - (norm * norm) * 1.1f)
            seg.coins.add(Coin(lane, laneX, height, cz))
        }
    }

    private fun spawnRopeCoinArc(seg: TrackSegment, lane: Int, startZ: Float, anchorZ: Float, landingZ: Float) {
        val laneX = GameConstants.LANE_X[lane]
        val count = 5
        val totalDist = landingZ - startZ
        val step = totalDist / (count - 1)
        for (i in 0 until count) {
            val cz = startZ + i * step
            // Swings down then up to landing platform
            val progress = i / (count - 1).toFloat()
            val height = 1.6f + sin(progress * Math.PI.toFloat()) * 1.1f
            seg.coins.add(Coin(lane, laneX, height, cz))
        }
    }

    private fun spawnCoinRow(seg: TrackSegment, lane: Int, startZ: Float, endZ: Float, y: Float, count: Int) {
        val laneX = GameConstants.LANE_X[lane]
        val totalDist = endZ - startZ
        val step = if (count > 1) totalDist / (count - 1) else -2.8f
        for (i in 0 until count) {
            val cz = startZ + i * step
            seg.coins.add(Coin(lane, laneX, y, cz))
        }
    }

    fun clearAheadObstacles(playerZ: Float, distance: Float) {
        for (seg in segments) {
            seg.obstacles.removeAll { obs ->
                obs.z <= playerZ && obs.z >= playerZ - distance
            }
        }
    }
}
