package com.superrunner.adventure3d.game

import kotlin.math.abs

enum class PowerUpType {
    SHIELD,
    MAGNET,
    MULTIPLIER
}

class PowerUp(
    val type: PowerUpType,
    val lane: Int,
    val x: Float,
    val y: Float,
    val z: Float
) {
    var isCollected: Boolean = false

    fun checkCollision(playerX: Float, playerZ: Float, prevPlayerZ: Float): Boolean {
        if (isCollected) return false

        val minZ = minOf(playerZ, prevPlayerZ) - 1.8f
        val maxZ = maxOf(playerZ, prevPlayerZ) + 1.8f
        val inSweepZ = z in minZ..maxZ
        val inProximity = abs(z - playerZ) < 2.2f

        if ((inSweepZ || inProximity) && abs(x - playerX) < 1.8f) {
            isCollected = true
            return true
        }
        return false
    }
}
