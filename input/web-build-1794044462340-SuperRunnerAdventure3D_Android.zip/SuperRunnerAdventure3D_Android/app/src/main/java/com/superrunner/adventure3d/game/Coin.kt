package com.superrunner.adventure3d.game

import android.graphics.Color
import android.graphics.Paint
import kotlin.math.abs
import kotlin.math.sin

/**
 * Collectible Gold Coin with unified collision detection for BOTH stationary and moving coins.
 * Guarantees reliable pickup in all 3 lanes, running, jumping, and sliding without duplicate increments.
 */
class Coin(
    val lane: Int,
    var x: Float,
    var y: Float,
    var z: Float
) {
    var isCollected: Boolean = false
        private set

    var rotationAngle: Float = 0f
        private set
    val baseY: Float = y

    private val coinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD700")
        style = Paint.Style.FILL
    }

    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E6A100")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    fun update(dt: Float, time: Float) {
        if (isCollected) return
        rotationAngle += dt * 3.5f
        y = baseY + (sin(time * 3f + z) * 0.08f)
    }

    /**
     * Unified collision check that works 100% reliably for BOTH stationary and moving coins.
     * Sweeps the continuous volume between prevPlayerZ and playerZ, and verifies lane matching.
     */
    fun checkCollision(
        playerX: Float,
        playerY: Float,
        playerZ: Float,
        prevPlayerZ: Float,
        isSliding: Boolean,
        playerLane: Int = -1
    ): Boolean {
        if (isCollected) return false

        // 1. Continuous Z Sweep & Proximity check
        // Covers travel between ticks + generous proximity threshold
        val minZ = minOf(playerZ, prevPlayerZ) - 2.4f
        val maxZ = maxOf(playerZ, prevPlayerZ) + 2.4f
        val inZSweep = z in minZ..maxZ
        val inZProximity = abs(z - playerZ) < 2.4f

        if (!inZSweep && !inZProximity) return false

        // 2. Lane X Match:
        // Either exact lane index matches OR physical lateral distance is within pickup margin (1.8m)
        val laneMatches = (playerLane in 0..2 && lane == playerLane)
        val dx = abs(x - playerX)
        if (!laneMatches && dx > 1.8f) return false

        // 3. Vertical Y Match:
        // Covers normal running, jumping up to 2.6m, and low sliding
        val playerBottom = playerY - 0.2f
        val playerTop = playerY + (if (isSliding) GameConstants.PLAYER_SLIDE_HEIGHT else GameConstants.PLAYER_HEIGHT) + 0.6f
        val dy = abs(y - (playerY + 0.8f))

        if (dy < 2.8f || (y in playerBottom..playerTop)) {
            isCollected = true
            return true
        }

        return false
    }

    fun collect() {
        isCollected = true
    }
}
