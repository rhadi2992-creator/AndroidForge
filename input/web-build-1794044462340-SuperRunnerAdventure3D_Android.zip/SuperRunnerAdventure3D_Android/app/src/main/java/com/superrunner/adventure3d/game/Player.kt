package com.superrunner.adventure3d.game

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

enum class PlayerActionState {
    RUNNING,
    ROPE_SWINGING,
    FALLING_CHASM
}

class Player {
    var currentLane: Int = 1 // 0 = Left, 1 = Center, 2 = Right
    var x: Float = 0f
    var targetX: Float = 0f
    var y: Float = 0f
    var z: Float = 0f
    var prevZ: Float = 0f
    var velocityY: Float = 0f

    var actionState: PlayerActionState = PlayerActionState.RUNNING
    var isGrounded: Boolean = true
    var isSliding: Boolean = false
    var slideTimer: Float = 0f

    // Turning mechanics
    var headingYaw: Float = 0f
    var targetHeadingYaw: Float = 0f

    // Rope Swing mechanics
    var ropeAnchorX: Float = 0f
    var ropeAnchorY: Float = 8.5f
    var ropeAnchorZ: Float = 0f
    var ropeSwingTime: Float = 0f
    var ropeAngle: Float = 0f
    var ropeTargetLandingZ: Float = 0f

    var invulnerableTimer: Float = 0f
    var activeShield: Boolean = false
    var activeMagnet: Boolean = false
    var activeMultiplier: Boolean = false

    fun reset() {
        currentLane = 1
        x = GameConstants.LANE_X[currentLane]
        targetX = x
        y = 0f
        z = 0f
        prevZ = 0.5f
        velocityY = 0f
        actionState = PlayerActionState.RUNNING
        isGrounded = true
        isSliding = false
        slideTimer = 0f
        headingYaw = 0f
        targetHeadingYaw = 0f
        ropeSwingTime = 0f
        ropeAngle = 0f
        invulnerableTimer = 0f
        activeShield = false
        activeMagnet = false
        activeMultiplier = false
    }

    fun changeLane(direction: Int) {
        if (actionState != PlayerActionState.RUNNING) return
        val newLane = (currentLane + direction).coerceIn(0, 2)
        if (newLane != currentLane) {
            currentLane = newLane
            targetX = GameConstants.LANE_X[newLane]
        }
    }

    fun jump(): Boolean {
        if (actionState == PlayerActionState.ROPE_SWINGING) {
            // Releasing the rope during a swing to land on platform
            releaseRope()
            return true
        }

        if (actionState == PlayerActionState.RUNNING && isGrounded) {
            velocityY = GameConstants.JUMP_FORCE
            isGrounded = false
            isSliding = false
            slideTimer = 0f
            return true
        }
        return false
    }

    fun slide() {
        if (actionState != PlayerActionState.RUNNING) return
        if (isGrounded && !isSliding) {
            isSliding = true
            slideTimer = GameConstants.SLIDE_DURATION
        } else if (!isGrounded) {
            // Fast fall
            velocityY = -GameConstants.JUMP_FORCE * 1.3f
            isSliding = true
            slideTimer = GameConstants.SLIDE_DURATION
        }
    }

    fun turn(direction: Int) {
        // -1 = Turn Left (-90 degrees), +1 = Turn Right (+90 degrees)
        targetHeadingYaw += if (direction < 0) -90f else 90f
    }

    fun startRopeSwing(anchorX: Float, anchorY: Float, anchorZ: Float, landingZ: Float) {
        actionState = PlayerActionState.ROPE_SWINGING
        ropeAnchorX = anchorX
        ropeAnchorY = anchorY
        ropeAnchorZ = anchorZ
        ropeTargetLandingZ = landingZ
        ropeSwingTime = 0f
        isGrounded = false
        isSliding = false
        slideTimer = 0f
        velocityY = 0f
    }

    fun releaseRope() {
        if (actionState != PlayerActionState.ROPE_SWINGING) return
        actionState = PlayerActionState.RUNNING
        // Launch forward toward safe landing platform
        z = ropeTargetLandingZ + 1.0f
        y = 1.2f
        velocityY = 3.5f // small landing arch
        isGrounded = false
    }

    fun fallIntoChasm() {
        actionState = PlayerActionState.FALLING_CHASM
        isGrounded = false
        velocityY = -24f
    }

    fun update(dt: Float, forwardSpeed: Float) {
        prevZ = z

        // Smooth heading yaw rotation for turns
        val dyaw = targetHeadingYaw - headingYaw
        headingYaw += dyaw * (8f * dt).coerceAtMost(1f)

        when (actionState) {
            PlayerActionState.RUNNING -> {
                z -= forwardSpeed * dt

                // Smooth lane interpolation
                val dx = targetX - x
                x += dx * (GameConstants.LANE_SWITCH_SPEED * dt).coerceAtMost(1f)

                // Gravity & Jump physics
                if (!isGrounded) {
                    velocityY -= GameConstants.GRAVITY * dt
                    y += velocityY * dt
                    if (y <= 0f) {
                        y = 0f
                        velocityY = 0f
                        isGrounded = true
                    }
                }

                // Slide timer
                if (isSliding) {
                    slideTimer -= dt
                    if (slideTimer <= 0f) {
                        isSliding = false
                    }
                }
            }

            PlayerActionState.ROPE_SWINGING -> {
                ropeSwingTime += dt * 2.8f
                // Pendulum physics along Z axis
                val swingArc = 0.75f // ~43 degrees max swing
                ropeAngle = -swingArc * cos(ropeSwingTime)

                val ropeLength = 7.0f
                x = ropeAnchorX
                y = (ropeAnchorY - ropeLength * cos(ropeAngle)).coerceAtLeast(1.0f)
                z = ropeAnchorZ + ropeLength * sin(ropeAngle)

                // Auto release if full forward swing reached
                if (ropeSwingTime > 3.0f && ropeAngle > 0.3f) {
                    releaseRope()
                }
            }

            PlayerActionState.FALLING_CHASM -> {
                z -= forwardSpeed * 0.4f * dt
                velocityY -= GameConstants.GRAVITY * dt
                y += velocityY * dt
            }
        }

        // Invulnerability timer
        if (invulnerableTimer > 0f) {
            invulnerableTimer -= dt
        }
    }
}
