package com.superrunner.adventure3d.game

import android.content.Context
import android.graphics.*
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs

enum class GameState {
    MENU,
    PLAYING,
    PAUSED,
    GAME_OVER
}

class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    private var gameThread: Thread? = null
    private var isRunning = false

    var gameState: GameState = GameState.MENU
    val player = Player()
    val trackManager = TrackManager()

    var score = 0
    var coins = 0
    var highScore = 0
    var forwardSpeed = GameConstants.INITIAL_SPEED
    var hasRevivedThisRun = false

    // Callbacks to Activity
    var onShowReviveDialog: (() -> Unit)? = null
    var onGameOver: ((score: Int, coins: Int) -> Unit)? = null
    var onScoreUpdated: ((score: Int, coins: Int) -> Unit)? = null

    // Active Adventure Prompt Messages
    private var activeTurnPrompt: String? = null
    private var activeRopePrompt: String? = null
    private var activeGapPrompt: String? = null
    private var gameTime = 0f

    // Touch controls
    private var touchStartX = 0f
    private var touchStartY = 0f
    private val swipeThreshold = 35f

    // Rendering Paints
    private val skyPaint = Paint().apply { color = Color.parseColor("#3EA6A8") }
    private val groundPaint = Paint().apply { color = Color.parseColor("#1B4332") }
    private val trackPaint = Paint().apply { color = Color.parseColor("#3D352E") }
    private val chasmPaint = Paint().apply { color = Color.parseColor("#0D1A15") }
    private val bridgePaint = Paint().apply { color = Color.parseColor("#5A3E28") }
    private val laneLinePaint = Paint().apply {
        color = Color.parseColor("#8A7758")
        strokeWidth = 3f
    }
    private val playerPaint = Paint().apply { color = Color.parseColor("#2B580C") }
    private val shieldPaint = Paint().apply {
        color = Color.parseColor("#8000F0FF")
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }
    private val obstacleWoodPaint = Paint().apply { color = Color.parseColor("#75471F") }
    private val obstacleRockPaint = Paint().apply { color = Color.parseColor("#55504A") }
    private val ropePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8D6E42")
        strokeWidth = 7f
        style = Paint.Style.STROKE
    }
    private val coinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFD700") }
    private val coinRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E6A100")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 42f
        typeface = Typeface.DEFAULT_BOLD
    }
    private val promptBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#D9000000")
        style = Paint.Style.FILL
    }
    private val promptTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD700")
        textSize = 46f
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val turnArrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD700")
        style = Paint.Style.FILL
    }

    private val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private val prefs = context.getSharedPreferences("super_runner_prefs", Context.MODE_PRIVATE)

    init {
        holder.addCallback(this)
        highScore = prefs.getInt("high_score", 0)
    }

    fun startNewGame() {
        player.reset()
        trackManager.reset()
        score = 0
        coins = 0
        forwardSpeed = GameConstants.INITIAL_SPEED
        hasRevivedThisRun = false
        gameTime = 0f
        activeTurnPrompt = null
        activeRopePrompt = null
        activeGapPrompt = null
        gameState = GameState.PLAYING
    }

    fun revive() {
        hasRevivedThisRun = true
        player.invulnerableTimer = 3.5f
        player.isGrounded = true
        player.isSliding = false
        player.velocityY = 0f
        player.actionState = PlayerActionState.RUNNING

        // Clear immediate hazards ahead
        trackManager.clearAheadObstacles(player.z, 25f)
        gameState = GameState.PLAYING
    }

    fun declineRevive() {
        hasRevivedThisRun = true
        gameState = GameState.GAME_OVER
        if (score > highScore) {
            highScore = score
            prefs.edit().putInt("high_score", highScore).apply()
        }
        onGameOver?.invoke(score, coins)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        isRunning = true
        gameThread = Thread(this).apply { start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        isRunning = false
        try {
            gameThread?.join()
        } catch (_: InterruptedException) {}
        gameThread = null
    }

    override fun run() {
        var lastTime = System.nanoTime()

        while (isRunning) {
            val now = System.nanoTime()
            val dt = ((now - lastTime) / 1_000_000_000f).coerceAtMost(0.05f)
            lastTime = now

            if (gameState == GameState.PLAYING) {
                update(dt)
            }

            render()
        }
    }

    private fun update(dt: Float) {
        gameTime += dt

        // Forward acceleration
        val distance = abs(player.z)
        score = distance.toInt()
        forwardSpeed = (GameConstants.INITIAL_SPEED + (distance / 100f) * GameConstants.SPEED_ACCEL)
            .coerceAtMost(GameConstants.MAX_SPEED)

        player.update(dt, forwardSpeed)
        trackManager.update(player.z)

        // Reset frame action prompts
        activeTurnPrompt = null
        activeRopePrompt = null
        activeGapPrompt = null

        // Magnet attraction with continuous motion
        if (player.activeMagnet) {
            for (seg in trackManager.segments) {
                for (coin in seg.coins) {
                    if (!coin.isCollected && abs(coin.z - player.z) < 28f) {
                        coin.x += (player.x - coin.x) * (14f * dt).coerceAtMost(1f)
                        coin.y += ((player.y + 0.8f) - coin.y) * (14f * dt).coerceAtMost(1f)
                    }
                }
            }
        }

        // Animate all coins & obstacles
        for (seg in trackManager.segments) {
            for (coin in seg.coins) {
                coin.update(dt, gameTime)
            }
            for (obs in seg.obstacles) {
                obs.update(gameTime)
            }
        }

        // Check Adventure Segment Triggers: Turns, Ropes, and Chasm Gaps
        for (seg in trackManager.segments) {
            when (seg.type) {
                SegmentType.TURN_LEFT -> {
                    val distToTurn = seg.turnTriggerZ - player.z
                    if (distToTurn in -14f..16f && !seg.turnCompleted) {
                        activeTurnPrompt = "<<< SWIPE LEFT TO TURN <<<"
                        // If player runs off road past the turn window without turning
                        if (distToTurn < -10f) {
                            handleCrash()
                            return
                        }
                    }
                }

                SegmentType.TURN_RIGHT -> {
                    val distToTurn = seg.turnTriggerZ - player.z
                    if (distToTurn in -14f..16f && !seg.turnCompleted) {
                        activeTurnPrompt = ">>> SWIPE RIGHT TO TURN >>>"
                        if (distToTurn < -10f) {
                            handleCrash()
                            return
                        }
                    }
                }

                SegmentType.ROPE_SWING -> {
                    val distToRope = seg.ropeAnchorZ - player.z
                    if (distToRope in -4f..14f && player.actionState == PlayerActionState.RUNNING && !seg.ropeCleared) {
                        activeRopePrompt = "SWIPE UP TO GRAB ROPE!"
                    } else if (player.actionState == PlayerActionState.ROPE_SWINGING) {
                        activeRopePrompt = "TAP OR SWIPE TO LAND!"
                        seg.ropeCleared = true
                    }

                    // Fall into canyon if in gap without swinging or jumping
                    if (player.z in seg.gapEndZ..seg.gapStartZ) {
                        if (player.actionState == PlayerActionState.RUNNING && player.y <= 0.15f) {
                            player.fallIntoChasm()
                            handleCrash()
                            return
                        }
                    }
                }

                SegmentType.CHASM_GAP -> {
                    val distToGap = seg.gapStartZ - player.z
                    if (distToGap in 0f..18f) {
                        activeGapPrompt = "JUMP OVER CHASM!"
                    }

                    // Fall into gap if grounded or low inside broken bridge
                    if (player.z in seg.gapEndZ..seg.gapStartZ) {
                        if (player.y <= 0.15f) {
                            player.fallIntoChasm()
                            handleCrash()
                            return
                        }
                    }
                }

                else -> {}
            }
        }

        // 1. UNIFIED COIN COLLECTION (Works 100% for BOTH stationary and moving coins)
        for (seg in trackManager.segments) {
            val collectedThisFrame = mutableListOf<Coin>()
            for (coin in seg.coins) {
                if (coin.checkCollision(
                        player.x,
                        player.y,
                        player.z,
                        player.prevZ,
                        player.isSliding,
                        player.currentLane
                    )
                ) {
                    val multiplier = if (player.activeMultiplier) 2 else 1
                    coins += 1 * multiplier
                    triggerHaptic(20)
                    onScoreUpdated?.invoke(score, coins)
                    collectedThisFrame.add(coin)
                }
            }
            if (collectedThisFrame.isNotEmpty()) {
                seg.coins.removeAll(collectedThisFrame)
            }

            // 2. POWER-UP COLLECTION
            for (pu in seg.powerUps) {
                if (pu.checkCollision(player.x, player.z, player.prevZ)) {
                    when (pu.type) {
                        PowerUpType.SHIELD -> player.activeShield = true
                        PowerUpType.MAGNET -> player.activeMagnet = true
                        PowerUpType.MULTIPLIER -> player.activeMultiplier = true
                    }
                    triggerHaptic(50)
                }
            }

            // 3. OBSTACLE COLLISION
            if (player.invulnerableTimer <= 0f && player.actionState == PlayerActionState.RUNNING) {
                for (obs in seg.obstacles) {
                    if (obs.checkCollision(player.x, player.y, player.z, player.isSliding)) {
                        handleCrash()
                        return
                    }
                }
            }
        }
    }

    private fun handleCrash() {
        if (player.activeShield) {
            // Shield absorbs fatal crash
            player.activeShield = false
            player.invulnerableTimer = 2.5f
            player.actionState = PlayerActionState.RUNNING
            triggerHaptic(80)
            return
        }

        triggerHaptic(120)

        // Check Rewarded Revive Offer
        if (!hasRevivedThisRun) {
            gameState = GameState.PAUSED
            post { onShowReviveDialog?.invoke() }
        } else {
            gameState = GameState.GAME_OVER
            if (score > highScore) {
                highScore = score
                prefs.edit().putInt("high_score", highScore).apply()
            }
            post { onGameOver?.invoke(score, coins) }
        }
    }

    private fun triggerHaptic(durationMs: Long) {
        try {
            vibrator?.let {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    it.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    it.vibrate(durationMs)
                }
            }
        } catch (_: Exception) {}
    }

    private fun render() {
        val canvas = holder.lockCanvas() ?: return

        try {
            val w = width.toFloat()
            val h = height.toFloat()

            // 1. Sky & Ground
            canvas.drawRect(0f, 0f, w, h * 0.45f, skyPaint)
            canvas.drawRect(0f, h * 0.45f, w, h, groundPaint)

            // Smooth camera banking during turns
            val cameraRoll = (player.targetHeadingYaw - player.headingYaw) * 0.15f
            canvas.save()
            if (abs(cameraRoll) > 0.1f) {
                canvas.rotate(cameraRoll, w / 2f, h * 0.6f)
            }

            // 2. 3D Perspective Track
            val horizonY = h * 0.45f
            val trackBottomW = w * 0.7f
            val trackTopW = w * 0.15f
            val trackBottomLeft = (w - trackBottomW) / 2f
            val trackTopLeft = (w - trackTopW) / 2f

            val trackPath = Path().apply {
                moveTo(trackBottomLeft, h)
                lineTo(trackTopLeft, horizonY)
                lineTo(trackTopLeft + trackTopW, horizonY)
                lineTo(trackBottomLeft + trackBottomW, h)
                close()
            }
            canvas.drawPath(trackPath, trackPaint)

            // Lane Dividers
            val lane1Bottom = trackBottomLeft + trackBottomW / 3f
            val lane1Top = trackTopLeft + trackTopW / 3f
            val lane2Bottom = trackBottomLeft + 2 * trackBottomW / 3f
            val lane2Top = trackTopLeft + 2 * trackTopW / 3f

            canvas.drawLine(lane1Bottom, h, lane1Top, horizonY, laneLinePaint)
            canvas.drawLine(lane2Bottom, h, lane2Top, horizonY, laneLinePaint)

            // 3. Render Adventure Environment Features (Turns, Chasms, Bridges, Ropes)
            for (seg in trackManager.segments) {
                val relZ = seg.z - player.z

                when (seg.type) {
                    SegmentType.CHASM_GAP, SegmentType.ROPE_SWING -> {
                        // Render broken bridge canyon chasm
                        val gapStartRel = seg.gapStartZ - player.z
                        val gapEndRel = seg.gapEndZ - player.z
                        if (gapEndRel in -70f..5f) {
                            val startScreen = project3D(0f, 0f, gapStartRel, w, h, horizonY)
                            val endScreen = project3D(0f, 0f, gapEndRel, w, h, horizonY)
                            if (startScreen != null && endScreen != null) {
                                val chasmW = w * (0.15f + 0.55f * startScreen.scale)
                                canvas.drawRect(
                                    startScreen.x - chasmW / 2f,
                                    endScreen.y,
                                    startScreen.x + chasmW / 2f,
                                    startScreen.y,
                                    chasmPaint
                                )
                            }
                        }
                    }

                    SegmentType.TURN_LEFT, SegmentType.TURN_RIGHT -> {
                        // Render corner junction branching path
                        val turnRel = seg.turnTriggerZ - player.z
                        if (turnRel in -55f..5f) {
                            val screen = project3D(0f, 0f, turnRel, w, h, horizonY)
                            if (screen != null) {
                                val cornerW = w * (0.15f + 0.55f * screen.scale)
                                val isLeft = seg.type == SegmentType.TURN_LEFT
                                val arrowDir = if (isLeft) -1f else 1f

                                // Glowing direction chevron on pavement
                                canvas.drawCircle(
                                    screen.x + arrowDir * cornerW * 0.35f,
                                    screen.y - 12f * screen.scale,
                                    14f * screen.scale,
                                    turnArrowPaint
                                )
                            }
                        }
                    }

                    SegmentType.ELEVATED_BRIDGE -> {
                        // Render wooden bridge plank stripes
                        if (relZ in -60f..5f) {
                            val screen = project3D(0f, 0f, relZ, w, h, horizonY)
                            if (screen != null) {
                                val bw = w * (0.15f + 0.55f * screen.scale) * 0.95f
                                canvas.drawRect(screen.x - bw / 2f, screen.y - 4f, screen.x + bw / 2f, screen.y, bridgePaint)
                            }
                        }
                    }

                    else -> {}
                }

                // Render Hanging Rope in ROPE_SWING segments
                if (seg.type == SegmentType.ROPE_SWING) {
                    val ropeRel = seg.ropeAnchorZ - player.z
                    if (ropeRel in -60f..8f) {
                        val anchorScreen = project3D(0f, 8.5f, ropeRel, w, h, horizonY)
                        val bottomScreen = if (player.actionState == PlayerActionState.ROPE_SWINGING) {
                            project3D(player.x, player.y + 0.8f, player.z - player.z, w, h, horizonY)
                        } else {
                            project3D(0f, 2.0f, ropeRel, w, h, horizonY)
                        }
                        if (anchorScreen != null && bottomScreen != null) {
                            canvas.drawLine(anchorScreen.x, anchorScreen.y, bottomScreen.x, bottomScreen.y, ropePaint)
                            canvas.drawCircle(anchorScreen.x, anchorScreen.y, 8f, obstacleWoodPaint)
                        }
                    }
                }

                // 4. Render Coins (Kept visible all the way to +1.2m so stationary coins never pop out)
                for (coin in seg.coins) {
                    if (coin.isCollected) continue
                    val coinRelZ = coin.z - player.z
                    if (coinRelZ in -65f..1.2f) {
                        val screen = project3D(coin.x, coin.y, coinRelZ, w, h, horizonY)
                        if (screen != null) {
                            val r = (14f * screen.scale).coerceIn(3.5f, 20f)
                            canvas.drawCircle(screen.x, screen.y, r, coinPaint)
                            canvas.drawCircle(screen.x, screen.y, (r * 0.7f).coerceAtLeast(2f), coinRimPaint)
                        }
                    }
                }

                // 5. Render Obstacles
                for (obs in seg.obstacles) {
                    val obsRelZ = obs.z - player.z
                    if (obsRelZ in -60f..-0.5f) {
                        val screen = project3D(obs.x, obs.minY, obsRelZ, w, h, horizonY)
                        if (screen != null) {
                            val trackWAtZ = w * (0.15f + 0.55f * screen.scale)
                            val ow = (trackWAtZ / 3f) * 0.85f
                            val oh = 52f * screen.scale
                            val paint = when (obs.type) {
                                ObstacleType.ROCK_LANE -> obstacleRockPaint
                                ObstacleType.SWINGING_PENDULUM -> obstacleRockPaint
                                ObstacleType.BROKEN_PLANKS -> bridgePaint
                                else -> obstacleWoodPaint
                            }
                            canvas.drawRect(screen.x - ow / 2f, screen.y - oh, screen.x + ow / 2f, screen.y, paint)

                            // Render pendulum chain if swinging
                            if (obs.type == ObstacleType.SWINGING_PENDULUM) {
                                val topScreen = project3D(0f, 6.0f, obsRelZ, w, h, horizonY)
                                if (topScreen != null) {
                                    canvas.drawLine(topScreen.x, topScreen.y, screen.x, screen.y - oh, laneLinePaint)
                                }
                            }
                        }
                    }
                }
            }

            // 6. Render Runner Character
            val playerScreen = project3D(player.x, player.y, -4f, w, h, horizonY)
            if (playerScreen != null) {
                val playerTrackW = w * (0.15f + 0.55f * playerScreen.scale)
                val pw = (playerTrackW / 3f) * 0.65f
                val ph = if (player.isSliding) 30f else 65f

                val showPlayer = player.invulnerableTimer <= 0f || (System.currentTimeMillis() / 100) % 2 == 0L
                if (showPlayer) {
                    if (player.actionState == PlayerActionState.ROPE_SWINGING) {
                        // Character hanging from swinging rope
                        canvas.drawRoundRect(
                            playerScreen.x - pw / 2f,
                            playerScreen.y - ph,
                            playerScreen.x + pw / 2f,
                            playerScreen.y,
                            10f,
                            10f,
                            playerPaint
                        )
                        // Hands reaching up to rope
                        canvas.drawLine(playerScreen.x, playerScreen.y - ph, playerScreen.x, playerScreen.y - ph - 25f, ropePaint)
                    } else {
                        canvas.drawRoundRect(
                            playerScreen.x - pw / 2f,
                            playerScreen.y - ph,
                            playerScreen.x + pw / 2f,
                            playerScreen.y,
                            12f,
                            12f,
                            playerPaint
                        )
                    }

                    // Shield bubble aura
                    if (player.activeShield) {
                        canvas.drawCircle(playerScreen.x, playerScreen.y - ph / 2f, 45f, shieldPaint)
                    }
                }
            }

            canvas.restore()

            // 7. On-Screen Adventure Action Banners & Indicators
            val activePrompt = activeTurnPrompt ?: activeRopePrompt ?: activeGapPrompt
            if (activePrompt != null && gameState == GameState.PLAYING) {
                val bannerW = 600f
                val bannerH = 75f
                val bannerX = w / 2f
                val bannerY = h * 0.22f

                canvas.drawRoundRect(
                    bannerX - bannerW / 2f,
                    bannerY - bannerH / 2f,
                    bannerX + bannerW / 2f,
                    bannerY + bannerH / 2f,
                    16f,
                    16f,
                    promptBgPaint
                )

                // Pulsing text effect
                val pulseColor = when {
                    activeTurnPrompt != null -> Color.parseColor("#FFE600")
                    activeRopePrompt != null -> Color.parseColor("#00F0FF")
                    else -> Color.parseColor("#FF453A")
                }
                promptTextPaint.color = pulseColor
                canvas.drawText(activePrompt, bannerX, bannerY + 16f, promptTextPaint)
            }

            // 8. In-Game HUD overlay
            if (gameState == GameState.PLAYING) {
                canvas.drawText("Distance: ${score}m", 40f, 60f, textPaint)
                canvas.drawText("Coins: $coins", w - 240f, 60f, textPaint)
            } else if (gameState == GameState.MENU) {
                val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#FFD700")
                    textSize = 58f
                    typeface = Typeface.DEFAULT_BOLD
                    textAlign = Paint.Align.CENTER
                }
                canvas.drawText("SUPER RUNNER 3D", w / 2f, h * 0.35f, titlePaint)
                titlePaint.textSize = 28f
                titlePaint.color = Color.WHITE
                canvas.drawText("TAP ANYWHERE TO RUN", w / 2f, h * 0.5f, titlePaint)
                canvas.drawText("Best Record: ${highScore}m", w / 2f, h * 0.62f, titlePaint)
            }

        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    private data class ProjectedPoint(val x: Float, val y: Float, val scale: Float)

    private fun project3D(worldX: Float, worldY: Float, relZ: Float, screenW: Float, screenH: Float, horizonY: Float): ProjectedPoint? {
        val dist = abs(relZ)
        if (dist <= 0.05f) return null

        val fov = 18f
        val scale = fov / (fov + dist)
        val centerX = screenW / 2f

        // Mathematically exact 3-lane perspective projection
        val currentTrackW = screenW * (0.15f + 0.55f * scale)
        val laneSpacing = currentTrackW / 3f
        val normLane = (worldX / 2.6f).coerceIn(-1.3f, 1.3f)
        val projX = centerX + normLane * laneSpacing

        // Vertical projection on road surface plane with height offset
        val groundY = horizonY + scale * (screenH - horizonY)
        val projY = groundY - (worldY * scale * 55f)

        return ProjectedPoint(projX, projY, scale)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = event.x
                touchStartY = event.y
                if (gameState == GameState.MENU) {
                    startNewGame()
                } else if (player.actionState == PlayerActionState.ROPE_SWINGING) {
                    // Tap during rope swinging releases rope to land
                    player.releaseRope()
                    triggerHaptic(25)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - touchStartX
                val dy = event.y - touchStartY

                if (abs(dx) > abs(dy)) {
                    if (abs(dx) > swipeThreshold) {
                        // Check if in active turn junction window
                        var turnHandled = false
                        for (seg in trackManager.segments) {
                            if (seg.type in listOf(SegmentType.TURN_LEFT, SegmentType.TURN_RIGHT) && !seg.turnCompleted) {
                                val distToTurn = seg.turnTriggerZ - player.z
                                if (distToTurn in -12f..16f) {
                                    if (dx < 0 && seg.type == SegmentType.TURN_LEFT) {
                                        player.turn(-1)
                                        seg.turnCompleted = true
                                        triggerHaptic(35)
                                        turnHandled = true
                                        break
                                    } else if (dx > 0 && seg.type == SegmentType.TURN_RIGHT) {
                                        player.turn(1)
                                        seg.turnCompleted = true
                                        triggerHaptic(35)
                                        turnHandled = true
                                        break
                                    }
                                }
                            }
                        }

                        // Normal lane change if not executing a turn
                        if (!turnHandled) {
                            if (dx > 0) player.changeLane(1) else player.changeLane(-1)
                        }
                    }
                } else {
                    if (abs(dy) > swipeThreshold) {
                        if (dy < 0) {
                            // Swipe UP: Check Rope Grab or Jump
                            var ropeGrabbed = false
                            for (seg in trackManager.segments) {
                                if (seg.type == SegmentType.ROPE_SWING && player.actionState == PlayerActionState.RUNNING) {
                                    val distToRope = seg.ropeAnchorZ - player.z
                                    if (distToRope in -5f..8f) {
                                        player.startRopeSwing(0f, 8.5f, seg.ropeAnchorZ, seg.ropeLandingZ)
                                        triggerHaptic(40)
                                        ropeGrabbed = true
                                        break
                                    }
                                }
                            }

                            if (!ropeGrabbed) {
                                player.jump()
                            }
                        } else {
                            // Swipe DOWN: Slide
                            player.slide()
                        }
                    }
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
