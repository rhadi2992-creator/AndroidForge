package com.superrunner.adventure3d.game

object GameConstants {
    val LANE_X = floatArrayOf(-2.6f, 0.0f, 2.6f)
    const val LANE_SWITCH_SPEED = 14.0f
    const val INITIAL_SPEED = 16.0f
    const val MAX_SPEED = 32.0f
    const val SPEED_ACCEL = 0.15f
    const val JUMP_FORCE = 13.0f
    const val GRAVITY = 34.0f
    const val SLIDE_DURATION = 0.72f
    const val SEGMENT_LENGTH = 42.0f
    const val ACTIVE_SEGMENTS = 6
    const val PLAYER_WIDTH = 1.0f
    const val PLAYER_HEIGHT = 1.8f
    const val PLAYER_SLIDE_HEIGHT = 0.8f
    const val COIN_RADIUS = 0.5f
}
