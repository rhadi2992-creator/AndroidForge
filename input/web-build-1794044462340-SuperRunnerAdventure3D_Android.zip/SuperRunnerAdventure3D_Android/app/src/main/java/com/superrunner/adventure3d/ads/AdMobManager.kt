package com.superrunner.adventure3d.ads

import android.app.Activity
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.superrunner.adventure3d.R

class AdMobManager(private val activity: Activity) {

    private val TAG = "AdMobManager"
    private var adView: AdView? = null
    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false
    private var lastInterstitialShowTime = 0L
    private val INTERSTITIAL_COOLDOWN_MS = 60_000L

    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false
    private var currentNativeAd: NativeAd? = null

    init {
        loadInterstitial()
        loadRewardedAd()
    }

    fun setupBanner(container: ViewGroup) {
        if (adView != null) return

        val banner = AdView(activity).apply {
            adUnitId = AdConfig.bannerAdUnitId
            setAdSize(AdSize.BANNER)
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.d(TAG, "Banner loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Banner failed: ${error.message}")
                }
            }
        }

        container.removeAllViews()
        container.addView(banner)
        adView = banner
        banner.loadAd(AdRequest.Builder().build())
    }

    fun setBannerVisibility(visible: Boolean) {
        adView?.visibility = if (visible) View.VISIBLE else View.GONE
    }

    fun pauseBanner() { adView?.pause() }
    fun resumeBanner() { adView?.resume() }

    fun loadInterstitial() {
        if (interstitialAd != null || isInterstitialLoading) return
        isInterstitialLoading = true

        InterstitialAd.load(
            activity,
            AdConfig.interstitialAdUnitId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                }
            }
        )
    }

    fun showInterstitialIfAllowed(onComplete: () -> Unit) {
        val now = System.currentTimeMillis()
        if (interstitialAd != null && (now - lastInterstitialShowTime >= INTERSTITIAL_COOLDOWN_MS)) {
            lastInterstitialShowTime = now
            interstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitial()
                    onComplete()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    loadInterstitial()
                    onComplete()
                }
            }
            interstitialAd?.show(activity)
        } else {
            onComplete()
        }
    }

    fun loadRewardedAd() {
        if (rewardedAd != null || isRewardedLoading) return
        isRewardedLoading = true

        RewardedAd.load(
            activity,
            AdConfig.rewardedAdUnitId,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                }
            }
        )
    }

    fun showRewardedReviveAd(onRewardEarned: () -> Unit, onAdFailedOrClosedWithoutReward: () -> Unit) {
        val ad = rewardedAd
        if (ad == null) {
            loadRewardedAd()
            onAdFailedOrClosedWithoutReward()
            return
        }

        var rewardGranted = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                loadRewardedAd()
                if (!rewardGranted) onAdFailedOrClosedWithoutReward()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                rewardedAd = null
                loadRewardedAd()
                onAdFailedOrClosedWithoutReward()
            }
        }

        ad.show(activity) { _ ->
            rewardGranted = true
            onRewardEarned()
        }
    }

    fun loadNativeAd(container: ViewGroup) {
        val adLoader = AdLoader.Builder(activity, AdConfig.nativeAdvancedAdUnitId)
            .forNativeAd { nativeAd ->
                currentNativeAd?.destroy()
                currentNativeAd = nativeAd
                val adView = activity.layoutInflater.inflate(R.layout.layout_native_ad, null) as NativeAdView
                populateNativeAdView(nativeAd, adView)
                container.removeAllViews()
                container.addView(adView)
                container.visibility = View.VISIBLE
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    container.visibility = View.GONE
                }
            })
            .build()
        adLoader.loadAd(AdRequest.Builder().build())
    }

    private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
        adView.headlineView = adView.findViewById(R.id.ad_headline)
        adView.bodyView = adView.findViewById(R.id.ad_body)
        adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
        adView.iconView = adView.findViewById(R.id.ad_app_icon)
        adView.advertiserView = adView.findViewById(R.id.ad_advertiser)
        adView.mediaView = adView.findViewById(R.id.ad_media)

        (adView.headlineView as? TextView)?.text = nativeAd.headline
        (adView.bodyView as? TextView)?.text = nativeAd.body
        (adView.callToActionView as? Button)?.text = nativeAd.callToAction
        adView.setNativeAd(nativeAd)
    }

    fun destroy() {
        adView?.destroy()
        currentNativeAd?.destroy()
        interstitialAd = null
        rewardedAd = null
    }
}
