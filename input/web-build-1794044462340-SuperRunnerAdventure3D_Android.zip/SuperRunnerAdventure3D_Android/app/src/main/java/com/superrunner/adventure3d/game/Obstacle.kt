package com.superrunner.adventure3d.game

import kotlin.math.abs
import kotlin.math.sin

enum class ObstacleType {
    BARRIER_JUMP,       // Low wooden hurdle - requires jump
    ROCK_LANE,          // Giant boulder - requires lane change
    OVERHEAD_SLIDE,     // Overhead temple arch / fallen log - requires slide
    SWINGING_PENDULUM,  // Spiked stone pendulum swinging across lanes - requires timing
    BROKEN_PLANKS       // Jagged gap / broken planks on bridge - requires jump
}

class Obstacle(
    val type: ObstacleType,
    val lane: Int,
    var x: Float,
    val z: Float,
    val minY: Float,
    val maxY: Float,
    val width: Float = 1.8f
) {
    private val baseX: Float = x

    fun update(time: Float) {
        if (type == ObstacleType.SWINGING_PENDULUM) {
            // Swings smoothly across lanes (-2.6m to +2.6m)
            x = baseX + sin(time * 3.2f + z) * 2.2f
        }
    }

    fun checkCollision(
        playerX: Float,
        playerY: Float,
        playerZ: Float,
        isSliding: Boolean
    ): Boolean {
        // Z proximity
        val dz = abs(z - playerZ)
        if (dz > 1.35f) return false

        // Lane X overlap
        val halfW = width * 0.45f
        val playerLeft = playerX - (GameConstants.PLAYER_WIDTH / 2f)
        val playerRight = playerX + (GameConstants.PLAYER_WIDTH / 2f)
        val obsLeft = x - halfW
        val obsRight = x + halfW

        val overlapX = playerRight >= obsLeft && playerLeft <= obsRight
        if (!overlapX) return false

        // Y height check
        val playerBottom = playerY
        val playerTop = playerY + (if (isSliding) GameConstants.PLAYER_SLIDE_HEIGHT else GameConstants.PLAYER_HEIGHT)

        val overlapY = playerTop > minY && playerBottom < maxY
        return overlapY
    }
}
