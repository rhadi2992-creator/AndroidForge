package com.superrunner.adventure3d

import android.app.Application
import com.google.android.gms.ads.MobileAds
import com.superrunner.adventure3d.ads.AppOpenAdManager

class SuperRunnerApp : Application() {

    lateinit var appOpenAdManager: AppOpenAdManager
        private set

    override fun onCreate() {
        super.onCreate()
        MobileAds.initialize(this) {}
        appOpenAdManager = AppOpenAdManager(this)
        appOpenAdManager.loadAd()
    }
}
