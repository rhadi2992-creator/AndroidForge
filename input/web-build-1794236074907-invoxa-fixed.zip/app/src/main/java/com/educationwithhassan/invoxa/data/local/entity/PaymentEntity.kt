package com.educationwithhassan.invoxa.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey val id: String,
    val invoiceId: String,
    val receiptNumber: String? = null,
    val amount: Double,
    val paymentDate: String,
    val paymentMethod: String,
    val referenceNumber: String,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
