package com.educationwithhassan.invoxa.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.educationwithhassan.invoxa.data.local.entity.*
import com.educationwithhassan.invoxa.data.repository.InvoxaRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class InvoiceViewModel(private val repository: InvoxaRepository) : ViewModel() {

    val invoices: StateFlow<List<InvoiceEntity>> = repository.allInvoices.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val customers: StateFlow<List<CustomerEntity>> = repository.allCustomers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val products: StateFlow<List<ProductEntity>> = repository.allProducts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val receipts: StateFlow<List<ReceiptEntity>> = repository.allReceipts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val payments: StateFlow<List<PaymentEntity>> = repository.allPayments.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val businessProfile: StateFlow<BusinessProfileEntity?> = repository.businessProfile.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    fun saveInvoice(invoice: InvoiceEntity) = viewModelScope.launch {
        repository.insertInvoice(invoice)
    }

    fun deleteInvoice(id: String) = viewModelScope.launch {
        repository.deleteInvoice(id)
    }

    fun saveCustomer(customer: CustomerEntity) = viewModelScope.launch {
        repository.insertCustomer(customer)
    }

    fun deleteCustomer(id: String) = viewModelScope.launch {
        repository.deleteCustomer(id)
    }

    fun saveProduct(product: ProductEntity) = viewModelScope.launch {
        repository.insertProduct(product)
    }

    fun deleteProduct(id: String) = viewModelScope.launch {
        repository.deleteProduct(id)
    }

    fun saveReceipt(receipt: ReceiptEntity) = viewModelScope.launch {
        repository.insertReceipt(receipt)
    }

    fun savePayment(payment: PaymentEntity) = viewModelScope.launch {
        repository.insertPayment(payment)
    }

    fun saveProfile(profile: BusinessProfileEntity) = viewModelScope.launch {
        repository.saveProfile(profile)
    }

    companion object {
        fun provideFactory(repository: InvoxaRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return InvoiceViewModel(repository) as T
                }
            }
    }
}
