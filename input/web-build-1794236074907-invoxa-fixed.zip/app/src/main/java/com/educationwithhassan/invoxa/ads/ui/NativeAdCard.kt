package com.educationwithhassan.invoxa.ads.ui

import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.educationwithhassan.invoxa.R
import com.educationwithhassan.invoxa.ads.AdMobManager
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

/**
 * Material 3 styled Native Advanced Ad Card for Jetpack Compose.
 * Displays clear "Ad" attribution, AdChoices, registered assets, and clean lifecycle management.
 */
@Composable
fun NativeAdCard(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var nativeAdState by remember { mutableStateOf<NativeAd?>(null) }
    var isFailed by remember { mutableStateOf(false) }

    // Load Native Ad
    LaunchedEffect(Unit) {
        AdMobManager.loadNativeAd(
            context = context,
            onAdLoaded = { ad ->
                nativeAdState = ad
            },
            onAdFailed = {
                isFailed = true
            }
        )
    }

    // Clean up when leaving composition
    DisposableEffect(nativeAdState) {
        onDispose {
            nativeAdState?.destroy()
        }
    }

    if (nativeAdState != null && !isFailed) {
        AndroidView(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            factory = { ctx ->
                val inflater = LayoutInflater.from(ctx)
                val adView = inflater.inflate(R.layout.ad_native_card, null, false) as NativeAdView
                populateNativeAdView(nativeAdState!!, adView)
                adView
            },
            update = { adView ->
                nativeAdState?.let { ad ->
                    populateNativeAdView(ad, adView)
                }
            }
        )
    }
}

private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
    // 1. Headline
    val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
    headlineView.text = nativeAd.headline
    adView.headlineView = headlineView

    // 2. Body
    val bodyView = adView.findViewById<TextView>(R.id.ad_body)
    if (nativeAd.body != null) {
        bodyView.text = nativeAd.body
        bodyView.visibility = View.VISIBLE
    } else {
        bodyView.visibility = View.GONE
    }
    adView.bodyView = bodyView

    // 3. Call to Action
    val ctaView = adView.findViewById<Button>(R.id.ad_call_to_action)
    if (nativeAd.callToAction != null) {
        ctaView.text = nativeAd.callToAction
        ctaView.visibility = View.VISIBLE
    } else {
        ctaView.visibility = View.GONE
    }
    adView.callToActionView = ctaView

    // 4. Icon
    val iconView = adView.findViewById<ImageView>(R.id.ad_app_icon)
    if (nativeAd.icon != null && nativeAd.icon?.drawable != null) {
        iconView.setImageDrawable(nativeAd.icon?.drawable)
        iconView.visibility = View.VISIBLE
    } else {
        iconView.visibility = View.GONE
    }
    adView.iconView = iconView

    // 5. Advertiser
    val advertiserView = adView.findViewById<TextView>(R.id.ad_advertiser)
    if (nativeAd.advertiser != null) {
        advertiserView.text = nativeAd.advertiser
        advertiserView.visibility = View.VISIBLE
    } else {
        advertiserView.text = "Sponsored"
        advertiserView.visibility = View.VISIBLE
    }
    adView.advertiserView = advertiserView

    // 6. Media View
    val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
    if (nativeAd.mediaContent != null && nativeAd.mediaContent?.hasVideoContent() == true) {
        mediaView.mediaContent = nativeAd.mediaContent
        mediaView.visibility = View.VISIBLE
        adView.mediaView = mediaView
    } else {
        mediaView.visibility = View.GONE
    }

    // Set the native ad to complete registration
    adView.setNativeAd(nativeAd)
}
