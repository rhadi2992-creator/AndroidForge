package com.educationwithhassan.invoxa.pdf

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.educationwithhassan.invoxa.data.local.entity.ReceiptEntity
import com.educationwithhassan.invoxa.util.CurrencyFormatter
import java.io.File
import java.io.FileOutputStream

object PdfReceiptGenerator {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 36f

    fun generateReceiptPdf(context: Context, receipt: ReceiptEntity): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        // Header Background
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), 90f, headerPaint)

        // Header Text
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 22f
            isFakeBoldText = true
            color = Color.WHITE
        }
        canvas.drawText("PAYMENT RECEIPT", MARGIN, 55f, titlePaint)

        val subTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 10f
            color = Color.LTGRAY
        }
        canvas.drawText("Receipt #${receipt.receiptNumber}", MARGIN, 72f, subTitlePaint)

        var y = 140f
        val bodyBoldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12f
            isFakeBoldText = true
            color = Color.BLACK
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 10f
            color = Color.DKGRAY
        }

        canvas.drawText("Received From: ${receipt.customerName}", MARGIN, y, bodyBoldPaint)
        y += 20f
        canvas.drawText("Payment Date: ${receipt.paymentDate}", MARGIN, y, bodyPaint)
        y += 18f
        canvas.drawText("Payment Method: ${receipt.paymentMethod.uppercase()}", MARGIN, y, bodyPaint)
        y += 18f
        canvas.drawText("Transaction Reference: ${receipt.transactionReference}", MARGIN, y, bodyPaint)

        y += 35f
        val amountBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2563EB")
            style = Paint.Style.FILL
        }
        canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + 40f, amountBoxPaint)

        val amountTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 14f
            isFakeBoldText = true
            color = Color.WHITE
        }
        val formattedAmount = CurrencyFormatter.format(receipt.amountReceived, receipt.currencyCode)
        canvas.drawText("AMOUNT RECEIVED: $formattedAmount", MARGIN + 15f, y + 26f, amountTextPaint)

        document.finishPage(page)

        val outputDir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val outputFile = File(outputDir, "${receipt.receiptNumber}.pdf")
        FileOutputStream(outputFile).use { out ->
            document.writeTo(out)
        }
        document.close()
        return outputFile
    }
}
