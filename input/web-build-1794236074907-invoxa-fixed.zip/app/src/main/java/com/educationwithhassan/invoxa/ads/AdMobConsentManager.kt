package com.educationwithhassan.invoxa.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * Manages Google User Messaging Platform (UMP) consent flows for GDPR, CCPA & international compliance.
 */
object AdMobConsentManager {

    private const val TAG = "InvoxaConsent"

    fun requestConsentAndInitialize(
        activity: Activity,
        onConsentComplete: (canRequestAds: Boolean) -> Unit
    ) {
        val consentInformation: ConsentInformation = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()

        consentInformation.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    if (formError != null) {
                        Log.w(TAG, "Consent form error: ${formError.errorCode}: ${formError.message}")
                    }
                    val canRequest = consentInformation.canRequestAds()
                    Log.d(TAG, "Consent flow finished. canRequestAds=$canRequest")
                    onConsentComplete(canRequest)
                }
            },
            { requestConsentError ->
                Log.w(TAG, "Consent info update failed: ${requestConsentError.errorCode}: ${requestConsentError.message}")
                // If update fails, respect existing canRequestAds status (or fallback gracefully)
                val canRequest = consentInformation.canRequestAds()
                onConsentComplete(canRequest)
            }
        )
    }

    fun canRequestAds(context: Context): Boolean {
        return UserMessagingPlatform.getConsentInformation(context).canRequestAds()
    }
}
