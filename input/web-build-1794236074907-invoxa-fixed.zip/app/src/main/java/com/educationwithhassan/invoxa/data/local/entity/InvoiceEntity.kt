package com.educationwithhassan.invoxa.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey val id: String,
    val invoiceNumber: String,
    val invoiceDate: String,
    val dueDate: String,
    val currencyCode: String,
    val templateId: String,
    val status: String, // DRAFT, UNPAID, PARTIALLY_PAID, PAID, OVERDUE

    // Customer Snapshot
    val customerId: String,
    val customerName: String,
    val customerEmail: String,
    val customerPhone: String,
    val customerAddress: String,
    val customerCompanyName: String? = null,

    // Serialized Line Items
    val itemsJson: String,

    // Decimal-safe calculated financials
    val subtotal: Double,
    val totalDiscount: Double,
    val totalTax: Double,
    val grandTotal: Double,
    val amountPaid: Double,
    val remainingBalance: Double,

    val paymentTerms: String,
    val notes: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
