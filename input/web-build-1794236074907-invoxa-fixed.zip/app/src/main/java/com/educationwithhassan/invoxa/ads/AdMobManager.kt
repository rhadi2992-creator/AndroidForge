package com.educationwithhassan.invoxa.ads

import android.app.Activity
import android.content.Context
import android.util.DisplayMetrics
import android.util.Log
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback
import java.util.Date

/**
 * Centralized Google AdMob Manager for Invoxa – Invoice & Billing Maker.
 * Coordinates all 6 ad formats, UMP compliance, lifecycle management,
 * frequency capping, and financial workflow safety guards.
 */
object AdMobManager {

    private const val TAG = "InvoxaAdMob"

    var isInitialized: Boolean = false
        private set

    // Safety Gate: Suppresses full-screen ads during invoice creation, receipt generation or PDF sharing
    private var isWorkflowActive: Boolean = false

    // Tracks if any full-screen ad is currently visible
    var isShowingFullScreenAd: Boolean = false
        private set

    // Interstitial Ad State
    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading: Boolean = false
    private var lastInterstitialShownTime: Long = 0L

    // App Open Ad State
    private var appOpenAd: AppOpenAd? = null
    private var isAppOpenLoading: Boolean = false
    private var appOpenLoadTime: Long = 0L
    private var lastAppOpenShownTime: Long = 0L

    // Rewarded Ad State
    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading: Boolean = false

    // Rewarded Interstitial Ad State
    private var rewardedInterstitialAd: RewardedInterstitialAd? = null
    private var isRewardedInterstitialLoading: Boolean = false

    /**
     * Initializes Google Mobile Ads SDK and initiates background preloading.
     */
    fun initialize(context: Context, onComplete: () -> Unit = {}) {
        if (isInitialized) {
            onComplete()
            return
        }

        MobileAds.initialize(context) { status ->
            isInitialized = true
            Log.d(TAG, "AdMob SDK Initialized successfully. Status: ${status.adapterStatusMap}")
            preloadAllFormats(context)
            onComplete()
        }
    }

    /**
     * Sets whether a critical workflow (e.g. invoice creation, PDF export, payment) is active.
     */
    fun setWorkflowActive(active: Boolean) {
        isWorkflowActive = active
        Log.d(TAG, "Workflow active status changed to: $active")
    }

    fun isWorkflowActive(): Boolean = isWorkflowActive

    /**
     * Preloads all full-screen formats in the background.
     */
    fun preloadAllFormats(context: Context) {
        loadInterstitialAd(context)
        loadAppOpenAd(context)
        loadRewardedAd(context)
        loadRewardedInterstitialAd(context)
    }

    // =========================================================================
    // 1. BANNER ADS (Anchored Adaptive Banner)
    // =========================================================================

    /**
     * Calculates the anchored adaptive banner size based on current screen width.
     */
    fun getAdaptiveBannerSize(context: Context, widthDp: Int): AdSize {
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, widthDp)
    }

    // =========================================================================
    // 2. INTERSTITIAL ADS
    // =========================================================================

    fun loadInterstitialAd(context: Context) {
        if (isInterstitialLoading || interstitialAd != null) return
        isInterstitialLoading = true

        val request = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            AdMobConfig.INTERSTITIAL_AD_UNIT_ID,
            request,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    Log.d(TAG, "Interstitial Ad loaded.")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                    Log.w(TAG, "Interstitial Ad failed to load: ${error.message} (Code: ${error.code})")
                }
            }
        )
    }

    fun showInterstitial(
        activity: Activity,
        forceShow: Boolean = false,
        onDismiss: () -> Unit = {}
    ) {
        // Safety guard: Never show during active invoice creation, editing, or PDF operations
        if (isWorkflowActive && !forceShow) {
            Log.d(TAG, "Interstitial suppressed: workflow active.")
            onDismiss()
            return
        }

        // Frequency capping: Check minimum cooldown between interstitial ads
        val now = System.currentTimeMillis()
        val elapsedSeconds = (now - lastInterstitialShownTime) / 1000
        if (!forceShow && elapsedSeconds < AdMobConfig.INTERSTITIAL_MIN_INTERVAL_SECONDS) {
            Log.d(TAG, "Interstitial cooldown active ($elapsedSeconds / ${AdMobConfig.INTERSTITIAL_MIN_INTERVAL_SECONDS}s).")
            onDismiss()
            return
        }

        val ad = interstitialAd
        if (ad != null && !isShowingFullScreenAd) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    isShowingFullScreenAd = true
                    lastInterstitialShownTime = System.currentTimeMillis()
                }

                override fun onAdDismissedFullScreenContent() {
                    isShowingFullScreenAd = false
                    interstitialAd = null
                    loadInterstitialAd(activity)
                    onDismiss()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    isShowingFullScreenAd = false
                    interstitialAd = null
                    loadInterstitialAd(activity)
                    onDismiss()
                }
            }
            ad.show(activity)
        } else {
            // Ad not ready or another full-screen ad visible; proceed without interruption
            loadInterstitialAd(activity)
            onDismiss()
        }
    }

    // =========================================================================
    // 3. APP OPEN ADS
    // =========================================================================

    fun loadAppOpenAd(context: Context) {
        if (isAppOpenLoading || isAppOpenAdAvailable()) return
        isAppOpenLoading = true

        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            context,
            AdMobConfig.APP_OPEN_AD_UNIT_ID,
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    appOpenLoadTime = Date().time
                    isAppOpenLoading = false
                    Log.d(TAG, "App Open Ad loaded.")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    appOpenAd = null
                    isAppOpenLoading = false
                    Log.w(TAG, "App Open Ad failed to load: ${error.message} (Code: ${error.code})")
                }
            }
        )
    }

    private fun isAppOpenAdAvailable(): Boolean {
        val wasLoadedRecently = (Date().time - appOpenLoadTime) < (AdMobConfig.APP_OPEN_MAX_CACHE_HOURS * 3600 * 1000)
        return appOpenAd != null && wasLoadedRecently
    }

    fun showAppOpenAdIfAvailable(
        activity: Activity,
        onDismiss: () -> Unit = {}
    ) {
        // Do not interrupt active invoice/receipt workflows or if another full-screen ad is active
        if (isWorkflowActive || isShowingFullScreenAd) {
            Log.d(TAG, "App Open Ad suppressed: workflow active ($isWorkflowActive) or full-screen ad showing.")
            onDismiss()
            return
        }

        // Check session cooldown
        val now = System.currentTimeMillis()
        val elapsedSeconds = (now - lastAppOpenShownTime) / 1000
        if (elapsedSeconds < AdMobConfig.APP_OPEN_MIN_INTERVAL_SECONDS && lastAppOpenShownTime != 0L) {
            Log.d(TAG, "App Open Ad suppressed: cooldown ($elapsedSeconds / ${AdMobConfig.APP_OPEN_MIN_INTERVAL_SECONDS}s).")
            onDismiss()
            return
        }

        if (!isAppOpenAdAvailable()) {
            loadAppOpenAd(activity)
            onDismiss()
            return
        }

        val ad = appOpenAd ?: return
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                isShowingFullScreenAd = true
                lastAppOpenShownTime = System.currentTimeMillis()
            }

            override fun onAdDismissedFullScreenContent() {
                isShowingFullScreenAd = false
                appOpenAd = null
                loadAppOpenAd(activity)
                onDismiss()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                isShowingFullScreenAd = false
                appOpenAd = null
                loadAppOpenAd(activity)
                onDismiss()
            }
        }
        ad.show(activity)
    }

    // =========================================================================
    // 4. REWARDED ADS (Standard Rewarded)
    // =========================================================================

    fun loadRewardedAd(context: Context) {
        if (isRewardedLoading || rewardedAd != null) return
        isRewardedLoading = true

        val request = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            AdMobConfig.REWARDED_AD_UNIT_ID,
            request,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    Log.d(TAG, "Rewarded Ad loaded.")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                    Log.w(TAG, "Rewarded Ad failed to load: ${error.message} (Code: ${error.code})")
                }
            }
        )
    }

    fun isRewardedAdReady(): Boolean = rewardedAd != null

    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: (RewardItem) -> Unit,
        onDismiss: (rewardGranted: Boolean) -> Unit
    ) {
        val ad = rewardedAd
        if (ad != null && !isShowingFullScreenAd) {
            var rewardEarned = false

            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    isShowingFullScreenAd = true
                }

                override fun onAdDismissedFullScreenContent() {
                    isShowingFullScreenAd = false
                    rewardedAd = null
                    loadRewardedAd(activity)
                    onDismiss(rewardEarned)
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    isShowingFullScreenAd = false
                    rewardedAd = null
                    loadRewardedAd(activity)
                    onDismiss(false)
                }
            }

            // CRITICAL: Grant reward ONLY inside onUserEarnedRewardListener
            ad.show(activity) { rewardItem ->
                rewardEarned = true
                Log.d(TAG, "User earned reward: ${rewardItem.amount} ${rewardItem.type}")
                onRewardEarned(rewardItem)
            }
        } else {
            loadRewardedAd(activity)
            onDismiss(false)
        }
    }

    // =========================================================================
    // 5. REWARDED INTERSTITIAL ADS
    // =========================================================================

    fun loadRewardedInterstitialAd(context: Context) {
        if (isRewardedInterstitialLoading || rewardedInterstitialAd != null) return
        isRewardedInterstitialLoading = true

        val request = AdRequest.Builder().build()
        RewardedInterstitialAd.load(
            context,
            AdMobConfig.REWARDED_INTERSTITIAL_AD_UNIT_ID,
            request,
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    rewardedInterstitialAd = ad
                    isRewardedInterstitialLoading = false
                    Log.d(TAG, "Rewarded Interstitial Ad loaded.")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedInterstitialAd = null
                    isRewardedInterstitialLoading = false
                    Log.w(TAG, "Rewarded Interstitial Ad failed to load: ${error.message} (Code: ${error.code})")
                }
            }
        )
    }

    fun isRewardedInterstitialAdReady(): Boolean = rewardedInterstitialAd != null

    fun showRewardedInterstitialAd(
        activity: Activity,
        onRewardEarned: (RewardItem) -> Unit,
        onDismiss: (rewardGranted: Boolean) -> Unit
    ) {
        val ad = rewardedInterstitialAd
        if (ad != null && !isShowingFullScreenAd) {
            var rewardEarned = false

            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    isShowingFullScreenAd = true
                }

                override fun onAdDismissedFullScreenContent() {
                    isShowingFullScreenAd = false
                    rewardedInterstitialAd = null
                    loadRewardedInterstitialAd(activity)
                    onDismiss(rewardEarned)
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    isShowingFullScreenAd = false
                    rewardedInterstitialAd = null
                    loadRewardedInterstitialAd(activity)
                    onDismiss(false)
                }
            }

            // CRITICAL: Official reward callback
            ad.show(activity) { rewardItem ->
                rewardEarned = true
                Log.d(TAG, "User earned rewarded interstitial reward: ${rewardItem.amount} ${rewardItem.type}")
                onRewardEarned(rewardItem)
            }
        } else {
            loadRewardedInterstitialAd(activity)
            onDismiss(false)
        }
    }

    // =========================================================================
    // 6. NATIVE ADVANCED ADS
    // =========================================================================

    fun loadNativeAd(
        context: Context,
        onAdLoaded: (NativeAd) -> Unit,
        onAdFailed: (LoadAdError) -> Unit
    ) {
        val adLoader = AdLoader.Builder(context, AdMobConfig.NATIVE_ADVANCED_AD_UNIT_ID)
            .forNativeAd { nativeAd ->
                onAdLoaded(nativeAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Native Ad failed to load: ${error.message} (Code: ${error.code})")
                    onAdFailed(error)
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
                    .build()
            )
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }
}
