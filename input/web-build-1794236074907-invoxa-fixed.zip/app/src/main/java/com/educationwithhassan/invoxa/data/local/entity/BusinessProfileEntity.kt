package com.educationwithhassan.invoxa.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "business_profile")
data class BusinessProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val logoUrl: String? = null,
    val address: String,
    val phone: String,
    val email: String,
    val website: String,
    val taxNumber: String,
    val defaultCurrency: String,
    val defaultTemplate: String,
    val paymentInstructions: String,
    val defaultNotes: String
)
