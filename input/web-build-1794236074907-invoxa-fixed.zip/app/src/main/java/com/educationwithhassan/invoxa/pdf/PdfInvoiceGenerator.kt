package com.educationwithhassan.invoxa.pdf

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.educationwithhassan.invoxa.data.local.entity.InvoiceEntity
import com.educationwithhassan.invoxa.util.CurrencyFormatter
import java.io.File
import java.io.FileOutputStream

object PdfInvoiceGenerator {

    private const val PAGE_WIDTH = 595 // A4 pt width
    private const val PAGE_HEIGHT = 842 // A4 pt height
    private const val MARGIN = 36f

    fun generateInvoicePdf(context: Context, invoice: InvoiceEntity): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val primaryColorHex = getPrimaryColorForTemplate(invoice.templateId)
        val primaryColor = Color.parseColor(primaryColorHex)

        // Header Background Banner
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = primaryColor
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), 90f, headerPaint)

        // Header Text
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 24f
            isFakeBoldText = true
            color = Color.WHITE
        }
        canvas.drawText("INVOICE", MARGIN, 55f, titlePaint)

        val subTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 10f
            color = Color.WHITE
        }
        canvas.drawText("#${invoice.invoiceNumber}", MARGIN, 72f, subTitlePaint)

        // Billed To
        var y = 130f
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f
            isFakeBoldText = true
            color = Color.GRAY
        }
        canvas.drawText("BILLED TO:", MARGIN, y, labelPaint)
        canvas.drawText("INVOICE DETAILS:", PAGE_WIDTH - MARGIN - 120f, y, labelPaint)

        y += 18f
        val bodyBoldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12f
            isFakeBoldText = true
            color = Color.BLACK
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f
            color = Color.DKGRAY
        }

        canvas.drawText(invoice.customerName, MARGIN, y, bodyBoldPaint)
        canvas.drawText("Issue Date: ${invoice.invoiceDate}", PAGE_WIDTH - MARGIN - 120f, y, bodyPaint)

        y += 15f
        if (!invoice.customerCompanyName.isNullOrEmpty()) {
            canvas.drawText(invoice.customerCompanyName, MARGIN, y, bodyPaint)
        }
        canvas.drawText("Due Date: ${invoice.dueDate}", PAGE_WIDTH - MARGIN - 120f, y, bodyPaint)

        y += 15f
        canvas.drawText(invoice.customerEmail, MARGIN, y, bodyPaint)
        canvas.drawText("Currency: ${invoice.currencyCode}", PAGE_WIDTH - MARGIN - 120f, y, bodyPaint)

        // Itemized Table
        y += 35f
        canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + 24f, headerPaint)

        val tableHeaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 10f
            isFakeBoldText = true
            color = Color.WHITE
        }
        canvas.drawText("Description", MARGIN + 10f, y + 16f, tableHeaderPaint)
        canvas.drawText("Line Total", PAGE_WIDTH - MARGIN - 80f, y + 16f, tableHeaderPaint)

        y += 45f
        // Totals
        val totalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 14f
            isFakeBoldText = true
            color = Color.BLACK
        }
        val formattedGrandTotal = CurrencyFormatter.format(invoice.grandTotal, invoice.currencyCode)
        canvas.drawText("Grand Total: $formattedGrandTotal", PAGE_WIDTH - MARGIN - 180f, y, totalPaint)

        y += 20f
        val balancePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12f
            isFakeBoldText = true
            color = Color.parseColor("#2563EB")
        }
        val formattedBalance = CurrencyFormatter.format(invoice.remainingBalance, invoice.currencyCode)
        canvas.drawText("Balance Due: $formattedBalance", PAGE_WIDTH - MARGIN - 180f, y, balancePaint)

        // Footer
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8f
            color = Color.GRAY
        }
        canvas.drawText("Generated offline with Invoxa – Education With Hassan", MARGIN, PAGE_HEIGHT - 25f, footerPaint)

        document.finishPage(page)

        val outputDir = File(context.cacheDir, "invoices").apply { mkdirs() }
        val outputFile = File(outputDir, "${invoice.invoiceNumber}.pdf")
        FileOutputStream(outputFile).use { out ->
            document.writeTo(out)
        }
        document.close()
        return outputFile
    }

    private fun getPrimaryColorForTemplate(templateId: String): String {
        return when (templateId) {
            "modern_blue" -> "#2563EB"
            "minimal_white" -> "#0F172A"
            "corporate_navy" -> "#1E293B"
            "elegant_purple" -> "#7C3AED"
            "classic" -> "#334155"
            else -> "#2563EB"
        }
    }
}
