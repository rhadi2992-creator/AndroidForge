package com.educationwithhassan.invoxa.ads.ui

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.educationwithhassan.invoxa.ads.AdMobConfig
import com.educationwithhassan.invoxa.ads.AdMobManager
import com.google.android.gms.ads.*

/**
 * Reusable Anchored Adaptive Banner Ad Component for Jetpack Compose.
 * - Automatically recalculates optimal banner width for both Portrait and Landscape.
 * - Handles phone and tablet form factors seamlessly.
 * - Disposes and destroys AdView instances cleanly to prevent leaks.
 * - Gracefully hides container when ad fails or offline.
 */
@Composable
fun AdaptiveBannerAd(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp

    var isAdLoaded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        if (isAdLoaded) {
            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                thickness = 1.dp
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                modifier = Modifier.fillMaxWidth(),
                factory = { ctx ->
                    val adView = AdView(ctx).apply {
                        adUnitId = AdMobConfig.BANNER_AD_UNIT_ID
                        val adSize = AdMobManager.getAdaptiveBannerSize(ctx, screenWidthDp)
                        setAdSize(adSize)
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        adListener = object : AdListener() {
                            override fun onAdLoaded() {
                                isAdLoaded = true
                            }

                            override fun onAdFailedToLoad(error: LoadAdError) {
                                isAdLoaded = false
                            }
                        }
                        loadAd(AdRequest.Builder().build())
                    }
                    adView
                },
                update = { adView ->
                    val expectedSize = AdMobManager.getAdaptiveBannerSize(adView.context, screenWidthDp)
                    if (adView.adSize != expectedSize) {
                        adView.setAdSize(expectedSize)
                        adView.loadAd(AdRequest.Builder().build())
                    }
                }
            )
        }
    }
}
