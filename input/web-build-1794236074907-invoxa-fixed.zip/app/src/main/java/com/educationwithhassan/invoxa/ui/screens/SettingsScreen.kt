package com.educationwithhassan.invoxa.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.educationwithhassan.invoxa.ads.AdMobConfig
import com.educationwithhassan.invoxa.ads.AdMobConsentManager
import com.educationwithhassan.invoxa.ads.AdMobManager
import com.educationwithhassan.invoxa.ads.ui.AdaptiveBannerAd
import com.educationwithhassan.invoxa.ads.ui.RewardedIntroDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    navController: NavController,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    activity: Activity? = null
) {
    var showRewardedIntro by remember { mutableStateOf(false) }

    if (showRewardedIntro && activity != null) {
        RewardedIntroDialog(
            title = "Unlock Advanced Currencies",
            description = "Watch a brief sponsored video to unlock multi-currency conversion and automated tax profiles for your invoices.",
            onWatchAd = {
                showRewardedIntro = false
                AdMobManager.showRewardedInterstitialAd(
                    activity = activity,
                    onRewardEarned = { reward ->
                        Toast.makeText(
                            activity,
                            "Reward granted! Multi-currency & tax tools unlocked.",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    onDismiss = { rewarded ->
                        if (!rewarded) {
                            Toast.makeText(
                                activity,
                                "Ad closed without earning reward.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                )
            },
            onDismiss = {
                showRewardedIntro = false
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings & Monetization") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            AdaptiveBannerAd()
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Theme Card
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Dark Mode", fontWeight = FontWeight.Bold)
                        Text(
                            "Toggle dark / light appearance",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isDarkTheme,
                        onCheckedChange = { onToggleTheme() }
                    )
                }
            }

            // AdMob Configuration & Ad Formats Status
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Google AdMob Ad Units (Production)", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "• App ID: ${AdMobConfig.APP_ID}\n" +
                        "• Banner: ${AdMobConfig.BANNER_AD_UNIT_ID}\n" +
                        "• Interstitial: ${AdMobConfig.INTERSTITIAL_AD_UNIT_ID}\n" +
                        "• App Open: ${AdMobConfig.APP_OPEN_AD_UNIT_ID}\n" +
                        "• Native Advanced: ${AdMobConfig.NATIVE_ADVANCED_AD_UNIT_ID}\n" +
                        "• Rewarded: ${AdMobConfig.REWARDED_AD_UNIT_ID}\n" +
                        "• Rewarded Interstitial: ${AdMobConfig.REWARDED_INTERSTITIAL_AD_UNIT_ID}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = MaterialTheme.typography.labelSmall.lineHeight * 1.3
                    )
                }
            }

            // Interactive Monetization Triggers
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Interactive Ad Formats", fontWeight = FontWeight.Bold)
                    Text(
                        "Test real format loading, reward verification, and introductory dialogs:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // 1. Rewarded Ad
                    OutlinedButton(
                        onClick = {
                            if (activity != null) {
                                AdMobManager.showRewardedAd(
                                    activity = activity,
                                    onRewardEarned = { reward ->
                                        Toast.makeText(
                                            activity,
                                            "Reward Verified: ${reward.amount} ${reward.type}",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    },
                                    onDismiss = { rewarded ->
                                        if (!rewarded) {
                                            Toast.makeText(activity, "Rewarded Ad dismissed without reward", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Stars, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Test Rewarded Ad (ID: 5636660310)")
                    }

                    // 2. Rewarded Interstitial Ad (With Intro Dialog)
                    OutlinedButton(
                        onClick = {
                            showRewardedIntro = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CardGiftcard, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Test Rewarded Interstitial (With Intro Dialog)")
                    }

                    // 3. Interstitial Ad
                    OutlinedButton(
                        onClick = {
                            if (activity != null) {
                                AdMobManager.showInterstitial(activity, forceShow = true) {
                                    Toast.makeText(activity, "Interstitial transition completed", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Fullscreen, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Test Interstitial Transition (ID: 8123222854)")
                    }

                    // 4. Consent Management (UMP)
                    OutlinedButton(
                        onClick = {
                            if (activity != null) {
                                AdMobConsentManager.requestConsentAndInitialize(activity) { canRequest ->
                                    Toast.makeText(
                                        activity,
                                        "UMP Consent evaluated. canRequestAds=$canRequest",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PrivacyTip, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Re-evaluate Google UMP Consent")
                    }
                }
            }

            // About Brand Card
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("About Invoxa", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Developer: Education With Hassan", style = MaterialTheme.typography.bodyMedium)
                    Text("Package: com.educationwithhassan.invoxa", style = MaterialTheme.typography.labelSmall)
                    Text("Target SDK: 35 · Min SDK: 24 · Gradle 8.9", style = MaterialTheme.typography.labelSmall)
                    Text("Version: 1.0.0 (AdMob Production Release)", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
