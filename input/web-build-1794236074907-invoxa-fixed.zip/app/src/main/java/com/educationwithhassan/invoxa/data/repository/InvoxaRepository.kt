package com.educationwithhassan.invoxa.data.repository

import com.educationwithhassan.invoxa.data.local.dao.*
import com.educationwithhassan.invoxa.data.local.entity.*
import kotlinx.coroutines.flow.Flow

class InvoxaRepository(
    private val invoiceDao: InvoiceDao,
    private val customerDao: CustomerDao,
    private val productDao: ProductDao,
    private val receiptDao: ReceiptDao,
    private val paymentDao: PaymentDao,
    private val businessProfileDao: BusinessProfileDao
) {
    val allInvoices: Flow<List<InvoiceEntity>> = invoiceDao.getAllInvoices()
    val allCustomers: Flow<List<CustomerEntity>> = customerDao.getAllCustomers()
    val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()
    val allReceipts: Flow<List<ReceiptEntity>> = receiptDao.getAllReceipts()
    val allPayments: Flow<List<PaymentEntity>> = paymentDao.getAllPayments()
    val businessProfile: Flow<BusinessProfileEntity?> = businessProfileDao.getProfile()

    suspend fun insertInvoice(invoice: InvoiceEntity) = invoiceDao.insertInvoice(invoice)
    suspend fun updateInvoice(invoice: InvoiceEntity) = invoiceDao.updateInvoice(invoice)
    suspend fun deleteInvoice(id: String) = invoiceDao.deleteInvoiceById(id)

    suspend fun insertCustomer(customer: CustomerEntity) = customerDao.insertCustomer(customer)
    suspend fun deleteCustomer(id: String) = customerDao.deleteCustomerById(id)

    suspend fun insertProduct(product: ProductEntity) = productDao.insertProduct(product)
    suspend fun deleteProduct(id: String) = productDao.deleteProductById(id)

    suspend fun insertReceipt(receipt: ReceiptEntity) = receiptDao.insertReceipt(receipt)
    suspend fun insertPayment(payment: PaymentEntity) = paymentDao.insertPayment(payment)
    suspend fun saveProfile(profile: BusinessProfileEntity) = businessProfileDao.insertProfile(profile)
}
