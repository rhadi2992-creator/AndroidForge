package com.educationwithhassan.invoxa.ads

/**
 * Official Google AdMob Configuration for Invoxa – Invoice & Billing Maker
 * Package: com.educationwithhassan.invoxa
 * Developer: Education With Hassan
 */
object AdMobConfig {

    // Official Production IDs
    const val APP_ID = "ca-app-pub-3133971041724338~6730250139"
    const val BANNER_AD_UNIT_ID = "ca-app-pub-3133971041724338/2418315086"
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3133971041724338/8123222854"
    const val APP_OPEN_AD_UNIT_ID = "ca-app-pub-3133971041724338/3010496976"
    const val NATIVE_ADVANCED_AD_UNIT_ID = "ca-app-pub-3133971041724338/4852906736"
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-3133971041724338/5636660310"
    const val REWARDED_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3133971041724338/9791527749"

    // Official Google Test IDs (useful for debug environments & automated sanity tests)
    const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/9214589741"
    const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"
    const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"
    const val TEST_REWARDED_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/5354046379"

    // Configuration Settings
    const val APP_OPEN_MAX_CACHE_HOURS = 4L
    const val INTERSTITIAL_MIN_INTERVAL_SECONDS = 60L
    const val APP_OPEN_MIN_INTERVAL_SECONDS = 240L
}
