package com.educationwithhassan.invoxa.ui.theme

import androidx.compose.ui.graphics.Color

val DeepNavy = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val ElectricBlue = Color(0xFF2563EB)
val SubtlePurple = Color(0xFF7C3AED)
val OffWhite = Color(0xFFF8FAFC)
val LightSlate = Color(0xFFF1F5F9)
val TextDark = Color(0xFF0F172A)
val TextMuted = Color(0xFF64748B)
val TextLight = Color(0xFFF8FAFC)
