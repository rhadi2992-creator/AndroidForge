package com.educationwithhassan.invoxa

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import com.educationwithhassan.invoxa.ads.AdMobManager
import com.educationwithhassan.invoxa.data.local.InvoxaDatabase
import com.educationwithhassan.invoxa.data.repository.InvoxaRepository

class InvoxaApp : Application(), Application.ActivityLifecycleCallbacks {

    private val TAG = "InvoxaApp"
    private var currentActivity: Activity? = null
    private var activityReferences = 0
    private var isActivityChangingConfigurations = false

    val database: InvoxaDatabase by lazy { InvoxaDatabase.getDatabase(this) }
    val repository: InvoxaRepository by lazy {
        InvoxaRepository(
            invoiceDao = database.invoiceDao(),
            customerDao = database.customerDao(),
            productDao = database.productDao(),
            receiptDao = database.receiptDao(),
            paymentDao = database.paymentDao(),
            businessProfileDao = database.businessProfileDao()
        )
    }

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(this)
        // Initialize AdMob
        AdMobManager.initialize(this)
    }

    fun getCurrentActivity(): Activity? = currentActivity

    // Activity Lifecycle Callbacks for App Open Ads & Activity Context Tracking
    override fun onActivityStarted(activity: Activity) {
        currentActivity = activity
        if (++activityReferences == 1 && !isActivityChangingConfigurations) {
            // App entered foreground
            Log.d(TAG, "App foregrounded, checking App Open Ad eligibility.")
            AdMobManager.showAppOpenAdIfAvailable(activity)
        }
    }

    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity
    }

    override fun onActivityPaused(activity: Activity) {}

    override fun onActivityStopped(activity: Activity) {
        isActivityChangingConfigurations = activity.isChangingConfigurations
        --activityReferences
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}

    override fun onActivityDestroyed(activity: Activity) {
        if (currentActivity == activity) {
            currentActivity = null
        }
    }
}
