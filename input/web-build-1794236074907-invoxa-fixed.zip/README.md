# Invoxa – Native Android Project Source
Package: `com.educationwithhassan.invoxa`
Developer Brand: Education With Hassan

This folder contains the complete native Android project using Kotlin, Jetpack Compose, Material 3, Room Database, Android PdfDocument, and Google AdMob SDK.

To build the APK:
1. Open this folder in Android Studio
2. Run `./gradlew assembleDebug` or build APK from Build menu.
Alternatively, use the in-app "Download Android Project (.ZIP)" button to download the entire package in 1 click!
