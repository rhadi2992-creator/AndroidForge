package com.educationwithhassan.invoxa.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "receipts")
data class ReceiptEntity(
    @PrimaryKey val id: String,
    val receiptNumber: String,
    val invoiceId: String?,
    val invoiceNumber: String?,
    val businessName: String,
    val customerName: String,
    val paymentDate: String,
    val paymentMethod: String,
    val amountReceived: Double,
    val currencyCode: String,
    val transactionReference: String,
    val notes: String,
    val createdAt: Long = System.currentTimeMillis()
)
