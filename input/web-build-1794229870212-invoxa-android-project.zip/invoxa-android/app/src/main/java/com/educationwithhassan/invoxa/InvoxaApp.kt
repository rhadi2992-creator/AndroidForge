package com.educationwithhassan.invoxa

import android.app.Application
import com.educationwithhassan.invoxa.ads.AdMobManager
import com.educationwithhassan.invoxa.data.local.InvoxaDatabase
import com.educationwithhassan.invoxa.data.repository.InvoxaRepository

class InvoxaApp : Application() {

    val database by lazy { InvoxaDatabase.getDatabase(this) }
    val repository by lazy {
        InvoxaRepository(
            invoiceDao = database.invoiceDao(),
            customerDao = database.customerDao(),
            productDao = database.productDao(),
            receiptDao = database.receiptDao(),
            paymentDao = database.paymentDao(),
            businessProfileDao = database.businessProfileDao()
        )
    }

    override fun onCreate() {
        super.onCreate()
        // Initialize AdMob SDK safely without blocking main thread
        AdMobManager.initialize(this)
    }
}
