package com.educationwithhassan.invoxa.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val companyName: String? = null,
    val email: String,
    val phone: String,
    val address: String,
    val createdAt: Long = System.currentTimeMillis()
)
