package com.educationwithhassan.invoxa.util

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object CurrencyFormatter {

    fun format(amount: Double, currencyCode: String): String {
        val decimals = getDecimalsForCurrency(currencyCode)
        val symbol = getSymbolForCurrency(currencyCode)

        val bigDecimal = BigDecimal(amount.toString()).setScale(decimals, RoundingMode.HALF_UP)
        val formatSymbols = DecimalFormatSymbols(Locale.US)
        
        val pattern = when (decimals) {
            0 -> "#,##0"
            3 -> "#,##0.000"
            else -> "#,##0.00"
        }

        val formatter = DecimalFormat(pattern, formatSymbols)
        return "$symbol ${formatter.format(bigDecimal)}"
    }

    fun getDecimalsForCurrency(code: String): Int {
        return when (code.uppercase()) {
            "JPY", "KRW", "IDR", "VND", "CLF" -> 0
            "KWD", "BHD", "OMR", "JOD", "TND", "IQD", "LYD" -> 3
            else -> 2
        }
    }

    fun getSymbolForCurrency(code: String): String {
        return when (code.uppercase()) {
            "USD" -> "$"
            "EUR" -> "€"
            "GBP" -> "£"
            "PKR" -> "Rs"
            "AED" -> "AED"
            "SAR" -> "SAR"
            "INR" -> "₹"
            "JPY" -> "¥"
            "CNY" -> "¥"
            "CAD" -> "CA$"
            "AUD" -> "A$"
            "KWD" -> "KD"
            "BHD" -> "BD"
            "OMR" -> "OMR"
            else -> code
        }
    }
}
