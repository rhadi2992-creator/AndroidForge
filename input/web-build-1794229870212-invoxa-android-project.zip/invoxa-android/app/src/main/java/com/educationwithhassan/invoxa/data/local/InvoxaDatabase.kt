package com.educationwithhassan.invoxa.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.educationwithhassan.invoxa.data.local.dao.*
import com.educationwithhassan.invoxa.data.local.entity.*

@Database(
    entities = [
        InvoiceEntity::class,
        CustomerEntity::class,
        ProductEntity::class,
        ReceiptEntity::class,
        PaymentEntity::class,
        BusinessProfileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class InvoxaDatabase : RoomDatabase() {

    abstract fun invoiceDao(): InvoiceDao
    abstract fun customerDao(): CustomerDao
    abstract fun productDao(): ProductDao
    abstract fun receiptDao(): ReceiptDao
    abstract fun paymentDao(): PaymentDao
    abstract fun businessProfileDao(): BusinessProfileDao

    companion object {
        @Volatile
        private var INSTANCE: InvoxaDatabase? = null

        fun getDatabase(context: Context): InvoxaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    InvoxaDatabase::class.java,
                    "invoxa_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
