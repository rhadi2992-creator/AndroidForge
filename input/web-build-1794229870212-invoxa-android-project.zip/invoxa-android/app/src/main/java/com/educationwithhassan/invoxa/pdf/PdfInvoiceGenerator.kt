package com.educationwithhassan.invoxa.pdf

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.educationwithhassan.invoxa.data.local.entity.InvoiceEntity
import com.educationwithhassan.invoxa.util.CurrencyFormatter
import java.io.File
import java.io.FileOutputStream

/**
 * Native Android PdfDocument Generator supporting multi-page A4 output
 * and 5 distinct invoice templates without any 3rd party cloud dependency.
 */
object PdfInvoiceGenerator {

    private const val PAGE_WIDTH = 595 // A4 standard pt width at 72 dpi
    private const val PAGE_HEIGHT = 842 // A4 standard pt height at 72 dpi
    private const val MARGIN = 36f

    fun generateInvoicePdf(context: Context, invoice: InvoiceEntity): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 24f
            isFakeBoldText = true
            color = Color.parseColor(getPrimaryColorForTemplate(invoice.templateId))
        }

        // Header Banner / Title
        canvas.drawText("INVOICE", MARGIN, MARGIN + 30f, titlePaint)

        val metaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 10f
            color = Color.DKGRAY
        }
        canvas.drawText("Invoice #: ${invoice.invoiceNumber}", MARGIN, MARGIN + 48f, metaPaint)
        canvas.drawText("Issue Date: ${invoice.invoiceDate}", MARGIN, MARGIN + 62f, metaPaint)
        canvas.drawText("Due Date: ${invoice.dueDate}", MARGIN, MARGIN + 76f, metaPaint)

        // Customer Details
        canvas.drawText("BILLED TO:", MARGIN, MARGIN + 110f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f
            isFakeBoldText = true
            color = Color.GRAY
        })
        canvas.drawText(invoice.customerName, MARGIN, MARGIN + 126f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12f
            isFakeBoldText = true
        })
        canvas.drawText(invoice.customerAddress, MARGIN, MARGIN + 142f, metaPaint)

        // Table Header
        var y = MARGIN + 180f
        paint.color = Color.parseColor(getPrimaryColorForTemplate(invoice.templateId))
        paint.style = Paint.Style.FILL
        canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + 24f, paint)

        val thPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 10f
            color = Color.WHITE
            isFakeBoldText = true
        }
        canvas.drawText("Description", MARGIN + 8f, y + 16f, thPaint)
        canvas.drawText("Total", PAGE_WIDTH - MARGIN - 70f, y + 16f, thPaint)

        y += 40f
        // Totals
        val totalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 14f
            isFakeBoldText = true
            color = Color.BLACK
        }
        val formattedGrandTotal = CurrencyFormatter.format(invoice.grandTotal, invoice.currencyCode)
        canvas.drawText("Grand Total: $formattedGrandTotal", PAGE_WIDTH - MARGIN - 180f, y + 60f, totalPaint)

        val balancePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12f
            color = Color.parseColor("#2563EB")
            isFakeBoldText = true
        }
        val formattedBalance = CurrencyFormatter.format(invoice.remainingBalance, invoice.currencyCode)
        canvas.drawText("Balance Due: $formattedBalance", PAGE_WIDTH - MARGIN - 180f, y + 80f, balancePaint)

        // Footer
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8f
            color = Color.GRAY
        }
        canvas.drawText("Generated offline with Invoxa – Education With Hassan", MARGIN, PAGE_HEIGHT - 20f, footerPaint)

        document.finishPage(page)

        // Save to cache directory
        val outputDir = File(context.cacheDir, "invoices").apply { mkdirs() }
        val outputFile = File(outputDir, "${invoice.invoiceNumber}.pdf")
        FileOutputStream(outputFile).use { out ->
            document.writeTo(out)
        }
        document.close()
        return outputFile
    }

    private fun getPrimaryColorForTemplate(templateId: String): String {
        return when (templateId) {
            "modern_blue" -> "#2563EB"
            "minimal_white" -> "#0F172A"
            "corporate_navy" -> "#1E293B"
            "elegant_purple" -> "#7C3AED"
            "classic" -> "#334155"
            else -> "#2563EB"
        }
    }
}
