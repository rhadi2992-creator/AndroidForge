package com.educationwithhassan.invoxa.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val unitPrice: Double,
    val taxRate: Double,
    val isService: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
