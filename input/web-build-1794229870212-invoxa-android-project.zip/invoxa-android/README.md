# Invoxa – Invoice & Billing Maker
Official Android Project Architecture & APK Build Guide

Developer Brand: **Education With Hassan**
Package Name: `com.educationwithhassan.invoxa`
Architecture: **Kotlin, Jetpack Compose, Material 3, Room Database, Android PdfDocument, AdMob**

---

## 🚀 Building APK from this Project

### Method 1: Android Studio (Recommended)
1. Unzip the project folder.
2. Open **Android Studio** (Ladybug / Koala or newer).
3. Select **File -> Open** and choose the unzipped folder.
4. Let Gradle sync dependencies automatically.
5. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
6. Find the generated APK in `app/build/outputs/apk/debug/app-debug.apk`.

### Method 2: Command Line (Linux / macOS / Windows)
```bash
# Clean and compile debug APK
./gradlew clean
./gradlew assembleDebug

# For release APK (signed):
./gradlew assembleRelease
```

### Method 3: Online ZIP-to-APK Builders
This repository has been structured strictly according to standard Gradle and Android directory conventions. Simply compress this entire folder into a `.zip` and upload to any Android cloud build service.

---

## 🔒 Offline & Security Guarantees
- 100% offline-first: Invoices, customers, receipts, and payments are stored in a local Room SQLite database.
- Zero mandatory cloud account: Users can start generating invoices immediately.
- AdMob uses official Google Test Unit IDs in debug configurations to safeguard your account against policy flags.
