# Study Planner & Focus Timer
### Developer: Education With Hassan
**Package Name**: `com.educationwithhassan.studyplanner`
**Version**: 1.0.0 (VersionCode: 1)
**Category**: Education / Productivity
**Tagline**: *Plan Smarter. Focus Deeper. Achieve More.*

---

## 📱 Project Overview
A complete, production-grade native Android application built with **Kotlin**, **Jetpack Compose**, **Material 3**, **Room Database**, **DataStore Preferences**, and official **Google Mobile Ads (AdMob) SDK** with real implementation of all 5 advertisement formats.

## 🌟 Key Features
- **Home Dashboard**: Live study progress, pending/completed task counters, streaks, and quick start shortcuts.
- **Study Planner**: Full task scheduling, priorities (Low, Medium, High), subject assignments, date/time pickers.
- **Pomodoro Focus Timer**: Monotonic foreground service with high-precision countdown unaffected by screen off, doze mode, or background lifecycle.
- **Offline Notes**: Fast, searchable note system organized by subjects with pinning.
- **Analytics & Statistics**: Real statistics computed from local Room records (daily, weekly, total hours).
- **5 Integrated Google AdMob Formats**:
  1. **Banner Ad**: Adaptive banner at dashboard bottom.
  2. **Native Ad**: Native card registered with headline, body, icon, and CTA.
  3. **Interstitial Ad**: Smooth transitions with 3-minute cooldown.
  4. **Rewarded Ad**: Unlocks bonus themes & productivity badges.
  5. **App Open Ad**: Preloaded foreground ad with 4-hour freshness check.
- **AdMob Frequency Manager**: Never interrupts active focus timer sessions.
- **Google UMP SDK**: Full GDPR / US state privacy consent flow.

---

## 🛠 AdMob Identifiers (Exact)
- **Publisher ID**: `pub-3133971041724338`
- **Application ID**: `ca-app-pub-3133971041724338~9508605101`
- **Banner Ad Unit ID**: `ca-app-pub-3133971041724338/3291068151`
- **Interstitial Ad Unit ID**: `ca-app-pub-3133971041724338/6359697585`
- **Native Ad Unit ID**: `ca-app-pub-3133971041724338/3246449084`
- **Rewarded Ad Unit ID**: `ca-app-pub-3133971041724338/1977986486`
- **App Open Ad Unit ID**: `ca-app-pub-3133971041724338/1630115083`

---

## 🚀 Build Instructions

### Prerequisites
- Android Studio Iguana / Jellyfish or newer
- JDK 17
- Android SDK 34

### Building Debug APK
```bash
./gradlew assembleDebug
```
*Outputs*: `app/build/outputs/apk/debug/app-debug.apk` (uses Google Test Ad IDs to prevent invalid traffic during testing).

### Building Release APK
```bash
./gradlew assembleRelease
```
*Outputs*: `app/build/outputs/apk/release/app-release-unsigned.apk` (uses exact production AdMob IDs).

### AndroidForge / Cloud ZIP-to-APK
This directory contains all required Gradle wrapper files (`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`), plugins, and dependencies. Upload directly to AndroidForge or any standard Gradle CI runner.
