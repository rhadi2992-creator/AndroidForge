package com.educationwithhassan.studyplanner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.educationwithhassan.studyplanner.ads.UmpConsentManager
import com.educationwithhassan.studyplanner.ui.navigation.AppNavigation
import com.educationwithhassan.studyplanner.ui.theme.StudyPlannerTheme

class MainActivity : ComponentActivity() {

    private lateinit var umpConsentManager: UmpConsentManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as StudyPlannerApp

        // Initialize Google UMP Consent
        umpConsentManager = UmpConsentManager(this)
        umpConsentManager.gatherConsent { canRequestAds ->
            if (canRequestAds) {
                // Preload App Open Ad and Interstitial
                app.appOpenAdManager.loadAd()
            }
        }

        setContent {
            val appThemeMode by app.settingsDataStore.themePreferenceFlow.collectAsState(initial = "SYSTEM")
            val darkTheme = when (appThemeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            StudyPlannerTheme(darkTheme = darkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation(app = app)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val app = application as StudyPlannerApp
        // Show App Open Ad when foregrounding, if permissible by AdFrequencyManager
        app.appOpenAdManager.showAdIfAvailable(this)
    }
}
