package com.educationwithhassan.studyplanner.ads

import com.educationwithhassan.studyplanner.BuildConfig

/**
 * Centralized AdMob Configuration.
 * Brand: Education With Hassan
 * Package: com.educationwithhassan.studyplanner
 *
 * ALL IDENTIFIERS ARE EXACTLY CONFIGURED AS SPECIFIED:
 * - PUBLISHER ID: pub-3133971041724338
 * - APP ID: ca-app-pub-3133971041724338~9508605101
 * - BANNER: ca-app-pub-3133971041724338/3291068151
 * - INTERSTITIAL: ca-app-pub-3133971041724338/6359697585
 * - NATIVE: ca-app-pub-3133971041724338/3246449084
 * - REWARDED: ca-app-pub-3133971041724338/1977986486
 * - APP OPEN: ca-app-pub-3133971041724338/1630115083
 */
object AdMobConfig {

    const val PUBLISHER_ID = "pub-3133971041724338"

    // Exact Production IDs
    private const val PROD_APP_ID = "ca-app-pub-3133971041724338~9508605101"
    private const val PROD_BANNER_AD_UNIT_ID = "ca-app-pub-3133971041724338/3291068151"
    private const val PROD_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3133971041724338/6359697585"
    private const val PROD_NATIVE_AD_UNIT_ID = "ca-app-pub-3133971041724338/3246449084"
    private const val PROD_REWARDED_AD_UNIT_ID = "ca-app-pub-3133971041724338/1977986486"
    private const val PROD_APP_OPEN_AD_UNIT_ID = "ca-app-pub-3133971041724338/1630115083"

    // Official Google Test IDs (prevents policy violations during development/QA)
    private const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    private const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
    private const val TEST_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
    private const val TEST_NATIVE_AD_UNIT_ID = "ca-app-pub-3940256099942544/2247696110"
    private const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
    private const val TEST_APP_OPEN_AD_UNIT_ID = "ca-app-pub-3940256099942544/9257399558"

    val isProduction: Boolean
        get() = BuildConfig.USE_PRODUCTION_ADS

    val appId: String
        get() = if (isProduction) PROD_APP_ID else TEST_APP_ID

    val bannerAdUnitId: String
        get() = if (isProduction) PROD_BANNER_AD_UNIT_ID else TEST_BANNER_AD_UNIT_ID

    val interstitialAdUnitId: String
        get() = if (isProduction) PROD_INTERSTITIAL_AD_UNIT_ID else TEST_INTERSTITIAL_AD_UNIT_ID

    val nativeAdUnitId: String
        get() = if (isProduction) PROD_NATIVE_AD_UNIT_ID else TEST_NATIVE_AD_UNIT_ID

    val rewardedAdUnitId: String
        get() = if (isProduction) PROD_REWARDED_AD_UNIT_ID else TEST_REWARDED_AD_UNIT_ID

    val appOpenAdUnitId: String
        get() = if (isProduction) PROD_APP_OPEN_AD_UNIT_ID else TEST_APP_OPEN_AD_UNIT_ID
}
