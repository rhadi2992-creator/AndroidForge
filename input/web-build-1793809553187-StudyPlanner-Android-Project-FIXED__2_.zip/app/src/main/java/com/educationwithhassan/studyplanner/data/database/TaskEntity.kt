package com.educationwithhassan.studyplanner.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val subjectId: Long,
    val subjectName: String,
    val dueDate: Long, // timestamp ms
    val startTime: String = "09:00",
    val estimatedDurationMinutes: Int = 45,
    val priority: String = "MEDIUM", // LOW, MEDIUM, HIGH
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
