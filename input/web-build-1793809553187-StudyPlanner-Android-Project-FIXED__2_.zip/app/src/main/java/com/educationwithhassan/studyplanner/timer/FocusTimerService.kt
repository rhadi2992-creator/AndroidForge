package com.educationwithhassan.studyplanner.timer

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.educationwithhassan.studyplanner.MainActivity
import com.educationwithhassan.studyplanner.R
import com.educationwithhassan.studyplanner.ads.AdFrequencyManager
import com.educationwithhassan.studyplanner.notifications.StudyNotificationHelper
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SessionType {
    FOCUS, SHORT_BREAK, LONG_BREAK
}

enum class TimerStatus {
    IDLE, RUNNING, PAUSED, COMPLETED
}

data class TimerState(
    val sessionType: SessionType = SessionType.FOCUS,
    val status: TimerStatus = TimerStatus.IDLE,
    val totalSeconds: Int = 25 * 60,
    val remainingSeconds: Int = 25 * 60,
    val completedSessionsCount: Int = 0,
    val activeSubjectName: String = "General Study"
)

/**
 * Foreground Service for Pomodoro Timer.
 * Uses monotonic clock (SystemClock.elapsedRealtime()) to guarantee accurate countdowns
 * across screen off, doze mode, and background activity transitions.
 */
class FocusTimerService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var timerJob: Job? = null
    private var sessionEndRealtime: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val totalSec = intent.getIntExtra(EXTRA_DURATION_SEC, 25 * 60)
                val type = intent.getStringExtra(EXTRA_TYPE) ?: SessionType.FOCUS.name
                val subject = intent.getStringExtra(EXTRA_SUBJECT) ?: "General Study"
                startTimer(totalSec, SessionType.valueOf(type), subject)
            }
            ACTION_PAUSE -> pauseTimer()
            ACTION_RESUME -> resumeTimer()
            ACTION_RESET -> resetTimer()
            ACTION_SKIP -> skipSession()
            ACTION_STOP_SERVICE -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startTimer(totalSec: Int, type: SessionType, subject: String) {
        AdFrequencyManager.isFocusSessionActive = (type == SessionType.FOCUS)
        val initialRemaining = totalSec
        sessionEndRealtime = SystemClock.elapsedRealtime() + (initialRemaining * 1000L)

        _timerState.value = _timerState.value.copy(
            sessionType = type,
            status = TimerStatus.RUNNING,
            totalSeconds = totalSec,
            remainingSeconds = initialRemaining,
            activeSubjectName = subject
        )

        startForeground(NOTIFICATION_ID, buildForegroundNotification())
        runCountdownLoop()
    }

    private fun resumeTimer() {
        val currentRemaining = _timerState.value.remainingSeconds
        sessionEndRealtime = SystemClock.elapsedRealtime() + (currentRemaining * 1000L)
        _timerState.value = _timerState.value.copy(status = TimerStatus.RUNNING)
        if (_timerState.value.sessionType == SessionType.FOCUS) {
            AdFrequencyManager.isFocusSessionActive = true
        }
        runCountdownLoop()
    }

    private fun pauseTimer() {
        timerJob?.cancel()
        _timerState.value = _timerState.value.copy(status = TimerStatus.PAUSED)
        updateNotification("Paused")
    }

    private fun resetTimer() {
        timerJob?.cancel()
        AdFrequencyManager.isFocusSessionActive = false
        _timerState.value = _timerState.value.copy(
            status = TimerStatus.IDLE,
            remainingSeconds = _timerState.value.totalSeconds
        )
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun skipSession() {
        timerJob?.cancel()
        completeSession()
    }

    private fun runCountdownLoop() {
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (isActive) {
                val millisLeft = sessionEndRealtime - SystemClock.elapsedRealtime()
                val secondsLeft = (millisLeft / 1000).toInt().coerceAtLeast(0)

                _timerState.value = _timerState.value.copy(remainingSeconds = secondsLeft)
                updateNotification("${secondsLeft / 60}:${String.format("%02d", secondsLeft % 60)}")

                if (secondsLeft <= 0) {
                    completeSession()
                    break
                }
                delay(500)
            }
        }
    }

    private fun completeSession() {
        AdFrequencyManager.isFocusSessionActive = false
        val currentType = _timerState.value.sessionType
        val nextCompleted = if (currentType == SessionType.FOCUS) {
            _timerState.value.completedSessionsCount + 1
        } else {
            _timerState.value.completedSessionsCount
        }

        _timerState.value = _timerState.value.copy(
            status = TimerStatus.COMPLETED,
            completedSessionsCount = nextCompleted
        )

        StudyNotificationHelper.showSessionCompleteNotification(
            this,
            currentType.name
        )

        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun buildForegroundNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, StudyNotificationHelper.CHANNEL_TIMER)
            .setContentTitle("Focus Session Active")
            .setContentText("Study Planner & Focus Timer")
            .setSmallIcon(R.drawable.ic_timer)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(timeText: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(this, StudyNotificationHelper.CHANNEL_TIMER)
            .setContentTitle("${_timerState.value.activeSubjectName} • ${_timerState.value.sessionType.name}")
            .setContentText("Remaining: $timeText")
            .setSmallIcon(R.drawable.ic_timer)
            .setOngoing(true)
            .build()
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        AdFrequencyManager.isFocusSessionActive = false
    }

    companion object {
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "ACTION_START"
        const val ACTION_PAUSE = "ACTION_PAUSE"
        const val ACTION_RESUME = "ACTION_RESUME"
        const val ACTION_RESET = "ACTION_RESET"
        const val ACTION_SKIP = "ACTION_SKIP"
        const val ACTION_STOP_SERVICE = "ACTION_STOP_SERVICE"

        const val EXTRA_DURATION_SEC = "EXTRA_DURATION_SEC"
        const val EXTRA_TYPE = "EXTRA_TYPE"
        const val EXTRA_SUBJECT = "EXTRA_SUBJECT"

        private val _timerState = MutableStateFlow(TimerState())
        val timerState = _timerState.asStateFlow()
    }
}
