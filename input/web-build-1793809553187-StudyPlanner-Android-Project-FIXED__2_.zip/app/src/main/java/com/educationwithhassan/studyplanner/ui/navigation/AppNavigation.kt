package com.educationwithhassan.studyplanner.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.educationwithhassan.studyplanner.StudyPlannerApp
import com.educationwithhassan.studyplanner.ui.screens.*

@Composable
fun AppNavigation(app: StudyPlannerApp) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                val items = listOf(
                    Screen.Home to Icons.Default.Home,
                    Screen.Planner to Icons.Default.CalendarMonth,
                    Screen.Focus to Icons.Default.Timer,
                    Screen.Statistics to Icons.Default.BarChart,
                    Screen.Settings to Icons.Default.Settings
                )

                items.forEach { (screen, icon) ->
                    NavigationBarItem(
                        icon = { Icon(icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.startDestinationId) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    app = app,
                    onNavigateToPlanner = { navController.navigate(Screen.Planner.route) },
                    onNavigateToFocus = { navController.navigate(Screen.Focus.route) },
                    onNavigateToNotes = { navController.navigate(Screen.Notes.route) }
                )
            }
            composable(Screen.Planner.route) {
                PlannerScreen(app = app)
            }
            composable(Screen.Focus.route) {
                FocusScreen(app = app)
            }
            composable(Screen.Statistics.route) {
                StatsScreen(app = app)
            }
            composable(Screen.Settings.route) {
                SettingsScreen(app = app)
            }
            composable(Screen.Notes.route) {
                NotesScreen(app = app)
            }
        }
    }
}
