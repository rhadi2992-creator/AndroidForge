package com.educationwithhassan.studyplanner.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.educationwithhassan.studyplanner.StudyPlannerApp
import com.educationwithhassan.studyplanner.ads.NativeAdCard
import com.educationwithhassan.studyplanner.data.database.TaskEntity
import kotlinx.coroutines.launch

@Composable
fun PlannerScreen(app: StudyPlannerApp) {
    val coroutineScope = rememberCoroutineScope()
    val allTasks by app.repository.allTasks.collectAsState(initial = emptyList())
    val subjects by app.repository.allSubjects.collectAsState(initial = emptyList())

    var showAddDialog by remember { mutableStateOf(false) }
    var taskTitle by remember { mutableStateOf("") }
    var taskDesc by remember { mutableStateOf("") }
    var selectedPriority by remember { mutableStateOf("MEDIUM") }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add Task")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(Modifier.height(8.dp))
                Text("Study Planner", style = MaterialTheme.typography.headlineLarge)
                Text("Organize, schedule, and conquer your goals.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
            }

            item {
                NativeAdCard()
                Spacer(Modifier.height(8.dp))
            }

            items(allTasks.size) { index ->
                val task = allTasks[index]
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = task.isCompleted,
                            onCheckedChange = { checked ->
                                coroutineScope.launch {
                                    app.repository.updateTask(
                                        task.copy(
                                            isCompleted = checked,
                                            completedAt = if (checked) System.currentTimeMillis() else null
                                        )
                                    )
                                }
                            }
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(task.title, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${task.subjectName} • ${task.priority} Priority",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = {
                            coroutineScope.launch { app.repository.deleteTask(task) }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Study Task") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = taskTitle,
                        onValueChange = { taskTitle = it },
                        label = { Text("Task Title") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = taskDesc,
                        onValueChange = { taskDesc = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (taskTitle.isNotBlank()) {
                            val sub = subjects.firstOrNull()
                            coroutineScope.launch {
                                app.repository.insertTask(
                                    TaskEntity(
                                        title = taskTitle.trim(),
                                        description = taskDesc.trim(),
                                        subjectId = sub?.id ?: 1L,
                                        subjectName = sub?.name ?: "General Study",
                                        dueDate = System.currentTimeMillis(),
                                        priority = selectedPriority
                                    )
                                )
                                taskTitle = ""
                                taskDesc = ""
                                showAddDialog = false
                            }
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
