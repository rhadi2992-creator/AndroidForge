package com.educationwithhassan.studyplanner.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val colorHex: String,
    val targetHoursWeekly: Float = 5.0f,
    val createdAt: Long = System.currentTimeMillis()
)
