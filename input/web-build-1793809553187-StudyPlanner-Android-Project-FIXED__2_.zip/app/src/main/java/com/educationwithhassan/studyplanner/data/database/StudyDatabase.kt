package com.educationwithhassan.studyplanner.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        TaskEntity::class,
        SubjectEntity::class,
        NoteEntity::class,
        StudySessionEntity::class,
        StudyGoalEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class StudyDatabase : RoomDatabase() {

    abstract fun studyDao(): StudyDao

    companion object {
        @Volatile
        private var INSTANCE: StudyDatabase? = null

        fun getDatabase(context: Context): StudyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    StudyDatabase::class.java,
                    "study_planner_database"
                )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed default subjects
                        CoroutineScope(Dispatchers.IO).launch {
                            val dao = getDatabase(context).studyDao()
                            seedDefaultSubjects(dao)
                        }
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedDefaultSubjects(dao: StudyDao) {
            val starterSubjects = listOf(
                SubjectEntity(name = "Mathematics", colorHex = "#3B82F6", targetHoursWeekly = 6.0f),
                SubjectEntity(name = "Science", colorHex = "#34D399", targetHoursWeekly = 5.0f),
                SubjectEntity(name = "English", colorHex = "#7655DB", targetHoursWeekly = 4.0f),
                SubjectEntity(name = "History", colorHex = "#F59E0B", targetHoursWeekly = 3.0f),
                SubjectEntity(name = "Computer Science", colorHex = "#38BDF8", targetHoursWeekly = 7.0f)
            )
            starterSubjects.forEach { dao.insertSubject(it) }
        }
    }
}
