package com.educationwithhassan.studyplanner.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "study_planner_preferences")

class SettingsDataStore(private val context: Context) {

    companion object {
        val KEY_THEME = stringPreferencesKey("theme_mode")
        val KEY_FOCUS_DURATION = intPreferencesKey("focus_duration_minutes")
        val KEY_SHORT_BREAK = intPreferencesKey("short_break_minutes")
        val KEY_LONG_BREAK = intPreferencesKey("long_break_minutes")
        val KEY_SESSIONS_BEFORE_LONG_BREAK = intPreferencesKey("sessions_before_long_break")
        val KEY_DAILY_GOAL_HOURS = floatPreferencesKey("daily_goal_hours")
        val KEY_SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val KEY_VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
        val KEY_REWARDED_THEME_UNLOCKED = booleanPreferencesKey("rewarded_theme_unlocked")
    }

    val themePreferenceFlow: Flow<String> = context.dataStore.data.map {
        it[KEY_THEME] ?: "SYSTEM"
    }

    val focusDurationFlow: Flow<Int> = context.dataStore.data.map {
        it[KEY_FOCUS_DURATION] ?: 25
    }

    val shortBreakFlow: Flow<Int> = context.dataStore.data.map {
        it[KEY_SHORT_BREAK] ?: 5
    }

    val longBreakFlow: Flow<Int> = context.dataStore.data.map {
        it[KEY_LONG_BREAK] ?: 15
    }

    val dailyGoalHoursFlow: Flow<Float> = context.dataStore.data.map {
        it[KEY_DAILY_GOAL_HOURS] ?: 3.0f
    }

    val soundEnabledFlow: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_SOUND_ENABLED] ?: true
    }

    val vibrationEnabledFlow: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_VIBRATION_ENABLED] ?: true
    }

    val rewardedThemeUnlockedFlow: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_REWARDED_THEME_UNLOCKED] ?: false
    }

    suspend fun setThemePreference(theme: String) {
        context.dataStore.edit { it[KEY_THEME] = theme }
    }

    suspend fun setFocusDuration(minutes: Int) {
        context.dataStore.edit { it[KEY_FOCUS_DURATION] = minutes }
    }

    suspend fun setShortBreakDuration(minutes: Int) {
        context.dataStore.edit { it[KEY_SHORT_BREAK] = minutes }
    }

    suspend fun setLongBreakDuration(minutes: Int) {
        context.dataStore.edit { it[KEY_LONG_BREAK] = minutes }
    }

    suspend fun setDailyGoalHours(hours: Float) {
        context.dataStore.edit { it[KEY_DAILY_GOAL_HOURS] = hours }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SOUND_ENABLED] = enabled }
    }

    suspend fun setVibrationEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_VIBRATION_ENABLED] = enabled }
    }

    suspend fun unlockRewardedTheme() {
        context.dataStore.edit { it[KEY_REWARDED_THEME_UNLOCKED] = true }
    }
}
