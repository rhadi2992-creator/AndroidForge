package com.educationwithhassan.studyplanner.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * Interstitial Ad Manager.
 * Uses Ad Unit ID: ca-app-pub-3133971041724338/6359697585
 */
class InterstitialAdManager(private val context: Context) {

    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false

    fun loadAd() {
        if (isLoading || interstitialAd != null) return
        isLoading = true

        val request = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            AdMobConfig.interstitialAdUnitId,
            request,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isLoading = false
                }
            }
        )
    }

    fun showIfReady(activity: Activity, onClosed: () -> Unit) {
        if (!AdFrequencyManager.canShowInterstitial()) {
            onClosed()
            return
        }

        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    AdFrequencyManager.isFullScreenAdShowing = true
                    AdFrequencyManager.recordInterstitialShown()
                }

                override fun onAdDismissedFullScreenContent() {
                    AdFrequencyManager.isFullScreenAdShowing = false
                    interstitialAd = null
                    loadAd()
                    onClosed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    AdFrequencyManager.isFullScreenAdShowing = false
                    interstitialAd = null
                    loadAd()
                    onClosed()
                }
            }
            ad.show(activity)
        } else {
            loadAd()
            onClosed()
        }
    }
}
