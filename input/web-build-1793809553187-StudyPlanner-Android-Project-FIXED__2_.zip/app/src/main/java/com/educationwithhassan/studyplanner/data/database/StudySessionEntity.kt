package com.educationwithhassan.studyplanner.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val durationMinutes: Int,
    val sessionType: String, // FOCUS, SHORT_BREAK, LONG_BREAK
    val subjectId: Long? = null,
    val subjectName: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
