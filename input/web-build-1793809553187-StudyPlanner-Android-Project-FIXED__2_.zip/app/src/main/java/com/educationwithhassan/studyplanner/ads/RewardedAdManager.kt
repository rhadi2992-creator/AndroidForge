package com.educationwithhassan.studyplanner.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * Rewarded Ad Manager.
 * Uses Ad Unit ID: ca-app-pub-3133971041724338/1977986486
 */
class RewardedAdManager(private val context: Context) {

    private var rewardedAd: RewardedAd? = null
    private var isLoading = false

    fun loadAd() {
        if (isLoading || rewardedAd != null) return
        isLoading = true

        val request = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            AdMobConfig.rewardedAdUnitId,
            request,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    isLoading = false
                }
            }
        )
    }

    val isLoaded: Boolean
        get() = rewardedAd != null

    fun show(
        activity: Activity,
        onUserEarnedReward: (amount: Int, type: String) -> Unit,
        onDismissed: () -> Unit
    ) {
        val ad = rewardedAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    AdFrequencyManager.isFullScreenAdShowing = true
                }

                override fun onAdDismissedFullScreenContent() {
                    AdFrequencyManager.isFullScreenAdShowing = false
                    rewardedAd = null
                    loadAd()
                    onDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    AdFrequencyManager.isFullScreenAdShowing = false
                    rewardedAd = null
                    loadAd()
                    onDismissed()
                }
            }
            ad.show(activity) { rewardItem ->
                onUserEarnedReward(rewardItem.amount, rewardItem.type)
            }
        } else {
            loadAd()
            onDismissed()
        }
    }
}
