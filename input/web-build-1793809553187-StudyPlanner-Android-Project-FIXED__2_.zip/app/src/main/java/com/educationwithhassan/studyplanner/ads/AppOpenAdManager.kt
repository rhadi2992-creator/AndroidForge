package com.educationwithhassan.studyplanner.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import java.util.Date

/**
 * App Open Ad Manager.
 * Uses Ad Unit ID: ca-app-pub-3133971041724338/1630115083
 */
class AppOpenAdManager(private val context: Context) {

    private var appOpenAd: AppOpenAd? = null
    private var isLoading = false
    private var loadTime: Long = 0

    fun loadAd() {
        if (isLoading || isAdAvailable()) return
        isLoading = true

        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            context,
            AdMobConfig.appOpenAdUnitId,
            request,
            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    isLoading = false
                    loadTime = Date().time
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    appOpenAd = null
                    isLoading = false
                }
            }
        )
    }

    private fun wasLoadTimeLessThan4HoursAgo(): Boolean {
        val dateDifference = Date().time - loadTime
        val numMilliSecondsPerHour = 3600000L
        return dateDifference < numMilliSecondsPerHour * 4
    }

    private fun isAdAvailable(): Boolean {
        return appOpenAd != null && wasLoadTimeLessThan4HoursAgo()
    }

    fun showAdIfAvailable(activity: Activity) {
        if (!AdFrequencyManager.canShowAppOpen()) return
        if (!isAdAvailable()) {
            loadAd()
            return
        }

        appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                AdFrequencyManager.isFullScreenAdShowing = true
                AdFrequencyManager.recordAppOpenShown()
            }

            override fun onAdDismissedFullScreenContent() {
                AdFrequencyManager.isFullScreenAdShowing = false
                appOpenAd = null
                loadAd()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                AdFrequencyManager.isFullScreenAdShowing = false
                appOpenAd = null
                loadAd()
            }
        }

        appOpenAd?.show(activity)
    }
}
