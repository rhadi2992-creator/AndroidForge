package com.educationwithhassan.studyplanner

import android.app.Application
import com.educationwithhassan.studyplanner.ads.AdMobConfig
import com.educationwithhassan.studyplanner.ads.AppOpenAdManager
import com.educationwithhassan.studyplanner.data.database.StudyDatabase
import com.educationwithhassan.studyplanner.data.preferences.SettingsDataStore
import com.educationwithhassan.studyplanner.data.repository.StudyRepository
import com.educationwithhassan.studyplanner.notifications.StudyNotificationHelper
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Application class for Study Planner & Focus Timer.
 * Brand: Education With Hassan
 * Initializes Room database, AdMob SDK, notification channels, and App Open Ad preloading.
 */
class StudyPlannerApp : Application() {

    lateinit var database: StudyDatabase
        private set

    lateinit var repository: StudyRepository
        private set

    lateinit var settingsDataStore: SettingsDataStore
        private set

    lateinit var appOpenAdManager: AppOpenAdManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        // 1. Initialize Room Database & Repositories
        database = StudyDatabase.getDatabase(this)
        repository = StudyRepository(database.studyDao())
        settingsDataStore = SettingsDataStore(this)

        // 2. Setup Notification Channels
        StudyNotificationHelper.createNotificationChannels(this)

        // 3. Initialize Google Mobile Ads SDK on background thread
        CoroutineScope(Dispatchers.IO).launch {
            MobileAds.initialize(this@StudyPlannerApp) { initializationStatus ->
                // AdMob SDK successfully initialized
            }
        }

        // 4. Initialize App Open Ad Manager
        appOpenAdManager = AppOpenAdManager(this)
    }

    companion object {
        lateinit var instance: StudyPlannerApp
            private set
    }
}
