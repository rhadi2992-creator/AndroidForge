package com.educationwithhassan.studyplanner.ads

import android.content.Context
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.educationwithhassan.studyplanner.R
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

/**
 * Compose wrapper for Google Native Ads with proper NativeAdView asset registration.
 * Uses Ad Unit ID: ca-app-pub-3133971041724338/3246449084
 */
@Composable
fun NativeAdCard(
    modifier: Modifier = Modifier
) {
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    AndroidView(
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        factory = { context ->
            val adLoader = AdLoader.Builder(context, AdMobConfig.nativeAdUnitId)
                .forNativeAd { ad ->
                    nativeAd?.destroy()
                    nativeAd = ad
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        // Silent fail gracefully
                    }
                })
                .build()

            adLoader.loadAd(AdRequest.Builder().build())

            NativeAdView(context).apply {
                val inflater = LayoutInflater.from(context)
                val view = inflater.inflate(R.layout.view_native_ad, this, true)

                val headlineView = view.findViewById<TextView>(R.id.ad_headline)
                val bodyView = view.findViewById<TextView>(R.id.ad_body)
                val callToActionView = view.findViewById<Button>(R.id.ad_call_to_action)
                val iconView = view.findViewById<ImageView>(R.id.ad_app_icon)

                this.headlineView = headlineView
                this.bodyView = bodyView
                this.callToActionView = callToActionView
                this.iconView = iconView

                nativeAd?.let { populateNativeAd(it, this) }
            }
        },
        update = { adView ->
            nativeAd?.let { populateNativeAd(it, adView) }
        }
    )

    DisposableEffect(Unit) {
        onDispose {
            nativeAd?.destroy()
        }
    }
}

private fun populateNativeAd(nativeAd: NativeAd, adView: NativeAdView) {
    val headline = adView.headlineView as? TextView
    val body = adView.bodyView as? TextView
    val cta = adView.callToActionView as? Button
    val icon = adView.iconView as? ImageView

    headline?.text = nativeAd.headline
    body?.text = nativeAd.body
    cta?.text = nativeAd.callToAction ?: "Learn More"

    nativeAd.icon?.let {
        icon?.setImageDrawable(it.drawable)
    }

    adView.setNativeAd(nativeAd)
}
