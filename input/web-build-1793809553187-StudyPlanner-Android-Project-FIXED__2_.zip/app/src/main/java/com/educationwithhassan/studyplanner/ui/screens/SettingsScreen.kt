package com.educationwithhassan.studyplanner.ui.screens

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.studyplanner.StudyPlannerApp
import com.educationwithhassan.studyplanner.ads.AdMobConfig
import com.educationwithhassan.studyplanner.ads.RewardedAdManager
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(app: StudyPlannerApp) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val rewardedAdManager = remember { RewardedAdManager(context).apply { loadAd() } }

    val currentTheme by app.settingsDataStore.themePreferenceFlow.collectAsState(initial = "SYSTEM")
    val rewardedThemeUnlocked by app.settingsDataStore.rewardedThemeUnlockedFlow.collectAsState(initial = false)

    var rewardStatusMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Settings & Preferences", style = MaterialTheme.typography.headlineLarge)
            Text("Customize timer, theme, and explore optional rewards.", style = MaterialTheme.typography.bodyMedium)
        }

        item {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("App Theme", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = currentTheme == "SYSTEM",
                            onClick = { coroutineScope.launch { app.settingsDataStore.setThemePreference("SYSTEM") } },
                            label = { Text("System") }
                        )
                        FilterChip(
                            selected = currentTheme == "LIGHT",
                            onClick = { coroutineScope.launch { app.settingsDataStore.setThemePreference("LIGHT") } },
                            label = { Text("Light") }
                        )
                        FilterChip(
                            selected = currentTheme == "DARK",
                            onClick = { coroutineScope.launch { app.settingsDataStore.setThemePreference("DARK") } },
                            label = { Text("Dark") }
                        )
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Bonus Productivity Reward", style = MaterialTheme.typography.titleMedium)
                    Text("Watch an optional rewarded ad to unlock the exclusive Cosmic Violet theme and achievement badge.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(12.dp))

                    if (rewardedThemeUnlocked) {
                        Text("✨ Bonus Theme & Productivity Badge Unlocked!", color = MaterialTheme.colorScheme.primary)
                    } else {
                        Button(
                            onClick = {
                                (context as? Activity)?.let { activity ->
                                    rewardedAdManager.show(
                                        activity,
                                        onUserEarnedReward = { amount, type ->
                                            coroutineScope.launch {
                                                app.settingsDataStore.unlockRewardedTheme()
                                                rewardStatusMessage = "Reward granted! Cosmic Violet theme unlocked."
                                            }
                                        },
                                        onDismissed = { }
                                    )
                                }
                            }
                        ) {
                            Icon(Icons.Default.CardGiftcard, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Watch Ad for Reward")
                        }
                    }

                    rewardStatusMessage?.let {
                        Spacer(Modifier.height(8.dp))
                        Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("About Application", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text("Study Planner & Focus Timer v1.0.0", style = MaterialTheme.typography.bodyMedium)
                    Text("Developer: Education With Hassan", style = MaterialTheme.typography.bodySmall)
                    Text("AdMob Mode: ${if (AdMobConfig.isProduction) "RELEASE (Production IDs)" else "DEBUG (Test IDs)"}", style = MaterialTheme.typography.bodySmall)
                    Text("Publisher ID: ${AdMobConfig.PUBLISHER_ID}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
