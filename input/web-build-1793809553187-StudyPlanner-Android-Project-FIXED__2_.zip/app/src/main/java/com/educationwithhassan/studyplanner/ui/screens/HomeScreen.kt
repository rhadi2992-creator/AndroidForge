package com.educationwithhassan.studyplanner.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.studyplanner.StudyPlannerApp
import com.educationwithhassan.studyplanner.ads.BannerAdView
import com.educationwithhassan.studyplanner.ui.theme.PrimaryIndigo
import com.educationwithhassan.studyplanner.ui.theme.SecondaryPurple
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(
    app: StudyPlannerApp,
    onNavigateToPlanner: () -> Unit,
    onNavigateToFocus: () -> Unit,
    onNavigateToNotes: () -> Unit
) {
    val pendingTasks by app.repository.pendingTasks.collectAsState(initial = emptyList())
    val completedTasks by app.repository.completedTasks.collectAsState(initial = emptyList())
    val allSessions by app.repository.allSessions.collectAsState(initial = emptyList())

    val todayFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
    val todayDateStr = todayFormat.format(Date())

    val totalStudyMinutes = allSessions.filter { it.sessionType == "FOCUS" }.sumOf { it.durationMinutes }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(PrimaryIndigo, SecondaryPurple)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Text(
                            text = "Hello, Scholar! 📚",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = todayDateStr,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Total Focus", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                                Text("${totalStudyMinutes / 60}h ${totalStudyMinutes % 60}m", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                            Column {
                                Text("Pending Tasks", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                                Text("${pendingTasks.size}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                            Column {
                                Text("Completed", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                                Text("${completedTasks.size}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onNavigateToFocus,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
                ) {
                    Icon(Icons.Default.Timer, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Start Focus")
                }

                OutlinedButton(
                    onClick = onNavigateToPlanner,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Add Task")
                }
            }
        }

        item {
            Text(
                text = "Upcoming Study Tasks",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        if (pendingTasks.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No pending tasks. You're all caught up! ✨")
                    }
                }
            }
        } else {
            items(pendingTasks.take(4).size) { index ->
                val task = pendingTasks[index]
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(task.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${task.subjectName} • ${task.startTime} (${task.estimatedDurationMinutes}m)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        AssistChip(
                            onClick = { },
                            label = { Text(task.priority) }
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            BannerAdView()
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
