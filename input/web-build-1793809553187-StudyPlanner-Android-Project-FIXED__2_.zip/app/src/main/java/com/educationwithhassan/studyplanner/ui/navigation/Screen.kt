package com.educationwithhassan.studyplanner.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Home : Screen("home", "Home")
    object Planner : Screen("planner", "Planner")
    object Focus : Screen("focus", "Focus")
    object Statistics : Screen("statistics", "Stats")
    object Settings : Screen("settings", "Settings")
    object Notes : Screen("notes", "Notes")
}
