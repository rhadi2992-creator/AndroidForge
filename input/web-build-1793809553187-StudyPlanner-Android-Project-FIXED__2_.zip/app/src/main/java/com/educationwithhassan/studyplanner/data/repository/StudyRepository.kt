package com.educationwithhassan.studyplanner.data.repository

import com.educationwithhassan.studyplanner.data.database.*
import kotlinx.coroutines.flow.Flow

class StudyRepository(private val dao: StudyDao) {

    // Tasks
    val allTasks: Flow<List<TaskEntity>> = dao.getAllTasks()
    val pendingTasks: Flow<List<TaskEntity>> = dao.getPendingTasks()
    val completedTasks: Flow<List<TaskEntity>> = dao.getCompletedTasks()

    suspend fun insertTask(task: TaskEntity) = dao.insertTask(task)
    suspend fun updateTask(task: TaskEntity) = dao.updateTask(task)
    suspend fun deleteTask(task: TaskEntity) = dao.deleteTask(task)

    // Subjects
    val allSubjects: Flow<List<SubjectEntity>> = dao.getAllSubjects()
    suspend fun insertSubject(subject: SubjectEntity) = dao.insertSubject(subject)
    suspend fun deleteSubject(subject: SubjectEntity) = dao.deleteSubject(subject)

    // Notes
    val allNotes: Flow<List<NoteEntity>> = dao.getAllNotes()
    fun searchNotes(query: String): Flow<List<NoteEntity>> = dao.searchNotes(query)
    suspend fun insertNote(note: NoteEntity) = dao.insertNote(note)
    suspend fun updateNote(note: NoteEntity) = dao.updateNote(note)
    suspend fun deleteNote(note: NoteEntity) = dao.deleteNote(note)

    // Sessions
    val allSessions: Flow<List<StudySessionEntity>> = dao.getAllSessions()
    fun getSessionsSince(timestamp: Long): Flow<List<StudySessionEntity>> = dao.getSessionsSince(timestamp)
    suspend fun insertSession(session: StudySessionEntity) = dao.insertSession(session)
}
