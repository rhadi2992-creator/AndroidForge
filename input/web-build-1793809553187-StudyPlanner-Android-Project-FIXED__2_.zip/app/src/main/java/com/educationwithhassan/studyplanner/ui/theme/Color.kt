package com.educationwithhassan.studyplanner.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryIndigo = Color(0xFF3730A3)
val PrimaryIndigoLight = Color(0xFF4F46E5)
val SecondaryPurple = Color(0xFF7655DB)
val SecondaryPurpleLight = Color(0xFF8B5CF6)
val AccentBlue = Color(0xFF3B82F6)
val SoftCyan = Color(0xFF38BDF8)
val MintGreen = Color(0xFF34D399)
val LightLavender = Color(0xFFF3F0FF)

val DarkNavy = Color(0xFF111827)
val DarkSurface = Color(0xFF1F2937)
val DarkCard = Color(0xFF182234)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val TextPrimaryDark = Color(0xFFF9FAFB)
val TextSecondaryDark = Color(0xFF9CA3AF)
val TextPrimaryLight = Color(0xFF111827)
val TextSecondaryLight = Color(0xFF6B7280)
