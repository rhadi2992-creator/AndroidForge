package com.educationwithhassan.studyplanner.ads

import android.os.SystemClock

/**
 * Centralized Ad Frequency and Policy Manager.
 * Guarantees compliance with Google Play and AdMob UX guidelines:
 * - Minimum cooldown between full-screen ads (Interstitial / App Open)
 * - Strict prohibition of ads during active Pomodoro Focus Sessions
 * - Prevents double-shows or overlapping full-screen dialogs
 */
object AdFrequencyManager {

    private const val INTERSTITIAL_COOLDOWN_MS = 180_000L
    private const val APP_OPEN_COOLDOWN_MS = 240_000L

    private var lastInterstitialShowTime = 0L
    private var lastAppOpenShowTime = 0L

    var isFocusSessionActive: Boolean = false
    var isFullScreenAdShowing: Boolean = false

    fun canShowInterstitial(): Boolean {
        if (isFocusSessionActive) return false
        if (isFullScreenAdShowing) return false
        val now = SystemClock.elapsedRealtime()
        return (now - lastInterstitialShowTime) >= INTERSTITIAL_COOLDOWN_MS
    }

    fun recordInterstitialShown() {
        lastInterstitialShowTime = SystemClock.elapsedRealtime()
    }

    fun canShowAppOpen(): Boolean {
        if (isFocusSessionActive) return false
        if (isFullScreenAdShowing) return false
        val now = SystemClock.elapsedRealtime()
        return (now - lastAppOpenShowTime) >= APP_OPEN_COOLDOWN_MS
    }

    fun recordAppOpenShown() {
        lastAppOpenShowTime = SystemClock.elapsedRealtime()
    }
}
