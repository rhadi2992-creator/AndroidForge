package com.educationwithhassan.studyplanner.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_goals")
data class StudyGoalEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val goalType: String, // DAILY, WEEKLY
    val targetMinutes: Int,
    val achievedMinutes: Int = 0,
    val dateKey: String, // YYYY-MM-DD or YYYY-WW
    val isAchieved: Boolean = false
)
