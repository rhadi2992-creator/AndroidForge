package com.educationwithhassan.studyplanner.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.educationwithhassan.studyplanner.R

object StudyNotificationHelper {

    const val CHANNEL_TIMER = "channel_focus_timer"
    const val CHANNEL_REMINDERS = "channel_study_reminders"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val timerChannel = NotificationChannel(
                CHANNEL_TIMER,
                "Focus Timer",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live progress for study sessions"
            }

            val remindersChannel = NotificationChannel(
                CHANNEL_REMINDERS,
                "Study Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Reminders for scheduled study tasks and goals"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(timerChannel)
            notificationManager.createNotificationChannel(remindersChannel)
        }
    }

    fun showSessionCompleteNotification(context: Context, sessionType: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val title = if (sessionType == "FOCUS") "Focus Session Completed!" else "Break Finished!"
        val message = if (sessionType == "FOCUS") {
            "Great job! Take a well-deserved break to refresh your mind."
        } else {
            "Ready to resume? Start your next focus block to hit your study goal!"
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_timer)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        manager.notify(2001, notification)
    }
}
