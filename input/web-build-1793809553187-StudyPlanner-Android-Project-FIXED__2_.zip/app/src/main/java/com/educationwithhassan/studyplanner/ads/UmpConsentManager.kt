package com.educationwithhassan.studyplanner.ads

import android.app.Activity
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * Google User Messaging Platform (UMP) Manager.
 * Requests consent info on application launch and presents GDPR / US State privacy forms when required.
 */
class UmpConsentManager(private val activity: Activity) {

    private val consentInformation: ConsentInformation =
        UserMessagingPlatform.getConsentInformation(activity)

    fun gatherConsent(onConsentComplete: (canRequestAds: Boolean) -> Unit) {
        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()

        consentInformation.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    onConsentComplete(consentInformation.canRequestAds())
                }
            },
            { requestConsentError ->
                onConsentComplete(consentInformation.canRequestAds())
            }
        )
    }

    val canRequestAds: Boolean
        get() = consentInformation.canRequestAds()

    val isPrivacyOptionsRequired: Boolean
        get() = consentInformation.privacyOptionsRequirementStatus ==
                ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptionsForm(onDismiss: () -> Unit) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) {
            onDismiss()
        }
    }
}
