# Proguard rules for Study Planner & Focus Timer
-keep class com.educationwithhassan.studyplanner.data.database.** { *; }
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.android.ump.** { *; }
-dontwarn com.google.android.gms.ads.**
-dontwarn com.google.android.ump.**
