# Shadow Warrior: 3D Ninja Combat — Android Studio Project & AdMob Integration

## Overview
Complete native Android project for **Shadow Warrior: 3D Ninja Combat**, featuring Kotlin, hardware-accelerated Android WebView, and all 5 official **Google Mobile Ads (AdMob)** formats.

### AdMob Configuration
- **AdMob App ID**: `ca-app-pub-3133971041724338~5461456996`
- **Banner Ad Unit**: `ca-app-pub-3133971041724338/8121465266`
- **App Open Ad Unit**: `ca-app-pub-3133971041724338/3363962603`
- **Rewarded Ad Unit**: `ca-app-pub-3133971041724338/2300107036`
- **Native Advanced Ad Unit**: `ca-app-pub-3133971041724338/2076745751`
- **Interstitial Ad Unit**: `ca-app-pub-3133971041724338/3613188701`

## How to Build
1. Open Android Studio.
2. Select **Open** and choose this folder.
3. Allow Gradle to sync.
4. Run on a device/emulator or select **Build > Generate Signed Bundle / APK**.
