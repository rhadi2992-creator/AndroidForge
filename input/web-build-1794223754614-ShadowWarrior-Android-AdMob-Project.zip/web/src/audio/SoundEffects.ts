/**
* @license
* SPDX-License-Identifier: Apache-2.0
*/
// Procedural Web Audio API sound synthesizer
// Zero external audio files or 404 dependencies
class SoundManager {
	constructor() {
		this.ctx = null;
		this.masterGain = null;
		this.sfxGain = null;
		this.musicGain = null;
		this.masterVolume = .8;
		this.sfxVolume = .9;
		this.musicVolume = .5;
		this.soundEnabled = true;
		this.musicEnabled = true;
		this.isBgmPlaying = false;
		this.bgmInterval = null;
		this.bgmStep = 0;
		// Lazy initialize on first interaction
	}
	initContext() {
		if (!this.ctx) {
			const AudioCtx = window.AudioContext || window.webkitAudioContext;
			this.ctx = new AudioCtx();
			this.masterGain = this.ctx.createGain();
			this.masterGain.gain.setValueAtTime(this.masterVolume, this.ctx.currentTime);
			this.masterGain.connect(this.ctx.destination);
			this.sfxGain = this.ctx.createGain();
			this.sfxGain.gain.setValueAtTime(this.sfxVolume, this.ctx.currentTime);
			this.sfxGain.connect(this.masterGain);
			this.musicGain = this.ctx.createGain();
			this.musicGain.gain.setValueAtTime(this.musicVolume, this.ctx.currentTime);
			this.musicGain.connect(this.masterGain);
		}
		if (this.ctx.state === "suspended") {
			this.ctx.resume();
		}
	}
	updateVolumes(master, sfx, music, soundOn, musicOn) {
		this.masterVolume = master;
		this.sfxVolume = sfx;
		this.musicVolume = music;
		this.soundEnabled = soundOn;
		this.musicEnabled = musicOn;
		if (this.ctx && this.masterGain && this.sfxGain && this.musicGain) {
			const t = this.ctx.currentTime;
			this.masterGain.gain.setValueAtTime(soundOn ? master : 0, t);
			this.sfxGain.gain.setValueAtTime(sfx, t);
			this.musicGain.gain.setValueAtTime(musicOn ? music : 0, t);
		}
		if (!musicOn && this.isBgmPlaying) {
			this.stopBgm();
		} else if (musicOn && !this.isBgmPlaying && this.soundEnabled) {
			this.startBgm();
		}
	}
	// --- Sound Effects ---
	playSwordSlash(combo = 1) {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		const filter = this.ctx.createBiquadFilter();
		// Noise burst for whoosh
		const bufferSize = this.ctx.sampleRate * .12;
		const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
		const output = noiseBuffer.getChannelData(0);
		for (let i = 0; i < bufferSize; i++) {
			output[i] = Math.random() * 2 - 1;
		}
		const whiteNoise = this.ctx.createBufferSource();
		whiteNoise.buffer = noiseBuffer;
		filter.type = "bandpass";
		filter.frequency.setValueAtTime(800 + combo * 300, t);
		filter.frequency.exponentialRampToValueAtTime(2400 + combo * 400, t + .1);
		filter.Q.setValueAtTime(2.5, t);
		gain.gain.setValueAtTime(.4 * this.sfxVolume, t);
		gain.gain.exponentialRampToValueAtTime(.001, t + .12);
		whiteNoise.connect(filter);
		filter.connect(gain);
		gain.connect(this.sfxGain);
		whiteNoise.start(t);
		whiteNoise.stop(t + .12);
		// Subtle blade ring
		osc.type = "sine";
		osc.frequency.setValueAtTime(1200 + combo * 400, t);
		osc.frequency.exponentialRampToValueAtTime(300, t + .1);
		const bladeGain = this.ctx.createGain();
		bladeGain.gain.setValueAtTime(.15 * this.sfxVolume, t);
		bladeGain.gain.exponentialRampToValueAtTime(.001, t + .1);
		osc.connect(bladeGain);
		bladeGain.connect(this.sfxGain);
		osc.start(t);
		osc.stop(t + .1);
	}
	playSwordClash() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		const freqs = [
			1840,
			2460,
			3720
		];
		freqs.forEach((freq) => {
			const osc = this.ctx.createOscillator();
			const gain = this.ctx.createGain();
			osc.type = "triangle";
			osc.frequency.setValueAtTime(freq, t);
			gain.gain.setValueAtTime(.25 * this.sfxVolume, t);
			gain.gain.exponentialRampToValueAtTime(.001, t + .28);
			osc.connect(gain);
			gain.connect(this.sfxGain);
			osc.start(t);
			osc.stop(t + .3);
		});
	}
	playHeavyImpact() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = "sine";
		osc.frequency.setValueAtTime(140, t);
		osc.frequency.exponentialRampToValueAtTime(35, t + .25);
		gain.gain.setValueAtTime(.6 * this.sfxVolume, t);
		gain.gain.exponentialRampToValueAtTime(.001, t + .25);
		osc.connect(gain);
		gain.connect(this.sfxGain);
		osc.start(t);
		osc.stop(t + .25);
	}
	playDodgeRoll() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = "sine";
		osc.frequency.setValueAtTime(450, t);
		osc.frequency.exponentialRampToValueAtTime(120, t + .22);
		gain.gain.setValueAtTime(.25 * this.sfxVolume, t);
		gain.gain.exponentialRampToValueAtTime(.001, t + .22);
		osc.connect(gain);
		gain.connect(this.sfxGain);
		osc.start(t);
		osc.stop(t + .22);
	}
	playSpecialBlast() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		// Power charge
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = "sawtooth";
		osc.frequency.setValueAtTime(120, t);
		osc.frequency.exponentialRampToValueAtTime(780, t + .35);
		gain.gain.setValueAtTime(.1, t);
		gain.gain.linearRampToValueAtTime(.45 * this.sfxVolume, t + .35);
		gain.gain.exponentialRampToValueAtTime(.001, t + .8);
		const filter = this.ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.setValueAtTime(300, t);
		filter.frequency.exponentialRampToValueAtTime(3200, t + .4);
		osc.connect(filter);
		filter.connect(gain);
		gain.connect(this.sfxGain);
		osc.start(t);
		osc.stop(t + .8);
		// Boom hit
		const boom = this.ctx.createOscillator();
		const boomGain = this.ctx.createGain();
		boom.type = "sine";
		boom.frequency.setValueAtTime(180, t + .35);
		boom.frequency.exponentialRampToValueAtTime(30, t + .9);
		boomGain.gain.setValueAtTime(.7 * this.sfxVolume, t + .35);
		boomGain.gain.exponentialRampToValueAtTime(.001, t + .9);
		boom.connect(boomGain);
		boomGain.connect(this.sfxGain);
		boom.start(t + .35);
		boom.stop(t + .9);
	}
	playBossRoar() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		const filter = this.ctx.createBiquadFilter();
		osc.type = "sawtooth";
		osc.frequency.setValueAtTime(80, t);
		osc.frequency.exponentialRampToValueAtTime(45, t + 1.2);
		filter.type = "lowpass";
		filter.frequency.setValueAtTime(450, t);
		filter.frequency.exponentialRampToValueAtTime(150, t + 1.2);
		gain.gain.setValueAtTime(.01, t);
		gain.gain.linearRampToValueAtTime(.6 * this.sfxVolume, t + .2);
		gain.gain.exponentialRampToValueAtTime(.001, t + 1.2);
		osc.connect(filter);
		filter.connect(gain);
		gain.connect(this.sfxGain);
		osc.start(t);
		osc.stop(t + 1.25);
	}
	playArrowShoot() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = "triangle";
		osc.frequency.setValueAtTime(800, t);
		osc.frequency.exponentialRampToValueAtTime(200, t + .15);
		gain.gain.setValueAtTime(.3 * this.sfxVolume, t);
		gain.gain.exponentialRampToValueAtTime(.001, t + .15);
		osc.connect(gain);
		gain.connect(this.sfxGain);
		osc.start(t);
		osc.stop(t + .15);
	}
	playHealthPickup() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		const notes = [
			523.25,
			659.25,
			783.99,
			1046.5
		];
		notes.forEach((freq, i) => {
			const osc = this.ctx.createOscillator();
			const gain = this.ctx.createGain();
			osc.type = "triangle";
			osc.frequency.setValueAtTime(freq, t + i * .05);
			gain.gain.setValueAtTime(.2 * this.sfxVolume, t + i * .05);
			gain.gain.exponentialRampToValueAtTime(.001, t + i * .05 + .3);
			osc.connect(gain);
			gain.connect(this.sfxGain);
			osc.start(t + i * .05);
			osc.stop(t + i * .05 + .32);
		});
	}
	playCoin() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		const notes = [987.77, 1318.51];
		notes.forEach((freq, i) => {
			const osc = this.ctx.createOscillator();
			const gain = this.ctx.createGain();
			osc.type = "sine";
			osc.frequency.setValueAtTime(freq, t + i * .08);
			gain.gain.setValueAtTime(.25 * this.sfxVolume, t + i * .08);
			gain.gain.exponentialRampToValueAtTime(.001, t + i * .08 + .2);
			osc.connect(gain);
			gain.connect(this.sfxGain);
			osc.start(t + i * .08);
			osc.stop(t + i * .08 + .22);
		});
	}
	playVictoryGong() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		// Japanese Bonsho Temple Bell harmonics
		const harmonics = [
			110,
			220,
			310,
			440,
			580
		];
		harmonics.forEach((freq, idx) => {
			const osc = this.ctx.createOscillator();
			const gain = this.ctx.createGain();
			osc.type = idx % 2 === 0 ? "sine" : "triangle";
			osc.frequency.setValueAtTime(freq, t);
			gain.gain.setValueAtTime(.4 / (idx + 1) * this.sfxVolume, t);
			gain.gain.exponentialRampToValueAtTime(1e-4, t + 3.5);
			osc.connect(gain);
			gain.connect(this.sfxGain);
			osc.start(t);
			osc.stop(t + 3.6);
		});
	}
	playGameOver() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		const notes = [
			293.66,
			261.63,
			220,
			174.61
		];
		notes.forEach((freq, idx) => {
			const osc = this.ctx.createOscillator();
			const gain = this.ctx.createGain();
			osc.type = "sawtooth";
			osc.frequency.setValueAtTime(freq, t + idx * .25);
			const filter = this.ctx.createBiquadFilter();
			filter.type = "lowpass";
			filter.frequency.setValueAtTime(600, t + idx * .25);
			gain.gain.setValueAtTime(.25 * this.sfxVolume, t + idx * .25);
			gain.gain.exponentialRampToValueAtTime(.001, t + idx * .25 + .5);
			osc.connect(filter);
			filter.connect(gain);
			gain.connect(this.sfxGain);
			osc.start(t + idx * .25);
			osc.stop(t + idx * .25 + .52);
		});
	}
	playClick() {
		if (!this.soundEnabled) return;
		this.initContext();
		if (!this.ctx || !this.sfxGain) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = "sine";
		osc.frequency.setValueAtTime(900, t);
		osc.frequency.exponentialRampToValueAtTime(300, t + .04);
		gain.gain.setValueAtTime(.15 * this.sfxVolume, t);
		gain.gain.exponentialRampToValueAtTime(.001, t + .04);
		osc.connect(gain);
		gain.connect(this.sfxGain);
		osc.start(t);
		osc.stop(t + .04);
	}
	// --- Procedural Japanese Taiko & Flute BGM ---
	startBgm() {
		if (!this.musicEnabled || this.isBgmPlaying) return;
		this.initContext();
		if (!this.ctx || !this.musicGain) return;
		this.isBgmPlaying = true;
		this.bgmStep = 0;
		// Japanese Insen / Hirajoshi pentatonic scale (D4, Eb4, G4, A4, Bb4, D5)
		const melodyNotes = [
			293.66,
			311.13,
			392,
			440,
			466.16,
			587.33
		];
		// Every 250ms (120 BPM sixteenth / eighth notes)
		this.bgmInterval = window.setInterval(() => {
			if (!this.musicEnabled || !this.ctx || !this.musicGain) return;
			const t = this.ctx.currentTime;
			const step = this.bgmStep % 16;
			this.bgmStep++;
			// Taiko Drum (Strong on beat 0, 4, 8, 12, accented on 10, 14)
			if (step === 0 || step === 4 || step === 8 || step === 12 || step === 10) {
				const isStrong = step === 0 || step === 8;
				const taikoOsc = this.ctx.createOscillator();
				const taikoGain = this.ctx.createGain();
				taikoOsc.type = "sine";
				taikoOsc.frequency.setValueAtTime(isStrong ? 110 : 85, t);
				taikoOsc.frequency.exponentialRampToValueAtTime(35, t + (isStrong ? .35 : .2));
				taikoGain.gain.setValueAtTime((isStrong ? .45 : .28) * this.musicVolume, t);
				taikoGain.gain.exponentialRampToValueAtTime(.001, t + (isStrong ? .35 : .2));
				taikoOsc.connect(taikoGain);
				taikoGain.connect(this.musicGain);
				taikoOsc.start(t);
				taikoOsc.stop(t + .36);
			}
			// Bamboo Shakuhachi flute note on syncopated steps
			if (step === 0 || step === 3 || step === 6 || step === 11 || step === 14) {
				const noteIndex = [
					0,
					2,
					3,
					1,
					4,
					2,
					5,
					3
				][Math.floor(this.bgmStep / 4 % 8)];
				const freq = melodyNotes[noteIndex % melodyNotes.length];
				const fluteOsc = this.ctx.createOscillator();
				const fluteGain = this.ctx.createGain();
				const fluteFilter = this.ctx.createBiquadFilter();
				fluteOsc.type = "triangle";
				fluteOsc.frequency.setValueAtTime(freq, t);
				fluteFilter.type = "lowpass";
				fluteFilter.frequency.setValueAtTime(1400, t);
				fluteGain.gain.setValueAtTime(.001, t);
				fluteGain.gain.linearRampToValueAtTime(.18 * this.musicVolume, t + .08);
				fluteGain.gain.exponentialRampToValueAtTime(.001, t + .45);
				fluteOsc.connect(fluteFilter);
				fluteFilter.connect(fluteGain);
				fluteGain.connect(this.musicGain);
				fluteOsc.start(t);
				fluteOsc.stop(t + .46);
			}
		}, 240);
	}
	stopBgm() {
		this.isBgmPlaying = false;
		if (this.bgmInterval !== null) {
			clearInterval(this.bgmInterval);
			this.bgmInterval = null;
		}
	}
}
export const soundManager = new SoundManager();

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBUUEsTUFBTSxhQUFhO0NBZ0JqQixjQUFjO2FBZnFCO29CQUNHO2lCQUNIO21CQUNFO3NCQUVmO21CQUNIO3FCQUNFO3NCQUNDO3NCQUNBO3NCQUVDO3FCQUNjO2lCQUNuQjs7Q0FJbEI7Q0FFQSxBQUFRLGNBQWM7RUFDcEIsSUFBSSxDQUFDLEtBQUssS0FBSztHQUNiLE1BQU0sV0FBVyxPQUFPLGdCQUFpQixPQUFrRTtHQUMzRyxLQUFLLE1BQU0sSUFBSSxTQUFTO0dBRXhCLEtBQUssYUFBYSxLQUFLLElBQUksV0FBVztHQUN0QyxLQUFLLFdBQVcsS0FBSyxlQUFlLEtBQUssY0FBYyxLQUFLLElBQUksV0FBVztHQUMzRSxLQUFLLFdBQVcsUUFBUSxLQUFLLElBQUksV0FBVztHQUU1QyxLQUFLLFVBQVUsS0FBSyxJQUFJLFdBQVc7R0FDbkMsS0FBSyxRQUFRLEtBQUssZUFBZSxLQUFLLFdBQVcsS0FBSyxJQUFJLFdBQVc7R0FDckUsS0FBSyxRQUFRLFFBQVEsS0FBSyxVQUFVO0dBRXBDLEtBQUssWUFBWSxLQUFLLElBQUksV0FBVztHQUNyQyxLQUFLLFVBQVUsS0FBSyxlQUFlLEtBQUssYUFBYSxLQUFLLElBQUksV0FBVztHQUN6RSxLQUFLLFVBQVUsUUFBUSxLQUFLLFVBQVU7RUFDeEM7RUFFQSxJQUFJLEtBQUssSUFBSSxVQUFVLGFBQWE7R0FDbEMsS0FBSyxJQUFJLE9BQU87RUFDbEI7Q0FDRjtDQUVBLEFBQU8sY0FBYyxRQUFnQixLQUFhLE9BQWUsU0FBa0IsU0FBa0I7RUFDbkcsS0FBSyxlQUFlO0VBQ3BCLEtBQUssWUFBWTtFQUNqQixLQUFLLGNBQWM7RUFDbkIsS0FBSyxlQUFlO0VBQ3BCLEtBQUssZUFBZTtFQUVwQixJQUFJLEtBQUssT0FBTyxLQUFLLGNBQWMsS0FBSyxXQUFXLEtBQUssV0FBVztHQUNqRSxNQUFNLElBQUksS0FBSyxJQUFJO0dBQ25CLEtBQUssV0FBVyxLQUFLLGVBQWUsVUFBVSxTQUFTLEdBQUcsQ0FBQztHQUMzRCxLQUFLLFFBQVEsS0FBSyxlQUFlLEtBQUssQ0FBQztHQUN2QyxLQUFLLFVBQVUsS0FBSyxlQUFlLFVBQVUsUUFBUSxHQUFHLENBQUM7RUFDM0Q7RUFFQSxJQUFJLENBQUMsV0FBVyxLQUFLLGNBQWM7R0FDakMsS0FBSyxRQUFRO0VBQ2YsT0FBTyxJQUFJLFdBQVcsQ0FBQyxLQUFLLGdCQUFnQixLQUFLLGNBQWM7R0FDN0QsS0FBSyxTQUFTO0VBQ2hCO0NBQ0Y7O0NBSUEsQUFBTyxlQUFlLFFBQVEsR0FBRztFQUMvQixJQUFJLENBQUMsS0FBSyxjQUFjO0VBQ3hCLEtBQUssWUFBWTtFQUNqQixJQUFJLENBQUMsS0FBSyxPQUFPLENBQUMsS0FBSyxTQUFTO0VBRWhDLE1BQU0sSUFBSSxLQUFLLElBQUk7RUFDbkIsTUFBTSxNQUFNLEtBQUssSUFBSSxpQkFBaUI7RUFDdEMsTUFBTSxPQUFPLEtBQUssSUFBSSxXQUFXO0VBQ2pDLE1BQU0sU0FBUyxLQUFLLElBQUksbUJBQW1COztFQUczQyxNQUFNLGFBQWEsS0FBSyxJQUFJLGFBQWE7RUFDekMsTUFBTSxjQUFjLEtBQUssSUFBSSxhQUFhLEdBQUcsWUFBWSxLQUFLLElBQUksVUFBVTtFQUM1RSxNQUFNLFNBQVMsWUFBWSxlQUFlLENBQUM7RUFDM0MsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFlBQVksS0FBSztHQUNuQyxPQUFPLEtBQUssS0FBSyxPQUFPLElBQUksSUFBSTtFQUNsQztFQUNBLE1BQU0sYUFBYSxLQUFLLElBQUksbUJBQW1CO0VBQy9DLFdBQVcsU0FBUztFQUVwQixPQUFPLE9BQU87RUFDZCxPQUFPLFVBQVUsZUFBZSxNQUFNLFFBQVEsS0FBSyxDQUFDO0VBQ3BELE9BQU8sVUFBVSw2QkFBNkIsT0FBTyxRQUFRLEtBQUssSUFBSSxFQUFHO0VBQ3pFLE9BQU8sRUFBRSxlQUFlLEtBQUssQ0FBQztFQUU5QixLQUFLLEtBQUssZUFBZSxLQUFNLEtBQUssV0FBVyxDQUFDO0VBQ2hELEtBQUssS0FBSyw2QkFBNkIsTUFBTyxJQUFJLEdBQUk7RUFFdEQsV0FBVyxRQUFRLE1BQU07RUFDekIsT0FBTyxRQUFRLElBQUk7RUFDbkIsS0FBSyxRQUFRLEtBQUssT0FBTztFQUV6QixXQUFXLE1BQU0sQ0FBQztFQUNsQixXQUFXLEtBQUssSUFBSSxHQUFJOztFQUd4QixJQUFJLE9BQU87RUFDWCxJQUFJLFVBQVUsZUFBZSxPQUFPLFFBQVEsS0FBSyxDQUFDO0VBQ2xELElBQUksVUFBVSw2QkFBNkIsS0FBSyxJQUFJLEVBQUc7RUFDdkQsTUFBTSxZQUFZLEtBQUssSUFBSSxXQUFXO0VBQ3RDLFVBQVUsS0FBSyxlQUFlLE1BQU8sS0FBSyxXQUFXLENBQUM7RUFDdEQsVUFBVSxLQUFLLDZCQUE2QixNQUFPLElBQUksRUFBRztFQUUxRCxJQUFJLFFBQVEsU0FBUztFQUNyQixVQUFVLFFBQVEsS0FBSyxPQUFPO0VBQzlCLElBQUksTUFBTSxDQUFDO0VBQ1gsSUFBSSxLQUFLLElBQUksRUFBRztDQUNsQjtDQUVBLEFBQU8saUJBQWlCO0VBQ3RCLElBQUksQ0FBQyxLQUFLLGNBQWM7RUFDeEIsS0FBSyxZQUFZO0VBQ2pCLElBQUksQ0FBQyxLQUFLLE9BQU8sQ0FBQyxLQUFLLFNBQVM7RUFFaEMsTUFBTSxJQUFJLEtBQUssSUFBSTtFQUNuQixNQUFNLFFBQVE7R0FBQztHQUFNO0dBQU07RUFBSTtFQUUvQixNQUFNLFNBQVEsU0FBUTtHQUNwQixNQUFNLE1BQU0sS0FBSyxJQUFLLGlCQUFpQjtHQUN2QyxNQUFNLE9BQU8sS0FBSyxJQUFLLFdBQVc7R0FDbEMsSUFBSSxPQUFPO0dBQ1gsSUFBSSxVQUFVLGVBQWUsTUFBTSxDQUFDO0dBQ3BDLEtBQUssS0FBSyxlQUFlLE1BQU8sS0FBSyxXQUFXLENBQUM7R0FDakQsS0FBSyxLQUFLLDZCQUE2QixNQUFPLElBQUksR0FBSTtHQUV0RCxJQUFJLFFBQVEsSUFBSTtHQUNoQixLQUFLLFFBQVEsS0FBSyxPQUFRO0dBQzFCLElBQUksTUFBTSxDQUFDO0dBQ1gsSUFBSSxLQUFLLElBQUksRUFBRztFQUNsQixDQUFDO0NBQ0g7Q0FFQSxBQUFPLGtCQUFrQjtFQUN2QixJQUFJLENBQUMsS0FBSyxjQUFjO0VBQ3hCLEtBQUssWUFBWTtFQUNqQixJQUFJLENBQUMsS0FBSyxPQUFPLENBQUMsS0FBSyxTQUFTO0VBRWhDLE1BQU0sSUFBSSxLQUFLLElBQUk7RUFDbkIsTUFBTSxNQUFNLEtBQUssSUFBSSxpQkFBaUI7RUFDdEMsTUFBTSxPQUFPLEtBQUssSUFBSSxXQUFXO0VBRWpDLElBQUksT0FBTztFQUNYLElBQUksVUFBVSxlQUFlLEtBQUssQ0FBQztFQUNuQyxJQUFJLFVBQVUsNkJBQTZCLElBQUksSUFBSSxHQUFJO0VBRXZELEtBQUssS0FBSyxlQUFlLEtBQU0sS0FBSyxXQUFXLENBQUM7RUFDaEQsS0FBSyxLQUFLLDZCQUE2QixNQUFPLElBQUksR0FBSTtFQUV0RCxJQUFJLFFBQVEsSUFBSTtFQUNoQixLQUFLLFFBQVEsS0FBSyxPQUFPO0VBQ3pCLElBQUksTUFBTSxDQUFDO0VBQ1gsSUFBSSxLQUFLLElBQUksR0FBSTtDQUNuQjtDQUVBLEFBQU8sZ0JBQWdCO0VBQ3JCLElBQUksQ0FBQyxLQUFLLGNBQWM7RUFDeEIsS0FBSyxZQUFZO0VBQ2pCLElBQUksQ0FBQyxLQUFLLE9BQU8sQ0FBQyxLQUFLLFNBQVM7RUFFaEMsTUFBTSxJQUFJLEtBQUssSUFBSTtFQUNuQixNQUFNLE1BQU0sS0FBSyxJQUFJLGlCQUFpQjtFQUN0QyxNQUFNLE9BQU8sS0FBSyxJQUFJLFdBQVc7RUFFakMsSUFBSSxPQUFPO0VBQ1gsSUFBSSxVQUFVLGVBQWUsS0FBSyxDQUFDO0VBQ25DLElBQUksVUFBVSw2QkFBNkIsS0FBSyxJQUFJLEdBQUk7RUFFeEQsS0FBSyxLQUFLLGVBQWUsTUFBTyxLQUFLLFdBQVcsQ0FBQztFQUNqRCxLQUFLLEtBQUssNkJBQTZCLE1BQU8sSUFBSSxHQUFJO0VBRXRELElBQUksUUFBUSxJQUFJO0VBQ2hCLEtBQUssUUFBUSxLQUFLLE9BQU87RUFDekIsSUFBSSxNQUFNLENBQUM7RUFDWCxJQUFJLEtBQUssSUFBSSxHQUFJO0NBQ25CO0NBRUEsQUFBTyxtQkFBbUI7RUFDeEIsSUFBSSxDQUFDLEtBQUssY0FBYztFQUN4QixLQUFLLFlBQVk7RUFDakIsSUFBSSxDQUFDLEtBQUssT0FBTyxDQUFDLEtBQUssU0FBUztFQUVoQyxNQUFNLElBQUksS0FBSyxJQUFJOztFQUVuQixNQUFNLE1BQU0sS0FBSyxJQUFJLGlCQUFpQjtFQUN0QyxNQUFNLE9BQU8sS0FBSyxJQUFJLFdBQVc7RUFDakMsSUFBSSxPQUFPO0VBQ1gsSUFBSSxVQUFVLGVBQWUsS0FBSyxDQUFDO0VBQ25DLElBQUksVUFBVSw2QkFBNkIsS0FBSyxJQUFJLEdBQUk7RUFFeEQsS0FBSyxLQUFLLGVBQWUsSUFBSyxDQUFDO0VBQy9CLEtBQUssS0FBSyx3QkFBd0IsTUFBTyxLQUFLLFdBQVcsSUFBSSxHQUFJO0VBQ2pFLEtBQUssS0FBSyw2QkFBNkIsTUFBTyxJQUFJLEVBQUc7RUFFckQsTUFBTSxTQUFTLEtBQUssSUFBSSxtQkFBbUI7RUFDM0MsT0FBTyxPQUFPO0VBQ2QsT0FBTyxVQUFVLGVBQWUsS0FBSyxDQUFDO0VBQ3RDLE9BQU8sVUFBVSw2QkFBNkIsTUFBTSxJQUFJLEVBQUc7RUFFM0QsSUFBSSxRQUFRLE1BQU07RUFDbEIsT0FBTyxRQUFRLElBQUk7RUFDbkIsS0FBSyxRQUFRLEtBQUssT0FBTztFQUN6QixJQUFJLE1BQU0sQ0FBQztFQUNYLElBQUksS0FBSyxJQUFJLEVBQUc7O0VBR2hCLE1BQU0sT0FBTyxLQUFLLElBQUksaUJBQWlCO0VBQ3ZDLE1BQU0sV0FBVyxLQUFLLElBQUksV0FBVztFQUNyQyxLQUFLLE9BQU87RUFDWixLQUFLLFVBQVUsZUFBZSxLQUFLLElBQUksR0FBSTtFQUMzQyxLQUFLLFVBQVUsNkJBQTZCLElBQUksSUFBSSxFQUFHO0VBQ3ZELFNBQVMsS0FBSyxlQUFlLEtBQU0sS0FBSyxXQUFXLElBQUksR0FBSTtFQUMzRCxTQUFTLEtBQUssNkJBQTZCLE1BQU8sSUFBSSxFQUFHO0VBRXpELEtBQUssUUFBUSxRQUFRO0VBQ3JCLFNBQVMsUUFBUSxLQUFLLE9BQU87RUFDN0IsS0FBSyxNQUFNLElBQUksR0FBSTtFQUNuQixLQUFLLEtBQUssSUFBSSxFQUFHO0NBQ25CO0NBRUEsQUFBTyxlQUFlO0VBQ3BCLElBQUksQ0FBQyxLQUFLLGNBQWM7RUFDeEIsS0FBSyxZQUFZO0VBQ2pCLElBQUksQ0FBQyxLQUFLLE9BQU8sQ0FBQyxLQUFLLFNBQVM7RUFFaEMsTUFBTSxJQUFJLEtBQUssSUFBSTtFQUNuQixNQUFNLE1BQU0sS0FBSyxJQUFJLGlCQUFpQjtFQUN0QyxNQUFNLE9BQU8sS0FBSyxJQUFJLFdBQVc7RUFDakMsTUFBTSxTQUFTLEtBQUssSUFBSSxtQkFBbUI7RUFFM0MsSUFBSSxPQUFPO0VBQ1gsSUFBSSxVQUFVLGVBQWUsSUFBSSxDQUFDO0VBQ2xDLElBQUksVUFBVSw2QkFBNkIsSUFBSSxJQUFJLEdBQUc7RUFFdEQsT0FBTyxPQUFPO0VBQ2QsT0FBTyxVQUFVLGVBQWUsS0FBSyxDQUFDO0VBQ3RDLE9BQU8sVUFBVSw2QkFBNkIsS0FBSyxJQUFJLEdBQUc7RUFFMUQsS0FBSyxLQUFLLGVBQWUsS0FBTSxDQUFDO0VBQ2hDLEtBQUssS0FBSyx3QkFBd0IsS0FBTSxLQUFLLFdBQVcsSUFBSSxFQUFHO0VBQy9ELEtBQUssS0FBSyw2QkFBNkIsTUFBTyxJQUFJLEdBQUc7RUFFckQsSUFBSSxRQUFRLE1BQU07RUFDbEIsT0FBTyxRQUFRLElBQUk7RUFDbkIsS0FBSyxRQUFRLEtBQUssT0FBTztFQUN6QixJQUFJLE1BQU0sQ0FBQztFQUNYLElBQUksS0FBSyxJQUFJLElBQUk7Q0FDbkI7Q0FFQSxBQUFPLGlCQUFpQjtFQUN0QixJQUFJLENBQUMsS0FBSyxjQUFjO0VBQ3hCLEtBQUssWUFBWTtFQUNqQixJQUFJLENBQUMsS0FBSyxPQUFPLENBQUMsS0FBSyxTQUFTO0VBRWhDLE1BQU0sSUFBSSxLQUFLLElBQUk7RUFDbkIsTUFBTSxNQUFNLEtBQUssSUFBSSxpQkFBaUI7RUFDdEMsTUFBTSxPQUFPLEtBQUssSUFBSSxXQUFXO0VBRWpDLElBQUksT0FBTztFQUNYLElBQUksVUFBVSxlQUFlLEtBQUssQ0FBQztFQUNuQyxJQUFJLFVBQVUsNkJBQTZCLEtBQUssSUFBSSxHQUFJO0VBRXhELEtBQUssS0FBSyxlQUFlLEtBQU0sS0FBSyxXQUFXLENBQUM7RUFDaEQsS0FBSyxLQUFLLDZCQUE2QixNQUFPLElBQUksR0FBSTtFQUV0RCxJQUFJLFFBQVEsSUFBSTtFQUNoQixLQUFLLFFBQVEsS0FBSyxPQUFPO0VBQ3pCLElBQUksTUFBTSxDQUFDO0VBQ1gsSUFBSSxLQUFLLElBQUksR0FBSTtDQUNuQjtDQUVBLEFBQU8sbUJBQW1CO0VBQ3hCLElBQUksQ0FBQyxLQUFLLGNBQWM7RUFDeEIsS0FBSyxZQUFZO0VBQ2pCLElBQUksQ0FBQyxLQUFLLE9BQU8sQ0FBQyxLQUFLLFNBQVM7RUFFaEMsTUFBTSxJQUFJLEtBQUssSUFBSTtFQUNuQixNQUFNLFFBQVE7R0FBQztHQUFRO0dBQVE7R0FBUTtFQUFNO0VBQzdDLE1BQU0sU0FBUyxNQUFNLE1BQU07R0FDekIsTUFBTSxNQUFNLEtBQUssSUFBSyxpQkFBaUI7R0FDdkMsTUFBTSxPQUFPLEtBQUssSUFBSyxXQUFXO0dBQ2xDLElBQUksT0FBTztHQUNYLElBQUksVUFBVSxlQUFlLE1BQU0sSUFBSSxJQUFJLEdBQUk7R0FFL0MsS0FBSyxLQUFLLGVBQWUsS0FBTSxLQUFLLFdBQVcsSUFBSSxJQUFJLEdBQUk7R0FDM0QsS0FBSyxLQUFLLDZCQUE2QixNQUFPLElBQUksSUFBSSxNQUFPLEVBQUc7R0FFaEUsSUFBSSxRQUFRLElBQUk7R0FDaEIsS0FBSyxRQUFRLEtBQUssT0FBUTtHQUMxQixJQUFJLE1BQU0sSUFBSSxJQUFJLEdBQUk7R0FDdEIsSUFBSSxLQUFLLElBQUksSUFBSSxNQUFPLEdBQUk7RUFDOUIsQ0FBQztDQUNIO0NBRUEsQUFBTyxXQUFXO0VBQ2hCLElBQUksQ0FBQyxLQUFLLGNBQWM7RUFDeEIsS0FBSyxZQUFZO0VBQ2pCLElBQUksQ0FBQyxLQUFLLE9BQU8sQ0FBQyxLQUFLLFNBQVM7RUFFaEMsTUFBTSxJQUFJLEtBQUssSUFBSTtFQUNuQixNQUFNLFFBQVEsQ0FBQyxRQUFRLE9BQU87RUFDOUIsTUFBTSxTQUFTLE1BQU0sTUFBTTtHQUN6QixNQUFNLE1BQU0sS0FBSyxJQUFLLGlCQUFpQjtHQUN2QyxNQUFNLE9BQU8sS0FBSyxJQUFLLFdBQVc7R0FDbEMsSUFBSSxPQUFPO0dBQ1gsSUFBSSxVQUFVLGVBQWUsTUFBTSxJQUFJLElBQUksR0FBSTtHQUUvQyxLQUFLLEtBQUssZUFBZSxNQUFPLEtBQUssV0FBVyxJQUFJLElBQUksR0FBSTtHQUM1RCxLQUFLLEtBQUssNkJBQTZCLE1BQU8sSUFBSSxJQUFJLE1BQU8sRUFBRztHQUVoRSxJQUFJLFFBQVEsSUFBSTtHQUNoQixLQUFLLFFBQVEsS0FBSyxPQUFRO0dBQzFCLElBQUksTUFBTSxJQUFJLElBQUksR0FBSTtHQUN0QixJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU8sR0FBSTtFQUM5QixDQUFDO0NBQ0g7Q0FFQSxBQUFPLGtCQUFrQjtFQUN2QixJQUFJLENBQUMsS0FBSyxjQUFjO0VBQ3hCLEtBQUssWUFBWTtFQUNqQixJQUFJLENBQUMsS0FBSyxPQUFPLENBQUMsS0FBSyxTQUFTO0VBRWhDLE1BQU0sSUFBSSxLQUFLLElBQUk7O0VBRW5CLE1BQU0sWUFBWTtHQUFDO0dBQUs7R0FBSztHQUFLO0dBQUs7RUFBRztFQUMxQyxVQUFVLFNBQVMsTUFBTSxRQUFRO0dBQy9CLE1BQU0sTUFBTSxLQUFLLElBQUssaUJBQWlCO0dBQ3ZDLE1BQU0sT0FBTyxLQUFLLElBQUssV0FBVztHQUNsQyxJQUFJLE9BQU8sTUFBTSxNQUFNLElBQUksU0FBUztHQUNwQyxJQUFJLFVBQVUsZUFBZSxNQUFNLENBQUM7R0FFcEMsS0FBSyxLQUFLLGVBQWdCLE1BQU8sTUFBTSxLQUFNLEtBQUssV0FBVyxDQUFDO0dBQzlELEtBQUssS0FBSyw2QkFBNkIsTUFBUSxJQUFJLEdBQUc7R0FFdEQsSUFBSSxRQUFRLElBQUk7R0FDaEIsS0FBSyxRQUFRLEtBQUssT0FBUTtHQUMxQixJQUFJLE1BQU0sQ0FBQztHQUNYLElBQUksS0FBSyxJQUFJLEdBQUc7RUFDbEIsQ0FBQztDQUNIO0NBRUEsQUFBTyxlQUFlO0VBQ3BCLElBQUksQ0FBQyxLQUFLLGNBQWM7RUFDeEIsS0FBSyxZQUFZO0VBQ2pCLElBQUksQ0FBQyxLQUFLLE9BQU8sQ0FBQyxLQUFLLFNBQVM7RUFFaEMsTUFBTSxJQUFJLEtBQUssSUFBSTtFQUNuQixNQUFNLFFBQVE7R0FBQztHQUFRO0dBQVE7R0FBUTtFQUFNO0VBQzdDLE1BQU0sU0FBUyxNQUFNLFFBQVE7R0FDM0IsTUFBTSxNQUFNLEtBQUssSUFBSyxpQkFBaUI7R0FDdkMsTUFBTSxPQUFPLEtBQUssSUFBSyxXQUFXO0dBQ2xDLElBQUksT0FBTztHQUNYLElBQUksVUFBVSxlQUFlLE1BQU0sSUFBSSxNQUFNLEdBQUk7R0FFakQsTUFBTSxTQUFTLEtBQUssSUFBSyxtQkFBbUI7R0FDNUMsT0FBTyxPQUFPO0dBQ2QsT0FBTyxVQUFVLGVBQWUsS0FBSyxJQUFJLE1BQU0sR0FBSTtHQUVuRCxLQUFLLEtBQUssZUFBZSxNQUFPLEtBQUssV0FBVyxJQUFJLE1BQU0sR0FBSTtHQUM5RCxLQUFLLEtBQUssNkJBQTZCLE1BQU8sSUFBSSxNQUFNLE1BQU8sRUFBRztHQUVsRSxJQUFJLFFBQVEsTUFBTTtHQUNsQixPQUFPLFFBQVEsSUFBSTtHQUNuQixLQUFLLFFBQVEsS0FBSyxPQUFRO0dBQzFCLElBQUksTUFBTSxJQUFJLE1BQU0sR0FBSTtHQUN4QixJQUFJLEtBQUssSUFBSSxNQUFNLE1BQU8sR0FBSTtFQUNoQyxDQUFDO0NBQ0g7Q0FFQSxBQUFPLFlBQVk7RUFDakIsSUFBSSxDQUFDLEtBQUssY0FBYztFQUN4QixLQUFLLFlBQVk7RUFDakIsSUFBSSxDQUFDLEtBQUssT0FBTyxDQUFDLEtBQUssU0FBUztFQUVoQyxNQUFNLElBQUksS0FBSyxJQUFJO0VBQ25CLE1BQU0sTUFBTSxLQUFLLElBQUksaUJBQWlCO0VBQ3RDLE1BQU0sT0FBTyxLQUFLLElBQUksV0FBVztFQUVqQyxJQUFJLE9BQU87RUFDWCxJQUFJLFVBQVUsZUFBZSxLQUFLLENBQUM7RUFDbkMsSUFBSSxVQUFVLDZCQUE2QixLQUFLLElBQUksR0FBSTtFQUV4RCxLQUFLLEtBQUssZUFBZSxNQUFPLEtBQUssV0FBVyxDQUFDO0VBQ2pELEtBQUssS0FBSyw2QkFBNkIsTUFBTyxJQUFJLEdBQUk7RUFFdEQsSUFBSSxRQUFRLElBQUk7RUFDaEIsS0FBSyxRQUFRLEtBQUssT0FBTztFQUN6QixJQUFJLE1BQU0sQ0FBQztFQUNYLElBQUksS0FBSyxJQUFJLEdBQUk7Q0FDbkI7O0NBSUEsQUFBTyxXQUFXO0VBQ2hCLElBQUksQ0FBQyxLQUFLLGdCQUFnQixLQUFLLGNBQWM7RUFDN0MsS0FBSyxZQUFZO0VBQ2pCLElBQUksQ0FBQyxLQUFLLE9BQU8sQ0FBQyxLQUFLLFdBQVc7RUFFbEMsS0FBSyxlQUFlO0VBQ3BCLEtBQUssVUFBVTs7RUFHZixNQUFNLGNBQWM7R0FBQztHQUFRO0dBQVE7R0FBUTtHQUFRO0dBQVE7RUFBTTs7RUFHbkUsS0FBSyxjQUFjLE9BQU8sa0JBQWtCO0dBQzFDLElBQUksQ0FBQyxLQUFLLGdCQUFnQixDQUFDLEtBQUssT0FBTyxDQUFDLEtBQUssV0FBVztHQUV4RCxNQUFNLElBQUksS0FBSyxJQUFJO0dBQ25CLE1BQU0sT0FBTyxLQUFLLFVBQVU7R0FDNUIsS0FBSzs7R0FHTCxJQUFJLFNBQVMsS0FBSyxTQUFTLEtBQUssU0FBUyxLQUFLLFNBQVMsTUFBTSxTQUFTLElBQUk7SUFDeEUsTUFBTSxXQUFXLFNBQVMsS0FBSyxTQUFTO0lBQ3hDLE1BQU0sV0FBVyxLQUFLLElBQUksaUJBQWlCO0lBQzNDLE1BQU0sWUFBWSxLQUFLLElBQUksV0FBVztJQUV0QyxTQUFTLE9BQU87SUFDaEIsU0FBUyxVQUFVLGVBQWUsV0FBVyxNQUFNLElBQUksQ0FBQztJQUN4RCxTQUFTLFVBQVUsNkJBQTZCLElBQUksS0FBSyxXQUFXLE1BQU8sR0FBSTtJQUUvRSxVQUFVLEtBQUssZ0JBQWdCLFdBQVcsTUFBTyxPQUFRLEtBQUssYUFBYSxDQUFDO0lBQzVFLFVBQVUsS0FBSyw2QkFBNkIsTUFBTyxLQUFLLFdBQVcsTUFBTyxHQUFJO0lBRTlFLFNBQVMsUUFBUSxTQUFTO0lBQzFCLFVBQVUsUUFBUSxLQUFLLFNBQVM7SUFDaEMsU0FBUyxNQUFNLENBQUM7SUFDaEIsU0FBUyxLQUFLLElBQUksR0FBSTtHQUN4Qjs7R0FHQSxJQUFJLFNBQVMsS0FBSyxTQUFTLEtBQUssU0FBUyxLQUFLLFNBQVMsTUFBTSxTQUFTLElBQUk7SUFDeEUsTUFBTSxZQUFZO0tBQUM7S0FBRztLQUFHO0tBQUc7S0FBRztLQUFHO0tBQUc7S0FBRztJQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU8sS0FBSyxVQUFVLElBQUssQ0FBQztJQUM1RSxNQUFNLE9BQU8sWUFBWSxZQUFZLFlBQVk7SUFFakQsTUFBTSxXQUFXLEtBQUssSUFBSSxpQkFBaUI7SUFDM0MsTUFBTSxZQUFZLEtBQUssSUFBSSxXQUFXO0lBQ3RDLE1BQU0sY0FBYyxLQUFLLElBQUksbUJBQW1CO0lBRWhELFNBQVMsT0FBTztJQUNoQixTQUFTLFVBQVUsZUFBZSxNQUFNLENBQUM7SUFFekMsWUFBWSxPQUFPO0lBQ25CLFlBQVksVUFBVSxlQUFlLE1BQU0sQ0FBQztJQUU1QyxVQUFVLEtBQUssZUFBZSxNQUFPLENBQUM7SUFDdEMsVUFBVSxLQUFLLHdCQUF3QixNQUFPLEtBQUssYUFBYSxJQUFJLEdBQUk7SUFDeEUsVUFBVSxLQUFLLDZCQUE2QixNQUFPLElBQUksR0FBSTtJQUUzRCxTQUFTLFFBQVEsV0FBVztJQUM1QixZQUFZLFFBQVEsU0FBUztJQUM3QixVQUFVLFFBQVEsS0FBSyxTQUFTO0lBRWhDLFNBQVMsTUFBTSxDQUFDO0lBQ2hCLFNBQVMsS0FBSyxJQUFJLEdBQUk7R0FDeEI7RUFDRixHQUFHLEdBQUc7Q0FDUjtDQUVBLEFBQU8sVUFBVTtFQUNmLEtBQUssZUFBZTtFQUNwQixJQUFJLEtBQUssZ0JBQWdCLE1BQU07R0FDN0IsY0FBYyxLQUFLLFdBQVc7R0FDOUIsS0FBSyxjQUFjO0VBQ3JCO0NBQ0Y7QUFDRjtBQUVBLE9BQU8sTUFBTSxlQUFlLElBQUksYUFBYSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTb3VuZEVmZmVjdHMudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG4vLyBQcm9jZWR1cmFsIFdlYiBBdWRpbyBBUEkgc291bmQgc3ludGhlc2l6ZXJcbi8vIFplcm8gZXh0ZXJuYWwgYXVkaW8gZmlsZXMgb3IgNDA0IGRlcGVuZGVuY2llc1xuXG5jbGFzcyBTb3VuZE1hbmFnZXIge1xuICBwcml2YXRlIGN0eDogQXVkaW9Db250ZXh0IHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgbWFzdGVyR2FpbjogR2Fpbk5vZGUgfCBudWxsID0gbnVsbDtcbiAgcHJpdmF0ZSBzZnhHYWluOiBHYWluTm9kZSB8IG51bGwgPSBudWxsO1xuICBwcml2YXRlIG11c2ljR2FpbjogR2Fpbk5vZGUgfCBudWxsID0gbnVsbDtcblxuICBwdWJsaWMgbWFzdGVyVm9sdW1lID0gMC44O1xuICBwdWJsaWMgc2Z4Vm9sdW1lID0gMC45O1xuICBwdWJsaWMgbXVzaWNWb2x1bWUgPSAwLjU7XG4gIHB1YmxpYyBzb3VuZEVuYWJsZWQgPSB0cnVlO1xuICBwdWJsaWMgbXVzaWNFbmFibGVkID0gdHJ1ZTtcblxuICBwcml2YXRlIGlzQmdtUGxheWluZyA9IGZhbHNlO1xuICBwcml2YXRlIGJnbUludGVydmFsOiBudW1iZXIgfCBudWxsID0gbnVsbDtcbiAgcHJpdmF0ZSBiZ21TdGVwID0gMDtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICAvLyBMYXp5IGluaXRpYWxpemUgb24gZmlyc3QgaW50ZXJhY3Rpb25cbiAgfVxuXG4gIHByaXZhdGUgaW5pdENvbnRleHQoKSB7XG4gICAgaWYgKCF0aGlzLmN0eCkge1xuICAgICAgY29uc3QgQXVkaW9DdHggPSB3aW5kb3cuQXVkaW9Db250ZXh0IHx8ICh3aW5kb3cgYXMgdW5rbm93biBhcyB7IHdlYmtpdEF1ZGlvQ29udGV4dDogdHlwZW9mIEF1ZGlvQ29udGV4dCB9KS53ZWJraXRBdWRpb0NvbnRleHQ7XG4gICAgICB0aGlzLmN0eCA9IG5ldyBBdWRpb0N0eCgpO1xuXG4gICAgICB0aGlzLm1hc3RlckdhaW4gPSB0aGlzLmN0eC5jcmVhdGVHYWluKCk7XG4gICAgICB0aGlzLm1hc3RlckdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSh0aGlzLm1hc3RlclZvbHVtZSwgdGhpcy5jdHguY3VycmVudFRpbWUpO1xuICAgICAgdGhpcy5tYXN0ZXJHYWluLmNvbm5lY3QodGhpcy5jdHguZGVzdGluYXRpb24pO1xuXG4gICAgICB0aGlzLnNmeEdhaW4gPSB0aGlzLmN0eC5jcmVhdGVHYWluKCk7XG4gICAgICB0aGlzLnNmeEdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSh0aGlzLnNmeFZvbHVtZSwgdGhpcy5jdHguY3VycmVudFRpbWUpO1xuICAgICAgdGhpcy5zZnhHYWluLmNvbm5lY3QodGhpcy5tYXN0ZXJHYWluKTtcblxuICAgICAgdGhpcy5tdXNpY0dhaW4gPSB0aGlzLmN0eC5jcmVhdGVHYWluKCk7XG4gICAgICB0aGlzLm11c2ljR2Fpbi5nYWluLnNldFZhbHVlQXRUaW1lKHRoaXMubXVzaWNWb2x1bWUsIHRoaXMuY3R4LmN1cnJlbnRUaW1lKTtcbiAgICAgIHRoaXMubXVzaWNHYWluLmNvbm5lY3QodGhpcy5tYXN0ZXJHYWluKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5jdHguc3RhdGUgPT09ICdzdXNwZW5kZWQnKSB7XG4gICAgICB0aGlzLmN0eC5yZXN1bWUoKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgdXBkYXRlVm9sdW1lcyhtYXN0ZXI6IG51bWJlciwgc2Z4OiBudW1iZXIsIG11c2ljOiBudW1iZXIsIHNvdW5kT246IGJvb2xlYW4sIG11c2ljT246IGJvb2xlYW4pIHtcbiAgICB0aGlzLm1hc3RlclZvbHVtZSA9IG1hc3RlcjtcbiAgICB0aGlzLnNmeFZvbHVtZSA9IHNmeDtcbiAgICB0aGlzLm11c2ljVm9sdW1lID0gbXVzaWM7XG4gICAgdGhpcy5zb3VuZEVuYWJsZWQgPSBzb3VuZE9uO1xuICAgIHRoaXMubXVzaWNFbmFibGVkID0gbXVzaWNPbjtcblxuICAgIGlmICh0aGlzLmN0eCAmJiB0aGlzLm1hc3RlckdhaW4gJiYgdGhpcy5zZnhHYWluICYmIHRoaXMubXVzaWNHYWluKSB7XG4gICAgICBjb25zdCB0ID0gdGhpcy5jdHguY3VycmVudFRpbWU7XG4gICAgICB0aGlzLm1hc3RlckdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZShzb3VuZE9uID8gbWFzdGVyIDogMCwgdCk7XG4gICAgICB0aGlzLnNmeEdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZShzZngsIHQpO1xuICAgICAgdGhpcy5tdXNpY0dhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZShtdXNpY09uID8gbXVzaWMgOiAwLCB0KTtcbiAgICB9XG5cbiAgICBpZiAoIW11c2ljT24gJiYgdGhpcy5pc0JnbVBsYXlpbmcpIHtcbiAgICAgIHRoaXMuc3RvcEJnbSgpO1xuICAgIH0gZWxzZSBpZiAobXVzaWNPbiAmJiAhdGhpcy5pc0JnbVBsYXlpbmcgJiYgdGhpcy5zb3VuZEVuYWJsZWQpIHtcbiAgICAgIHRoaXMuc3RhcnRCZ20oKTtcbiAgICB9XG4gIH1cblxuICAvLyAtLS0gU291bmQgRWZmZWN0cyAtLS1cblxuICBwdWJsaWMgcGxheVN3b3JkU2xhc2goY29tYm8gPSAxKSB7XG4gICAgaWYgKCF0aGlzLnNvdW5kRW5hYmxlZCkgcmV0dXJuO1xuICAgIHRoaXMuaW5pdENvbnRleHQoKTtcbiAgICBpZiAoIXRoaXMuY3R4IHx8ICF0aGlzLnNmeEdhaW4pIHJldHVybjtcblxuICAgIGNvbnN0IHQgPSB0aGlzLmN0eC5jdXJyZW50VGltZTtcbiAgICBjb25zdCBvc2MgPSB0aGlzLmN0eC5jcmVhdGVPc2NpbGxhdG9yKCk7XG4gICAgY29uc3QgZ2FpbiA9IHRoaXMuY3R4LmNyZWF0ZUdhaW4oKTtcbiAgICBjb25zdCBmaWx0ZXIgPSB0aGlzLmN0eC5jcmVhdGVCaXF1YWRGaWx0ZXIoKTtcblxuICAgIC8vIE5vaXNlIGJ1cnN0IGZvciB3aG9vc2hcbiAgICBjb25zdCBidWZmZXJTaXplID0gdGhpcy5jdHguc2FtcGxlUmF0ZSAqIDAuMTI7XG4gICAgY29uc3Qgbm9pc2VCdWZmZXIgPSB0aGlzLmN0eC5jcmVhdGVCdWZmZXIoMSwgYnVmZmVyU2l6ZSwgdGhpcy5jdHguc2FtcGxlUmF0ZSk7XG4gICAgY29uc3Qgb3V0cHV0ID0gbm9pc2VCdWZmZXIuZ2V0Q2hhbm5lbERhdGEoMCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBidWZmZXJTaXplOyBpKyspIHtcbiAgICAgIG91dHB1dFtpXSA9IE1hdGgucmFuZG9tKCkgKiAyIC0gMTtcbiAgICB9XG4gICAgY29uc3Qgd2hpdGVOb2lzZSA9IHRoaXMuY3R4LmNyZWF0ZUJ1ZmZlclNvdXJjZSgpO1xuICAgIHdoaXRlTm9pc2UuYnVmZmVyID0gbm9pc2VCdWZmZXI7XG5cbiAgICBmaWx0ZXIudHlwZSA9ICdiYW5kcGFzcyc7XG4gICAgZmlsdGVyLmZyZXF1ZW5jeS5zZXRWYWx1ZUF0VGltZSg4MDAgKyBjb21ibyAqIDMwMCwgdCk7XG4gICAgZmlsdGVyLmZyZXF1ZW5jeS5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDI0MDAgKyBjb21ibyAqIDQwMCwgdCArIDAuMSk7XG4gICAgZmlsdGVyLlEuc2V0VmFsdWVBdFRpbWUoMi41LCB0KTtcblxuICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgwLjQgKiB0aGlzLnNmeFZvbHVtZSwgdCk7XG4gICAgZ2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4wMDEsIHQgKyAwLjEyKTtcblxuICAgIHdoaXRlTm9pc2UuY29ubmVjdChmaWx0ZXIpO1xuICAgIGZpbHRlci5jb25uZWN0KGdhaW4pO1xuICAgIGdhaW4uY29ubmVjdCh0aGlzLnNmeEdhaW4pO1xuXG4gICAgd2hpdGVOb2lzZS5zdGFydCh0KTtcbiAgICB3aGl0ZU5vaXNlLnN0b3AodCArIDAuMTIpO1xuXG4gICAgLy8gU3VidGxlIGJsYWRlIHJpbmdcbiAgICBvc2MudHlwZSA9ICdzaW5lJztcbiAgICBvc2MuZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKDEyMDAgKyBjb21ibyAqIDQwMCwgdCk7XG4gICAgb3NjLmZyZXF1ZW5jeS5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDMwMCwgdCArIDAuMSk7XG4gICAgY29uc3QgYmxhZGVHYWluID0gdGhpcy5jdHguY3JlYXRlR2FpbigpO1xuICAgIGJsYWRlR2Fpbi5nYWluLnNldFZhbHVlQXRUaW1lKDAuMTUgKiB0aGlzLnNmeFZvbHVtZSwgdCk7XG4gICAgYmxhZGVHYWluLmdhaW4uZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSgwLjAwMSwgdCArIDAuMSk7XG5cbiAgICBvc2MuY29ubmVjdChibGFkZUdhaW4pO1xuICAgIGJsYWRlR2Fpbi5jb25uZWN0KHRoaXMuc2Z4R2Fpbik7XG4gICAgb3NjLnN0YXJ0KHQpO1xuICAgIG9zYy5zdG9wKHQgKyAwLjEpO1xuICB9XG5cbiAgcHVibGljIHBsYXlTd29yZENsYXNoKCkge1xuICAgIGlmICghdGhpcy5zb3VuZEVuYWJsZWQpIHJldHVybjtcbiAgICB0aGlzLmluaXRDb250ZXh0KCk7XG4gICAgaWYgKCF0aGlzLmN0eCB8fCAhdGhpcy5zZnhHYWluKSByZXR1cm47XG5cbiAgICBjb25zdCB0ID0gdGhpcy5jdHguY3VycmVudFRpbWU7XG4gICAgY29uc3QgZnJlcXMgPSBbMTg0MCwgMjQ2MCwgMzcyMF07XG5cbiAgICBmcmVxcy5mb3JFYWNoKGZyZXEgPT4ge1xuICAgICAgY29uc3Qgb3NjID0gdGhpcy5jdHghLmNyZWF0ZU9zY2lsbGF0b3IoKTtcbiAgICAgIGNvbnN0IGdhaW4gPSB0aGlzLmN0eCEuY3JlYXRlR2FpbigpO1xuICAgICAgb3NjLnR5cGUgPSAndHJpYW5nbGUnO1xuICAgICAgb3NjLmZyZXF1ZW5jeS5zZXRWYWx1ZUF0VGltZShmcmVxLCB0KTtcbiAgICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgwLjI1ICogdGhpcy5zZnhWb2x1bWUsIHQpO1xuICAgICAgZ2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4wMDEsIHQgKyAwLjI4KTtcblxuICAgICAgb3NjLmNvbm5lY3QoZ2Fpbik7XG4gICAgICBnYWluLmNvbm5lY3QodGhpcy5zZnhHYWluISk7XG4gICAgICBvc2Muc3RhcnQodCk7XG4gICAgICBvc2Muc3RvcCh0ICsgMC4zKTtcbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBwbGF5SGVhdnlJbXBhY3QoKSB7XG4gICAgaWYgKCF0aGlzLnNvdW5kRW5hYmxlZCkgcmV0dXJuO1xuICAgIHRoaXMuaW5pdENvbnRleHQoKTtcbiAgICBpZiAoIXRoaXMuY3R4IHx8ICF0aGlzLnNmeEdhaW4pIHJldHVybjtcblxuICAgIGNvbnN0IHQgPSB0aGlzLmN0eC5jdXJyZW50VGltZTtcbiAgICBjb25zdCBvc2MgPSB0aGlzLmN0eC5jcmVhdGVPc2NpbGxhdG9yKCk7XG4gICAgY29uc3QgZ2FpbiA9IHRoaXMuY3R4LmNyZWF0ZUdhaW4oKTtcblxuICAgIG9zYy50eXBlID0gJ3NpbmUnO1xuICAgIG9zYy5mcmVxdWVuY3kuc2V0VmFsdWVBdFRpbWUoMTQwLCB0KTtcbiAgICBvc2MuZnJlcXVlbmN5LmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMzUsIHQgKyAwLjI1KTtcblxuICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgwLjYgKiB0aGlzLnNmeFZvbHVtZSwgdCk7XG4gICAgZ2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4wMDEsIHQgKyAwLjI1KTtcblxuICAgIG9zYy5jb25uZWN0KGdhaW4pO1xuICAgIGdhaW4uY29ubmVjdCh0aGlzLnNmeEdhaW4pO1xuICAgIG9zYy5zdGFydCh0KTtcbiAgICBvc2Muc3RvcCh0ICsgMC4yNSk7XG4gIH1cblxuICBwdWJsaWMgcGxheURvZGdlUm9sbCgpIHtcbiAgICBpZiAoIXRoaXMuc291bmRFbmFibGVkKSByZXR1cm47XG4gICAgdGhpcy5pbml0Q29udGV4dCgpO1xuICAgIGlmICghdGhpcy5jdHggfHwgIXRoaXMuc2Z4R2FpbikgcmV0dXJuO1xuXG4gICAgY29uc3QgdCA9IHRoaXMuY3R4LmN1cnJlbnRUaW1lO1xuICAgIGNvbnN0IG9zYyA9IHRoaXMuY3R4LmNyZWF0ZU9zY2lsbGF0b3IoKTtcbiAgICBjb25zdCBnYWluID0gdGhpcy5jdHguY3JlYXRlR2FpbigpO1xuXG4gICAgb3NjLnR5cGUgPSAnc2luZSc7XG4gICAgb3NjLmZyZXF1ZW5jeS5zZXRWYWx1ZUF0VGltZSg0NTAsIHQpO1xuICAgIG9zYy5mcmVxdWVuY3kuZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSgxMjAsIHQgKyAwLjIyKTtcblxuICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgwLjI1ICogdGhpcy5zZnhWb2x1bWUsIHQpO1xuICAgIGdhaW4uZ2Fpbi5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDAuMDAxLCB0ICsgMC4yMik7XG5cbiAgICBvc2MuY29ubmVjdChnYWluKTtcbiAgICBnYWluLmNvbm5lY3QodGhpcy5zZnhHYWluKTtcbiAgICBvc2Muc3RhcnQodCk7XG4gICAgb3NjLnN0b3AodCArIDAuMjIpO1xuICB9XG5cbiAgcHVibGljIHBsYXlTcGVjaWFsQmxhc3QoKSB7XG4gICAgaWYgKCF0aGlzLnNvdW5kRW5hYmxlZCkgcmV0dXJuO1xuICAgIHRoaXMuaW5pdENvbnRleHQoKTtcbiAgICBpZiAoIXRoaXMuY3R4IHx8ICF0aGlzLnNmeEdhaW4pIHJldHVybjtcblxuICAgIGNvbnN0IHQgPSB0aGlzLmN0eC5jdXJyZW50VGltZTtcbiAgICAvLyBQb3dlciBjaGFyZ2VcbiAgICBjb25zdCBvc2MgPSB0aGlzLmN0eC5jcmVhdGVPc2NpbGxhdG9yKCk7XG4gICAgY29uc3QgZ2FpbiA9IHRoaXMuY3R4LmNyZWF0ZUdhaW4oKTtcbiAgICBvc2MudHlwZSA9ICdzYXd0b290aCc7XG4gICAgb3NjLmZyZXF1ZW5jeS5zZXRWYWx1ZUF0VGltZSgxMjAsIHQpO1xuICAgIG9zYy5mcmVxdWVuY3kuZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSg3ODAsIHQgKyAwLjM1KTtcblxuICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgwLjEsIHQpO1xuICAgIGdhaW4uZ2Fpbi5saW5lYXJSYW1wVG9WYWx1ZUF0VGltZSgwLjQ1ICogdGhpcy5zZnhWb2x1bWUsIHQgKyAwLjM1KTtcbiAgICBnYWluLmdhaW4uZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSgwLjAwMSwgdCArIDAuOCk7XG5cbiAgICBjb25zdCBmaWx0ZXIgPSB0aGlzLmN0eC5jcmVhdGVCaXF1YWRGaWx0ZXIoKTtcbiAgICBmaWx0ZXIudHlwZSA9ICdsb3dwYXNzJztcbiAgICBmaWx0ZXIuZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKDMwMCwgdCk7XG4gICAgZmlsdGVyLmZyZXF1ZW5jeS5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDMyMDAsIHQgKyAwLjQpO1xuXG4gICAgb3NjLmNvbm5lY3QoZmlsdGVyKTtcbiAgICBmaWx0ZXIuY29ubmVjdChnYWluKTtcbiAgICBnYWluLmNvbm5lY3QodGhpcy5zZnhHYWluKTtcbiAgICBvc2Muc3RhcnQodCk7XG4gICAgb3NjLnN0b3AodCArIDAuOCk7XG5cbiAgICAvLyBCb29tIGhpdFxuICAgIGNvbnN0IGJvb20gPSB0aGlzLmN0eC5jcmVhdGVPc2NpbGxhdG9yKCk7XG4gICAgY29uc3QgYm9vbUdhaW4gPSB0aGlzLmN0eC5jcmVhdGVHYWluKCk7XG4gICAgYm9vbS50eXBlID0gJ3NpbmUnO1xuICAgIGJvb20uZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKDE4MCwgdCArIDAuMzUpO1xuICAgIGJvb20uZnJlcXVlbmN5LmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMzAsIHQgKyAwLjkpO1xuICAgIGJvb21HYWluLmdhaW4uc2V0VmFsdWVBdFRpbWUoMC43ICogdGhpcy5zZnhWb2x1bWUsIHQgKyAwLjM1KTtcbiAgICBib29tR2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4wMDEsIHQgKyAwLjkpO1xuXG4gICAgYm9vbS5jb25uZWN0KGJvb21HYWluKTtcbiAgICBib29tR2Fpbi5jb25uZWN0KHRoaXMuc2Z4R2Fpbik7XG4gICAgYm9vbS5zdGFydCh0ICsgMC4zNSk7XG4gICAgYm9vbS5zdG9wKHQgKyAwLjkpO1xuICB9XG5cbiAgcHVibGljIHBsYXlCb3NzUm9hcigpIHtcbiAgICBpZiAoIXRoaXMuc291bmRFbmFibGVkKSByZXR1cm47XG4gICAgdGhpcy5pbml0Q29udGV4dCgpO1xuICAgIGlmICghdGhpcy5jdHggfHwgIXRoaXMuc2Z4R2FpbikgcmV0dXJuO1xuXG4gICAgY29uc3QgdCA9IHRoaXMuY3R4LmN1cnJlbnRUaW1lO1xuICAgIGNvbnN0IG9zYyA9IHRoaXMuY3R4LmNyZWF0ZU9zY2lsbGF0b3IoKTtcbiAgICBjb25zdCBnYWluID0gdGhpcy5jdHguY3JlYXRlR2FpbigpO1xuICAgIGNvbnN0IGZpbHRlciA9IHRoaXMuY3R4LmNyZWF0ZUJpcXVhZEZpbHRlcigpO1xuXG4gICAgb3NjLnR5cGUgPSAnc2F3dG9vdGgnO1xuICAgIG9zYy5mcmVxdWVuY3kuc2V0VmFsdWVBdFRpbWUoODAsIHQpO1xuICAgIG9zYy5mcmVxdWVuY3kuZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSg0NSwgdCArIDEuMik7XG5cbiAgICBmaWx0ZXIudHlwZSA9ICdsb3dwYXNzJztcbiAgICBmaWx0ZXIuZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKDQ1MCwgdCk7XG4gICAgZmlsdGVyLmZyZXF1ZW5jeS5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDE1MCwgdCArIDEuMik7XG5cbiAgICBnYWluLmdhaW4uc2V0VmFsdWVBdFRpbWUoMC4wMSwgdCk7XG4gICAgZ2Fpbi5nYWluLmxpbmVhclJhbXBUb1ZhbHVlQXRUaW1lKDAuNiAqIHRoaXMuc2Z4Vm9sdW1lLCB0ICsgMC4yKTtcbiAgICBnYWluLmdhaW4uZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSgwLjAwMSwgdCArIDEuMik7XG5cbiAgICBvc2MuY29ubmVjdChmaWx0ZXIpO1xuICAgIGZpbHRlci5jb25uZWN0KGdhaW4pO1xuICAgIGdhaW4uY29ubmVjdCh0aGlzLnNmeEdhaW4pO1xuICAgIG9zYy5zdGFydCh0KTtcbiAgICBvc2Muc3RvcCh0ICsgMS4yNSk7XG4gIH1cblxuICBwdWJsaWMgcGxheUFycm93U2hvb3QoKSB7XG4gICAgaWYgKCF0aGlzLnNvdW5kRW5hYmxlZCkgcmV0dXJuO1xuICAgIHRoaXMuaW5pdENvbnRleHQoKTtcbiAgICBpZiAoIXRoaXMuY3R4IHx8ICF0aGlzLnNmeEdhaW4pIHJldHVybjtcblxuICAgIGNvbnN0IHQgPSB0aGlzLmN0eC5jdXJyZW50VGltZTtcbiAgICBjb25zdCBvc2MgPSB0aGlzLmN0eC5jcmVhdGVPc2NpbGxhdG9yKCk7XG4gICAgY29uc3QgZ2FpbiA9IHRoaXMuY3R4LmNyZWF0ZUdhaW4oKTtcblxuICAgIG9zYy50eXBlID0gJ3RyaWFuZ2xlJztcbiAgICBvc2MuZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKDgwMCwgdCk7XG4gICAgb3NjLmZyZXF1ZW5jeS5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDIwMCwgdCArIDAuMTUpO1xuXG4gICAgZ2Fpbi5nYWluLnNldFZhbHVlQXRUaW1lKDAuMyAqIHRoaXMuc2Z4Vm9sdW1lLCB0KTtcbiAgICBnYWluLmdhaW4uZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSgwLjAwMSwgdCArIDAuMTUpO1xuXG4gICAgb3NjLmNvbm5lY3QoZ2Fpbik7XG4gICAgZ2Fpbi5jb25uZWN0KHRoaXMuc2Z4R2Fpbik7XG4gICAgb3NjLnN0YXJ0KHQpO1xuICAgIG9zYy5zdG9wKHQgKyAwLjE1KTtcbiAgfVxuXG4gIHB1YmxpYyBwbGF5SGVhbHRoUGlja3VwKCkge1xuICAgIGlmICghdGhpcy5zb3VuZEVuYWJsZWQpIHJldHVybjtcbiAgICB0aGlzLmluaXRDb250ZXh0KCk7XG4gICAgaWYgKCF0aGlzLmN0eCB8fCAhdGhpcy5zZnhHYWluKSByZXR1cm47XG5cbiAgICBjb25zdCB0ID0gdGhpcy5jdHguY3VycmVudFRpbWU7XG4gICAgY29uc3Qgbm90ZXMgPSBbNTIzLjI1LCA2NTkuMjUsIDc4My45OSwgMTA0Ni41XTsgLy8gQzUgLT4gRTUgLT4gRzUgLT4gQzZcbiAgICBub3Rlcy5mb3JFYWNoKChmcmVxLCBpKSA9PiB7XG4gICAgICBjb25zdCBvc2MgPSB0aGlzLmN0eCEuY3JlYXRlT3NjaWxsYXRvcigpO1xuICAgICAgY29uc3QgZ2FpbiA9IHRoaXMuY3R4IS5jcmVhdGVHYWluKCk7XG4gICAgICBvc2MudHlwZSA9ICd0cmlhbmdsZSc7XG4gICAgICBvc2MuZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKGZyZXEsIHQgKyBpICogMC4wNSk7XG5cbiAgICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgwLjIgKiB0aGlzLnNmeFZvbHVtZSwgdCArIGkgKiAwLjA1KTtcbiAgICAgIGdhaW4uZ2Fpbi5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDAuMDAxLCB0ICsgaSAqIDAuMDUgKyAwLjMpO1xuXG4gICAgICBvc2MuY29ubmVjdChnYWluKTtcbiAgICAgIGdhaW4uY29ubmVjdCh0aGlzLnNmeEdhaW4hKTtcbiAgICAgIG9zYy5zdGFydCh0ICsgaSAqIDAuMDUpO1xuICAgICAgb3NjLnN0b3AodCArIGkgKiAwLjA1ICsgMC4zMik7XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgcGxheUNvaW4oKSB7XG4gICAgaWYgKCF0aGlzLnNvdW5kRW5hYmxlZCkgcmV0dXJuO1xuICAgIHRoaXMuaW5pdENvbnRleHQoKTtcbiAgICBpZiAoIXRoaXMuY3R4IHx8ICF0aGlzLnNmeEdhaW4pIHJldHVybjtcblxuICAgIGNvbnN0IHQgPSB0aGlzLmN0eC5jdXJyZW50VGltZTtcbiAgICBjb25zdCBub3RlcyA9IFs5ODcuNzcsIDEzMTguNTFdOyAvLyBCNSwgRTZcbiAgICBub3Rlcy5mb3JFYWNoKChmcmVxLCBpKSA9PiB7XG4gICAgICBjb25zdCBvc2MgPSB0aGlzLmN0eCEuY3JlYXRlT3NjaWxsYXRvcigpO1xuICAgICAgY29uc3QgZ2FpbiA9IHRoaXMuY3R4IS5jcmVhdGVHYWluKCk7XG4gICAgICBvc2MudHlwZSA9ICdzaW5lJztcbiAgICAgIG9zYy5mcmVxdWVuY3kuc2V0VmFsdWVBdFRpbWUoZnJlcSwgdCArIGkgKiAwLjA4KTtcblxuICAgICAgZ2Fpbi5nYWluLnNldFZhbHVlQXRUaW1lKDAuMjUgKiB0aGlzLnNmeFZvbHVtZSwgdCArIGkgKiAwLjA4KTtcbiAgICAgIGdhaW4uZ2Fpbi5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDAuMDAxLCB0ICsgaSAqIDAuMDggKyAwLjIpO1xuXG4gICAgICBvc2MuY29ubmVjdChnYWluKTtcbiAgICAgIGdhaW4uY29ubmVjdCh0aGlzLnNmeEdhaW4hKTtcbiAgICAgIG9zYy5zdGFydCh0ICsgaSAqIDAuMDgpO1xuICAgICAgb3NjLnN0b3AodCArIGkgKiAwLjA4ICsgMC4yMik7XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgcGxheVZpY3RvcnlHb25nKCkge1xuICAgIGlmICghdGhpcy5zb3VuZEVuYWJsZWQpIHJldHVybjtcbiAgICB0aGlzLmluaXRDb250ZXh0KCk7XG4gICAgaWYgKCF0aGlzLmN0eCB8fCAhdGhpcy5zZnhHYWluKSByZXR1cm47XG5cbiAgICBjb25zdCB0ID0gdGhpcy5jdHguY3VycmVudFRpbWU7XG4gICAgLy8gSmFwYW5lc2UgQm9uc2hvIFRlbXBsZSBCZWxsIGhhcm1vbmljc1xuICAgIGNvbnN0IGhhcm1vbmljcyA9IFsxMTAsIDIyMCwgMzEwLCA0NDAsIDU4MF07XG4gICAgaGFybW9uaWNzLmZvckVhY2goKGZyZXEsIGlkeCkgPT4ge1xuICAgICAgY29uc3Qgb3NjID0gdGhpcy5jdHghLmNyZWF0ZU9zY2lsbGF0b3IoKTtcbiAgICAgIGNvbnN0IGdhaW4gPSB0aGlzLmN0eCEuY3JlYXRlR2FpbigpO1xuICAgICAgb3NjLnR5cGUgPSBpZHggJSAyID09PSAwID8gJ3NpbmUnIDogJ3RyaWFuZ2xlJztcbiAgICAgIG9zYy5mcmVxdWVuY3kuc2V0VmFsdWVBdFRpbWUoZnJlcSwgdCk7XG5cbiAgICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgoMC40IC8gKGlkeCArIDEpKSAqIHRoaXMuc2Z4Vm9sdW1lLCB0KTtcbiAgICAgIGdhaW4uZ2Fpbi5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDAuMDAwMSwgdCArIDMuNSk7XG5cbiAgICAgIG9zYy5jb25uZWN0KGdhaW4pO1xuICAgICAgZ2Fpbi5jb25uZWN0KHRoaXMuc2Z4R2FpbiEpO1xuICAgICAgb3NjLnN0YXJ0KHQpO1xuICAgICAgb3NjLnN0b3AodCArIDMuNik7XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgcGxheUdhbWVPdmVyKCkge1xuICAgIGlmICghdGhpcy5zb3VuZEVuYWJsZWQpIHJldHVybjtcbiAgICB0aGlzLmluaXRDb250ZXh0KCk7XG4gICAgaWYgKCF0aGlzLmN0eCB8fCAhdGhpcy5zZnhHYWluKSByZXR1cm47XG5cbiAgICBjb25zdCB0ID0gdGhpcy5jdHguY3VycmVudFRpbWU7XG4gICAgY29uc3Qgbm90ZXMgPSBbMjkzLjY2LCAyNjEuNjMsIDIyMC4wMCwgMTc0LjYxXTsgLy8gRDQsIEM0LCBBMywgRjNcbiAgICBub3Rlcy5mb3JFYWNoKChmcmVxLCBpZHgpID0+IHtcbiAgICAgIGNvbnN0IG9zYyA9IHRoaXMuY3R4IS5jcmVhdGVPc2NpbGxhdG9yKCk7XG4gICAgICBjb25zdCBnYWluID0gdGhpcy5jdHghLmNyZWF0ZUdhaW4oKTtcbiAgICAgIG9zYy50eXBlID0gJ3Nhd3Rvb3RoJztcbiAgICAgIG9zYy5mcmVxdWVuY3kuc2V0VmFsdWVBdFRpbWUoZnJlcSwgdCArIGlkeCAqIDAuMjUpO1xuXG4gICAgICBjb25zdCBmaWx0ZXIgPSB0aGlzLmN0eCEuY3JlYXRlQmlxdWFkRmlsdGVyKCk7XG4gICAgICBmaWx0ZXIudHlwZSA9ICdsb3dwYXNzJztcbiAgICAgIGZpbHRlci5mcmVxdWVuY3kuc2V0VmFsdWVBdFRpbWUoNjAwLCB0ICsgaWR4ICogMC4yNSk7XG5cbiAgICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgwLjI1ICogdGhpcy5zZnhWb2x1bWUsIHQgKyBpZHggKiAwLjI1KTtcbiAgICAgIGdhaW4uZ2Fpbi5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDAuMDAxLCB0ICsgaWR4ICogMC4yNSArIDAuNSk7XG5cbiAgICAgIG9zYy5jb25uZWN0KGZpbHRlcik7XG4gICAgICBmaWx0ZXIuY29ubmVjdChnYWluKTtcbiAgICAgIGdhaW4uY29ubmVjdCh0aGlzLnNmeEdhaW4hKTtcbiAgICAgIG9zYy5zdGFydCh0ICsgaWR4ICogMC4yNSk7XG4gICAgICBvc2Muc3RvcCh0ICsgaWR4ICogMC4yNSArIDAuNTIpO1xuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIHBsYXlDbGljaygpIHtcbiAgICBpZiAoIXRoaXMuc291bmRFbmFibGVkKSByZXR1cm47XG4gICAgdGhpcy5pbml0Q29udGV4dCgpO1xuICAgIGlmICghdGhpcy5jdHggfHwgIXRoaXMuc2Z4R2FpbikgcmV0dXJuO1xuXG4gICAgY29uc3QgdCA9IHRoaXMuY3R4LmN1cnJlbnRUaW1lO1xuICAgIGNvbnN0IG9zYyA9IHRoaXMuY3R4LmNyZWF0ZU9zY2lsbGF0b3IoKTtcbiAgICBjb25zdCBnYWluID0gdGhpcy5jdHguY3JlYXRlR2FpbigpO1xuXG4gICAgb3NjLnR5cGUgPSAnc2luZSc7XG4gICAgb3NjLmZyZXF1ZW5jeS5zZXRWYWx1ZUF0VGltZSg5MDAsIHQpO1xuICAgIG9zYy5mcmVxdWVuY3kuZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSgzMDAsIHQgKyAwLjA0KTtcblxuICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgwLjE1ICogdGhpcy5zZnhWb2x1bWUsIHQpO1xuICAgIGdhaW4uZ2Fpbi5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDAuMDAxLCB0ICsgMC4wNCk7XG5cbiAgICBvc2MuY29ubmVjdChnYWluKTtcbiAgICBnYWluLmNvbm5lY3QodGhpcy5zZnhHYWluKTtcbiAgICBvc2Muc3RhcnQodCk7XG4gICAgb3NjLnN0b3AodCArIDAuMDQpO1xuICB9XG5cbiAgLy8gLS0tIFByb2NlZHVyYWwgSmFwYW5lc2UgVGFpa28gJiBGbHV0ZSBCR00gLS0tXG5cbiAgcHVibGljIHN0YXJ0QmdtKCkge1xuICAgIGlmICghdGhpcy5tdXNpY0VuYWJsZWQgfHwgdGhpcy5pc0JnbVBsYXlpbmcpIHJldHVybjtcbiAgICB0aGlzLmluaXRDb250ZXh0KCk7XG4gICAgaWYgKCF0aGlzLmN0eCB8fCAhdGhpcy5tdXNpY0dhaW4pIHJldHVybjtcblxuICAgIHRoaXMuaXNCZ21QbGF5aW5nID0gdHJ1ZTtcbiAgICB0aGlzLmJnbVN0ZXAgPSAwO1xuXG4gICAgLy8gSmFwYW5lc2UgSW5zZW4gLyBIaXJham9zaGkgcGVudGF0b25pYyBzY2FsZSAoRDQsIEViNCwgRzQsIEE0LCBCYjQsIEQ1KVxuICAgIGNvbnN0IG1lbG9keU5vdGVzID0gWzI5My42NiwgMzExLjEzLCAzOTIuMDAsIDQ0MC4wMCwgNDY2LjE2LCA1ODcuMzNdO1xuXG4gICAgLy8gRXZlcnkgMjUwbXMgKDEyMCBCUE0gc2l4dGVlbnRoIC8gZWlnaHRoIG5vdGVzKVxuICAgIHRoaXMuYmdtSW50ZXJ2YWwgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgaWYgKCF0aGlzLm11c2ljRW5hYmxlZCB8fCAhdGhpcy5jdHggfHwgIXRoaXMubXVzaWNHYWluKSByZXR1cm47XG5cbiAgICAgIGNvbnN0IHQgPSB0aGlzLmN0eC5jdXJyZW50VGltZTtcbiAgICAgIGNvbnN0IHN0ZXAgPSB0aGlzLmJnbVN0ZXAgJSAxNjtcbiAgICAgIHRoaXMuYmdtU3RlcCsrO1xuXG4gICAgICAvLyBUYWlrbyBEcnVtIChTdHJvbmcgb24gYmVhdCAwLCA0LCA4LCAxMiwgYWNjZW50ZWQgb24gMTAsIDE0KVxuICAgICAgaWYgKHN0ZXAgPT09IDAgfHwgc3RlcCA9PT0gNCB8fCBzdGVwID09PSA4IHx8IHN0ZXAgPT09IDEyIHx8IHN0ZXAgPT09IDEwKSB7XG4gICAgICAgIGNvbnN0IGlzU3Ryb25nID0gc3RlcCA9PT0gMCB8fCBzdGVwID09PSA4O1xuICAgICAgICBjb25zdCB0YWlrb09zYyA9IHRoaXMuY3R4LmNyZWF0ZU9zY2lsbGF0b3IoKTtcbiAgICAgICAgY29uc3QgdGFpa29HYWluID0gdGhpcy5jdHguY3JlYXRlR2FpbigpO1xuXG4gICAgICAgIHRhaWtvT3NjLnR5cGUgPSAnc2luZSc7XG4gICAgICAgIHRhaWtvT3NjLmZyZXF1ZW5jeS5zZXRWYWx1ZUF0VGltZShpc1N0cm9uZyA/IDExMCA6IDg1LCB0KTtcbiAgICAgICAgdGFpa29Pc2MuZnJlcXVlbmN5LmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMzUsIHQgKyAoaXNTdHJvbmcgPyAwLjM1IDogMC4yKSk7XG5cbiAgICAgICAgdGFpa29HYWluLmdhaW4uc2V0VmFsdWVBdFRpbWUoKGlzU3Ryb25nID8gMC40NSA6IDAuMjgpICogdGhpcy5tdXNpY1ZvbHVtZSwgdCk7XG4gICAgICAgIHRhaWtvR2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4wMDEsIHQgKyAoaXNTdHJvbmcgPyAwLjM1IDogMC4yKSk7XG5cbiAgICAgICAgdGFpa29Pc2MuY29ubmVjdCh0YWlrb0dhaW4pO1xuICAgICAgICB0YWlrb0dhaW4uY29ubmVjdCh0aGlzLm11c2ljR2Fpbik7XG4gICAgICAgIHRhaWtvT3NjLnN0YXJ0KHQpO1xuICAgICAgICB0YWlrb09zYy5zdG9wKHQgKyAwLjM2KTtcbiAgICAgIH1cblxuICAgICAgLy8gQmFtYm9vIFNoYWt1aGFjaGkgZmx1dGUgbm90ZSBvbiBzeW5jb3BhdGVkIHN0ZXBzXG4gICAgICBpZiAoc3RlcCA9PT0gMCB8fCBzdGVwID09PSAzIHx8IHN0ZXAgPT09IDYgfHwgc3RlcCA9PT0gMTEgfHwgc3RlcCA9PT0gMTQpIHtcbiAgICAgICAgY29uc3Qgbm90ZUluZGV4ID0gWzAsIDIsIDMsIDEsIDQsIDIsIDUsIDNdW01hdGguZmxvb3IoKHRoaXMuYmdtU3RlcCAvIDQpICUgOCldO1xuICAgICAgICBjb25zdCBmcmVxID0gbWVsb2R5Tm90ZXNbbm90ZUluZGV4ICUgbWVsb2R5Tm90ZXMubGVuZ3RoXTtcblxuICAgICAgICBjb25zdCBmbHV0ZU9zYyA9IHRoaXMuY3R4LmNyZWF0ZU9zY2lsbGF0b3IoKTtcbiAgICAgICAgY29uc3QgZmx1dGVHYWluID0gdGhpcy5jdHguY3JlYXRlR2FpbigpO1xuICAgICAgICBjb25zdCBmbHV0ZUZpbHRlciA9IHRoaXMuY3R4LmNyZWF0ZUJpcXVhZEZpbHRlcigpO1xuXG4gICAgICAgIGZsdXRlT3NjLnR5cGUgPSAndHJpYW5nbGUnO1xuICAgICAgICBmbHV0ZU9zYy5mcmVxdWVuY3kuc2V0VmFsdWVBdFRpbWUoZnJlcSwgdCk7XG5cbiAgICAgICAgZmx1dGVGaWx0ZXIudHlwZSA9ICdsb3dwYXNzJztcbiAgICAgICAgZmx1dGVGaWx0ZXIuZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKDE0MDAsIHQpO1xuXG4gICAgICAgIGZsdXRlR2Fpbi5nYWluLnNldFZhbHVlQXRUaW1lKDAuMDAxLCB0KTtcbiAgICAgICAgZmx1dGVHYWluLmdhaW4ubGluZWFyUmFtcFRvVmFsdWVBdFRpbWUoMC4xOCAqIHRoaXMubXVzaWNWb2x1bWUsIHQgKyAwLjA4KTtcbiAgICAgICAgZmx1dGVHYWluLmdhaW4uZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSgwLjAwMSwgdCArIDAuNDUpO1xuXG4gICAgICAgIGZsdXRlT3NjLmNvbm5lY3QoZmx1dGVGaWx0ZXIpO1xuICAgICAgICBmbHV0ZUZpbHRlci5jb25uZWN0KGZsdXRlR2Fpbik7XG4gICAgICAgIGZsdXRlR2Fpbi5jb25uZWN0KHRoaXMubXVzaWNHYWluKTtcblxuICAgICAgICBmbHV0ZU9zYy5zdGFydCh0KTtcbiAgICAgICAgZmx1dGVPc2Muc3RvcCh0ICsgMC40Nik7XG4gICAgICB9XG4gICAgfSwgMjQwKTtcbiAgfVxuXG4gIHB1YmxpYyBzdG9wQmdtKCkge1xuICAgIHRoaXMuaXNCZ21QbGF5aW5nID0gZmFsc2U7XG4gICAgaWYgKHRoaXMuYmdtSW50ZXJ2YWwgIT09IG51bGwpIHtcbiAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5iZ21JbnRlcnZhbCk7XG4gICAgICB0aGlzLmJnbUludGVydmFsID0gbnVsbDtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IHNvdW5kTWFuYWdlciA9IG5ldyBTb3VuZE1hbmFnZXIoKTtcbiJdfQ==