/**
* @license
* SPDX-License-Identifier: Apache-2.0
*/
import * as THREE from "/node_modules/.vite/deps/three.js?v=677b64f2";
import { TextureGenerator } from "/src/engine/TextureGenerator.ts";
export class EnvironmentBuilder {
	/**
	* Builds an authentic Japanese multi-tier Pagoda
	*/
	static createPagoda(levels = 3) {
		const pagoda = new THREE.Group();
		const redWoodMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getRedLacquerTexture(),
			roughness: .5,
			metalness: .1
		});
		const roofTileMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getRoofTileTexture(),
			roughness: .6,
			metalness: .2
		});
		const stoneMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getStonePavementTexture(),
			roughness: .8,
			metalness: .1
		});
		const goldMat = new THREE.MeshStandardMaterial({
			color: 14658082,
			roughness: .3,
			metalness: .9
		});
		// 1. Stone Foundation
		const baseGeo = new THREE.BoxGeometry(9, 1.2, 9);
		const baseMesh = new THREE.Mesh(baseGeo, stoneMat);
		baseMesh.position.y = .6;
		baseMesh.castShadow = true;
		baseMesh.receiveShadow = true;
		pagoda.add(baseMesh);
		// Stone Steps
		const stepGeo = new THREE.BoxGeometry(3.5, .4, 1.2);
		const step = new THREE.Mesh(stepGeo, stoneMat);
		step.position.set(0, .2, 5);
		pagoda.add(step);
		let currentY = 1.2;
		for (let i = 0; i < levels; i++) {
			const scale = 1 - i * .18;
			const floorHeight = 2.8 * scale;
			const floorWidth = 6.5 * scale;
			// Central Chamber
			const wallGeo = new THREE.BoxGeometry(floorWidth, floorHeight, floorWidth);
			const wallMesh = new THREE.Mesh(wallGeo, redWoodMat);
			wallMesh.position.y = currentY + floorHeight * .5;
			wallMesh.castShadow = true;
			wallMesh.receiveShadow = true;
			pagoda.add(wallMesh);
			// Veranda / Balcony Railing
			const railingGeo = new THREE.BoxGeometry(floorWidth + 1.2, .6, floorWidth + 1.2);
			const railingMesh = new THREE.Mesh(railingGeo, redWoodMat);
			railingMesh.position.y = currentY + .3;
			pagoda.add(railingMesh);
			// Flared Roof Eaves
			const roofBottomWidth = floorWidth + 3.2;
			const roofTopWidth = floorWidth * .7;
			const roofGeo = new THREE.CylinderGeometry(roofTopWidth, roofBottomWidth, 1.2 * scale, 4);
			const roofMesh = new THREE.Mesh(roofGeo, roofTileMat);
			roofMesh.position.y = currentY + floorHeight + .6 * scale;
			roofMesh.rotation.y = Math.PI / 4;
			roofMesh.castShadow = true;
			roofMesh.receiveShadow = true;
			pagoda.add(roofMesh);
			// Corner Eave Finials
			const cornerGeo = new THREE.ConeGeometry(.18, .8, 4);
			for (let c = 0; c < 4; c++) {
				const angle = c * Math.PI / 2 + Math.PI / 4;
				const dist = roofBottomWidth * Math.SQRT2 / 2;
				const cornerFinial = new THREE.Mesh(cornerGeo, goldMat);
				cornerFinial.position.set(Math.cos(angle) * dist, currentY + floorHeight + .4 * scale, Math.sin(angle) * dist);
				cornerFinial.rotation.set(.4 * Math.sin(angle), 0, .4 * Math.cos(angle));
				pagoda.add(cornerFinial);
			}
			currentY += floorHeight + 1 * scale;
		}
		// Sorin Spire (Pinnacle on top)
		const spireGeo = new THREE.CylinderGeometry(.08, .22, 3.5, 8);
		const spireMesh = new THREE.Mesh(spireGeo, goldMat);
		spireMesh.position.y = currentY + 1.75;
		spireMesh.castShadow = true;
		pagoda.add(spireMesh);
		// Spire Rings
		for (let r = 0; r < 7; r++) {
			const ringGeo = new THREE.TorusGeometry(.26 - r * .02, .05, 8, 16);
			const ringMesh = new THREE.Mesh(ringGeo, goldMat);
			ringMesh.position.y = currentY + .8 + r * .35;
			ringMesh.rotation.x = Math.PI / 2;
			pagoda.add(ringMesh);
		}
		return pagoda;
	}
	/**
	* Builds an authentic Red Torii Gate
	*/
	static createToriiGate() {
		const torii = new THREE.Group();
		const redMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getRedLacquerTexture(),
			roughness: .5,
			metalness: .1
		});
		const blackMat = new THREE.MeshStandardMaterial({
			color: 1579035,
			roughness: .7,
			metalness: .2
		});
		const stoneMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getStonePavementTexture(),
			roughness: .8
		});
		// Twin Pillars (Hashira)
		const pillarHeight = 6.2;
		const pillarDist = 2.4;
		const pillarGeo = new THREE.CylinderGeometry(.3, .35, pillarHeight, 16);
		// Left Pillar
		const leftPillar = new THREE.Mesh(pillarGeo, redMat);
		leftPillar.position.set(-pillarDist, pillarHeight * .5, 0);
		leftPillar.castShadow = true;
		torii.add(leftPillar);
		const baseGeo = new THREE.CylinderGeometry(.48, .52, .6, 16);
		const leftBase = new THREE.Mesh(baseGeo, stoneMat);
		leftBase.position.set(-pillarDist, .3, 0);
		torii.add(leftBase);
		// Right Pillar
		const rightPillar = new THREE.Mesh(pillarGeo, redMat);
		rightPillar.position.set(pillarDist, pillarHeight * .5, 0);
		rightPillar.castShadow = true;
		torii.add(rightPillar);
		const rightBase = new THREE.Mesh(baseGeo, stoneMat);
		rightBase.position.set(pillarDist, .3, 0);
		torii.add(rightBase);
		// Top Sweeping Lintel (Kasagi & Shimaki)
		const lintelWidth = 7.6;
		const kasagiGeo = new THREE.BoxGeometry(lintelWidth, .5, .7);
		const kasagiMesh = new THREE.Mesh(kasagiGeo, redMat);
		kasagiMesh.position.set(0, pillarHeight + .2, 0);
		kasagiMesh.castShadow = true;
		torii.add(kasagiMesh);
		// Black Roof Cap on top of lintel
		const capGeo = new THREE.BoxGeometry(lintelWidth + .4, .15, .85);
		const capMesh = new THREE.Mesh(capGeo, blackMat);
		capMesh.position.set(0, pillarHeight + .5, 0);
		torii.add(capMesh);
		// Secondary Tie-Beam (Nuki)
		const nukiGeo = new THREE.BoxGeometry(lintelWidth - 1.2, .35, .45);
		const nukiMesh = new THREE.Mesh(nukiGeo, redMat);
		nukiMesh.position.set(0, pillarHeight - .9, 0);
		nukiMesh.castShadow = true;
		torii.add(nukiMesh);
		// Central Plaque (Gakuzuka)
		const plaqueGeo = new THREE.BoxGeometry(.5, .9, .1);
		const plaqueMesh = new THREE.Mesh(plaqueGeo, blackMat);
		plaqueMesh.position.set(0, pillarHeight - .35, 0);
		torii.add(plaqueMesh);
		return torii;
	}
	/**
	* Builds an authentic Japanese Stone Lantern (Toro) with warm light
	*/
	static createStoneLantern(hasPointLight = true) {
		const group = new THREE.Group();
		const stoneMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getStonePavementTexture(),
			roughness: .85,
			metalness: .05
		});
		const glowPaperMat = new THREE.MeshBasicMaterial({ color: 16758605 });
		// 1. Basestone (Kiso)
		const baseGeo = new THREE.CylinderGeometry(.55, .65, .35, 6);
		const base = new THREE.Mesh(baseGeo, stoneMat);
		base.position.y = .175;
		base.castShadow = true;
		group.add(base);
		// 2. Shaft (Sao)
		const shaftGeo = new THREE.CylinderGeometry(.24, .28, .95, 6);
		const shaft = new THREE.Mesh(shaftGeo, stoneMat);
		shaft.position.y = .8;
		shaft.castShadow = true;
		group.add(shaft);
		// 3. Middle Platform (Chudai)
		const platformGeo = new THREE.CylinderGeometry(.62, .45, .3, 6);
		const platform = new THREE.Mesh(platformGeo, stoneMat);
		platform.position.y = 1.4;
		group.add(platform);
		// 4. Firebox (Hibukuro) with glowing windows
		const fireboxGeo = new THREE.CylinderGeometry(.42, .42, .5, 6);
		const firebox = new THREE.Mesh(fireboxGeo, glowPaperMat);
		firebox.position.y = 1.8;
		group.add(firebox);
		// 5. Roof Umbrella (Kasa)
		const umbrellaGeo = new THREE.ConeGeometry(.78, .45, 6);
		const umbrella = new THREE.Mesh(umbrellaGeo, stoneMat);
		umbrella.position.y = 2.25;
		umbrella.castShadow = true;
		group.add(umbrella);
		// 6. Jewel Finial (Hoju)
		const finialGeo = new THREE.SphereGeometry(.14, 8, 8);
		const finial = new THREE.Mesh(finialGeo, stoneMat);
		finial.position.y = 2.58;
		group.add(finial);
		let light;
		if (hasPointLight) {
			light = new THREE.PointLight(16750592, 1.5, 12, 1.2);
			light.position.set(0, 1.8, 0);
			group.add(light);
		}
		return {
			group,
			light
		};
	}
	/**
	* Builds an authentic Cherry Blossom (Sakura) Tree
	*/
	static createSakuraTree() {
		const tree = new THREE.Group();
		// Weathered Gnarled Bark
		const barkMat = new THREE.MeshStandardMaterial({
			color: 4333574,
			roughness: .9,
			metalness: .05
		});
		// Foliage Material with sakura petal texture
		const foliageMat = new THREE.MeshStandardMaterial({
			color: 16020150,
			roughness: .7,
			metalness: .1
		});
		const highlightFoliageMat = new THREE.MeshStandardMaterial({
			color: 16502760,
			roughness: .6,
			metalness: .05
		});
		// Main Trunk (twisted & leaning slightly for organic realism)
		const trunkGeo = new THREE.CylinderGeometry(.35, .6, 3.8, 10);
		const trunk = new THREE.Mesh(trunkGeo, barkMat);
		trunk.position.set(0, 1.9, 0);
		trunk.rotation.z = .08;
		trunk.castShadow = true;
		tree.add(trunk);
		// Root flares
		for (let r = 0; r < 4; r++) {
			const angle = r * Math.PI / 2;
			const rootGeo = new THREE.BoxGeometry(.4, .6, .9);
			const rootMesh = new THREE.Mesh(rootGeo, barkMat);
			rootMesh.position.set(Math.cos(angle) * .45, .25, Math.sin(angle) * .45);
			rootMesh.rotation.y = angle;
			tree.add(rootMesh);
		}
		// Main Branches
		const branches = [
			{
				pos: new THREE.Vector3(.5, 3.2, .4),
				rot: new THREE.Euler(.4, .2, .6),
				scale: .7
			},
			{
				pos: new THREE.Vector3(-.6, 3.4, -.3),
				rot: new THREE.Euler(-.3, -.4, -.7),
				scale: .65
			},
			{
				pos: new THREE.Vector3(.1, 3.8, -.5),
				rot: new THREE.Euler(-.6, .5, .2),
				scale: .6
			}
		];
		branches.forEach((b) => {
			const bGeo = new THREE.CylinderGeometry(.18 * b.scale, .28 * b.scale, 2.2 * b.scale, 8);
			const bMesh = new THREE.Mesh(bGeo, barkMat);
			bMesh.position.copy(b.pos);
			bMesh.rotation.copy(b.rot);
			bMesh.castShadow = true;
			tree.add(bMesh);
		});
		// Cloud-like Sakura Blossom Canopy Clusters
		const clusters = [
			{
				pos: new THREE.Vector3(0, 4.8, 0),
				r: 1.8,
				mat: foliageMat
			},
			{
				pos: new THREE.Vector3(1.4, 4.3, .8),
				r: 1.4,
				mat: highlightFoliageMat
			},
			{
				pos: new THREE.Vector3(-1.5, 4.2, -.7),
				r: 1.5,
				mat: foliageMat
			},
			{
				pos: new THREE.Vector3(.3, 4.9, -1.3),
				r: 1.3,
				mat: highlightFoliageMat
			},
			{
				pos: new THREE.Vector3(-.7, 5.2, .8),
				r: 1.2,
				mat: foliageMat
			},
			{
				pos: new THREE.Vector3(.9, 3.6, -.6),
				r: 1.1,
				mat: highlightFoliageMat
			}
		];
		clusters.forEach((c) => {
			const geo = new THREE.DodecahedronGeometry(c.r, 2);
			const mesh = new THREE.Mesh(geo, c.mat);
			mesh.position.copy(c.pos);
			mesh.castShadow = true;
			tree.add(mesh);
		});
		return tree;
	}
	/**
	* Builds an authentic Japanese Tiered Black Pine Tree
	*/
	static createPineTree() {
		const tree = new THREE.Group();
		const barkMat = new THREE.MeshStandardMaterial({
			color: 2563606,
			roughness: .95
		});
		const needleMat = new THREE.MeshStandardMaterial({
			color: 1332013,
			roughness: .8
		});
		// Leaning curved trunk
		const trunkGeo = new THREE.CylinderGeometry(.3, .55, 4.5, 8);
		const trunk = new THREE.Mesh(trunkGeo, barkMat);
		trunk.position.set(.3, 2.25, 0);
		trunk.rotation.z = .12;
		trunk.castShadow = true;
		tree.add(trunk);
		// Tiered flat foliage pads
		const tiers = [
			{
				y: 2.8,
				r: 2.2,
				h: .6,
				x: .8
			},
			{
				y: 3.8,
				r: 1.8,
				h: .5,
				x: .4
			},
			{
				y: 4.6,
				r: 1.4,
				h: .45,
				x: .2
			},
			{
				y: 5.3,
				r: .9,
				h: .4,
				x: 0
			}
		];
		tiers.forEach((tier) => {
			const padGeo = new THREE.CylinderGeometry(.2, tier.r, tier.h, 10);
			const pad = new THREE.Mesh(padGeo, needleMat);
			pad.position.set(tier.x, tier.y, 0);
			pad.castShadow = true;
			tree.add(pad);
		});
		return tree;
	}
	/**
	* Builds an arched Wooden Japanese Bridge
	*/
	static createArchedBridge(length = 10, width = 3) {
		const bridge = new THREE.Group();
		const woodMat = new THREE.MeshStandardMaterial({
			color: 7877903,
			roughness: .7,
			metalness: .1
		});
		const redMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getRedLacquerTexture(),
			roughness: .5
		});
		const goldMat = new THREE.MeshStandardMaterial({
			color: 14658082,
			metalness: .9,
			roughness: .2
		});
		const segments = 12;
		const stepAngle = Math.PI / segments;
		for (let i = 0; i <= segments; i++) {
			const angle = i * stepAngle;
			const x = (i - segments / 2) * (length / segments);
			const y = Math.sin(angle) * 1.4;
			// Deck Plank
			const plankGeo = new THREE.BoxGeometry(length / segments + .08, .2, width);
			const plank = new THREE.Mesh(plankGeo, woodMat);
			plank.position.set(x, y + .2, 0);
			plank.castShadow = true;
			plank.receiveShadow = true;
			bridge.add(plank);
			// Railing Posts on both sides
			[-width * .5 + .15, width * .5 - .15].forEach((zPos) => {
				const postGeo = new THREE.CylinderGeometry(.08, .08, .9, 8);
				const post = new THREE.Mesh(postGeo, redMat);
				post.position.set(x, y + .7, zPos);
				post.castShadow = true;
				bridge.add(post);
				// Golden Giboshi finial on top of posts
				const finialGeo = new THREE.ConeGeometry(.1, .2, 8);
				const finial = new THREE.Mesh(finialGeo, goldMat);
				finial.position.set(x, y + 1.25, zPos);
				bridge.add(finial);
			});
		}
		return bridge;
	}
	/**
	* Builds an Enemy Campfire with flickering point light and embers
	*/
	static createCampfire() {
		const group = new THREE.Group();
		const rockMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getStonePavementTexture(),
			roughness: .9
		});
		const woodMat = new THREE.MeshStandardMaterial({
			color: 2692100,
			roughness: .95
		});
		// Rock ring
		for (let i = 0; i < 8; i++) {
			const angle = i * Math.PI * 2 / 8;
			const rockGeo = new THREE.DodecahedronGeometry(.24, 1);
			const rock = new THREE.Mesh(rockGeo, rockMat);
			rock.position.set(Math.cos(angle) * .8, .15, Math.sin(angle) * .8);
			group.add(rock);
		}
		// Crossed logs
		for (let j = 0; j < 4; j++) {
			const angle = j * Math.PI / 2;
			const logGeo = new THREE.CylinderGeometry(.1, .12, 1.2, 6);
			const log = new THREE.Mesh(logGeo, woodMat);
			log.position.set(0, .25, 0);
			log.rotation.set(.4, angle, 0);
			group.add(log);
		}
		// Glowing core
		const coreGeo = new THREE.SphereGeometry(.35, 12, 12);
		const coreMat = new THREE.MeshBasicMaterial({ color: 16729344 });
		const core = new THREE.Mesh(coreGeo, coreMat);
		core.position.y = .35;
		group.add(core);
		const light = new THREE.PointLight(16733440, 3.5, 16, 1.5);
		light.position.set(0, .8, 0);
		group.add(light);
		return {
			group,
			light
		};
	}
	/**
	* Builds an Enemy War Tent
	*/
	static createEnemyTent() {
		const tent = new THREE.Group();
		const canvasMat = new THREE.MeshStandardMaterial({
			color: 4144966,
			roughness: .8
		});
		const woodMat = new THREE.MeshStandardMaterial({
			color: 5395035,
			roughness: .8
		});
		// Wedge tent geometry
		const tentGeo = new THREE.ConeGeometry(2.4, 2.8, 4);
		const tentMesh = new THREE.Mesh(tentGeo, canvasMat);
		tentMesh.position.y = 1.4;
		tentMesh.rotation.y = Math.PI / 4;
		tentMesh.castShadow = true;
		tent.add(tentMesh);
		// Front poles
		const poleGeo = new THREE.CylinderGeometry(.08, .08, 3, 8);
		const leftPole = new THREE.Mesh(poleGeo, woodMat);
		leftPole.position.set(-1.2, 1.5, 1.2);
		const rightPole = new THREE.Mesh(poleGeo, woodMat);
		rightPole.position.set(1.2, 1.5, 1.2);
		tent.add(leftPole, rightPole);
		return tent;
	}
	/**
	* Builds a Samurai Wooden Watchtower
	*/
	static createWatchtower() {
		const tower = new THREE.Group();
		const woodMat = new THREE.MeshStandardMaterial({
			color: 4528643,
			roughness: .8
		});
		const roofMat = new THREE.MeshStandardMaterial({
			color: 1841431,
			roughness: .7
		});
		// 4 Corner Legs
		const legGeo = new THREE.CylinderGeometry(.12, .16, 7.5, 8);
		[
			[-1.4, -1.4],
			[1.4, -1.4],
			[-1.4, 1.4],
			[1.4, 1.4]
		].forEach(([x, z]) => {
			const leg = new THREE.Mesh(legGeo, woodMat);
			leg.position.set(x, 3.75, z);
			leg.castShadow = true;
			tower.add(leg);
		});
		// Cross braces
		const braceGeo = new THREE.BoxGeometry(3, .1, .1);
		[2.2, 4.8].forEach((y) => {
			const b1 = new THREE.Mesh(braceGeo, woodMat);
			b1.position.set(0, y, 1.4);
			const b2 = new THREE.Mesh(braceGeo, woodMat);
			b2.position.set(0, y, -1.4);
			tower.add(b1, b2);
		});
		// Lookout Platform
		const platformGeo = new THREE.BoxGeometry(3.4, .25, 3.4);
		const platform = new THREE.Mesh(platformGeo, woodMat);
		platform.position.y = 5.6;
		platform.castShadow = true;
		tower.add(platform);
		// Platform Railing
		const railGeo = new THREE.BoxGeometry(3.4, .8, 3.4);
		const rail = new THREE.Mesh(railGeo, woodMat);
		rail.position.y = 6.1;
		tower.add(rail);
		// Tower Roof
		const roofGeo = new THREE.ConeGeometry(2.8, 1.4, 4);
		const roof = new THREE.Mesh(roofGeo, roofMat);
		roof.position.y = 8.2;
		roof.rotation.y = Math.PI / 4;
		roof.castShadow = true;
		tower.add(roof);
		return tower;
	}
	/**
	* Builds a Traditional Thatched Village Hut (Minka)
	*/
	static createVillageHut() {
		const hut = new THREE.Group();
		const woodMat = new THREE.MeshStandardMaterial({
			color: 4073251,
			roughness: .85
		});
		const thatchMat = new THREE.MeshStandardMaterial({
			color: 8736014,
			roughness: .95
		});
		// Walls
		const wallGeo = new THREE.BoxGeometry(4.8, 2.6, 3.8);
		const wall = new THREE.Mesh(wallGeo, woodMat);
		wall.position.y = 1.3;
		wall.castShadow = true;
		wall.receiveShadow = true;
		hut.add(wall);
		// Thatched Roof
		const roofGeo = new THREE.ConeGeometry(3.8, 2.2, 4);
		const roof = new THREE.Mesh(roofGeo, thatchMat);
		roof.position.y = 3.4;
		roof.rotation.y = Math.PI / 4;
		roof.scale.set(1.4, 1, 1.1);
		roof.castShadow = true;
		hut.add(roof);
		return hut;
	}
	/**
	* Builds Spiked Wooden Barricades (Chevaux-de-frise)
	*/
	static createSpikedBarricade() {
		const bar = new THREE.Group();
		const woodMat = new THREE.MeshStandardMaterial({
			color: 2562321,
			roughness: .9
		});
		// Central cross beam
		const beamGeo = new THREE.CylinderGeometry(.1, .1, 4, 8);
		beamGeo.rotateZ(Math.PI / 2);
		const beam = new THREE.Mesh(beamGeo, woodMat);
		beam.position.y = .7;
		bar.add(beam);
		// Crossed sharpened stakes
		for (let i = -1.5; i <= 1.5; i += .75) {
			const stakeGeo = new THREE.CylinderGeometry(.04, .08, 1.8, 6);
			const s1 = new THREE.Mesh(stakeGeo, woodMat);
			s1.position.set(i, .7, 0);
			s1.rotation.set(.65, 0, 0);
			const s2 = new THREE.Mesh(stakeGeo, woodMat);
			s2.position.set(i, .7, 0);
			s2.rotation.set(-.65, 0, 0);
			bar.add(s1, s2);
		}
		return bar;
	}
	/**
	* Builds Iron Fire Brazier with dynamic light
	*/
	static createBrazier(fireColor = 16729344) {
		const group = new THREE.Group();
		const ironMat = new THREE.MeshStandardMaterial({
			color: 1579035,
			metalness: .8,
			roughness: .3
		});
		// Tripod legs
		for (let i = 0; i < 3; i++) {
			const angle = i * Math.PI * 2 / 3;
			const legGeo = new THREE.CylinderGeometry(.05, .06, 1.4, 8);
			const leg = new THREE.Mesh(legGeo, ironMat);
			leg.position.set(Math.cos(angle) * .45, .7, Math.sin(angle) * .45);
			leg.rotation.set(-.25 * Math.sin(angle), 0, .25 * Math.cos(angle));
			group.add(leg);
		}
		// Iron Bowl
		const bowlGeo = new THREE.CylinderGeometry(.6, .35, .4, 12);
		const bowl = new THREE.Mesh(bowlGeo, ironMat);
		bowl.position.y = 1.35;
		group.add(bowl);
		// Glowing core
		const coreGeo = new THREE.SphereGeometry(.35, 8, 8);
		const coreMat = new THREE.MeshBasicMaterial({ color: fireColor });
		const core = new THREE.Mesh(coreGeo, coreMat);
		core.position.y = 1.45;
		group.add(core);
		const light = new THREE.PointLight(fireColor, 2.5, 14, 1.3);
		light.position.set(0, 1.8, 0);
		group.add(light);
		return {
			group,
			light
		};
	}
	/**
	* Builds Stone Guardian Beast / Dragon Statue
	*/
	static createDragonStatue() {
		const statue = new THREE.Group();
		const stoneMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getStonePavementTexture(),
			roughness: .85
		});
		// Plinth
		const plinthGeo = new THREE.BoxGeometry(1.6, .8, 1.6);
		const plinth = new THREE.Mesh(plinthGeo, stoneMat);
		plinth.position.y = .4;
		plinth.castShadow = true;
		statue.add(plinth);
		// Body
		const bodyGeo = new THREE.BoxGeometry(1.1, 1.4, 1.1);
		const body = new THREE.Mesh(bodyGeo, stoneMat);
		body.position.y = 1.4;
		body.castShadow = true;
		statue.add(body);
		// Head
		const headGeo = new THREE.DodecahedronGeometry(.5, 1);
		const head = new THREE.Mesh(headGeo, stoneMat);
		head.position.set(0, 2.1, .25);
		statue.add(head);
		return statue;
	}
	/**
	* Builds Volcanic Obsidian Monolith Spikes
	*/
	static createObsidianMonolith() {
		const mono = new THREE.Group();
		const obsMat = new THREE.MeshStandardMaterial({
			color: 592139,
			metalness: .85,
			roughness: .15
		});
		const spikeGeo = new THREE.ConeGeometry(1.2, 7.5, 5);
		const spike = new THREE.Mesh(spikeGeo, obsMat);
		spike.position.y = 3.5;
		spike.rotation.set(.12, .4, .08);
		spike.castShadow = true;
		mono.add(spike);
		// Sub spikes
		[-.8, .8].forEach((x) => {
			const subGeo = new THREE.ConeGeometry(.6, 4.2, 4);
			const sub = new THREE.Mesh(subGeo, obsMat);
			sub.position.set(x, 1.8, .4);
			sub.rotation.set(-.2, 0, x * .3);
			mono.add(sub);
		});
		return mono;
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLFlBQVksV0FBVztBQUN2QixTQUFTLHdCQUF3QjtBQUVqQyxPQUFPLE1BQU0sbUJBQW1COzs7O0NBSTlCLE9BQWMsYUFBYSxTQUFTLEdBQWdCO0VBQ2xELE1BQU0sU0FBUyxJQUFJLE1BQU0sTUFBTTtFQUUvQixNQUFNLGFBQWEsSUFBSSxNQUFNLHFCQUFxQjtHQUNoRCxLQUFLLGlCQUFpQixxQkFBcUI7R0FDM0MsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDO0VBRUQsTUFBTSxjQUFjLElBQUksTUFBTSxxQkFBcUI7R0FDakQsS0FBSyxpQkFBaUIsbUJBQW1CO0dBQ3pDLFdBQVc7R0FDWCxXQUFXO0VBQ2IsQ0FBQztFQUVELE1BQU0sV0FBVyxJQUFJLE1BQU0scUJBQXFCO0dBQzlDLEtBQUssaUJBQWlCLHdCQUF3QjtHQUM5QyxXQUFXO0dBQ1gsV0FBVztFQUNiLENBQUM7RUFFRCxNQUFNLFVBQVUsSUFBSSxNQUFNLHFCQUFxQjtHQUM3QyxPQUFPO0dBQ1AsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDOztFQUdELE1BQU0sVUFBVSxJQUFJLE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQztFQUMvQyxNQUFNLFdBQVcsSUFBSSxNQUFNLEtBQUssU0FBUyxRQUFRO0VBQ2pELFNBQVMsU0FBUyxJQUFJO0VBQ3RCLFNBQVMsYUFBYTtFQUN0QixTQUFTLGdCQUFnQjtFQUN6QixPQUFPLElBQUksUUFBUTs7RUFHbkIsTUFBTSxVQUFVLElBQUksTUFBTSxZQUFZLEtBQUssSUFBSyxHQUFHO0VBQ25ELE1BQU0sT0FBTyxJQUFJLE1BQU0sS0FBSyxTQUFTLFFBQVE7RUFDN0MsS0FBSyxTQUFTLElBQUksR0FBRyxJQUFLLENBQUM7RUFDM0IsT0FBTyxJQUFJLElBQUk7RUFFZixJQUFJLFdBQVc7RUFFZixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLO0dBQy9CLE1BQU0sUUFBUSxJQUFJLElBQUk7R0FDdEIsTUFBTSxjQUFjLE1BQU07R0FDMUIsTUFBTSxhQUFhLE1BQU07O0dBR3pCLE1BQU0sVUFBVSxJQUFJLE1BQU0sWUFBWSxZQUFZLGFBQWEsVUFBVTtHQUN6RSxNQUFNLFdBQVcsSUFBSSxNQUFNLEtBQUssU0FBUyxVQUFVO0dBQ25ELFNBQVMsU0FBUyxJQUFJLFdBQVcsY0FBYztHQUMvQyxTQUFTLGFBQWE7R0FDdEIsU0FBUyxnQkFBZ0I7R0FDekIsT0FBTyxJQUFJLFFBQVE7O0dBR25CLE1BQU0sYUFBYSxJQUFJLE1BQU0sWUFBWSxhQUFhLEtBQUssSUFBSyxhQUFhLEdBQUc7R0FDaEYsTUFBTSxjQUFjLElBQUksTUFBTSxLQUFLLFlBQVksVUFBVTtHQUN6RCxZQUFZLFNBQVMsSUFBSSxXQUFXO0dBQ3BDLE9BQU8sSUFBSSxXQUFXOztHQUd0QixNQUFNLGtCQUFrQixhQUFhO0dBQ3JDLE1BQU0sZUFBZSxhQUFhO0dBQ2xDLE1BQU0sVUFBVSxJQUFJLE1BQU0saUJBQWlCLGNBQWMsaUJBQWlCLE1BQU0sT0FBTyxDQUFDO0dBQ3hGLE1BQU0sV0FBVyxJQUFJLE1BQU0sS0FBSyxTQUFTLFdBQVc7R0FDcEQsU0FBUyxTQUFTLElBQUksV0FBVyxjQUFjLEtBQU07R0FDckQsU0FBUyxTQUFTLElBQUksS0FBSyxLQUFLO0dBQ2hDLFNBQVMsYUFBYTtHQUN0QixTQUFTLGdCQUFnQjtHQUN6QixPQUFPLElBQUksUUFBUTs7R0FHbkIsTUFBTSxZQUFZLElBQUksTUFBTSxhQUFhLEtBQU0sSUFBSyxDQUFDO0dBQ3JELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7SUFDMUIsTUFBTSxRQUFTLElBQUksS0FBSyxLQUFNLElBQUksS0FBSyxLQUFLO0lBQzVDLE1BQU0sT0FBUSxrQkFBa0IsS0FBSyxRQUFTO0lBQzlDLE1BQU0sZUFBZSxJQUFJLE1BQU0sS0FBSyxXQUFXLE9BQU87SUFDdEQsYUFBYSxTQUFTLElBQ3BCLEtBQUssSUFBSSxLQUFLLElBQUksTUFDbEIsV0FBVyxjQUFjLEtBQU0sT0FDL0IsS0FBSyxJQUFJLEtBQUssSUFBSSxJQUNwQjtJQUNBLGFBQWEsU0FBUyxJQUFJLEtBQU0sS0FBSyxJQUFJLEtBQUssR0FBRyxHQUFHLEtBQU0sS0FBSyxJQUFJLEtBQUssQ0FBQztJQUN6RSxPQUFPLElBQUksWUFBWTtHQUN6QjtHQUVBLFlBQVksY0FBYyxJQUFNO0VBQ2xDOztFQUdBLE1BQU0sV0FBVyxJQUFJLE1BQU0saUJBQWlCLEtBQU0sS0FBTSxLQUFLLENBQUM7RUFDOUQsTUFBTSxZQUFZLElBQUksTUFBTSxLQUFLLFVBQVUsT0FBTztFQUNsRCxVQUFVLFNBQVMsSUFBSSxXQUFXO0VBQ2xDLFVBQVUsYUFBYTtFQUN2QixPQUFPLElBQUksU0FBUzs7RUFHcEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztHQUMxQixNQUFNLFVBQVUsSUFBSSxNQUFNLGNBQWMsTUFBTyxJQUFJLEtBQU0sS0FBTSxHQUFHLEVBQUU7R0FDcEUsTUFBTSxXQUFXLElBQUksTUFBTSxLQUFLLFNBQVMsT0FBTztHQUNoRCxTQUFTLFNBQVMsSUFBSSxXQUFXLEtBQU0sSUFBSTtHQUMzQyxTQUFTLFNBQVMsSUFBSSxLQUFLLEtBQUs7R0FDaEMsT0FBTyxJQUFJLFFBQVE7RUFDckI7RUFFQSxPQUFPO0NBQ1Q7Ozs7Q0FLQSxPQUFjLGtCQUErQjtFQUMzQyxNQUFNLFFBQVEsSUFBSSxNQUFNLE1BQU07RUFFOUIsTUFBTSxTQUFTLElBQUksTUFBTSxxQkFBcUI7R0FDNUMsS0FBSyxpQkFBaUIscUJBQXFCO0dBQzNDLFdBQVc7R0FDWCxXQUFXO0VBQ2IsQ0FBQztFQUVELE1BQU0sV0FBVyxJQUFJLE1BQU0scUJBQXFCO0dBQzlDLE9BQU87R0FDUCxXQUFXO0dBQ1gsV0FBVztFQUNiLENBQUM7RUFFRCxNQUFNLFdBQVcsSUFBSSxNQUFNLHFCQUFxQjtHQUM5QyxLQUFLLGlCQUFpQix3QkFBd0I7R0FDOUMsV0FBVztFQUNiLENBQUM7O0VBR0QsTUFBTSxlQUFlO0VBQ3JCLE1BQU0sYUFBYTtFQUNuQixNQUFNLFlBQVksSUFBSSxNQUFNLGlCQUFpQixJQUFLLEtBQU0sY0FBYyxFQUFFOztFQUd4RSxNQUFNLGFBQWEsSUFBSSxNQUFNLEtBQUssV0FBVyxNQUFNO0VBQ25ELFdBQVcsU0FBUyxJQUFJLENBQUMsWUFBWSxlQUFlLElBQUssQ0FBQztFQUMxRCxXQUFXLGFBQWE7RUFDeEIsTUFBTSxJQUFJLFVBQVU7RUFFcEIsTUFBTSxVQUFVLElBQUksTUFBTSxpQkFBaUIsS0FBTSxLQUFNLElBQUssRUFBRTtFQUM5RCxNQUFNLFdBQVcsSUFBSSxNQUFNLEtBQUssU0FBUyxRQUFRO0VBQ2pELFNBQVMsU0FBUyxJQUFJLENBQUMsWUFBWSxJQUFLLENBQUM7RUFDekMsTUFBTSxJQUFJLFFBQVE7O0VBR2xCLE1BQU0sY0FBYyxJQUFJLE1BQU0sS0FBSyxXQUFXLE1BQU07RUFDcEQsWUFBWSxTQUFTLElBQUksWUFBWSxlQUFlLElBQUssQ0FBQztFQUMxRCxZQUFZLGFBQWE7RUFDekIsTUFBTSxJQUFJLFdBQVc7RUFFckIsTUFBTSxZQUFZLElBQUksTUFBTSxLQUFLLFNBQVMsUUFBUTtFQUNsRCxVQUFVLFNBQVMsSUFBSSxZQUFZLElBQUssQ0FBQztFQUN6QyxNQUFNLElBQUksU0FBUzs7RUFHbkIsTUFBTSxjQUFjO0VBQ3BCLE1BQU0sWUFBWSxJQUFJLE1BQU0sWUFBWSxhQUFhLElBQUssRUFBRztFQUM3RCxNQUFNLGFBQWEsSUFBSSxNQUFNLEtBQUssV0FBVyxNQUFNO0VBQ25ELFdBQVcsU0FBUyxJQUFJLEdBQUcsZUFBZSxJQUFLLENBQUM7RUFDaEQsV0FBVyxhQUFhO0VBQ3hCLE1BQU0sSUFBSSxVQUFVOztFQUdwQixNQUFNLFNBQVMsSUFBSSxNQUFNLFlBQVksY0FBYyxJQUFLLEtBQU0sR0FBSTtFQUNsRSxNQUFNLFVBQVUsSUFBSSxNQUFNLEtBQUssUUFBUSxRQUFRO0VBQy9DLFFBQVEsU0FBUyxJQUFJLEdBQUcsZUFBZSxJQUFLLENBQUM7RUFDN0MsTUFBTSxJQUFJLE9BQU87O0VBR2pCLE1BQU0sVUFBVSxJQUFJLE1BQU0sWUFBWSxjQUFjLEtBQUssS0FBTSxHQUFJO0VBQ25FLE1BQU0sV0FBVyxJQUFJLE1BQU0sS0FBSyxTQUFTLE1BQU07RUFDL0MsU0FBUyxTQUFTLElBQUksR0FBRyxlQUFlLElBQUssQ0FBQztFQUM5QyxTQUFTLGFBQWE7RUFDdEIsTUFBTSxJQUFJLFFBQVE7O0VBR2xCLE1BQU0sWUFBWSxJQUFJLE1BQU0sWUFBWSxJQUFLLElBQUssRUFBRztFQUNyRCxNQUFNLGFBQWEsSUFBSSxNQUFNLEtBQUssV0FBVyxRQUFRO0VBQ3JELFdBQVcsU0FBUyxJQUFJLEdBQUcsZUFBZSxLQUFNLENBQUM7RUFDakQsTUFBTSxJQUFJLFVBQVU7RUFFcEIsT0FBTztDQUNUOzs7O0NBS0EsT0FBYyxtQkFBbUIsZ0JBQWdCLE1BQXdEO0VBQ3ZHLE1BQU0sUUFBUSxJQUFJLE1BQU0sTUFBTTtFQUU5QixNQUFNLFdBQVcsSUFBSSxNQUFNLHFCQUFxQjtHQUM5QyxLQUFLLGlCQUFpQix3QkFBd0I7R0FDOUMsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDO0VBRUQsTUFBTSxlQUFlLElBQUksTUFBTSxrQkFBa0IsRUFDL0MsT0FBTyxTQUNULENBQUM7O0VBR0QsTUFBTSxVQUFVLElBQUksTUFBTSxpQkFBaUIsS0FBTSxLQUFNLEtBQU0sQ0FBQztFQUM5RCxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssU0FBUyxRQUFRO0VBQzdDLEtBQUssU0FBUyxJQUFJO0VBQ2xCLEtBQUssYUFBYTtFQUNsQixNQUFNLElBQUksSUFBSTs7RUFHZCxNQUFNLFdBQVcsSUFBSSxNQUFNLGlCQUFpQixLQUFNLEtBQU0sS0FBTSxDQUFDO0VBQy9ELE1BQU0sUUFBUSxJQUFJLE1BQU0sS0FBSyxVQUFVLFFBQVE7RUFDL0MsTUFBTSxTQUFTLElBQUk7RUFDbkIsTUFBTSxhQUFhO0VBQ25CLE1BQU0sSUFBSSxLQUFLOztFQUdmLE1BQU0sY0FBYyxJQUFJLE1BQU0saUJBQWlCLEtBQU0sS0FBTSxJQUFLLENBQUM7RUFDakUsTUFBTSxXQUFXLElBQUksTUFBTSxLQUFLLGFBQWEsUUFBUTtFQUNyRCxTQUFTLFNBQVMsSUFBSTtFQUN0QixNQUFNLElBQUksUUFBUTs7RUFHbEIsTUFBTSxhQUFhLElBQUksTUFBTSxpQkFBaUIsS0FBTSxLQUFNLElBQUssQ0FBQztFQUNoRSxNQUFNLFVBQVUsSUFBSSxNQUFNLEtBQUssWUFBWSxZQUFZO0VBQ3ZELFFBQVEsU0FBUyxJQUFJO0VBQ3JCLE1BQU0sSUFBSSxPQUFPOztFQUdqQixNQUFNLGNBQWMsSUFBSSxNQUFNLGFBQWEsS0FBTSxLQUFNLENBQUM7RUFDeEQsTUFBTSxXQUFXLElBQUksTUFBTSxLQUFLLGFBQWEsUUFBUTtFQUNyRCxTQUFTLFNBQVMsSUFBSTtFQUN0QixTQUFTLGFBQWE7RUFDdEIsTUFBTSxJQUFJLFFBQVE7O0VBR2xCLE1BQU0sWUFBWSxJQUFJLE1BQU0sZUFBZSxLQUFNLEdBQUcsQ0FBQztFQUNyRCxNQUFNLFNBQVMsSUFBSSxNQUFNLEtBQUssV0FBVyxRQUFRO0VBQ2pELE9BQU8sU0FBUyxJQUFJO0VBQ3BCLE1BQU0sSUFBSSxNQUFNO0VBRWhCLElBQUk7RUFDSixJQUFJLGVBQWU7R0FDakIsUUFBUSxJQUFJLE1BQU0sV0FBVyxVQUFVLEtBQUssSUFBSSxHQUFHO0dBQ25ELE1BQU0sU0FBUyxJQUFJLEdBQUcsS0FBSyxDQUFDO0dBQzVCLE1BQU0sSUFBSSxLQUFLO0VBQ2pCO0VBRUEsT0FBTztHQUFFO0dBQU87RUFBTTtDQUN4Qjs7OztDQUtBLE9BQWMsbUJBQWdDO0VBQzVDLE1BQU0sT0FBTyxJQUFJLE1BQU0sTUFBTTs7RUFHN0IsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FDN0MsT0FBTztHQUNQLFdBQVc7R0FDWCxXQUFXO0VBQ2IsQ0FBQzs7RUFHRCxNQUFNLGFBQWEsSUFBSSxNQUFNLHFCQUFxQjtHQUNoRCxPQUFPO0dBQ1AsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDO0VBRUQsTUFBTSxzQkFBc0IsSUFBSSxNQUFNLHFCQUFxQjtHQUN6RCxPQUFPO0dBQ1AsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDOztFQUdELE1BQU0sV0FBVyxJQUFJLE1BQU0saUJBQWlCLEtBQU0sSUFBSyxLQUFLLEVBQUU7RUFDOUQsTUFBTSxRQUFRLElBQUksTUFBTSxLQUFLLFVBQVUsT0FBTztFQUM5QyxNQUFNLFNBQVMsSUFBSSxHQUFHLEtBQUssQ0FBQztFQUM1QixNQUFNLFNBQVMsSUFBSTtFQUNuQixNQUFNLGFBQWE7RUFDbkIsS0FBSyxJQUFJLEtBQUs7O0VBR2QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztHQUMxQixNQUFNLFFBQVMsSUFBSSxLQUFLLEtBQU07R0FDOUIsTUFBTSxVQUFVLElBQUksTUFBTSxZQUFZLElBQUssSUFBSyxFQUFHO0dBQ25ELE1BQU0sV0FBVyxJQUFJLE1BQU0sS0FBSyxTQUFTLE9BQU87R0FDaEQsU0FBUyxTQUFTLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFNLEtBQU0sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFJO0dBQzFFLFNBQVMsU0FBUyxJQUFJO0dBQ3RCLEtBQUssSUFBSSxRQUFRO0VBQ25COztFQUdBLE1BQU0sV0FBVztHQUNmO0lBQUUsS0FBSyxJQUFJLE1BQU0sUUFBUSxJQUFLLEtBQUssRUFBRztJQUFHLEtBQUssSUFBSSxNQUFNLE1BQU0sSUFBSyxJQUFLLEVBQUc7SUFBRyxPQUFPO0dBQUk7R0FDekY7SUFBRSxLQUFLLElBQUksTUFBTSxRQUFRLENBQUMsSUFBSyxLQUFLLENBQUMsRUFBRztJQUFHLEtBQUssSUFBSSxNQUFNLE1BQU0sQ0FBQyxJQUFLLENBQUMsSUFBSyxDQUFDLEVBQUc7SUFBRyxPQUFPO0dBQUs7R0FDL0Y7SUFBRSxLQUFLLElBQUksTUFBTSxRQUFRLElBQUssS0FBSyxDQUFDLEVBQUc7SUFBRyxLQUFLLElBQUksTUFBTSxNQUFNLENBQUMsSUFBSyxJQUFLLEVBQUc7SUFBRyxPQUFPO0dBQUk7RUFDN0Y7RUFFQSxTQUFTLFNBQVEsTUFBSztHQUNwQixNQUFNLE9BQU8sSUFBSSxNQUFNLGlCQUFpQixNQUFPLEVBQUUsT0FBTyxNQUFPLEVBQUUsT0FBTyxNQUFNLEVBQUUsT0FBTyxDQUFDO0dBQ3hGLE1BQU0sUUFBUSxJQUFJLE1BQU0sS0FBSyxNQUFNLE9BQU87R0FDMUMsTUFBTSxTQUFTLEtBQUssRUFBRSxHQUFHO0dBQ3pCLE1BQU0sU0FBUyxLQUFLLEVBQUUsR0FBRztHQUN6QixNQUFNLGFBQWE7R0FDbkIsS0FBSyxJQUFJLEtBQUs7RUFDaEIsQ0FBQzs7RUFHRCxNQUFNLFdBQVc7R0FDZjtJQUFFLEtBQUssSUFBSSxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFBRyxHQUFHO0lBQUssS0FBSztHQUFXO0dBQzdEO0lBQUUsS0FBSyxJQUFJLE1BQU0sUUFBUSxLQUFLLEtBQUssRUFBRztJQUFHLEdBQUc7SUFBSyxLQUFLO0dBQW9CO0dBQzFFO0lBQUUsS0FBSyxJQUFJLE1BQU0sUUFBUSxDQUFDLEtBQUssS0FBSyxDQUFDLEVBQUc7SUFBRyxHQUFHO0lBQUssS0FBSztHQUFXO0dBQ25FO0lBQUUsS0FBSyxJQUFJLE1BQU0sUUFBUSxJQUFLLEtBQUssQ0FBQyxHQUFHO0lBQUcsR0FBRztJQUFLLEtBQUs7R0FBb0I7R0FDM0U7SUFBRSxLQUFLLElBQUksTUFBTSxRQUFRLENBQUMsSUFBSyxLQUFLLEVBQUc7SUFBRyxHQUFHO0lBQUssS0FBSztHQUFXO0dBQ2xFO0lBQUUsS0FBSyxJQUFJLE1BQU0sUUFBUSxJQUFLLEtBQUssQ0FBQyxFQUFHO0lBQUcsR0FBRztJQUFLLEtBQUs7R0FBb0I7RUFDN0U7RUFFQSxTQUFTLFNBQVEsTUFBSztHQUNwQixNQUFNLE1BQU0sSUFBSSxNQUFNLHFCQUFxQixFQUFFLEdBQUcsQ0FBQztHQUNqRCxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssS0FBSyxFQUFFLEdBQUc7R0FDdEMsS0FBSyxTQUFTLEtBQUssRUFBRSxHQUFHO0dBQ3hCLEtBQUssYUFBYTtHQUNsQixLQUFLLElBQUksSUFBSTtFQUNmLENBQUM7RUFFRCxPQUFPO0NBQ1Q7Ozs7Q0FLQSxPQUFjLGlCQUE4QjtFQUMxQyxNQUFNLE9BQU8sSUFBSSxNQUFNLE1BQU07RUFFN0IsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FDN0MsT0FBTztHQUNQLFdBQVc7RUFDYixDQUFDO0VBRUQsTUFBTSxZQUFZLElBQUksTUFBTSxxQkFBcUI7R0FDL0MsT0FBTztHQUNQLFdBQVc7RUFDYixDQUFDOztFQUdELE1BQU0sV0FBVyxJQUFJLE1BQU0saUJBQWlCLElBQUssS0FBTSxLQUFLLENBQUM7RUFDN0QsTUFBTSxRQUFRLElBQUksTUFBTSxLQUFLLFVBQVUsT0FBTztFQUM5QyxNQUFNLFNBQVMsSUFBSSxJQUFLLE1BQU0sQ0FBQztFQUMvQixNQUFNLFNBQVMsSUFBSTtFQUNuQixNQUFNLGFBQWE7RUFDbkIsS0FBSyxJQUFJLEtBQUs7O0VBR2QsTUFBTSxRQUFRO0dBQ1o7SUFBRSxHQUFHO0lBQUssR0FBRztJQUFLLEdBQUc7SUFBSyxHQUFHO0dBQUk7R0FDakM7SUFBRSxHQUFHO0lBQUssR0FBRztJQUFLLEdBQUc7SUFBSyxHQUFHO0dBQUk7R0FDakM7SUFBRSxHQUFHO0lBQUssR0FBRztJQUFLLEdBQUc7SUFBTSxHQUFHO0dBQUk7R0FDbEM7SUFBRSxHQUFHO0lBQUssR0FBRztJQUFLLEdBQUc7SUFBSyxHQUFHO0dBQUk7RUFDbkM7RUFFQSxNQUFNLFNBQVEsU0FBUTtHQUNwQixNQUFNLFNBQVMsSUFBSSxNQUFNLGlCQUFpQixJQUFLLEtBQUssR0FBRyxLQUFLLEdBQUcsRUFBRTtHQUNqRSxNQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUssUUFBUSxTQUFTO0dBQzVDLElBQUksU0FBUyxJQUFJLEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQztHQUNsQyxJQUFJLGFBQWE7R0FDakIsS0FBSyxJQUFJLEdBQUc7RUFDZCxDQUFDO0VBRUQsT0FBTztDQUNUOzs7O0NBS0EsT0FBYyxtQkFBbUIsU0FBUyxJQUFJLFFBQVEsR0FBZ0I7RUFDcEUsTUFBTSxTQUFTLElBQUksTUFBTSxNQUFNO0VBRS9CLE1BQU0sVUFBVSxJQUFJLE1BQU0scUJBQXFCO0dBQzdDLE9BQU87R0FDUCxXQUFXO0dBQ1gsV0FBVztFQUNiLENBQUM7RUFFRCxNQUFNLFNBQVMsSUFBSSxNQUFNLHFCQUFxQjtHQUM1QyxLQUFLLGlCQUFpQixxQkFBcUI7R0FDM0MsV0FBVztFQUNiLENBQUM7RUFFRCxNQUFNLFVBQVUsSUFBSSxNQUFNLHFCQUFxQjtHQUM3QyxPQUFPO0dBQ1AsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDO0VBRUQsTUFBTSxXQUFXO0VBQ2pCLE1BQU0sWUFBWSxLQUFLLEtBQUs7RUFFNUIsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLFVBQVUsS0FBSztHQUNsQyxNQUFNLFFBQVEsSUFBSTtHQUNsQixNQUFNLEtBQUssSUFBSSxXQUFXLE1BQU0sU0FBUztHQUN6QyxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSTs7R0FHNUIsTUFBTSxXQUFXLElBQUksTUFBTSxZQUFZLFNBQVMsV0FBVyxLQUFNLElBQUssS0FBSztHQUMzRSxNQUFNLFFBQVEsSUFBSSxNQUFNLEtBQUssVUFBVSxPQUFPO0dBQzlDLE1BQU0sU0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFLLENBQUM7R0FDaEMsTUFBTSxhQUFhO0dBQ25CLE1BQU0sZ0JBQWdCO0dBQ3RCLE9BQU8sSUFBSSxLQUFLOztHQUdoQixDQUFDLENBQUMsUUFBUSxLQUFNLEtBQU0sUUFBUSxLQUFNLEdBQUksQ0FBQyxDQUFDLFNBQVEsU0FBUTtJQUN4RCxNQUFNLFVBQVUsSUFBSSxNQUFNLGlCQUFpQixLQUFNLEtBQU0sSUFBSyxDQUFDO0lBQzdELE1BQU0sT0FBTyxJQUFJLE1BQU0sS0FBSyxTQUFTLE1BQU07SUFDM0MsS0FBSyxTQUFTLElBQUksR0FBRyxJQUFJLElBQUssSUFBSTtJQUNsQyxLQUFLLGFBQWE7SUFDbEIsT0FBTyxJQUFJLElBQUk7O0lBR2YsTUFBTSxZQUFZLElBQUksTUFBTSxhQUFhLElBQUssSUFBSyxDQUFDO0lBQ3BELE1BQU0sU0FBUyxJQUFJLE1BQU0sS0FBSyxXQUFXLE9BQU87SUFDaEQsT0FBTyxTQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sSUFBSTtJQUNyQyxPQUFPLElBQUksTUFBTTtHQUNuQixDQUFDO0VBQ0g7RUFFQSxPQUFPO0NBQ1Q7Ozs7Q0FLQSxPQUFjLGlCQUFrRTtFQUM5RSxNQUFNLFFBQVEsSUFBSSxNQUFNLE1BQU07RUFFOUIsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FDN0MsS0FBSyxpQkFBaUIsd0JBQXdCO0dBQzlDLFdBQVc7RUFDYixDQUFDO0VBRUQsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FDN0MsT0FBTztHQUNQLFdBQVc7RUFDYixDQUFDOztFQUdELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7R0FDMUIsTUFBTSxRQUFTLElBQUksS0FBSyxLQUFLLElBQUs7R0FDbEMsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUIsS0FBTSxDQUFDO0dBQ3RELE1BQU0sT0FBTyxJQUFJLE1BQU0sS0FBSyxTQUFTLE9BQU87R0FDNUMsS0FBSyxTQUFTLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFLLEtBQU0sS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFHO0dBQ3BFLE1BQU0sSUFBSSxJQUFJO0VBQ2hCOztFQUdBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7R0FDMUIsTUFBTSxRQUFTLElBQUksS0FBSyxLQUFNO0dBQzlCLE1BQU0sU0FBUyxJQUFJLE1BQU0saUJBQWlCLElBQUssS0FBTSxLQUFLLENBQUM7R0FDM0QsTUFBTSxNQUFNLElBQUksTUFBTSxLQUFLLFFBQVEsT0FBTztHQUMxQyxJQUFJLFNBQVMsSUFBSSxHQUFHLEtBQU0sQ0FBQztHQUMzQixJQUFJLFNBQVMsSUFBSSxJQUFLLE9BQU8sQ0FBQztHQUM5QixNQUFNLElBQUksR0FBRztFQUNmOztFQUdBLE1BQU0sVUFBVSxJQUFJLE1BQU0sZUFBZSxLQUFNLElBQUksRUFBRTtFQUNyRCxNQUFNLFVBQVUsSUFBSSxNQUFNLGtCQUFrQixFQUFFLE9BQU8sU0FBUyxDQUFDO0VBQy9ELE1BQU0sT0FBTyxJQUFJLE1BQU0sS0FBSyxTQUFTLE9BQU87RUFDNUMsS0FBSyxTQUFTLElBQUk7RUFDbEIsTUFBTSxJQUFJLElBQUk7RUFFZCxNQUFNLFFBQVEsSUFBSSxNQUFNLFdBQVcsVUFBVSxLQUFLLElBQUksR0FBRztFQUN6RCxNQUFNLFNBQVMsSUFBSSxHQUFHLElBQUssQ0FBQztFQUM1QixNQUFNLElBQUksS0FBSztFQUVmLE9BQU87R0FBRTtHQUFPO0VBQU07Q0FDeEI7Ozs7Q0FLQSxPQUFjLGtCQUErQjtFQUMzQyxNQUFNLE9BQU8sSUFBSSxNQUFNLE1BQU07RUFFN0IsTUFBTSxZQUFZLElBQUksTUFBTSxxQkFBcUI7R0FDL0MsT0FBTztHQUNQLFdBQVc7RUFDYixDQUFDO0VBRUQsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FDN0MsT0FBTztHQUNQLFdBQVc7RUFDYixDQUFDOztFQUdELE1BQU0sVUFBVSxJQUFJLE1BQU0sYUFBYSxLQUFLLEtBQUssQ0FBQztFQUNsRCxNQUFNLFdBQVcsSUFBSSxNQUFNLEtBQUssU0FBUyxTQUFTO0VBQ2xELFNBQVMsU0FBUyxJQUFJO0VBQ3RCLFNBQVMsU0FBUyxJQUFJLEtBQUssS0FBSztFQUNoQyxTQUFTLGFBQWE7RUFDdEIsS0FBSyxJQUFJLFFBQVE7O0VBR2pCLE1BQU0sVUFBVSxJQUFJLE1BQU0saUJBQWlCLEtBQU0sS0FBTSxHQUFLLENBQUM7RUFDN0QsTUFBTSxXQUFXLElBQUksTUFBTSxLQUFLLFNBQVMsT0FBTztFQUNoRCxTQUFTLFNBQVMsSUFBSSxDQUFDLEtBQUssS0FBSyxHQUFHO0VBQ3BDLE1BQU0sWUFBWSxJQUFJLE1BQU0sS0FBSyxTQUFTLE9BQU87RUFDakQsVUFBVSxTQUFTLElBQUksS0FBSyxLQUFLLEdBQUc7RUFDcEMsS0FBSyxJQUFJLFVBQVUsU0FBUztFQUU1QixPQUFPO0NBQ1Q7Ozs7Q0FLQSxPQUFjLG1CQUFnQztFQUM1QyxNQUFNLFFBQVEsSUFBSSxNQUFNLE1BQU07RUFDOUIsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FBRSxPQUFPO0dBQVUsV0FBVztFQUFJLENBQUM7RUFDbEYsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FBRSxPQUFPO0dBQVUsV0FBVztFQUFJLENBQUM7O0VBR2xGLE1BQU0sU0FBUyxJQUFJLE1BQU0saUJBQWlCLEtBQU0sS0FBTSxLQUFLLENBQUM7RUFDNUQ7R0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUc7R0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHO0dBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRztHQUFHLENBQUMsS0FBSyxHQUFHO0VBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLE9BQU87R0FDdkUsTUFBTSxNQUFNLElBQUksTUFBTSxLQUFLLFFBQVEsT0FBTztHQUMxQyxJQUFJLFNBQVMsSUFBSSxHQUFHLE1BQU0sQ0FBQztHQUMzQixJQUFJLGFBQWE7R0FDakIsTUFBTSxJQUFJLEdBQUc7RUFDZixDQUFDOztFQUdELE1BQU0sV0FBVyxJQUFJLE1BQU0sWUFBWSxHQUFLLElBQUssRUFBRztFQUNwRCxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsU0FBUSxNQUFLO0dBQ3RCLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxVQUFVLE9BQU87R0FDM0MsR0FBRyxTQUFTLElBQUksR0FBRyxHQUFHLEdBQUc7R0FDekIsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLFVBQVUsT0FBTztHQUMzQyxHQUFHLFNBQVMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxHQUFHO0dBQzFCLE1BQU0sSUFBSSxJQUFJLEVBQUU7RUFDbEIsQ0FBQzs7RUFHRCxNQUFNLGNBQWMsSUFBSSxNQUFNLFlBQVksS0FBSyxLQUFNLEdBQUc7RUFDeEQsTUFBTSxXQUFXLElBQUksTUFBTSxLQUFLLGFBQWEsT0FBTztFQUNwRCxTQUFTLFNBQVMsSUFBSTtFQUN0QixTQUFTLGFBQWE7RUFDdEIsTUFBTSxJQUFJLFFBQVE7O0VBR2xCLE1BQU0sVUFBVSxJQUFJLE1BQU0sWUFBWSxLQUFLLElBQUssR0FBRztFQUNuRCxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0VBQzVDLEtBQUssU0FBUyxJQUFJO0VBQ2xCLE1BQU0sSUFBSSxJQUFJOztFQUdkLE1BQU0sVUFBVSxJQUFJLE1BQU0sYUFBYSxLQUFLLEtBQUssQ0FBQztFQUNsRCxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0VBQzVDLEtBQUssU0FBUyxJQUFJO0VBQ2xCLEtBQUssU0FBUyxJQUFJLEtBQUssS0FBSztFQUM1QixLQUFLLGFBQWE7RUFDbEIsTUFBTSxJQUFJLElBQUk7RUFFZCxPQUFPO0NBQ1Q7Ozs7Q0FLQSxPQUFjLG1CQUFnQztFQUM1QyxNQUFNLE1BQU0sSUFBSSxNQUFNLE1BQU07RUFDNUIsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FBRSxPQUFPO0dBQVUsV0FBVztFQUFLLENBQUM7RUFDbkYsTUFBTSxZQUFZLElBQUksTUFBTSxxQkFBcUI7R0FBRSxPQUFPO0dBQVUsV0FBVztFQUFLLENBQUM7O0VBR3JGLE1BQU0sVUFBVSxJQUFJLE1BQU0sWUFBWSxLQUFLLEtBQUssR0FBRztFQUNuRCxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0VBQzVDLEtBQUssU0FBUyxJQUFJO0VBQ2xCLEtBQUssYUFBYTtFQUNsQixLQUFLLGdCQUFnQjtFQUNyQixJQUFJLElBQUksSUFBSTs7RUFHWixNQUFNLFVBQVUsSUFBSSxNQUFNLGFBQWEsS0FBSyxLQUFLLENBQUM7RUFDbEQsTUFBTSxPQUFPLElBQUksTUFBTSxLQUFLLFNBQVMsU0FBUztFQUM5QyxLQUFLLFNBQVMsSUFBSTtFQUNsQixLQUFLLFNBQVMsSUFBSSxLQUFLLEtBQUs7RUFDNUIsS0FBSyxNQUFNLElBQUksS0FBSyxHQUFLLEdBQUc7RUFDNUIsS0FBSyxhQUFhO0VBQ2xCLElBQUksSUFBSSxJQUFJO0VBRVosT0FBTztDQUNUOzs7O0NBS0EsT0FBYyx3QkFBcUM7RUFDakQsTUFBTSxNQUFNLElBQUksTUFBTSxNQUFNO0VBQzVCLE1BQU0sVUFBVSxJQUFJLE1BQU0scUJBQXFCO0dBQUUsT0FBTztHQUFVLFdBQVc7RUFBSSxDQUFDOztFQUdsRixNQUFNLFVBQVUsSUFBSSxNQUFNLGlCQUFpQixJQUFLLElBQUssR0FBSyxDQUFDO0VBQzNELFFBQVEsUUFBUSxLQUFLLEtBQUssQ0FBQztFQUMzQixNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0VBQzVDLEtBQUssU0FBUyxJQUFJO0VBQ2xCLElBQUksSUFBSSxJQUFJOztFQUdaLEtBQUssSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFNO0dBQ3RDLE1BQU0sV0FBVyxJQUFJLE1BQU0saUJBQWlCLEtBQU0sS0FBTSxLQUFLLENBQUM7R0FDOUQsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLFVBQVUsT0FBTztHQUMzQyxHQUFHLFNBQVMsSUFBSSxHQUFHLElBQUssQ0FBQztHQUN6QixHQUFHLFNBQVMsSUFBSSxLQUFNLEdBQUcsQ0FBQztHQUMxQixNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssVUFBVSxPQUFPO0dBQzNDLEdBQUcsU0FBUyxJQUFJLEdBQUcsSUFBSyxDQUFDO0dBQ3pCLEdBQUcsU0FBUyxJQUFJLENBQUMsS0FBTSxHQUFHLENBQUM7R0FDM0IsSUFBSSxJQUFJLElBQUksRUFBRTtFQUNoQjtFQUVBLE9BQU87Q0FDVDs7OztDQUtBLE9BQWMsY0FBYyxZQUFZLFVBQTJEO0VBQ2pHLE1BQU0sUUFBUSxJQUFJLE1BQU0sTUFBTTtFQUM5QixNQUFNLFVBQVUsSUFBSSxNQUFNLHFCQUFxQjtHQUFFLE9BQU87R0FBVSxXQUFXO0dBQUssV0FBVztFQUFJLENBQUM7O0VBR2xHLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7R0FDMUIsTUFBTSxRQUFTLElBQUksS0FBSyxLQUFLLElBQUs7R0FDbEMsTUFBTSxTQUFTLElBQUksTUFBTSxpQkFBaUIsS0FBTSxLQUFNLEtBQUssQ0FBQztHQUM1RCxNQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUssUUFBUSxPQUFPO0dBQzFDLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksS0FBTSxJQUFLLEtBQUssSUFBSSxLQUFLLElBQUksR0FBSTtHQUNwRSxJQUFJLFNBQVMsSUFBSSxDQUFDLE1BQU8sS0FBSyxJQUFJLEtBQUssR0FBRyxHQUFHLE1BQU8sS0FBSyxJQUFJLEtBQUssQ0FBQztHQUNuRSxNQUFNLElBQUksR0FBRztFQUNmOztFQUdBLE1BQU0sVUFBVSxJQUFJLE1BQU0saUJBQWlCLElBQUssS0FBTSxJQUFLLEVBQUU7RUFDN0QsTUFBTSxPQUFPLElBQUksTUFBTSxLQUFLLFNBQVMsT0FBTztFQUM1QyxLQUFLLFNBQVMsSUFBSTtFQUNsQixNQUFNLElBQUksSUFBSTs7RUFHZCxNQUFNLFVBQVUsSUFBSSxNQUFNLGVBQWUsS0FBTSxHQUFHLENBQUM7RUFDbkQsTUFBTSxVQUFVLElBQUksTUFBTSxrQkFBa0IsRUFBRSxPQUFPLFVBQVUsQ0FBQztFQUNoRSxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0VBQzVDLEtBQUssU0FBUyxJQUFJO0VBQ2xCLE1BQU0sSUFBSSxJQUFJO0VBRWQsTUFBTSxRQUFRLElBQUksTUFBTSxXQUFXLFdBQVcsS0FBSyxJQUFJLEdBQUc7RUFDMUQsTUFBTSxTQUFTLElBQUksR0FBRyxLQUFLLENBQUM7RUFDNUIsTUFBTSxJQUFJLEtBQUs7RUFFZixPQUFPO0dBQUU7R0FBTztFQUFNO0NBQ3hCOzs7O0NBS0EsT0FBYyxxQkFBa0M7RUFDOUMsTUFBTSxTQUFTLElBQUksTUFBTSxNQUFNO0VBQy9CLE1BQU0sV0FBVyxJQUFJLE1BQU0scUJBQXFCO0dBQzlDLEtBQUssaUJBQWlCLHdCQUF3QjtHQUM5QyxXQUFXO0VBQ2IsQ0FBQzs7RUFHRCxNQUFNLFlBQVksSUFBSSxNQUFNLFlBQVksS0FBSyxJQUFLLEdBQUc7RUFDckQsTUFBTSxTQUFTLElBQUksTUFBTSxLQUFLLFdBQVcsUUFBUTtFQUNqRCxPQUFPLFNBQVMsSUFBSTtFQUNwQixPQUFPLGFBQWE7RUFDcEIsT0FBTyxJQUFJLE1BQU07O0VBR2pCLE1BQU0sVUFBVSxJQUFJLE1BQU0sWUFBWSxLQUFLLEtBQUssR0FBRztFQUNuRCxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssU0FBUyxRQUFRO0VBQzdDLEtBQUssU0FBUyxJQUFJO0VBQ2xCLEtBQUssYUFBYTtFQUNsQixPQUFPLElBQUksSUFBSTs7RUFHZixNQUFNLFVBQVUsSUFBSSxNQUFNLHFCQUFxQixJQUFLLENBQUM7RUFDckQsTUFBTSxPQUFPLElBQUksTUFBTSxLQUFLLFNBQVMsUUFBUTtFQUM3QyxLQUFLLFNBQVMsSUFBSSxHQUFHLEtBQUssR0FBSTtFQUM5QixPQUFPLElBQUksSUFBSTtFQUVmLE9BQU87Q0FDVDs7OztDQUtBLE9BQWMseUJBQXNDO0VBQ2xELE1BQU0sT0FBTyxJQUFJLE1BQU0sTUFBTTtFQUM3QixNQUFNLFNBQVMsSUFBSSxNQUFNLHFCQUFxQjtHQUM1QyxPQUFPO0dBQ1AsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDO0VBRUQsTUFBTSxXQUFXLElBQUksTUFBTSxhQUFhLEtBQUssS0FBSyxDQUFDO0VBQ25ELE1BQU0sUUFBUSxJQUFJLE1BQU0sS0FBSyxVQUFVLE1BQU07RUFDN0MsTUFBTSxTQUFTLElBQUk7RUFDbkIsTUFBTSxTQUFTLElBQUksS0FBTSxJQUFLLEdBQUk7RUFDbEMsTUFBTSxhQUFhO0VBQ25CLEtBQUssSUFBSSxLQUFLOztFQUdkLENBQUMsQ0FBQyxJQUFLLEVBQUcsQ0FBQyxDQUFDLFNBQVEsTUFBSztHQUN2QixNQUFNLFNBQVMsSUFBSSxNQUFNLGFBQWEsSUFBSyxLQUFLLENBQUM7R0FDakQsTUFBTSxNQUFNLElBQUksTUFBTSxLQUFLLFFBQVEsTUFBTTtHQUN6QyxJQUFJLFNBQVMsSUFBSSxHQUFHLEtBQUssRUFBRztHQUM1QixJQUFJLFNBQVMsSUFBSSxDQUFDLElBQUssR0FBRyxJQUFJLEVBQUc7R0FDakMsS0FBSyxJQUFJLEdBQUc7RUFDZCxDQUFDO0VBRUQsT0FBTztDQUNUO0FBQ0YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRW52aXJvbm1lbnRCdWlsZGVyLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0ICogYXMgVEhSRUUgZnJvbSAndGhyZWUnO1xuaW1wb3J0IHsgVGV4dHVyZUdlbmVyYXRvciB9IGZyb20gJy4vVGV4dHVyZUdlbmVyYXRvcic7XG5cbmV4cG9ydCBjbGFzcyBFbnZpcm9ubWVudEJ1aWxkZXIge1xuICAvKipcbiAgICogQnVpbGRzIGFuIGF1dGhlbnRpYyBKYXBhbmVzZSBtdWx0aS10aWVyIFBhZ29kYVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBjcmVhdGVQYWdvZGEobGV2ZWxzID0gMyk6IFRIUkVFLkdyb3VwIHtcbiAgICBjb25zdCBwYWdvZGEgPSBuZXcgVEhSRUUuR3JvdXAoKTtcblxuICAgIGNvbnN0IHJlZFdvb2RNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgbWFwOiBUZXh0dXJlR2VuZXJhdG9yLmdldFJlZExhY3F1ZXJUZXh0dXJlKCksXG4gICAgICByb3VnaG5lc3M6IDAuNSxcbiAgICAgIG1ldGFsbmVzczogMC4xLFxuICAgIH0pO1xuXG4gICAgY29uc3Qgcm9vZlRpbGVNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgbWFwOiBUZXh0dXJlR2VuZXJhdG9yLmdldFJvb2ZUaWxlVGV4dHVyZSgpLFxuICAgICAgcm91Z2huZXNzOiAwLjYsXG4gICAgICBtZXRhbG5lc3M6IDAuMixcbiAgICB9KTtcblxuICAgIGNvbnN0IHN0b25lTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIG1hcDogVGV4dHVyZUdlbmVyYXRvci5nZXRTdG9uZVBhdmVtZW50VGV4dHVyZSgpLFxuICAgICAgcm91Z2huZXNzOiAwLjgsXG4gICAgICBtZXRhbG5lc3M6IDAuMSxcbiAgICB9KTtcblxuICAgIGNvbnN0IGdvbGRNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgY29sb3I6IDB4ZGZhYTIyLFxuICAgICAgcm91Z2huZXNzOiAwLjMsXG4gICAgICBtZXRhbG5lc3M6IDAuOSxcbiAgICB9KTtcblxuICAgIC8vIDEuIFN0b25lIEZvdW5kYXRpb25cbiAgICBjb25zdCBiYXNlR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDksIDEuMiwgOSk7XG4gICAgY29uc3QgYmFzZU1lc2ggPSBuZXcgVEhSRUUuTWVzaChiYXNlR2VvLCBzdG9uZU1hdCk7XG4gICAgYmFzZU1lc2gucG9zaXRpb24ueSA9IDAuNjtcbiAgICBiYXNlTWVzaC5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICBiYXNlTWVzaC5yZWNlaXZlU2hhZG93ID0gdHJ1ZTtcbiAgICBwYWdvZGEuYWRkKGJhc2VNZXNoKTtcblxuICAgIC8vIFN0b25lIFN0ZXBzXG4gICAgY29uc3Qgc3RlcEdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeSgzLjUsIDAuNCwgMS4yKTtcbiAgICBjb25zdCBzdGVwID0gbmV3IFRIUkVFLk1lc2goc3RlcEdlbywgc3RvbmVNYXQpO1xuICAgIHN0ZXAucG9zaXRpb24uc2V0KDAsIDAuMiwgNSk7XG4gICAgcGFnb2RhLmFkZChzdGVwKTtcblxuICAgIGxldCBjdXJyZW50WSA9IDEuMjtcblxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGV2ZWxzOyBpKyspIHtcbiAgICAgIGNvbnN0IHNjYWxlID0gMSAtIGkgKiAwLjE4O1xuICAgICAgY29uc3QgZmxvb3JIZWlnaHQgPSAyLjggKiBzY2FsZTtcbiAgICAgIGNvbnN0IGZsb29yV2lkdGggPSA2LjUgKiBzY2FsZTtcblxuICAgICAgLy8gQ2VudHJhbCBDaGFtYmVyXG4gICAgICBjb25zdCB3YWxsR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KGZsb29yV2lkdGgsIGZsb29ySGVpZ2h0LCBmbG9vcldpZHRoKTtcbiAgICAgIGNvbnN0IHdhbGxNZXNoID0gbmV3IFRIUkVFLk1lc2god2FsbEdlbywgcmVkV29vZE1hdCk7XG4gICAgICB3YWxsTWVzaC5wb3NpdGlvbi55ID0gY3VycmVudFkgKyBmbG9vckhlaWdodCAqIDAuNTtcbiAgICAgIHdhbGxNZXNoLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgICAgd2FsbE1lc2gucmVjZWl2ZVNoYWRvdyA9IHRydWU7XG4gICAgICBwYWdvZGEuYWRkKHdhbGxNZXNoKTtcblxuICAgICAgLy8gVmVyYW5kYSAvIEJhbGNvbnkgUmFpbGluZ1xuICAgICAgY29uc3QgcmFpbGluZ0dlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeShmbG9vcldpZHRoICsgMS4yLCAwLjYsIGZsb29yV2lkdGggKyAxLjIpO1xuICAgICAgY29uc3QgcmFpbGluZ01lc2ggPSBuZXcgVEhSRUUuTWVzaChyYWlsaW5nR2VvLCByZWRXb29kTWF0KTtcbiAgICAgIHJhaWxpbmdNZXNoLnBvc2l0aW9uLnkgPSBjdXJyZW50WSArIDAuMztcbiAgICAgIHBhZ29kYS5hZGQocmFpbGluZ01lc2gpO1xuXG4gICAgICAvLyBGbGFyZWQgUm9vZiBFYXZlc1xuICAgICAgY29uc3Qgcm9vZkJvdHRvbVdpZHRoID0gZmxvb3JXaWR0aCArIDMuMjtcbiAgICAgIGNvbnN0IHJvb2ZUb3BXaWR0aCA9IGZsb29yV2lkdGggKiAwLjc7XG4gICAgICBjb25zdCByb29mR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkocm9vZlRvcFdpZHRoLCByb29mQm90dG9tV2lkdGgsIDEuMiAqIHNjYWxlLCA0KTtcbiAgICAgIGNvbnN0IHJvb2ZNZXNoID0gbmV3IFRIUkVFLk1lc2gocm9vZkdlbywgcm9vZlRpbGVNYXQpO1xuICAgICAgcm9vZk1lc2gucG9zaXRpb24ueSA9IGN1cnJlbnRZICsgZmxvb3JIZWlnaHQgKyAwLjYgKiBzY2FsZTtcbiAgICAgIHJvb2ZNZXNoLnJvdGF0aW9uLnkgPSBNYXRoLlBJIC8gNDtcbiAgICAgIHJvb2ZNZXNoLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgICAgcm9vZk1lc2gucmVjZWl2ZVNoYWRvdyA9IHRydWU7XG4gICAgICBwYWdvZGEuYWRkKHJvb2ZNZXNoKTtcblxuICAgICAgLy8gQ29ybmVyIEVhdmUgRmluaWFsc1xuICAgICAgY29uc3QgY29ybmVyR2VvID0gbmV3IFRIUkVFLkNvbmVHZW9tZXRyeSgwLjE4LCAwLjgsIDQpO1xuICAgICAgZm9yIChsZXQgYyA9IDA7IGMgPCA0OyBjKyspIHtcbiAgICAgICAgY29uc3QgYW5nbGUgPSAoYyAqIE1hdGguUEkpIC8gMiArIE1hdGguUEkgLyA0O1xuICAgICAgICBjb25zdCBkaXN0ID0gKHJvb2ZCb3R0b21XaWR0aCAqIE1hdGguU1FSVDIpIC8gMjtcbiAgICAgICAgY29uc3QgY29ybmVyRmluaWFsID0gbmV3IFRIUkVFLk1lc2goY29ybmVyR2VvLCBnb2xkTWF0KTtcbiAgICAgICAgY29ybmVyRmluaWFsLnBvc2l0aW9uLnNldChcbiAgICAgICAgICBNYXRoLmNvcyhhbmdsZSkgKiBkaXN0LFxuICAgICAgICAgIGN1cnJlbnRZICsgZmxvb3JIZWlnaHQgKyAwLjQgKiBzY2FsZSxcbiAgICAgICAgICBNYXRoLnNpbihhbmdsZSkgKiBkaXN0XG4gICAgICAgICk7XG4gICAgICAgIGNvcm5lckZpbmlhbC5yb3RhdGlvbi5zZXQoMC40ICogTWF0aC5zaW4oYW5nbGUpLCAwLCAwLjQgKiBNYXRoLmNvcyhhbmdsZSkpO1xuICAgICAgICBwYWdvZGEuYWRkKGNvcm5lckZpbmlhbCk7XG4gICAgICB9XG5cbiAgICAgIGN1cnJlbnRZICs9IGZsb29ySGVpZ2h0ICsgMS4wICogc2NhbGU7XG4gICAgfVxuXG4gICAgLy8gU29yaW4gU3BpcmUgKFBpbm5hY2xlIG9uIHRvcClcbiAgICBjb25zdCBzcGlyZUdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMDgsIDAuMjIsIDMuNSwgOCk7XG4gICAgY29uc3Qgc3BpcmVNZXNoID0gbmV3IFRIUkVFLk1lc2goc3BpcmVHZW8sIGdvbGRNYXQpO1xuICAgIHNwaXJlTWVzaC5wb3NpdGlvbi55ID0gY3VycmVudFkgKyAxLjc1O1xuICAgIHNwaXJlTWVzaC5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICBwYWdvZGEuYWRkKHNwaXJlTWVzaCk7XG5cbiAgICAvLyBTcGlyZSBSaW5nc1xuICAgIGZvciAobGV0IHIgPSAwOyByIDwgNzsgcisrKSB7XG4gICAgICBjb25zdCByaW5nR2VvID0gbmV3IFRIUkVFLlRvcnVzR2VvbWV0cnkoMC4yNiAtIHIgKiAwLjAyLCAwLjA1LCA4LCAxNik7XG4gICAgICBjb25zdCByaW5nTWVzaCA9IG5ldyBUSFJFRS5NZXNoKHJpbmdHZW8sIGdvbGRNYXQpO1xuICAgICAgcmluZ01lc2gucG9zaXRpb24ueSA9IGN1cnJlbnRZICsgMC44ICsgciAqIDAuMzU7XG4gICAgICByaW5nTWVzaC5yb3RhdGlvbi54ID0gTWF0aC5QSSAvIDI7XG4gICAgICBwYWdvZGEuYWRkKHJpbmdNZXNoKTtcbiAgICB9XG5cbiAgICByZXR1cm4gcGFnb2RhO1xuICB9XG5cbiAgLyoqXG4gICAqIEJ1aWxkcyBhbiBhdXRoZW50aWMgUmVkIFRvcmlpIEdhdGVcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgY3JlYXRlVG9yaWlHYXRlKCk6IFRIUkVFLkdyb3VwIHtcbiAgICBjb25zdCB0b3JpaSA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuXG4gICAgY29uc3QgcmVkTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIG1hcDogVGV4dHVyZUdlbmVyYXRvci5nZXRSZWRMYWNxdWVyVGV4dHVyZSgpLFxuICAgICAgcm91Z2huZXNzOiAwLjUsXG4gICAgICBtZXRhbG5lc3M6IDAuMSxcbiAgICB9KTtcblxuICAgIGNvbnN0IGJsYWNrTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiAweDE4MTgxYixcbiAgICAgIHJvdWdobmVzczogMC43LFxuICAgICAgbWV0YWxuZXNzOiAwLjIsXG4gICAgfSk7XG5cbiAgICBjb25zdCBzdG9uZU1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7XG4gICAgICBtYXA6IFRleHR1cmVHZW5lcmF0b3IuZ2V0U3RvbmVQYXZlbWVudFRleHR1cmUoKSxcbiAgICAgIHJvdWdobmVzczogMC44LFxuICAgIH0pO1xuXG4gICAgLy8gVHdpbiBQaWxsYXJzIChIYXNoaXJhKVxuICAgIGNvbnN0IHBpbGxhckhlaWdodCA9IDYuMjtcbiAgICBjb25zdCBwaWxsYXJEaXN0ID0gMi40O1xuICAgIGNvbnN0IHBpbGxhckdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMywgMC4zNSwgcGlsbGFySGVpZ2h0LCAxNik7XG5cbiAgICAvLyBMZWZ0IFBpbGxhclxuICAgIGNvbnN0IGxlZnRQaWxsYXIgPSBuZXcgVEhSRUUuTWVzaChwaWxsYXJHZW8sIHJlZE1hdCk7XG4gICAgbGVmdFBpbGxhci5wb3NpdGlvbi5zZXQoLXBpbGxhckRpc3QsIHBpbGxhckhlaWdodCAqIDAuNSwgMCk7XG4gICAgbGVmdFBpbGxhci5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICB0b3JpaS5hZGQobGVmdFBpbGxhcik7XG5cbiAgICBjb25zdCBiYXNlR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC40OCwgMC41MiwgMC42LCAxNik7XG4gICAgY29uc3QgbGVmdEJhc2UgPSBuZXcgVEhSRUUuTWVzaChiYXNlR2VvLCBzdG9uZU1hdCk7XG4gICAgbGVmdEJhc2UucG9zaXRpb24uc2V0KC1waWxsYXJEaXN0LCAwLjMsIDApO1xuICAgIHRvcmlpLmFkZChsZWZ0QmFzZSk7XG5cbiAgICAvLyBSaWdodCBQaWxsYXJcbiAgICBjb25zdCByaWdodFBpbGxhciA9IG5ldyBUSFJFRS5NZXNoKHBpbGxhckdlbywgcmVkTWF0KTtcbiAgICByaWdodFBpbGxhci5wb3NpdGlvbi5zZXQocGlsbGFyRGlzdCwgcGlsbGFySGVpZ2h0ICogMC41LCAwKTtcbiAgICByaWdodFBpbGxhci5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICB0b3JpaS5hZGQocmlnaHRQaWxsYXIpO1xuXG4gICAgY29uc3QgcmlnaHRCYXNlID0gbmV3IFRIUkVFLk1lc2goYmFzZUdlbywgc3RvbmVNYXQpO1xuICAgIHJpZ2h0QmFzZS5wb3NpdGlvbi5zZXQocGlsbGFyRGlzdCwgMC4zLCAwKTtcbiAgICB0b3JpaS5hZGQocmlnaHRCYXNlKTtcblxuICAgIC8vIFRvcCBTd2VlcGluZyBMaW50ZWwgKEthc2FnaSAmIFNoaW1ha2kpXG4gICAgY29uc3QgbGludGVsV2lkdGggPSA3LjY7XG4gICAgY29uc3Qga2FzYWdpR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KGxpbnRlbFdpZHRoLCAwLjUsIDAuNyk7XG4gICAgY29uc3Qga2FzYWdpTWVzaCA9IG5ldyBUSFJFRS5NZXNoKGthc2FnaUdlbywgcmVkTWF0KTtcbiAgICBrYXNhZ2lNZXNoLnBvc2l0aW9uLnNldCgwLCBwaWxsYXJIZWlnaHQgKyAwLjIsIDApO1xuICAgIGthc2FnaU1lc2guY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgdG9yaWkuYWRkKGthc2FnaU1lc2gpO1xuXG4gICAgLy8gQmxhY2sgUm9vZiBDYXAgb24gdG9wIG9mIGxpbnRlbFxuICAgIGNvbnN0IGNhcEdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeShsaW50ZWxXaWR0aCArIDAuNCwgMC4xNSwgMC44NSk7XG4gICAgY29uc3QgY2FwTWVzaCA9IG5ldyBUSFJFRS5NZXNoKGNhcEdlbywgYmxhY2tNYXQpO1xuICAgIGNhcE1lc2gucG9zaXRpb24uc2V0KDAsIHBpbGxhckhlaWdodCArIDAuNSwgMCk7XG4gICAgdG9yaWkuYWRkKGNhcE1lc2gpO1xuXG4gICAgLy8gU2Vjb25kYXJ5IFRpZS1CZWFtIChOdWtpKVxuICAgIGNvbnN0IG51a2lHZW8gPSBuZXcgVEhSRUUuQm94R2VvbWV0cnkobGludGVsV2lkdGggLSAxLjIsIDAuMzUsIDAuNDUpO1xuICAgIGNvbnN0IG51a2lNZXNoID0gbmV3IFRIUkVFLk1lc2gobnVraUdlbywgcmVkTWF0KTtcbiAgICBudWtpTWVzaC5wb3NpdGlvbi5zZXQoMCwgcGlsbGFySGVpZ2h0IC0gMC45LCAwKTtcbiAgICBudWtpTWVzaC5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICB0b3JpaS5hZGQobnVraU1lc2gpO1xuXG4gICAgLy8gQ2VudHJhbCBQbGFxdWUgKEdha3V6dWthKVxuICAgIGNvbnN0IHBsYXF1ZUdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeSgwLjUsIDAuOSwgMC4xKTtcbiAgICBjb25zdCBwbGFxdWVNZXNoID0gbmV3IFRIUkVFLk1lc2gocGxhcXVlR2VvLCBibGFja01hdCk7XG4gICAgcGxhcXVlTWVzaC5wb3NpdGlvbi5zZXQoMCwgcGlsbGFySGVpZ2h0IC0gMC4zNSwgMCk7XG4gICAgdG9yaWkuYWRkKHBsYXF1ZU1lc2gpO1xuXG4gICAgcmV0dXJuIHRvcmlpO1xuICB9XG5cbiAgLyoqXG4gICAqIEJ1aWxkcyBhbiBhdXRoZW50aWMgSmFwYW5lc2UgU3RvbmUgTGFudGVybiAoVG9ybykgd2l0aCB3YXJtIGxpZ2h0XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGNyZWF0ZVN0b25lTGFudGVybihoYXNQb2ludExpZ2h0ID0gdHJ1ZSk6IHsgZ3JvdXA6IFRIUkVFLkdyb3VwOyBsaWdodD86IFRIUkVFLlBvaW50TGlnaHQgfSB7XG4gICAgY29uc3QgZ3JvdXAgPSBuZXcgVEhSRUUuR3JvdXAoKTtcblxuICAgIGNvbnN0IHN0b25lTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIG1hcDogVGV4dHVyZUdlbmVyYXRvci5nZXRTdG9uZVBhdmVtZW50VGV4dHVyZSgpLFxuICAgICAgcm91Z2huZXNzOiAwLjg1LFxuICAgICAgbWV0YWxuZXNzOiAwLjA1LFxuICAgIH0pO1xuXG4gICAgY29uc3QgZ2xvd1BhcGVyTWF0ID0gbmV3IFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiAweGZmYjc0ZCxcbiAgICB9KTtcblxuICAgIC8vIDEuIEJhc2VzdG9uZSAoS2lzbylcbiAgICBjb25zdCBiYXNlR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC41NSwgMC42NSwgMC4zNSwgNik7XG4gICAgY29uc3QgYmFzZSA9IG5ldyBUSFJFRS5NZXNoKGJhc2VHZW8sIHN0b25lTWF0KTtcbiAgICBiYXNlLnBvc2l0aW9uLnkgPSAwLjE3NTtcbiAgICBiYXNlLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgIGdyb3VwLmFkZChiYXNlKTtcblxuICAgIC8vIDIuIFNoYWZ0IChTYW8pXG4gICAgY29uc3Qgc2hhZnRHZW8gPSBuZXcgVEhSRUUuQ3lsaW5kZXJHZW9tZXRyeSgwLjI0LCAwLjI4LCAwLjk1LCA2KTtcbiAgICBjb25zdCBzaGFmdCA9IG5ldyBUSFJFRS5NZXNoKHNoYWZ0R2VvLCBzdG9uZU1hdCk7XG4gICAgc2hhZnQucG9zaXRpb24ueSA9IDAuODtcbiAgICBzaGFmdC5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICBncm91cC5hZGQoc2hhZnQpO1xuXG4gICAgLy8gMy4gTWlkZGxlIFBsYXRmb3JtIChDaHVkYWkpXG4gICAgY29uc3QgcGxhdGZvcm1HZW8gPSBuZXcgVEhSRUUuQ3lsaW5kZXJHZW9tZXRyeSgwLjYyLCAwLjQ1LCAwLjMsIDYpO1xuICAgIGNvbnN0IHBsYXRmb3JtID0gbmV3IFRIUkVFLk1lc2gocGxhdGZvcm1HZW8sIHN0b25lTWF0KTtcbiAgICBwbGF0Zm9ybS5wb3NpdGlvbi55ID0gMS40O1xuICAgIGdyb3VwLmFkZChwbGF0Zm9ybSk7XG5cbiAgICAvLyA0LiBGaXJlYm94IChIaWJ1a3Vybykgd2l0aCBnbG93aW5nIHdpbmRvd3NcbiAgICBjb25zdCBmaXJlYm94R2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC40MiwgMC40MiwgMC41LCA2KTtcbiAgICBjb25zdCBmaXJlYm94ID0gbmV3IFRIUkVFLk1lc2goZmlyZWJveEdlbywgZ2xvd1BhcGVyTWF0KTtcbiAgICBmaXJlYm94LnBvc2l0aW9uLnkgPSAxLjg7XG4gICAgZ3JvdXAuYWRkKGZpcmVib3gpO1xuXG4gICAgLy8gNS4gUm9vZiBVbWJyZWxsYSAoS2FzYSlcbiAgICBjb25zdCB1bWJyZWxsYUdlbyA9IG5ldyBUSFJFRS5Db25lR2VvbWV0cnkoMC43OCwgMC40NSwgNik7XG4gICAgY29uc3QgdW1icmVsbGEgPSBuZXcgVEhSRUUuTWVzaCh1bWJyZWxsYUdlbywgc3RvbmVNYXQpO1xuICAgIHVtYnJlbGxhLnBvc2l0aW9uLnkgPSAyLjI1O1xuICAgIHVtYnJlbGxhLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgIGdyb3VwLmFkZCh1bWJyZWxsYSk7XG5cbiAgICAvLyA2LiBKZXdlbCBGaW5pYWwgKEhvanUpXG4gICAgY29uc3QgZmluaWFsR2VvID0gbmV3IFRIUkVFLlNwaGVyZUdlb21ldHJ5KDAuMTQsIDgsIDgpO1xuICAgIGNvbnN0IGZpbmlhbCA9IG5ldyBUSFJFRS5NZXNoKGZpbmlhbEdlbywgc3RvbmVNYXQpO1xuICAgIGZpbmlhbC5wb3NpdGlvbi55ID0gMi41ODtcbiAgICBncm91cC5hZGQoZmluaWFsKTtcblxuICAgIGxldCBsaWdodDogVEhSRUUuUG9pbnRMaWdodCB8IHVuZGVmaW5lZDtcbiAgICBpZiAoaGFzUG9pbnRMaWdodCkge1xuICAgICAgbGlnaHQgPSBuZXcgVEhSRUUuUG9pbnRMaWdodCgweGZmOTgwMCwgMS41LCAxMiwgMS4yKTtcbiAgICAgIGxpZ2h0LnBvc2l0aW9uLnNldCgwLCAxLjgsIDApO1xuICAgICAgZ3JvdXAuYWRkKGxpZ2h0KTtcbiAgICB9XG5cbiAgICByZXR1cm4geyBncm91cCwgbGlnaHQgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWlsZHMgYW4gYXV0aGVudGljIENoZXJyeSBCbG9zc29tIChTYWt1cmEpIFRyZWVcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgY3JlYXRlU2FrdXJhVHJlZSgpOiBUSFJFRS5Hcm91cCB7XG4gICAgY29uc3QgdHJlZSA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuXG4gICAgLy8gV2VhdGhlcmVkIEduYXJsZWQgQmFya1xuICAgIGNvbnN0IGJhcmtNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgY29sb3I6IDB4NDIyMDA2LFxuICAgICAgcm91Z2huZXNzOiAwLjksXG4gICAgICBtZXRhbG5lc3M6IDAuMDUsXG4gICAgfSk7XG5cbiAgICAvLyBGb2xpYWdlIE1hdGVyaWFsIHdpdGggc2FrdXJhIHBldGFsIHRleHR1cmVcbiAgICBjb25zdCBmb2xpYWdlTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiAweGY0NzJiNixcbiAgICAgIHJvdWdobmVzczogMC43LFxuICAgICAgbWV0YWxuZXNzOiAwLjEsXG4gICAgfSk7XG5cbiAgICBjb25zdCBoaWdobGlnaHRGb2xpYWdlTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiAweGZiY2ZlOCxcbiAgICAgIHJvdWdobmVzczogMC42LFxuICAgICAgbWV0YWxuZXNzOiAwLjA1LFxuICAgIH0pO1xuXG4gICAgLy8gTWFpbiBUcnVuayAodHdpc3RlZCAmIGxlYW5pbmcgc2xpZ2h0bHkgZm9yIG9yZ2FuaWMgcmVhbGlzbSlcbiAgICBjb25zdCB0cnVua0dlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMzUsIDAuNiwgMy44LCAxMCk7XG4gICAgY29uc3QgdHJ1bmsgPSBuZXcgVEhSRUUuTWVzaCh0cnVua0dlbywgYmFya01hdCk7XG4gICAgdHJ1bmsucG9zaXRpb24uc2V0KDAsIDEuOSwgMCk7XG4gICAgdHJ1bmsucm90YXRpb24ueiA9IDAuMDg7XG4gICAgdHJ1bmsuY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgdHJlZS5hZGQodHJ1bmspO1xuXG4gICAgLy8gUm9vdCBmbGFyZXNcbiAgICBmb3IgKGxldCByID0gMDsgciA8IDQ7IHIrKykge1xuICAgICAgY29uc3QgYW5nbGUgPSAociAqIE1hdGguUEkpIC8gMjtcbiAgICAgIGNvbnN0IHJvb3RHZW8gPSBuZXcgVEhSRUUuQm94R2VvbWV0cnkoMC40LCAwLjYsIDAuOSk7XG4gICAgICBjb25zdCByb290TWVzaCA9IG5ldyBUSFJFRS5NZXNoKHJvb3RHZW8sIGJhcmtNYXQpO1xuICAgICAgcm9vdE1lc2gucG9zaXRpb24uc2V0KE1hdGguY29zKGFuZ2xlKSAqIDAuNDUsIDAuMjUsIE1hdGguc2luKGFuZ2xlKSAqIDAuNDUpO1xuICAgICAgcm9vdE1lc2gucm90YXRpb24ueSA9IGFuZ2xlO1xuICAgICAgdHJlZS5hZGQocm9vdE1lc2gpO1xuICAgIH1cblxuICAgIC8vIE1haW4gQnJhbmNoZXNcbiAgICBjb25zdCBicmFuY2hlcyA9IFtcbiAgICAgIHsgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygwLjUsIDMuMiwgMC40KSwgcm90OiBuZXcgVEhSRUUuRXVsZXIoMC40LCAwLjIsIDAuNiksIHNjYWxlOiAwLjcgfSxcbiAgICAgIHsgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygtMC42LCAzLjQsIC0wLjMpLCByb3Q6IG5ldyBUSFJFRS5FdWxlcigtMC4zLCAtMC40LCAtMC43KSwgc2NhbGU6IDAuNjUgfSxcbiAgICAgIHsgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygwLjEsIDMuOCwgLTAuNSksIHJvdDogbmV3IFRIUkVFLkV1bGVyKC0wLjYsIDAuNSwgMC4yKSwgc2NhbGU6IDAuNiB9LFxuICAgIF07XG5cbiAgICBicmFuY2hlcy5mb3JFYWNoKGIgPT4ge1xuICAgICAgY29uc3QgYkdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMTggKiBiLnNjYWxlLCAwLjI4ICogYi5zY2FsZSwgMi4yICogYi5zY2FsZSwgOCk7XG4gICAgICBjb25zdCBiTWVzaCA9IG5ldyBUSFJFRS5NZXNoKGJHZW8sIGJhcmtNYXQpO1xuICAgICAgYk1lc2gucG9zaXRpb24uY29weShiLnBvcyk7XG4gICAgICBiTWVzaC5yb3RhdGlvbi5jb3B5KGIucm90KTtcbiAgICAgIGJNZXNoLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgICAgdHJlZS5hZGQoYk1lc2gpO1xuICAgIH0pO1xuXG4gICAgLy8gQ2xvdWQtbGlrZSBTYWt1cmEgQmxvc3NvbSBDYW5vcHkgQ2x1c3RlcnNcbiAgICBjb25zdCBjbHVzdGVycyA9IFtcbiAgICAgIHsgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygwLCA0LjgsIDApLCByOiAxLjgsIG1hdDogZm9saWFnZU1hdCB9LFxuICAgICAgeyBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKDEuNCwgNC4zLCAwLjgpLCByOiAxLjQsIG1hdDogaGlnaGxpZ2h0Rm9saWFnZU1hdCB9LFxuICAgICAgeyBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKC0xLjUsIDQuMiwgLTAuNyksIHI6IDEuNSwgbWF0OiBmb2xpYWdlTWF0IH0sXG4gICAgICB7IHBvczogbmV3IFRIUkVFLlZlY3RvcjMoMC4zLCA0LjksIC0xLjMpLCByOiAxLjMsIG1hdDogaGlnaGxpZ2h0Rm9saWFnZU1hdCB9LFxuICAgICAgeyBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKC0wLjcsIDUuMiwgMC44KSwgcjogMS4yLCBtYXQ6IGZvbGlhZ2VNYXQgfSxcbiAgICAgIHsgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygwLjksIDMuNiwgLTAuNiksIHI6IDEuMSwgbWF0OiBoaWdobGlnaHRGb2xpYWdlTWF0IH0sXG4gICAgXTtcblxuICAgIGNsdXN0ZXJzLmZvckVhY2goYyA9PiB7XG4gICAgICBjb25zdCBnZW8gPSBuZXcgVEhSRUUuRG9kZWNhaGVkcm9uR2VvbWV0cnkoYy5yLCAyKTtcbiAgICAgIGNvbnN0IG1lc2ggPSBuZXcgVEhSRUUuTWVzaChnZW8sIGMubWF0KTtcbiAgICAgIG1lc2gucG9zaXRpb24uY29weShjLnBvcyk7XG4gICAgICBtZXNoLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgICAgdHJlZS5hZGQobWVzaCk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gdHJlZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWlsZHMgYW4gYXV0aGVudGljIEphcGFuZXNlIFRpZXJlZCBCbGFjayBQaW5lIFRyZWVcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgY3JlYXRlUGluZVRyZWUoKTogVEhSRUUuR3JvdXAge1xuICAgIGNvbnN0IHRyZWUgPSBuZXcgVEhSRUUuR3JvdXAoKTtcblxuICAgIGNvbnN0IGJhcmtNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgY29sb3I6IDB4MjcxZTE2LFxuICAgICAgcm91Z2huZXNzOiAwLjk1LFxuICAgIH0pO1xuXG4gICAgY29uc3QgbmVlZGxlTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiAweDE0NTMyZCxcbiAgICAgIHJvdWdobmVzczogMC44LFxuICAgIH0pO1xuXG4gICAgLy8gTGVhbmluZyBjdXJ2ZWQgdHJ1bmtcbiAgICBjb25zdCB0cnVua0dlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMywgMC41NSwgNC41LCA4KTtcbiAgICBjb25zdCB0cnVuayA9IG5ldyBUSFJFRS5NZXNoKHRydW5rR2VvLCBiYXJrTWF0KTtcbiAgICB0cnVuay5wb3NpdGlvbi5zZXQoMC4zLCAyLjI1LCAwKTtcbiAgICB0cnVuay5yb3RhdGlvbi56ID0gMC4xMjtcbiAgICB0cnVuay5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICB0cmVlLmFkZCh0cnVuayk7XG5cbiAgICAvLyBUaWVyZWQgZmxhdCBmb2xpYWdlIHBhZHNcbiAgICBjb25zdCB0aWVycyA9IFtcbiAgICAgIHsgeTogMi44LCByOiAyLjIsIGg6IDAuNiwgeDogMC44IH0sXG4gICAgICB7IHk6IDMuOCwgcjogMS44LCBoOiAwLjUsIHg6IDAuNCB9LFxuICAgICAgeyB5OiA0LjYsIHI6IDEuNCwgaDogMC40NSwgeDogMC4yIH0sXG4gICAgICB7IHk6IDUuMywgcjogMC45LCBoOiAwLjQsIHg6IDAuMCB9LFxuICAgIF07XG5cbiAgICB0aWVycy5mb3JFYWNoKHRpZXIgPT4ge1xuICAgICAgY29uc3QgcGFkR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC4yLCB0aWVyLnIsIHRpZXIuaCwgMTApO1xuICAgICAgY29uc3QgcGFkID0gbmV3IFRIUkVFLk1lc2gocGFkR2VvLCBuZWVkbGVNYXQpO1xuICAgICAgcGFkLnBvc2l0aW9uLnNldCh0aWVyLngsIHRpZXIueSwgMCk7XG4gICAgICBwYWQuY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgICB0cmVlLmFkZChwYWQpO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIHRyZWU7XG4gIH1cblxuICAvKipcbiAgICogQnVpbGRzIGFuIGFyY2hlZCBXb29kZW4gSmFwYW5lc2UgQnJpZGdlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGNyZWF0ZUFyY2hlZEJyaWRnZShsZW5ndGggPSAxMCwgd2lkdGggPSAzKTogVEhSRUUuR3JvdXAge1xuICAgIGNvbnN0IGJyaWRnZSA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuXG4gICAgY29uc3Qgd29vZE1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7XG4gICAgICBjb2xvcjogMHg3ODM1MGYsXG4gICAgICByb3VnaG5lc3M6IDAuNyxcbiAgICAgIG1ldGFsbmVzczogMC4xLFxuICAgIH0pO1xuXG4gICAgY29uc3QgcmVkTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIG1hcDogVGV4dHVyZUdlbmVyYXRvci5nZXRSZWRMYWNxdWVyVGV4dHVyZSgpLFxuICAgICAgcm91Z2huZXNzOiAwLjUsXG4gICAgfSk7XG5cbiAgICBjb25zdCBnb2xkTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiAweGRmYWEyMixcbiAgICAgIG1ldGFsbmVzczogMC45LFxuICAgICAgcm91Z2huZXNzOiAwLjIsXG4gICAgfSk7XG5cbiAgICBjb25zdCBzZWdtZW50cyA9IDEyO1xuICAgIGNvbnN0IHN0ZXBBbmdsZSA9IE1hdGguUEkgLyBzZWdtZW50cztcblxuICAgIGZvciAobGV0IGkgPSAwOyBpIDw9IHNlZ21lbnRzOyBpKyspIHtcbiAgICAgIGNvbnN0IGFuZ2xlID0gaSAqIHN0ZXBBbmdsZTtcbiAgICAgIGNvbnN0IHggPSAoaSAtIHNlZ21lbnRzIC8gMikgKiAobGVuZ3RoIC8gc2VnbWVudHMpO1xuICAgICAgY29uc3QgeSA9IE1hdGguc2luKGFuZ2xlKSAqIDEuNDtcblxuICAgICAgLy8gRGVjayBQbGFua1xuICAgICAgY29uc3QgcGxhbmtHZW8gPSBuZXcgVEhSRUUuQm94R2VvbWV0cnkobGVuZ3RoIC8gc2VnbWVudHMgKyAwLjA4LCAwLjIsIHdpZHRoKTtcbiAgICAgIGNvbnN0IHBsYW5rID0gbmV3IFRIUkVFLk1lc2gocGxhbmtHZW8sIHdvb2RNYXQpO1xuICAgICAgcGxhbmsucG9zaXRpb24uc2V0KHgsIHkgKyAwLjIsIDApO1xuICAgICAgcGxhbmsuY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgICBwbGFuay5yZWNlaXZlU2hhZG93ID0gdHJ1ZTtcbiAgICAgIGJyaWRnZS5hZGQocGxhbmspO1xuXG4gICAgICAvLyBSYWlsaW5nIFBvc3RzIG9uIGJvdGggc2lkZXNcbiAgICAgIFstd2lkdGggKiAwLjUgKyAwLjE1LCB3aWR0aCAqIDAuNSAtIDAuMTVdLmZvckVhY2goelBvcyA9PiB7XG4gICAgICAgIGNvbnN0IHBvc3RHZW8gPSBuZXcgVEhSRUUuQ3lsaW5kZXJHZW9tZXRyeSgwLjA4LCAwLjA4LCAwLjksIDgpO1xuICAgICAgICBjb25zdCBwb3N0ID0gbmV3IFRIUkVFLk1lc2gocG9zdEdlbywgcmVkTWF0KTtcbiAgICAgICAgcG9zdC5wb3NpdGlvbi5zZXQoeCwgeSArIDAuNywgelBvcyk7XG4gICAgICAgIHBvc3QuY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgICAgIGJyaWRnZS5hZGQocG9zdCk7XG5cbiAgICAgICAgLy8gR29sZGVuIEdpYm9zaGkgZmluaWFsIG9uIHRvcCBvZiBwb3N0c1xuICAgICAgICBjb25zdCBmaW5pYWxHZW8gPSBuZXcgVEhSRUUuQ29uZUdlb21ldHJ5KDAuMSwgMC4yLCA4KTtcbiAgICAgICAgY29uc3QgZmluaWFsID0gbmV3IFRIUkVFLk1lc2goZmluaWFsR2VvLCBnb2xkTWF0KTtcbiAgICAgICAgZmluaWFsLnBvc2l0aW9uLnNldCh4LCB5ICsgMS4yNSwgelBvcyk7XG4gICAgICAgIGJyaWRnZS5hZGQoZmluaWFsKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiBicmlkZ2U7XG4gIH1cblxuICAvKipcbiAgICogQnVpbGRzIGFuIEVuZW15IENhbXBmaXJlIHdpdGggZmxpY2tlcmluZyBwb2ludCBsaWdodCBhbmQgZW1iZXJzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGNyZWF0ZUNhbXBmaXJlKCk6IHsgZ3JvdXA6IFRIUkVFLkdyb3VwOyBsaWdodDogVEhSRUUuUG9pbnRMaWdodCB9IHtcbiAgICBjb25zdCBncm91cCA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuXG4gICAgY29uc3Qgcm9ja01hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7XG4gICAgICBtYXA6IFRleHR1cmVHZW5lcmF0b3IuZ2V0U3RvbmVQYXZlbWVudFRleHR1cmUoKSxcbiAgICAgIHJvdWdobmVzczogMC45LFxuICAgIH0pO1xuXG4gICAgY29uc3Qgd29vZE1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7XG4gICAgICBjb2xvcjogMHgyOTE0MDQsXG4gICAgICByb3VnaG5lc3M6IDAuOTUsXG4gICAgfSk7XG5cbiAgICAvLyBSb2NrIHJpbmdcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDg7IGkrKykge1xuICAgICAgY29uc3QgYW5nbGUgPSAoaSAqIE1hdGguUEkgKiAyKSAvIDg7XG4gICAgICBjb25zdCByb2NrR2VvID0gbmV3IFRIUkVFLkRvZGVjYWhlZHJvbkdlb21ldHJ5KDAuMjQsIDEpO1xuICAgICAgY29uc3Qgcm9jayA9IG5ldyBUSFJFRS5NZXNoKHJvY2tHZW8sIHJvY2tNYXQpO1xuICAgICAgcm9jay5wb3NpdGlvbi5zZXQoTWF0aC5jb3MoYW5nbGUpICogMC44LCAwLjE1LCBNYXRoLnNpbihhbmdsZSkgKiAwLjgpO1xuICAgICAgZ3JvdXAuYWRkKHJvY2spO1xuICAgIH1cblxuICAgIC8vIENyb3NzZWQgbG9nc1xuICAgIGZvciAobGV0IGogPSAwOyBqIDwgNDsgaisrKSB7XG4gICAgICBjb25zdCBhbmdsZSA9IChqICogTWF0aC5QSSkgLyAyO1xuICAgICAgY29uc3QgbG9nR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC4xLCAwLjEyLCAxLjIsIDYpO1xuICAgICAgY29uc3QgbG9nID0gbmV3IFRIUkVFLk1lc2gobG9nR2VvLCB3b29kTWF0KTtcbiAgICAgIGxvZy5wb3NpdGlvbi5zZXQoMCwgMC4yNSwgMCk7XG4gICAgICBsb2cucm90YXRpb24uc2V0KDAuNCwgYW5nbGUsIDApO1xuICAgICAgZ3JvdXAuYWRkKGxvZyk7XG4gICAgfVxuXG4gICAgLy8gR2xvd2luZyBjb3JlXG4gICAgY29uc3QgY29yZUdlbyA9IG5ldyBUSFJFRS5TcGhlcmVHZW9tZXRyeSgwLjM1LCAxMiwgMTIpO1xuICAgIGNvbnN0IGNvcmVNYXQgPSBuZXcgVEhSRUUuTWVzaEJhc2ljTWF0ZXJpYWwoeyBjb2xvcjogMHhmZjQ1MDAgfSk7XG4gICAgY29uc3QgY29yZSA9IG5ldyBUSFJFRS5NZXNoKGNvcmVHZW8sIGNvcmVNYXQpO1xuICAgIGNvcmUucG9zaXRpb24ueSA9IDAuMzU7XG4gICAgZ3JvdXAuYWRkKGNvcmUpO1xuXG4gICAgY29uc3QgbGlnaHQgPSBuZXcgVEhSRUUuUG9pbnRMaWdodCgweGZmNTUwMCwgMy41LCAxNiwgMS41KTtcbiAgICBsaWdodC5wb3NpdGlvbi5zZXQoMCwgMC44LCAwKTtcbiAgICBncm91cC5hZGQobGlnaHQpO1xuXG4gICAgcmV0dXJuIHsgZ3JvdXAsIGxpZ2h0IH07XG4gIH1cblxuICAvKipcbiAgICogQnVpbGRzIGFuIEVuZW15IFdhciBUZW50XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGNyZWF0ZUVuZW15VGVudCgpOiBUSFJFRS5Hcm91cCB7XG4gICAgY29uc3QgdGVudCA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuXG4gICAgY29uc3QgY2FudmFzTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiAweDNmM2Y0NixcbiAgICAgIHJvdWdobmVzczogMC44LFxuICAgIH0pO1xuXG4gICAgY29uc3Qgd29vZE1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7XG4gICAgICBjb2xvcjogMHg1MjUyNWIsXG4gICAgICByb3VnaG5lc3M6IDAuOCxcbiAgICB9KTtcblxuICAgIC8vIFdlZGdlIHRlbnQgZ2VvbWV0cnlcbiAgICBjb25zdCB0ZW50R2VvID0gbmV3IFRIUkVFLkNvbmVHZW9tZXRyeSgyLjQsIDIuOCwgNCk7XG4gICAgY29uc3QgdGVudE1lc2ggPSBuZXcgVEhSRUUuTWVzaCh0ZW50R2VvLCBjYW52YXNNYXQpO1xuICAgIHRlbnRNZXNoLnBvc2l0aW9uLnkgPSAxLjQ7XG4gICAgdGVudE1lc2gucm90YXRpb24ueSA9IE1hdGguUEkgLyA0O1xuICAgIHRlbnRNZXNoLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgIHRlbnQuYWRkKHRlbnRNZXNoKTtcblxuICAgIC8vIEZyb250IHBvbGVzXG4gICAgY29uc3QgcG9sZUdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMDgsIDAuMDgsIDMuMCwgOCk7XG4gICAgY29uc3QgbGVmdFBvbGUgPSBuZXcgVEhSRUUuTWVzaChwb2xlR2VvLCB3b29kTWF0KTtcbiAgICBsZWZ0UG9sZS5wb3NpdGlvbi5zZXQoLTEuMiwgMS41LCAxLjIpO1xuICAgIGNvbnN0IHJpZ2h0UG9sZSA9IG5ldyBUSFJFRS5NZXNoKHBvbGVHZW8sIHdvb2RNYXQpO1xuICAgIHJpZ2h0UG9sZS5wb3NpdGlvbi5zZXQoMS4yLCAxLjUsIDEuMik7XG4gICAgdGVudC5hZGQobGVmdFBvbGUsIHJpZ2h0UG9sZSk7XG5cbiAgICByZXR1cm4gdGVudDtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWlsZHMgYSBTYW11cmFpIFdvb2RlbiBXYXRjaHRvd2VyXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGNyZWF0ZVdhdGNodG93ZXIoKTogVEhSRUUuR3JvdXAge1xuICAgIGNvbnN0IHRvd2VyID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgY29uc3Qgd29vZE1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7IGNvbG9yOiAweDQ1MWEwMywgcm91Z2huZXNzOiAwLjggfSk7XG4gICAgY29uc3Qgcm9vZk1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7IGNvbG9yOiAweDFjMTkxNywgcm91Z2huZXNzOiAwLjcgfSk7XG5cbiAgICAvLyA0IENvcm5lciBMZWdzXG4gICAgY29uc3QgbGVnR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC4xMiwgMC4xNiwgNy41LCA4KTtcbiAgICBbWy0xLjQsIC0xLjRdLCBbMS40LCAtMS40XSwgWy0xLjQsIDEuNF0sIFsxLjQsIDEuNF1dLmZvckVhY2goKFt4LCB6XSkgPT4ge1xuICAgICAgY29uc3QgbGVnID0gbmV3IFRIUkVFLk1lc2gobGVnR2VvLCB3b29kTWF0KTtcbiAgICAgIGxlZy5wb3NpdGlvbi5zZXQoeCwgMy43NSwgeik7XG4gICAgICBsZWcuY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgICB0b3dlci5hZGQobGVnKTtcbiAgICB9KTtcblxuICAgIC8vIENyb3NzIGJyYWNlc1xuICAgIGNvbnN0IGJyYWNlR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDMuMCwgMC4xLCAwLjEpO1xuICAgIFsyLjIsIDQuOF0uZm9yRWFjaCh5ID0+IHtcbiAgICAgIGNvbnN0IGIxID0gbmV3IFRIUkVFLk1lc2goYnJhY2VHZW8sIHdvb2RNYXQpO1xuICAgICAgYjEucG9zaXRpb24uc2V0KDAsIHksIDEuNCk7XG4gICAgICBjb25zdCBiMiA9IG5ldyBUSFJFRS5NZXNoKGJyYWNlR2VvLCB3b29kTWF0KTtcbiAgICAgIGIyLnBvc2l0aW9uLnNldCgwLCB5LCAtMS40KTtcbiAgICAgIHRvd2VyLmFkZChiMSwgYjIpO1xuICAgIH0pO1xuXG4gICAgLy8gTG9va291dCBQbGF0Zm9ybVxuICAgIGNvbnN0IHBsYXRmb3JtR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDMuNCwgMC4yNSwgMy40KTtcbiAgICBjb25zdCBwbGF0Zm9ybSA9IG5ldyBUSFJFRS5NZXNoKHBsYXRmb3JtR2VvLCB3b29kTWF0KTtcbiAgICBwbGF0Zm9ybS5wb3NpdGlvbi55ID0gNS42O1xuICAgIHBsYXRmb3JtLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgIHRvd2VyLmFkZChwbGF0Zm9ybSk7XG5cbiAgICAvLyBQbGF0Zm9ybSBSYWlsaW5nXG4gICAgY29uc3QgcmFpbEdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeSgzLjQsIDAuOCwgMy40KTtcbiAgICBjb25zdCByYWlsID0gbmV3IFRIUkVFLk1lc2gocmFpbEdlbywgd29vZE1hdCk7XG4gICAgcmFpbC5wb3NpdGlvbi55ID0gNi4xO1xuICAgIHRvd2VyLmFkZChyYWlsKTtcblxuICAgIC8vIFRvd2VyIFJvb2ZcbiAgICBjb25zdCByb29mR2VvID0gbmV3IFRIUkVFLkNvbmVHZW9tZXRyeSgyLjgsIDEuNCwgNCk7XG4gICAgY29uc3Qgcm9vZiA9IG5ldyBUSFJFRS5NZXNoKHJvb2ZHZW8sIHJvb2ZNYXQpO1xuICAgIHJvb2YucG9zaXRpb24ueSA9IDguMjtcbiAgICByb29mLnJvdGF0aW9uLnkgPSBNYXRoLlBJIC8gNDtcbiAgICByb29mLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgIHRvd2VyLmFkZChyb29mKTtcblxuICAgIHJldHVybiB0b3dlcjtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWlsZHMgYSBUcmFkaXRpb25hbCBUaGF0Y2hlZCBWaWxsYWdlIEh1dCAoTWlua2EpXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGNyZWF0ZVZpbGxhZ2VIdXQoKTogVEhSRUUuR3JvdXAge1xuICAgIGNvbnN0IGh1dCA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIGNvbnN0IHdvb2RNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoeyBjb2xvcjogMHgzZTI3MjMsIHJvdWdobmVzczogMC44NSB9KTtcbiAgICBjb25zdCB0aGF0Y2hNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoeyBjb2xvcjogMHg4NTRkMGUsIHJvdWdobmVzczogMC45NSB9KTtcblxuICAgIC8vIFdhbGxzXG4gICAgY29uc3Qgd2FsbEdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeSg0LjgsIDIuNiwgMy44KTtcbiAgICBjb25zdCB3YWxsID0gbmV3IFRIUkVFLk1lc2god2FsbEdlbywgd29vZE1hdCk7XG4gICAgd2FsbC5wb3NpdGlvbi55ID0gMS4zO1xuICAgIHdhbGwuY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgd2FsbC5yZWNlaXZlU2hhZG93ID0gdHJ1ZTtcbiAgICBodXQuYWRkKHdhbGwpO1xuXG4gICAgLy8gVGhhdGNoZWQgUm9vZlxuICAgIGNvbnN0IHJvb2ZHZW8gPSBuZXcgVEhSRUUuQ29uZUdlb21ldHJ5KDMuOCwgMi4yLCA0KTtcbiAgICBjb25zdCByb29mID0gbmV3IFRIUkVFLk1lc2gocm9vZkdlbywgdGhhdGNoTWF0KTtcbiAgICByb29mLnBvc2l0aW9uLnkgPSAzLjQ7XG4gICAgcm9vZi5yb3RhdGlvbi55ID0gTWF0aC5QSSAvIDQ7XG4gICAgcm9vZi5zY2FsZS5zZXQoMS40LCAxLjAsIDEuMSk7XG4gICAgcm9vZi5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICBodXQuYWRkKHJvb2YpO1xuXG4gICAgcmV0dXJuIGh1dDtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWlsZHMgU3Bpa2VkIFdvb2RlbiBCYXJyaWNhZGVzIChDaGV2YXV4LWRlLWZyaXNlKVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBjcmVhdGVTcGlrZWRCYXJyaWNhZGUoKTogVEhSRUUuR3JvdXAge1xuICAgIGNvbnN0IGJhciA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIGNvbnN0IHdvb2RNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoeyBjb2xvcjogMHgyNzE5MTEsIHJvdWdobmVzczogMC45IH0pO1xuXG4gICAgLy8gQ2VudHJhbCBjcm9zcyBiZWFtXG4gICAgY29uc3QgYmVhbUdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMSwgMC4xLCA0LjAsIDgpO1xuICAgIGJlYW1HZW8ucm90YXRlWihNYXRoLlBJIC8gMik7XG4gICAgY29uc3QgYmVhbSA9IG5ldyBUSFJFRS5NZXNoKGJlYW1HZW8sIHdvb2RNYXQpO1xuICAgIGJlYW0ucG9zaXRpb24ueSA9IDAuNztcbiAgICBiYXIuYWRkKGJlYW0pO1xuXG4gICAgLy8gQ3Jvc3NlZCBzaGFycGVuZWQgc3Rha2VzXG4gICAgZm9yIChsZXQgaSA9IC0xLjU7IGkgPD0gMS41OyBpICs9IDAuNzUpIHtcbiAgICAgIGNvbnN0IHN0YWtlR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC4wNCwgMC4wOCwgMS44LCA2KTtcbiAgICAgIGNvbnN0IHMxID0gbmV3IFRIUkVFLk1lc2goc3Rha2VHZW8sIHdvb2RNYXQpO1xuICAgICAgczEucG9zaXRpb24uc2V0KGksIDAuNywgMCk7XG4gICAgICBzMS5yb3RhdGlvbi5zZXQoMC42NSwgMCwgMCk7XG4gICAgICBjb25zdCBzMiA9IG5ldyBUSFJFRS5NZXNoKHN0YWtlR2VvLCB3b29kTWF0KTtcbiAgICAgIHMyLnBvc2l0aW9uLnNldChpLCAwLjcsIDApO1xuICAgICAgczIucm90YXRpb24uc2V0KC0wLjY1LCAwLCAwKTtcbiAgICAgIGJhci5hZGQoczEsIHMyKTtcbiAgICB9XG5cbiAgICByZXR1cm4gYmFyO1xuICB9XG5cbiAgLyoqXG4gICAqIEJ1aWxkcyBJcm9uIEZpcmUgQnJhemllciB3aXRoIGR5bmFtaWMgbGlnaHRcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgY3JlYXRlQnJhemllcihmaXJlQ29sb3IgPSAweGZmNDUwMCk6IHsgZ3JvdXA6IFRIUkVFLkdyb3VwOyBsaWdodDogVEhSRUUuUG9pbnRMaWdodCB9IHtcbiAgICBjb25zdCBncm91cCA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIGNvbnN0IGlyb25NYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoeyBjb2xvcjogMHgxODE4MWIsIG1ldGFsbmVzczogMC44LCByb3VnaG5lc3M6IDAuMyB9KTtcblxuICAgIC8vIFRyaXBvZCBsZWdzXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCAzOyBpKyspIHtcbiAgICAgIGNvbnN0IGFuZ2xlID0gKGkgKiBNYXRoLlBJICogMikgLyAzO1xuICAgICAgY29uc3QgbGVnR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC4wNSwgMC4wNiwgMS40LCA4KTtcbiAgICAgIGNvbnN0IGxlZyA9IG5ldyBUSFJFRS5NZXNoKGxlZ0dlbywgaXJvbk1hdCk7XG4gICAgICBsZWcucG9zaXRpb24uc2V0KE1hdGguY29zKGFuZ2xlKSAqIDAuNDUsIDAuNywgTWF0aC5zaW4oYW5nbGUpICogMC40NSk7XG4gICAgICBsZWcucm90YXRpb24uc2V0KC0wLjI1ICogTWF0aC5zaW4oYW5nbGUpLCAwLCAwLjI1ICogTWF0aC5jb3MoYW5nbGUpKTtcbiAgICAgIGdyb3VwLmFkZChsZWcpO1xuICAgIH1cblxuICAgIC8vIElyb24gQm93bFxuICAgIGNvbnN0IGJvd2xHZW8gPSBuZXcgVEhSRUUuQ3lsaW5kZXJHZW9tZXRyeSgwLjYsIDAuMzUsIDAuNCwgMTIpO1xuICAgIGNvbnN0IGJvd2wgPSBuZXcgVEhSRUUuTWVzaChib3dsR2VvLCBpcm9uTWF0KTtcbiAgICBib3dsLnBvc2l0aW9uLnkgPSAxLjM1O1xuICAgIGdyb3VwLmFkZChib3dsKTtcblxuICAgIC8vIEdsb3dpbmcgY29yZVxuICAgIGNvbnN0IGNvcmVHZW8gPSBuZXcgVEhSRUUuU3BoZXJlR2VvbWV0cnkoMC4zNSwgOCwgOCk7XG4gICAgY29uc3QgY29yZU1hdCA9IG5ldyBUSFJFRS5NZXNoQmFzaWNNYXRlcmlhbCh7IGNvbG9yOiBmaXJlQ29sb3IgfSk7XG4gICAgY29uc3QgY29yZSA9IG5ldyBUSFJFRS5NZXNoKGNvcmVHZW8sIGNvcmVNYXQpO1xuICAgIGNvcmUucG9zaXRpb24ueSA9IDEuNDU7XG4gICAgZ3JvdXAuYWRkKGNvcmUpO1xuXG4gICAgY29uc3QgbGlnaHQgPSBuZXcgVEhSRUUuUG9pbnRMaWdodChmaXJlQ29sb3IsIDIuNSwgMTQsIDEuMyk7XG4gICAgbGlnaHQucG9zaXRpb24uc2V0KDAsIDEuOCwgMCk7XG4gICAgZ3JvdXAuYWRkKGxpZ2h0KTtcblxuICAgIHJldHVybiB7IGdyb3VwLCBsaWdodCB9O1xuICB9XG5cbiAgLyoqXG4gICAqIEJ1aWxkcyBTdG9uZSBHdWFyZGlhbiBCZWFzdCAvIERyYWdvbiBTdGF0dWVcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgY3JlYXRlRHJhZ29uU3RhdHVlKCk6IFRIUkVFLkdyb3VwIHtcbiAgICBjb25zdCBzdGF0dWUgPSBuZXcgVEhSRUUuR3JvdXAoKTtcbiAgICBjb25zdCBzdG9uZU1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7XG4gICAgICBtYXA6IFRleHR1cmVHZW5lcmF0b3IuZ2V0U3RvbmVQYXZlbWVudFRleHR1cmUoKSxcbiAgICAgIHJvdWdobmVzczogMC44NSxcbiAgICB9KTtcblxuICAgIC8vIFBsaW50aFxuICAgIGNvbnN0IHBsaW50aEdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeSgxLjYsIDAuOCwgMS42KTtcbiAgICBjb25zdCBwbGludGggPSBuZXcgVEhSRUUuTWVzaChwbGludGhHZW8sIHN0b25lTWF0KTtcbiAgICBwbGludGgucG9zaXRpb24ueSA9IDAuNDtcbiAgICBwbGludGguY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgc3RhdHVlLmFkZChwbGludGgpO1xuXG4gICAgLy8gQm9keVxuICAgIGNvbnN0IGJvZHlHZW8gPSBuZXcgVEhSRUUuQm94R2VvbWV0cnkoMS4xLCAxLjQsIDEuMSk7XG4gICAgY29uc3QgYm9keSA9IG5ldyBUSFJFRS5NZXNoKGJvZHlHZW8sIHN0b25lTWF0KTtcbiAgICBib2R5LnBvc2l0aW9uLnkgPSAxLjQ7XG4gICAgYm9keS5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICBzdGF0dWUuYWRkKGJvZHkpO1xuXG4gICAgLy8gSGVhZFxuICAgIGNvbnN0IGhlYWRHZW8gPSBuZXcgVEhSRUUuRG9kZWNhaGVkcm9uR2VvbWV0cnkoMC41LCAxKTtcbiAgICBjb25zdCBoZWFkID0gbmV3IFRIUkVFLk1lc2goaGVhZEdlbywgc3RvbmVNYXQpO1xuICAgIGhlYWQucG9zaXRpb24uc2V0KDAsIDIuMSwgMC4yNSk7XG4gICAgc3RhdHVlLmFkZChoZWFkKTtcblxuICAgIHJldHVybiBzdGF0dWU7XG4gIH1cblxuICAvKipcbiAgICogQnVpbGRzIFZvbGNhbmljIE9ic2lkaWFuIE1vbm9saXRoIFNwaWtlc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyBjcmVhdGVPYnNpZGlhbk1vbm9saXRoKCk6IFRIUkVFLkdyb3VwIHtcbiAgICBjb25zdCBtb25vID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgY29uc3Qgb2JzTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiAweDA5MDkwYixcbiAgICAgIG1ldGFsbmVzczogMC44NSxcbiAgICAgIHJvdWdobmVzczogMC4xNSxcbiAgICB9KTtcblxuICAgIGNvbnN0IHNwaWtlR2VvID0gbmV3IFRIUkVFLkNvbmVHZW9tZXRyeSgxLjIsIDcuNSwgNSk7XG4gICAgY29uc3Qgc3Bpa2UgPSBuZXcgVEhSRUUuTWVzaChzcGlrZUdlbywgb2JzTWF0KTtcbiAgICBzcGlrZS5wb3NpdGlvbi55ID0gMy41O1xuICAgIHNwaWtlLnJvdGF0aW9uLnNldCgwLjEyLCAwLjQsIDAuMDgpO1xuICAgIHNwaWtlLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgIG1vbm8uYWRkKHNwaWtlKTtcblxuICAgIC8vIFN1YiBzcGlrZXNcbiAgICBbLTAuOCwgMC44XS5mb3JFYWNoKHggPT4ge1xuICAgICAgY29uc3Qgc3ViR2VvID0gbmV3IFRIUkVFLkNvbmVHZW9tZXRyeSgwLjYsIDQuMiwgNCk7XG4gICAgICBjb25zdCBzdWIgPSBuZXcgVEhSRUUuTWVzaChzdWJHZW8sIG9ic01hdCk7XG4gICAgICBzdWIucG9zaXRpb24uc2V0KHgsIDEuOCwgMC40KTtcbiAgICAgIHN1Yi5yb3RhdGlvbi5zZXQoLTAuMiwgMCwgeCAqIDAuMyk7XG4gICAgICBtb25vLmFkZChzdWIpO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIG1vbm87XG4gIH1cbn1cbiJdfQ==