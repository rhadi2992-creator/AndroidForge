/**
* @license
* SPDX-License-Identifier: Apache-2.0
*/
import * as THREE from "/node_modules/.vite/deps/three.js?v=677b64f2";
import { TextureGenerator } from "/src/engine/TextureGenerator.ts";
export class CharacterFactory {
	/**
	* Builds high-fidelity procedural Ninja hero model
	*/
	static createNinjaPlayer(skin, weapon) {
		const root = new THREE.Group();
		// Contact ground shadow disc
		const shadowGeo = new THREE.CircleGeometry(.55, 24);
		const shadowMat = new THREE.MeshBasicMaterial({
			color: 0,
			transparent: true,
			opacity: .45,
			depthWrite: false
		});
		const shadowDisc = new THREE.Mesh(shadowGeo, shadowMat);
		shadowDisc.rotation.x = -Math.PI / 2;
		shadowDisc.position.y = .02;
		root.add(shadowDisc);
		// Common materials
		const suitMat = new THREE.MeshStandardMaterial({
			color: new THREE.Color(skin.suitColor),
			roughness: .8,
			metalness: .15
		});
		const accentMat = new THREE.MeshStandardMaterial({
			color: new THREE.Color(skin.accentColor),
			roughness: .5,
			metalness: .35
		});
		const metalMat = new THREE.MeshStandardMaterial({
			color: 14540253,
			roughness: .25,
			metalness: .85
		});
		const goldMat = new THREE.MeshStandardMaterial({
			color: 14658082,
			roughness: .3,
			metalness: .9
		});
		const skinToneMat = new THREE.MeshStandardMaterial({
			color: 14724201,
			roughness: .7,
			metalness: .05
		});
		// 1. Torso & Pelvis
		const torso = new THREE.Group();
		torso.position.y = .95;
		root.add(torso);
		// Pelvis
		const pelvisGeo = new THREE.BoxGeometry(.38, .22, .26);
		const pelvisMesh = new THREE.Mesh(pelvisGeo, suitMat);
		pelvisMesh.castShadow = true;
		pelvisMesh.receiveShadow = true;
		torso.add(pelvisMesh);
		// Upper Chest
		const chestGeo = new THREE.BoxGeometry(.46, .45, .3);
		const chestMesh = new THREE.Mesh(chestGeo, suitMat);
		chestMesh.position.y = .32;
		chestMesh.castShadow = true;
		chestMesh.receiveShadow = true;
		torso.add(chestMesh);
		// Ninja Vest / Crossed Harness
		const vestGeo = new THREE.BoxGeometry(.48, .32, .32);
		const vestMesh = new THREE.Mesh(vestGeo, accentMat);
		vestMesh.position.y = .32;
		torso.add(vestMesh);
		// Obi / Waist Sash
		const obiGeo = new THREE.CylinderGeometry(.24, .23, .14, 16);
		const obiMesh = new THREE.Mesh(obiGeo, accentMat);
		obiMesh.position.y = .1;
		torso.add(obiMesh);
		// Obi Knot
		const knotGeo = new THREE.BoxGeometry(.12, .14, .08);
		const knotMesh = new THREE.Mesh(knotGeo, accentMat);
		knotMesh.position.set(0, .1, .16);
		torso.add(knotMesh);
		// 2. Head & Ninja Mask
		const head = new THREE.Group();
		head.position.y = .62;
		torso.add(head);
		// Hood/Cowl
		const hoodGeo = new THREE.SphereGeometry(.2, 16, 16);
		hoodGeo.scale(1, 1.15, 1.05);
		const hoodMesh = new THREE.Mesh(hoodGeo, suitMat);
		hoodMesh.position.y = .15;
		hoodMesh.castShadow = true;
		head.add(hoodMesh);
		// Face Aperture (eyes visible)
		const eyeApertureGeo = new THREE.BoxGeometry(.2, .07, .06);
		const eyeApertureMesh = new THREE.Mesh(eyeApertureGeo, skinToneMat);
		eyeApertureMesh.position.set(0, .16, .18);
		head.add(eyeApertureMesh);
		// Piercing Eyes
		const eyeGeo = new THREE.BoxGeometry(.045, .015, .02);
		const eyeGlowMat = new THREE.MeshBasicMaterial({ color: 6809849 });
		const leftEye = new THREE.Mesh(eyeGeo, eyeGlowMat);
		leftEye.position.set(-.05, .165, .205);
		const rightEye = new THREE.Mesh(eyeGeo, eyeGlowMat);
		rightEye.position.set(.05, .165, .205);
		head.add(leftEye, rightEye);
		// Forehead Plate (Hitai-ate)
		const plateGeo = new THREE.BoxGeometry(.18, .065, .03);
		const plateMesh = new THREE.Mesh(plateGeo, metalMat);
		plateMesh.position.set(0, .25, .19);
		head.add(plateMesh);
		// Headband Ribbon (flowing behind)
		const ribbon = new THREE.Group();
		ribbon.position.set(0, .23, -.2);
		const ribbonGeo = new THREE.BoxGeometry(.06, .38, .02);
		const ribbonMesh1 = new THREE.Mesh(ribbonGeo, accentMat);
		ribbonMesh1.position.set(-.04, -.16, 0);
		ribbonMesh1.rotation.z = .15;
		const ribbonMesh2 = new THREE.Mesh(ribbonGeo, accentMat);
		ribbonMesh2.position.set(.04, -.16, 0);
		ribbonMesh2.rotation.z = -.15;
		ribbon.add(ribbonMesh1, ribbonMesh2);
		head.add(ribbon);
		// 3. Arms & Katana
		// Left Arm
		const leftArm = new THREE.Group();
		leftArm.position.set(-.31, .48, 0);
		torso.add(leftArm);
		// Shoulder Pauldron
		const pauldronGeo = new THREE.BoxGeometry(.14, .12, .16);
		const leftPauldron = new THREE.Mesh(pauldronGeo, accentMat);
		leftArm.add(leftPauldron);
		const upperArmGeo = new THREE.CylinderGeometry(.065, .06, .28, 12);
		upperArmGeo.translate(0, -.14, 0);
		const leftUpperArmMesh = new THREE.Mesh(upperArmGeo, suitMat);
		leftUpperArmMesh.castShadow = true;
		leftArm.add(leftUpperArmMesh);
		const leftForearm = new THREE.Group();
		leftForearm.position.set(0, -.28, 0);
		leftArm.add(leftForearm);
		const forearmGeo = new THREE.CylinderGeometry(.06, .055, .26, 12);
		forearmGeo.translate(0, -.13, 0);
		const leftForearmMesh = new THREE.Mesh(forearmGeo, accentMat);
		leftForearm.add(leftForearmMesh);
		// Right Arm (Weapon Hand)
		const rightArm = new THREE.Group();
		rightArm.position.set(.31, .48, 0);
		torso.add(rightArm);
		const rightPauldron = new THREE.Mesh(pauldronGeo, accentMat);
		rightArm.add(rightPauldron);
		const rightUpperArmMesh = new THREE.Mesh(upperArmGeo, suitMat);
		rightUpperArmMesh.castShadow = true;
		rightArm.add(rightUpperArmMesh);
		const rightForearm = new THREE.Group();
		rightForearm.position.set(0, -.28, 0);
		rightArm.add(rightForearm);
		const rightForearmMesh = new THREE.Mesh(forearmGeo, accentMat);
		rightForearm.add(rightForearmMesh);
		// Hand
		const handGeo = new THREE.BoxGeometry(.08, .08, .09);
		const rightHand = new THREE.Mesh(handGeo, suitMat);
		rightHand.position.set(0, -.26, 0);
		rightForearm.add(rightHand);
		// Katana Group attached to right hand
		const swordGroup = new THREE.Group();
		swordGroup.position.set(0, -.26, .06);
		swordGroup.rotation.x = Math.PI / 2;
		rightForearm.add(swordGroup);
		// Tsuka (Handle)
		const handleGeo = new THREE.CylinderGeometry(.022, .022, .24, 8);
		const handleMat = new THREE.MeshStandardMaterial({
			color: 1579035,
			roughness: .9
		});
		const handleMesh = new THREE.Mesh(handleGeo, handleMat);
		handleMesh.position.y = -.1;
		swordGroup.add(handleMesh);
		// Tsuba (Handguard)
		const tsubaGeo = new THREE.CylinderGeometry(.085, .085, .015, 16);
		const tsubaMesh = new THREE.Mesh(tsubaGeo, goldMat);
		tsubaMesh.position.y = .02;
		swordGroup.add(tsubaMesh);
		// Katana Blade
		const bladeGeo = new THREE.BoxGeometry(.018, .95, .05);
		bladeGeo.translate(0, .48, 0);
		const bladeMat = new THREE.MeshStandardMaterial({
			color: new THREE.Color(weapon.bladeColor || 14870768),
			metalness: .95,
			roughness: .15,
			emissive: new THREE.Color(weapon.glowColor || 0),
			emissiveIntensity: .35
		});
		const bladeMesh = new THREE.Mesh(bladeGeo, bladeMat);
		bladeMesh.castShadow = true;
		swordGroup.add(bladeMesh);
		// Katana Tip (Curved point)
		const tipGeo = new THREE.ConeGeometry(.03, .1, 4);
		tipGeo.translate(0, .98, 0);
		const tipMesh = new THREE.Mesh(tipGeo, bladeMat);
		tipMesh.rotation.y = Math.PI / 4;
		swordGroup.add(tipMesh);
		// Slash Arc Trail (dynamically shown during attacks)
		const slashGeo = new THREE.PlaneGeometry(1.6, .6);
		slashGeo.translate(.4, .7, 0);
		const slashMat = new THREE.MeshBasicMaterial({
			map: TextureGenerator.getSlashTrailTexture(),
			color: new THREE.Color(weapon.trailColor || "#f97316"),
			transparent: true,
			opacity: 0,
			side: THREE.DoubleSide,
			depthWrite: false,
			blending: THREE.AdditiveBlending
		});
		const slashTrail = new THREE.Mesh(slashGeo, slashMat);
		slashTrail.rotation.z = Math.PI / 4;
		swordGroup.add(slashTrail);
		// 4. Legs
		// Left Leg
		const leftLeg = new THREE.Group();
		leftLeg.position.set(-.13, -.1, 0);
		torso.add(leftLeg);
		const thighGeo = new THREE.CylinderGeometry(.085, .075, .42, 12);
		thighGeo.translate(0, -.21, 0);
		const leftThighMesh = new THREE.Mesh(thighGeo, suitMat);
		leftThighMesh.castShadow = true;
		leftLeg.add(leftThighMesh);
		const leftCalf = new THREE.Group();
		leftCalf.position.set(0, -.42, 0);
		leftLeg.add(leftCalf);
		const calfGeo = new THREE.CylinderGeometry(.075, .065, .4, 12);
		calfGeo.translate(0, -.2, 0);
		const leftCalfMesh = new THREE.Mesh(calfGeo, accentMat);
		leftCalfMesh.castShadow = true;
		leftCalf.add(leftCalfMesh);
		// Tabi Boot
		const footGeo = new THREE.BoxGeometry(.12, .09, .22);
		footGeo.translate(0, -.42, .04);
		const leftFootMesh = new THREE.Mesh(footGeo, suitMat);
		leftCalf.add(leftFootMesh);
		// Right Leg
		const rightLeg = new THREE.Group();
		rightLeg.position.set(.13, -.1, 0);
		torso.add(rightLeg);
		const rightThighMesh = new THREE.Mesh(thighGeo, suitMat);
		rightThighMesh.castShadow = true;
		rightLeg.add(rightThighMesh);
		const rightCalf = new THREE.Group();
		rightCalf.position.set(0, -.42, 0);
		rightLeg.add(rightCalf);
		const rightCalfMesh = new THREE.Mesh(calfGeo, accentMat);
		rightCalfMesh.castShadow = true;
		rightCalf.add(rightCalfMesh);
		const rightFootMesh = new THREE.Mesh(footGeo, suitMat);
		rightCalf.add(rightFootMesh);
		return {
			root,
			torso,
			head,
			ribbon,
			leftArm,
			rightArm,
			leftForearm,
			rightForearm,
			leftLeg,
			rightLeg,
			leftCalf,
			rightCalf,
			swordGroup,
			slashTrail,
			shadowDisc,
			animTime: 0,
			currentAnim: "idle",
			animProgress: 0,
			animSpeed: 1
		};
	}
	/**
	* Builds distinct enemy characters: Normal Ashigaru, Fast Ninja, Heavy Brute, Archer, or Boss
	*/
	static createEnemy(type, isBoss = false, bossTheme) {
		const root = new THREE.Group();
		// Scale multiplier for bosses
		const scale = isBoss ? 1.45 : type === "heavy" ? 1.25 : 1;
		root.scale.set(scale, scale, scale);
		// Contact ground shadow disc
		const shadowGeo = new THREE.CircleGeometry(.55 * scale, 24);
		const shadowMat = new THREE.MeshBasicMaterial({
			color: 0,
			transparent: true,
			opacity: .45,
			depthWrite: false
		});
		const shadowDisc = new THREE.Mesh(shadowGeo, shadowMat);
		shadowDisc.rotation.x = -Math.PI / 2;
		shadowDisc.position.y = .02;
		root.add(shadowDisc);
		// Colors per enemy type
		let suitColor = 2565930;
		let armorColor = 10033947;
		let eyeColor = 15680580;
		if (type === "fast") {
			suitColor = 988970;
			armorColor = 7020968;
			eyeColor = 11032055;
		} else if (type === "heavy") {
			suitColor = 1579035;
			armorColor = 4144966;
			eyeColor = 16096779;
		} else if (type === "archer") {
			suitColor = 1976635;
			armorColor = 11817737;
			eyeColor = 16436245;
		} else if (isBoss) {
			suitColor = bossTheme === "raiden" ? 592139 : 4524554;
			armorColor = bossTheme === "raiden" ? 14251782 : 12131356;
			eyeColor = bossTheme === "raiden" ? 3718648 : 16720418;
		}
		const suitMat = new THREE.MeshStandardMaterial({
			color: suitColor,
			roughness: .8,
			metalness: .2
		});
		const armorMat = new THREE.MeshStandardMaterial({
			color: armorColor,
			roughness: .4,
			metalness: .6
		});
		const metalMat = new THREE.MeshStandardMaterial({
			color: 8947865,
			roughness: .3,
			metalness: .85
		});
		// Torso
		const torso = new THREE.Group();
		torso.position.y = .95;
		root.add(torso);
		const chestWidth = type === "heavy" || isBoss ? .62 : .46;
		const chestGeo = new THREE.BoxGeometry(chestWidth, .48, .32);
		const chestMesh = new THREE.Mesh(chestGeo, suitMat);
		chestMesh.position.y = .32;
		chestMesh.castShadow = true;
		torso.add(chestMesh);
		// Armor breastplate (Do)
		const doGeo = new THREE.BoxGeometry(chestWidth + .04, .34, .34);
		const doMesh = new THREE.Mesh(doGeo, armorMat);
		doMesh.position.y = .34;
		torso.add(doMesh);
		// Head
		const head = new THREE.Group();
		head.position.y = .62;
		torso.add(head);
		const headGeo = new THREE.SphereGeometry(.19, 16, 16);
		const headMesh = new THREE.Mesh(headGeo, suitMat);
		headMesh.position.y = .15;
		headMesh.castShadow = true;
		head.add(headMesh);
		// Eyes
		const eyeGeo = new THREE.BoxGeometry(.045, .02, .02);
		const eyeMat = new THREE.MeshBasicMaterial({ color: eyeColor });
		const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
		leftEye.position.set(-.06, .165, .19);
		const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
		rightEye.position.set(.06, .165, .19);
		head.add(leftEye, rightEye);
		// Headgear per type
		if (type === "normal" || type === "archer") {
			// Conical Jingasa Straw Hat
			const hatGeo = new THREE.ConeGeometry(.42, .16, 18);
			const hatMat = new THREE.MeshStandardMaterial({
				color: 9584654,
				roughness: .9
			});
			const hat = new THREE.Mesh(hatGeo, hatMat);
			hat.position.y = .28;
			head.add(hat);
		} else if (type === "heavy" || isBoss) {
			// Samurai Kabuto Helmet with horned crest
			const kabutoGeo = new THREE.CylinderGeometry(.24, .26, .2, 16);
			const kabuto = new THREE.Mesh(kabutoGeo, armorMat);
			kabuto.position.y = .24;
			head.add(kabuto);
			// Horned crest (Maedate)
			const crestGeo = new THREE.ConeGeometry(.035, .32, 4);
			const goldMat = new THREE.MeshStandardMaterial({
				color: 16096779,
				metalness: .9,
				roughness: .2
			});
			const leftHorn = new THREE.Mesh(crestGeo, goldMat);
			leftHorn.position.set(-.1, .36, .15);
			leftHorn.rotation.set(-.2, 0, -.4);
			const rightHorn = new THREE.Mesh(crestGeo, goldMat);
			rightHorn.position.set(.1, .36, .15);
			rightHorn.rotation.set(-.2, 0, .4);
			head.add(leftHorn, rightHorn);
		}
		// Arms
		const leftArm = new THREE.Group();
		leftArm.position.set(-(chestWidth * .5 + .08), .48, 0);
		torso.add(leftArm);
		const rightArm = new THREE.Group();
		rightArm.position.set(chestWidth * .5 + .08, .48, 0);
		torso.add(rightArm);
		const armGeo = new THREE.CylinderGeometry(.07, .06, .28, 10);
		armGeo.translate(0, -.14, 0);
		const leftUpperArm = new THREE.Mesh(armGeo, suitMat);
		leftUpperArm.castShadow = true;
		leftArm.add(leftUpperArm);
		const rightUpperArm = new THREE.Mesh(armGeo, suitMat);
		rightUpperArm.castShadow = true;
		rightArm.add(rightUpperArm);
		const leftForearm = new THREE.Group();
		leftForearm.position.set(0, -.28, 0);
		leftArm.add(leftForearm);
		const rightForearm = new THREE.Group();
		rightForearm.position.set(0, -.28, 0);
		rightArm.add(rightForearm);
		const forearmGeo = new THREE.CylinderGeometry(.065, .06, .26, 10);
		forearmGeo.translate(0, -.13, 0);
		leftForearm.add(new THREE.Mesh(forearmGeo, armorMat));
		rightForearm.add(new THREE.Mesh(forearmGeo, armorMat));
		// Weapon
		const swordGroup = new THREE.Group();
		swordGroup.position.set(0, -.26, .06);
		swordGroup.rotation.x = Math.PI / 2;
		rightForearm.add(swordGroup);
		let bow;
		if (type === "archer") {
			// Yumi Bow in left hand
			bow = new THREE.Group();
			bow.position.set(0, -.26, .1);
			leftForearm.add(bow);
			const bowGeo = new THREE.TorusGeometry(.55, .02, 8, 24, Math.PI * .65);
			const bowMat = new THREE.MeshStandardMaterial({
				color: 7877903,
				roughness: .7
			});
			const bowMesh = new THREE.Mesh(bowGeo, bowMat);
			bowMesh.rotation.z = Math.PI / 2;
			bow.add(bowMesh);
			// Quiver on back
			const quiverGeo = new THREE.CylinderGeometry(.07, .06, .5, 8);
			const quiverMat = new THREE.MeshStandardMaterial({ color: 4528643 });
			const quiver = new THREE.Mesh(quiverGeo, quiverMat);
			quiver.position.set(.12, .35, -.2);
			quiver.rotation.z = .35;
			torso.add(quiver);
		} else if (type === "heavy") {
			// Spiked Kanabo Club
			const clubGeo = new THREE.CylinderGeometry(.06, .035, 1.1, 10);
			clubGeo.translate(0, .5, 0);
			const clubMesh = new THREE.Mesh(clubGeo, metalMat);
			clubMesh.castShadow = true;
			swordGroup.add(clubMesh);
		} else {
			// Sword
			const handleGeo = new THREE.CylinderGeometry(.022, .022, .22, 8);
			const handle = new THREE.Mesh(handleGeo, suitMat);
			handle.position.y = -.1;
			swordGroup.add(handle);
			const bladeGeo = new THREE.BoxGeometry(.02, isBoss ? 1.3 : .9, .05);
			bladeGeo.translate(0, isBoss ? .65 : .45, 0);
			const bladeMat = new THREE.MeshStandardMaterial({
				color: isBoss ? 16729156 : 13421772,
				metalness: .9,
				roughness: .2
			});
			const blade = new THREE.Mesh(bladeGeo, bladeMat);
			blade.castShadow = true;
			swordGroup.add(blade);
		}
		// Slash Trail for enemies
		const slashGeo = new THREE.PlaneGeometry(1.6, .6);
		slashGeo.translate(.4, .7, 0);
		const slashMat = new THREE.MeshBasicMaterial({
			map: TextureGenerator.getSlashTrailTexture(),
			color: new THREE.Color(isBoss ? 14427686 : 10033947),
			transparent: true,
			opacity: 0,
			side: THREE.DoubleSide,
			depthWrite: false
		});
		const slashTrail = new THREE.Mesh(slashGeo, slashMat);
		slashTrail.rotation.z = Math.PI / 4;
		swordGroup.add(slashTrail);
		// Legs
		const leftLeg = new THREE.Group();
		leftLeg.position.set(-.16, -.1, 0);
		torso.add(leftLeg);
		const rightLeg = new THREE.Group();
		rightLeg.position.set(.16, -.1, 0);
		torso.add(rightLeg);
		const legGeo = new THREE.CylinderGeometry(.09, .075, .4, 10);
		legGeo.translate(0, -.2, 0);
		leftLeg.add(new THREE.Mesh(legGeo, suitMat));
		rightLeg.add(new THREE.Mesh(legGeo, suitMat));
		const leftCalf = new THREE.Group();
		leftCalf.position.set(0, -.4, 0);
		leftLeg.add(leftCalf);
		const rightCalf = new THREE.Group();
		rightCalf.position.set(0, -.4, 0);
		rightLeg.add(rightCalf);
		const calfGeo = new THREE.CylinderGeometry(.08, .07, .38, 10);
		calfGeo.translate(0, -.19, 0);
		leftCalf.add(new THREE.Mesh(calfGeo, armorMat));
		rightCalf.add(new THREE.Mesh(calfGeo, armorMat));
		// Boss demonic aura
		let aura;
		if (isBoss) {
			const auraGeo = new THREE.SphereGeometry(1.4, 16, 16);
			const auraMat = new THREE.MeshBasicMaterial({
				color: bossTheme === "raiden" ? 959977 : 15680580,
				transparent: true,
				opacity: .15,
				wireframe: true
			});
			aura = new THREE.Mesh(auraGeo, auraMat);
			aura.position.y = 1;
			root.add(aura);
		}
		const ribbon = new THREE.Group();
		return {
			root,
			torso,
			head,
			ribbon,
			leftArm,
			rightArm,
			leftForearm,
			rightForearm,
			leftLeg,
			rightLeg,
			leftCalf,
			rightCalf,
			swordGroup,
			slashTrail,
			shadowDisc,
			bow,
			aura,
			animTime: 0,
			currentAnim: "idle",
			animProgress: 0,
			animSpeed: 1
		};
	}
	/**
	* Applies kinematics & animation frames to rig
	*/
	static updateAnimation(rig, delta) {
		rig.animTime += delta * rig.animSpeed;
		const t = rig.animTime;
		// Headband ribbon subtle wave
		if (rig.ribbon.children.length > 0) {
			rig.ribbon.children[0].rotation.x = Math.sin(t * 5) * .15;
			rig.ribbon.children[1].rotation.x = Math.sin(t * 5 + .5) * .15;
		}
		if (rig.aura) {
			rig.aura.rotation.y += delta * .8;
			rig.aura.rotation.x += delta * .4;
		}
		switch (rig.currentAnim) {
			case "idle": {
				// Subtle breathing sway
				const breathe = Math.sin(t * 2.5) * .025;
				rig.torso.position.y = .95 + breathe;
				rig.head.rotation.x = Math.sin(t * 1.5) * .03;
				// Arm relaxation
				rig.leftArm.rotation.x = THREE.MathUtils.damp(rig.leftArm.rotation.x, .1, 8, delta);
				rig.leftArm.rotation.z = THREE.MathUtils.damp(rig.leftArm.rotation.z, -.15, 8, delta);
				rig.rightArm.rotation.x = THREE.MathUtils.damp(rig.rightArm.rotation.x, -.2, 8, delta);
				rig.rightArm.rotation.z = THREE.MathUtils.damp(rig.rightArm.rotation.z, .15, 8, delta);
				rig.leftForearm.rotation.x = THREE.MathUtils.damp(rig.leftForearm.rotation.x, -.3, 8, delta);
				rig.rightForearm.rotation.x = THREE.MathUtils.damp(rig.rightForearm.rotation.x, -.5, 8, delta);
				rig.leftLeg.rotation.x = THREE.MathUtils.damp(rig.leftLeg.rotation.x, .05, 8, delta);
				rig.rightLeg.rotation.x = THREE.MathUtils.damp(rig.rightLeg.rotation.x, -.05, 8, delta);
				rig.leftCalf.rotation.x = THREE.MathUtils.damp(rig.leftCalf.rotation.x, 0, 8, delta);
				rig.rightCalf.rotation.x = THREE.MathUtils.damp(rig.rightCalf.rotation.x, 0, 8, delta);
				// Hide slash trail
				rig.slashTrail.material.opacity = 0;
				break;
			}
			case "run": {
				const runCycle = Math.sin(t * 12);
				const runCos = Math.cos(t * 12);
				rig.torso.position.y = .95 + Math.abs(runCos) * .08;
				rig.torso.rotation.x = .18;
				// Opposite leg movement
				rig.leftLeg.rotation.x = runCycle * .7;
				rig.rightLeg.rotation.x = -runCycle * .7;
				rig.leftCalf.rotation.x = runCycle > 0 ? runCycle * .8 : .1;
				rig.rightCalf.rotation.x = runCycle < 0 ? -runCycle * .8 : .1;
				// Pumping arms
				rig.leftArm.rotation.x = -runCycle * .8;
				rig.rightArm.rotation.x = runCycle * .8;
				rig.leftForearm.rotation.x = -.5;
				rig.rightForearm.rotation.x = -.6;
				rig.slashTrail.material.opacity = 0;
				break;
			}
			case "jump": {
				rig.torso.rotation.x = .1;
				rig.leftLeg.rotation.x = -.4;
				rig.rightLeg.rotation.x = -.5;
				rig.leftCalf.rotation.x = .8;
				rig.rightCalf.rotation.x = .7;
				rig.leftArm.rotation.x = -1.2;
				rig.rightArm.rotation.x = -1.4;
				rig.slashTrail.material.opacity = 0;
				break;
			}
			case "attack1": {
				// Horizontal slash combo 1
				const p = rig.animProgress;
				rig.torso.rotation.y = THREE.MathUtils.lerp(-.4, .6, p);
				rig.rightArm.rotation.x = THREE.MathUtils.lerp(-.5, -1.2, p);
				rig.rightArm.rotation.y = THREE.MathUtils.lerp(.8, -1.1, p);
				rig.rightArm.rotation.z = THREE.MathUtils.lerp(.5, -.3, p);
				const trailMat = rig.slashTrail.material;
				trailMat.opacity = Math.sin(p * Math.PI) * .9;
				break;
			}
			case "attack2": {
				// Reverse diagonal rising slash combo 2
				const p = rig.animProgress;
				rig.torso.rotation.y = THREE.MathUtils.lerp(.5, -.6, p);
				rig.rightArm.rotation.x = THREE.MathUtils.lerp(-1.4, -.3, p);
				rig.rightArm.rotation.y = THREE.MathUtils.lerp(-.9, .9, p);
				rig.rightArm.rotation.z = THREE.MathUtils.lerp(-.5, .4, p);
				const trailMat = rig.slashTrail.material;
				trailMat.opacity = Math.sin(p * Math.PI) * .95;
				break;
			}
			case "attack3": {
				// Leaping Overhead Spin Slam combo 3
				const p = rig.animProgress;
				rig.torso.position.y = .95 + Math.sin(p * Math.PI) * .4;
				rig.torso.rotation.x = THREE.MathUtils.lerp(-.3, .5, p);
				rig.rightArm.rotation.x = THREE.MathUtils.lerp(-2.4, -.4, p);
				rig.rightArm.rotation.y = 0;
				rig.leftArm.rotation.x = THREE.MathUtils.lerp(-1.8, -.2, p);
				const trailMat = rig.slashTrail.material;
				trailMat.opacity = Math.sin(p * Math.PI) * 1;
				break;
			}
			case "kick": {
				const p = rig.animProgress;
				rig.torso.rotation.x = -.2;
				rig.rightLeg.rotation.x = -Math.sin(p * Math.PI) * 1.4;
				rig.rightCalf.rotation.x = -Math.sin(p * Math.PI) * .3;
				rig.leftLeg.rotation.x = .2;
				break;
			}
			case "dodge": {
				// Ninja tumble roll
				const p = rig.animProgress;
				rig.torso.position.y = .45 + Math.sin(p * Math.PI) * .2;
				rig.torso.rotation.x = p * Math.PI * 2;
				rig.leftLeg.rotation.x = -.8;
				rig.rightLeg.rotation.x = -.8;
				rig.leftArm.rotation.x = -1.2;
				rig.rightArm.rotation.x = -1.2;
				break;
			}
			case "flinch": {
				const p = rig.animProgress;
				rig.torso.position.y = .95;
				rig.torso.rotation.x = -Math.sin(p * Math.PI) * .4;
				rig.head.rotation.x = -Math.sin(p * Math.PI) * .3;
				rig.rightArm.rotation.x = .5;
				rig.leftArm.rotation.x = .5;
				break;
			}
			case "victory": {
				// Katana held high in salute
				rig.torso.rotation.y = THREE.MathUtils.damp(rig.torso.rotation.y, 0, 5, delta);
				rig.rightArm.rotation.x = THREE.MathUtils.damp(rig.rightArm.rotation.x, -2.8, 6, delta);
				rig.rightArm.rotation.z = THREE.MathUtils.damp(rig.rightArm.rotation.z, .2, 6, delta);
				rig.leftArm.rotation.x = THREE.MathUtils.damp(rig.leftArm.rotation.x, -.3, 6, delta);
				rig.head.rotation.x = THREE.MathUtils.damp(rig.head.rotation.x, -.2, 6, delta);
				break;
			}
			case "dead": {
				// Fallen warrior
				rig.torso.position.y = THREE.MathUtils.damp(rig.torso.position.y, .2, 4, delta);
				rig.torso.rotation.x = THREE.MathUtils.damp(rig.torso.rotation.x, Math.PI / 2, 4, delta);
				rig.rightArm.rotation.x = THREE.MathUtils.damp(rig.rightArm.rotation.x, .8, 4, delta);
				rig.leftArm.rotation.x = THREE.MathUtils.damp(rig.leftArm.rotation.x, .8, 4, delta);
				rig.slashTrail.material.opacity = 0;
				break;
			}
		}
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLFlBQVksV0FBVztBQUV2QixTQUFTLHdCQUF3QjtBQTJCakMsT0FBTyxNQUFNLGlCQUFpQjs7OztDQUk1QixPQUFjLGtCQUFrQixNQUFrQixRQUE4QjtFQUM5RSxNQUFNLE9BQU8sSUFBSSxNQUFNLE1BQU07O0VBRzdCLE1BQU0sWUFBWSxJQUFJLE1BQU0sZUFBZSxLQUFNLEVBQUU7RUFDbkQsTUFBTSxZQUFZLElBQUksTUFBTSxrQkFBa0I7R0FDNUMsT0FBTztHQUNQLGFBQWE7R0FDYixTQUFTO0dBQ1QsWUFBWTtFQUNkLENBQUM7RUFDRCxNQUFNLGFBQWEsSUFBSSxNQUFNLEtBQUssV0FBVyxTQUFTO0VBQ3RELFdBQVcsU0FBUyxJQUFJLENBQUMsS0FBSyxLQUFLO0VBQ25DLFdBQVcsU0FBUyxJQUFJO0VBQ3hCLEtBQUssSUFBSSxVQUFVOztFQUduQixNQUFNLFVBQVUsSUFBSSxNQUFNLHFCQUFxQjtHQUM3QyxPQUFPLElBQUksTUFBTSxNQUFNLEtBQUssU0FBUztHQUNyQyxXQUFXO0dBQ1gsV0FBVztFQUNiLENBQUM7RUFFRCxNQUFNLFlBQVksSUFBSSxNQUFNLHFCQUFxQjtHQUMvQyxPQUFPLElBQUksTUFBTSxNQUFNLEtBQUssV0FBVztHQUN2QyxXQUFXO0dBQ1gsV0FBVztFQUNiLENBQUM7RUFFRCxNQUFNLFdBQVcsSUFBSSxNQUFNLHFCQUFxQjtHQUM5QyxPQUFPO0dBQ1AsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDO0VBRUQsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FDN0MsT0FBTztHQUNQLFdBQVc7R0FDWCxXQUFXO0VBQ2IsQ0FBQztFQUVELE1BQU0sY0FBYyxJQUFJLE1BQU0scUJBQXFCO0dBQ2pELE9BQU87R0FDUCxXQUFXO0dBQ1gsV0FBVztFQUNiLENBQUM7O0VBR0QsTUFBTSxRQUFRLElBQUksTUFBTSxNQUFNO0VBQzlCLE1BQU0sU0FBUyxJQUFJO0VBQ25CLEtBQUssSUFBSSxLQUFLOztFQUdkLE1BQU0sWUFBWSxJQUFJLE1BQU0sWUFBWSxLQUFNLEtBQU0sR0FBSTtFQUN4RCxNQUFNLGFBQWEsSUFBSSxNQUFNLEtBQUssV0FBVyxPQUFPO0VBQ3BELFdBQVcsYUFBYTtFQUN4QixXQUFXLGdCQUFnQjtFQUMzQixNQUFNLElBQUksVUFBVTs7RUFHcEIsTUFBTSxXQUFXLElBQUksTUFBTSxZQUFZLEtBQU0sS0FBTSxFQUFHO0VBQ3RELE1BQU0sWUFBWSxJQUFJLE1BQU0sS0FBSyxVQUFVLE9BQU87RUFDbEQsVUFBVSxTQUFTLElBQUk7RUFDdkIsVUFBVSxhQUFhO0VBQ3ZCLFVBQVUsZ0JBQWdCO0VBQzFCLE1BQU0sSUFBSSxTQUFTOztFQUduQixNQUFNLFVBQVUsSUFBSSxNQUFNLFlBQVksS0FBTSxLQUFNLEdBQUk7RUFDdEQsTUFBTSxXQUFXLElBQUksTUFBTSxLQUFLLFNBQVMsU0FBUztFQUNsRCxTQUFTLFNBQVMsSUFBSTtFQUN0QixNQUFNLElBQUksUUFBUTs7RUFHbEIsTUFBTSxTQUFTLElBQUksTUFBTSxpQkFBaUIsS0FBTSxLQUFNLEtBQU0sRUFBRTtFQUM5RCxNQUFNLFVBQVUsSUFBSSxNQUFNLEtBQUssUUFBUSxTQUFTO0VBQ2hELFFBQVEsU0FBUyxJQUFJO0VBQ3JCLE1BQU0sSUFBSSxPQUFPOztFQUdqQixNQUFNLFVBQVUsSUFBSSxNQUFNLFlBQVksS0FBTSxLQUFNLEdBQUk7RUFDdEQsTUFBTSxXQUFXLElBQUksTUFBTSxLQUFLLFNBQVMsU0FBUztFQUNsRCxTQUFTLFNBQVMsSUFBSSxHQUFHLElBQUssR0FBSTtFQUNsQyxNQUFNLElBQUksUUFBUTs7RUFHbEIsTUFBTSxPQUFPLElBQUksTUFBTSxNQUFNO0VBQzdCLEtBQUssU0FBUyxJQUFJO0VBQ2xCLE1BQU0sSUFBSSxJQUFJOztFQUdkLE1BQU0sVUFBVSxJQUFJLE1BQU0sZUFBZSxJQUFLLElBQUksRUFBRTtFQUNwRCxRQUFRLE1BQU0sR0FBRyxNQUFNLElBQUk7RUFDM0IsTUFBTSxXQUFXLElBQUksTUFBTSxLQUFLLFNBQVMsT0FBTztFQUNoRCxTQUFTLFNBQVMsSUFBSTtFQUN0QixTQUFTLGFBQWE7RUFDdEIsS0FBSyxJQUFJLFFBQVE7O0VBR2pCLE1BQU0saUJBQWlCLElBQUksTUFBTSxZQUFZLElBQUssS0FBTSxHQUFJO0VBQzVELE1BQU0sa0JBQWtCLElBQUksTUFBTSxLQUFLLGdCQUFnQixXQUFXO0VBQ2xFLGdCQUFnQixTQUFTLElBQUksR0FBRyxLQUFNLEdBQUk7RUFDMUMsS0FBSyxJQUFJLGVBQWU7O0VBR3hCLE1BQU0sU0FBUyxJQUFJLE1BQU0sWUFBWSxNQUFPLE1BQU8sR0FBSTtFQUN2RCxNQUFNLGFBQWEsSUFBSSxNQUFNLGtCQUFrQixFQUFFLE9BQU8sUUFBUyxDQUFDO0VBQ2xFLE1BQU0sVUFBVSxJQUFJLE1BQU0sS0FBSyxRQUFRLFVBQVU7RUFDakQsUUFBUSxTQUFTLElBQUksQ0FBQyxLQUFNLE1BQU8sSUFBSztFQUN4QyxNQUFNLFdBQVcsSUFBSSxNQUFNLEtBQUssUUFBUSxVQUFVO0VBQ2xELFNBQVMsU0FBUyxJQUFJLEtBQU0sTUFBTyxJQUFLO0VBQ3hDLEtBQUssSUFBSSxTQUFTLFFBQVE7O0VBRzFCLE1BQU0sV0FBVyxJQUFJLE1BQU0sWUFBWSxLQUFNLE1BQU8sR0FBSTtFQUN4RCxNQUFNLFlBQVksSUFBSSxNQUFNLEtBQUssVUFBVSxRQUFRO0VBQ25ELFVBQVUsU0FBUyxJQUFJLEdBQUcsS0FBTSxHQUFJO0VBQ3BDLEtBQUssSUFBSSxTQUFTOztFQUdsQixNQUFNLFNBQVMsSUFBSSxNQUFNLE1BQU07RUFDL0IsT0FBTyxTQUFTLElBQUksR0FBRyxLQUFNLENBQUMsRUFBRztFQUNqQyxNQUFNLFlBQVksSUFBSSxNQUFNLFlBQVksS0FBTSxLQUFNLEdBQUk7RUFDeEQsTUFBTSxjQUFjLElBQUksTUFBTSxLQUFLLFdBQVcsU0FBUztFQUN2RCxZQUFZLFNBQVMsSUFBSSxDQUFDLEtBQU0sQ0FBQyxLQUFNLENBQUM7RUFDeEMsWUFBWSxTQUFTLElBQUk7RUFDekIsTUFBTSxjQUFjLElBQUksTUFBTSxLQUFLLFdBQVcsU0FBUztFQUN2RCxZQUFZLFNBQVMsSUFBSSxLQUFNLENBQUMsS0FBTSxDQUFDO0VBQ3ZDLFlBQVksU0FBUyxJQUFJLENBQUM7RUFDMUIsT0FBTyxJQUFJLGFBQWEsV0FBVztFQUNuQyxLQUFLLElBQUksTUFBTTs7O0VBSWYsTUFBTSxVQUFVLElBQUksTUFBTSxNQUFNO0VBQ2hDLFFBQVEsU0FBUyxJQUFJLENBQUMsS0FBTSxLQUFNLENBQUM7RUFDbkMsTUFBTSxJQUFJLE9BQU87O0VBR2pCLE1BQU0sY0FBYyxJQUFJLE1BQU0sWUFBWSxLQUFNLEtBQU0sR0FBSTtFQUMxRCxNQUFNLGVBQWUsSUFBSSxNQUFNLEtBQUssYUFBYSxTQUFTO0VBQzFELFFBQVEsSUFBSSxZQUFZO0VBRXhCLE1BQU0sY0FBYyxJQUFJLE1BQU0saUJBQWlCLE1BQU8sS0FBTSxLQUFNLEVBQUU7RUFDcEUsWUFBWSxVQUFVLEdBQUcsQ0FBQyxLQUFNLENBQUM7RUFDakMsTUFBTSxtQkFBbUIsSUFBSSxNQUFNLEtBQUssYUFBYSxPQUFPO0VBQzVELGlCQUFpQixhQUFhO0VBQzlCLFFBQVEsSUFBSSxnQkFBZ0I7RUFFNUIsTUFBTSxjQUFjLElBQUksTUFBTSxNQUFNO0VBQ3BDLFlBQVksU0FBUyxJQUFJLEdBQUcsQ0FBQyxLQUFNLENBQUM7RUFDcEMsUUFBUSxJQUFJLFdBQVc7RUFFdkIsTUFBTSxhQUFhLElBQUksTUFBTSxpQkFBaUIsS0FBTSxNQUFPLEtBQU0sRUFBRTtFQUNuRSxXQUFXLFVBQVUsR0FBRyxDQUFDLEtBQU0sQ0FBQztFQUNoQyxNQUFNLGtCQUFrQixJQUFJLE1BQU0sS0FBSyxZQUFZLFNBQVM7RUFDNUQsWUFBWSxJQUFJLGVBQWU7O0VBRy9CLE1BQU0sV0FBVyxJQUFJLE1BQU0sTUFBTTtFQUNqQyxTQUFTLFNBQVMsSUFBSSxLQUFNLEtBQU0sQ0FBQztFQUNuQyxNQUFNLElBQUksUUFBUTtFQUVsQixNQUFNLGdCQUFnQixJQUFJLE1BQU0sS0FBSyxhQUFhLFNBQVM7RUFDM0QsU0FBUyxJQUFJLGFBQWE7RUFFMUIsTUFBTSxvQkFBb0IsSUFBSSxNQUFNLEtBQUssYUFBYSxPQUFPO0VBQzdELGtCQUFrQixhQUFhO0VBQy9CLFNBQVMsSUFBSSxpQkFBaUI7RUFFOUIsTUFBTSxlQUFlLElBQUksTUFBTSxNQUFNO0VBQ3JDLGFBQWEsU0FBUyxJQUFJLEdBQUcsQ0FBQyxLQUFNLENBQUM7RUFDckMsU0FBUyxJQUFJLFlBQVk7RUFFekIsTUFBTSxtQkFBbUIsSUFBSSxNQUFNLEtBQUssWUFBWSxTQUFTO0VBQzdELGFBQWEsSUFBSSxnQkFBZ0I7O0VBR2pDLE1BQU0sVUFBVSxJQUFJLE1BQU0sWUFBWSxLQUFNLEtBQU0sR0FBSTtFQUN0RCxNQUFNLFlBQVksSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0VBQ2pELFVBQVUsU0FBUyxJQUFJLEdBQUcsQ0FBQyxLQUFNLENBQUM7RUFDbEMsYUFBYSxJQUFJLFNBQVM7O0VBRzFCLE1BQU0sYUFBYSxJQUFJLE1BQU0sTUFBTTtFQUNuQyxXQUFXLFNBQVMsSUFBSSxHQUFHLENBQUMsS0FBTSxHQUFJO0VBQ3RDLFdBQVcsU0FBUyxJQUFJLEtBQUssS0FBSztFQUNsQyxhQUFhLElBQUksVUFBVTs7RUFHM0IsTUFBTSxZQUFZLElBQUksTUFBTSxpQkFBaUIsTUFBTyxNQUFPLEtBQU0sQ0FBQztFQUNsRSxNQUFNLFlBQVksSUFBSSxNQUFNLHFCQUFxQjtHQUFFLE9BQU87R0FBVSxXQUFXO0VBQUksQ0FBQztFQUNwRixNQUFNLGFBQWEsSUFBSSxNQUFNLEtBQUssV0FBVyxTQUFTO0VBQ3RELFdBQVcsU0FBUyxJQUFJLENBQUM7RUFDekIsV0FBVyxJQUFJLFVBQVU7O0VBR3pCLE1BQU0sV0FBVyxJQUFJLE1BQU0saUJBQWlCLE1BQU8sTUFBTyxNQUFPLEVBQUU7RUFDbkUsTUFBTSxZQUFZLElBQUksTUFBTSxLQUFLLFVBQVUsT0FBTztFQUNsRCxVQUFVLFNBQVMsSUFBSTtFQUN2QixXQUFXLElBQUksU0FBUzs7RUFHeEIsTUFBTSxXQUFXLElBQUksTUFBTSxZQUFZLE1BQU8sS0FBTSxHQUFJO0VBQ3hELFNBQVMsVUFBVSxHQUFHLEtBQU0sQ0FBQztFQUM3QixNQUFNLFdBQVcsSUFBSSxNQUFNLHFCQUFxQjtHQUM5QyxPQUFPLElBQUksTUFBTSxNQUFNLE9BQU8sY0FBYyxRQUFRO0dBQ3BELFdBQVc7R0FDWCxXQUFXO0dBQ1gsVUFBVSxJQUFJLE1BQU0sTUFBTSxPQUFPLGFBQWEsQ0FBUTtHQUN0RCxtQkFBbUI7RUFDckIsQ0FBQztFQUNELE1BQU0sWUFBWSxJQUFJLE1BQU0sS0FBSyxVQUFVLFFBQVE7RUFDbkQsVUFBVSxhQUFhO0VBQ3ZCLFdBQVcsSUFBSSxTQUFTOztFQUd4QixNQUFNLFNBQVMsSUFBSSxNQUFNLGFBQWEsS0FBTSxJQUFLLENBQUM7RUFDbEQsT0FBTyxVQUFVLEdBQUcsS0FBTSxDQUFDO0VBQzNCLE1BQU0sVUFBVSxJQUFJLE1BQU0sS0FBSyxRQUFRLFFBQVE7RUFDL0MsUUFBUSxTQUFTLElBQUksS0FBSyxLQUFLO0VBQy9CLFdBQVcsSUFBSSxPQUFPOztFQUd0QixNQUFNLFdBQVcsSUFBSSxNQUFNLGNBQWMsS0FBSyxFQUFHO0VBQ2pELFNBQVMsVUFBVSxJQUFLLElBQUssQ0FBQztFQUM5QixNQUFNLFdBQVcsSUFBSSxNQUFNLGtCQUFrQjtHQUMzQyxLQUFLLGlCQUFpQixxQkFBcUI7R0FDM0MsT0FBTyxJQUFJLE1BQU0sTUFBTSxPQUFPLGNBQWMsU0FBUztHQUNyRCxhQUFhO0dBQ2IsU0FBUztHQUNULE1BQU0sTUFBTTtHQUNaLFlBQVk7R0FDWixVQUFVLE1BQU07RUFDbEIsQ0FBQztFQUNELE1BQU0sYUFBYSxJQUFJLE1BQU0sS0FBSyxVQUFVLFFBQVE7RUFDcEQsV0FBVyxTQUFTLElBQUksS0FBSyxLQUFLO0VBQ2xDLFdBQVcsSUFBSSxVQUFVOzs7RUFJekIsTUFBTSxVQUFVLElBQUksTUFBTSxNQUFNO0VBQ2hDLFFBQVEsU0FBUyxJQUFJLENBQUMsS0FBTSxDQUFDLElBQUssQ0FBQztFQUNuQyxNQUFNLElBQUksT0FBTztFQUVqQixNQUFNLFdBQVcsSUFBSSxNQUFNLGlCQUFpQixNQUFPLE1BQU8sS0FBTSxFQUFFO0VBQ2xFLFNBQVMsVUFBVSxHQUFHLENBQUMsS0FBTSxDQUFDO0VBQzlCLE1BQU0sZ0JBQWdCLElBQUksTUFBTSxLQUFLLFVBQVUsT0FBTztFQUN0RCxjQUFjLGFBQWE7RUFDM0IsUUFBUSxJQUFJLGFBQWE7RUFFekIsTUFBTSxXQUFXLElBQUksTUFBTSxNQUFNO0VBQ2pDLFNBQVMsU0FBUyxJQUFJLEdBQUcsQ0FBQyxLQUFNLENBQUM7RUFDakMsUUFBUSxJQUFJLFFBQVE7RUFFcEIsTUFBTSxVQUFVLElBQUksTUFBTSxpQkFBaUIsTUFBTyxNQUFPLElBQUssRUFBRTtFQUNoRSxRQUFRLFVBQVUsR0FBRyxDQUFDLElBQUssQ0FBQztFQUM1QixNQUFNLGVBQWUsSUFBSSxNQUFNLEtBQUssU0FBUyxTQUFTO0VBQ3RELGFBQWEsYUFBYTtFQUMxQixTQUFTLElBQUksWUFBWTs7RUFHekIsTUFBTSxVQUFVLElBQUksTUFBTSxZQUFZLEtBQU0sS0FBTSxHQUFJO0VBQ3RELFFBQVEsVUFBVSxHQUFHLENBQUMsS0FBTSxHQUFJO0VBQ2hDLE1BQU0sZUFBZSxJQUFJLE1BQU0sS0FBSyxTQUFTLE9BQU87RUFDcEQsU0FBUyxJQUFJLFlBQVk7O0VBR3pCLE1BQU0sV0FBVyxJQUFJLE1BQU0sTUFBTTtFQUNqQyxTQUFTLFNBQVMsSUFBSSxLQUFNLENBQUMsSUFBSyxDQUFDO0VBQ25DLE1BQU0sSUFBSSxRQUFRO0VBRWxCLE1BQU0saUJBQWlCLElBQUksTUFBTSxLQUFLLFVBQVUsT0FBTztFQUN2RCxlQUFlLGFBQWE7RUFDNUIsU0FBUyxJQUFJLGNBQWM7RUFFM0IsTUFBTSxZQUFZLElBQUksTUFBTSxNQUFNO0VBQ2xDLFVBQVUsU0FBUyxJQUFJLEdBQUcsQ0FBQyxLQUFNLENBQUM7RUFDbEMsU0FBUyxJQUFJLFNBQVM7RUFFdEIsTUFBTSxnQkFBZ0IsSUFBSSxNQUFNLEtBQUssU0FBUyxTQUFTO0VBQ3ZELGNBQWMsYUFBYTtFQUMzQixVQUFVLElBQUksYUFBYTtFQUUzQixNQUFNLGdCQUFnQixJQUFJLE1BQU0sS0FBSyxTQUFTLE9BQU87RUFDckQsVUFBVSxJQUFJLGFBQWE7RUFFM0IsT0FBTztHQUNMO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBLFVBQVU7R0FDVixhQUFhO0dBQ2IsY0FBYztHQUNkLFdBQVc7RUFDYjtDQUNGOzs7O0NBS0EsT0FBYyxZQUFZLE1BQWlCLFNBQVMsT0FBTyxXQUFrQztFQUMzRixNQUFNLE9BQU8sSUFBSSxNQUFNLE1BQU07O0VBRzdCLE1BQU0sUUFBUSxTQUFTLE9BQVEsU0FBUyxVQUFVLE9BQU87RUFDekQsS0FBSyxNQUFNLElBQUksT0FBTyxPQUFPLEtBQUs7O0VBR2xDLE1BQU0sWUFBWSxJQUFJLE1BQU0sZUFBZSxNQUFPLE9BQU8sRUFBRTtFQUMzRCxNQUFNLFlBQVksSUFBSSxNQUFNLGtCQUFrQjtHQUM1QyxPQUFPO0dBQ1AsYUFBYTtHQUNiLFNBQVM7R0FDVCxZQUFZO0VBQ2QsQ0FBQztFQUNELE1BQU0sYUFBYSxJQUFJLE1BQU0sS0FBSyxXQUFXLFNBQVM7RUFDdEQsV0FBVyxTQUFTLElBQUksQ0FBQyxLQUFLLEtBQUs7RUFDbkMsV0FBVyxTQUFTLElBQUk7RUFDeEIsS0FBSyxJQUFJLFVBQVU7O0VBR25CLElBQUksWUFBWTtFQUNoQixJQUFJLGFBQWE7RUFDakIsSUFBSSxXQUFXO0VBRWYsSUFBSSxTQUFTLFFBQVE7R0FDbkIsWUFBWTtHQUNaLGFBQWE7R0FDYixXQUFXO0VBQ2IsT0FBTyxJQUFJLFNBQVMsU0FBUztHQUMzQixZQUFZO0dBQ1osYUFBYTtHQUNiLFdBQVc7RUFDYixPQUFPLElBQUksU0FBUyxVQUFVO0dBQzVCLFlBQVk7R0FDWixhQUFhO0dBQ2IsV0FBVztFQUNiLE9BQU8sSUFBSSxRQUFRO0dBQ2pCLFlBQVksY0FBYyxXQUFXLFNBQVc7R0FDaEQsYUFBYSxjQUFjLFdBQVcsV0FBVztHQUNqRCxXQUFXLGNBQWMsV0FBVyxVQUFXO0VBQ2pEO0VBRUEsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FBRSxPQUFPO0dBQVcsV0FBVztHQUFLLFdBQVc7RUFBSSxDQUFDO0VBQ25HLE1BQU0sV0FBVyxJQUFJLE1BQU0scUJBQXFCO0dBQUUsT0FBTztHQUFZLFdBQVc7R0FBSyxXQUFXO0VBQUksQ0FBQztFQUNyRyxNQUFNLFdBQVcsSUFBSSxNQUFNLHFCQUFxQjtHQUFFLE9BQU87R0FBVSxXQUFXO0dBQUssV0FBVztFQUFLLENBQUM7O0VBR3BHLE1BQU0sUUFBUSxJQUFJLE1BQU0sTUFBTTtFQUM5QixNQUFNLFNBQVMsSUFBSTtFQUNuQixLQUFLLElBQUksS0FBSztFQUVkLE1BQU0sYUFBYSxTQUFTLFdBQVcsU0FBUyxNQUFPO0VBQ3ZELE1BQU0sV0FBVyxJQUFJLE1BQU0sWUFBWSxZQUFZLEtBQU0sR0FBSTtFQUM3RCxNQUFNLFlBQVksSUFBSSxNQUFNLEtBQUssVUFBVSxPQUFPO0VBQ2xELFVBQVUsU0FBUyxJQUFJO0VBQ3ZCLFVBQVUsYUFBYTtFQUN2QixNQUFNLElBQUksU0FBUzs7RUFHbkIsTUFBTSxRQUFRLElBQUksTUFBTSxZQUFZLGFBQWEsS0FBTSxLQUFNLEdBQUk7RUFDakUsTUFBTSxTQUFTLElBQUksTUFBTSxLQUFLLE9BQU8sUUFBUTtFQUM3QyxPQUFPLFNBQVMsSUFBSTtFQUNwQixNQUFNLElBQUksTUFBTTs7RUFHaEIsTUFBTSxPQUFPLElBQUksTUFBTSxNQUFNO0VBQzdCLEtBQUssU0FBUyxJQUFJO0VBQ2xCLE1BQU0sSUFBSSxJQUFJO0VBRWQsTUFBTSxVQUFVLElBQUksTUFBTSxlQUFlLEtBQU0sSUFBSSxFQUFFO0VBQ3JELE1BQU0sV0FBVyxJQUFJLE1BQU0sS0FBSyxTQUFTLE9BQU87RUFDaEQsU0FBUyxTQUFTLElBQUk7RUFDdEIsU0FBUyxhQUFhO0VBQ3RCLEtBQUssSUFBSSxRQUFROztFQUdqQixNQUFNLFNBQVMsSUFBSSxNQUFNLFlBQVksTUFBTyxLQUFNLEdBQUk7RUFDdEQsTUFBTSxTQUFTLElBQUksTUFBTSxrQkFBa0IsRUFBRSxPQUFPLFNBQVMsQ0FBQztFQUM5RCxNQUFNLFVBQVUsSUFBSSxNQUFNLEtBQUssUUFBUSxNQUFNO0VBQzdDLFFBQVEsU0FBUyxJQUFJLENBQUMsS0FBTSxNQUFPLEdBQUk7RUFDdkMsTUFBTSxXQUFXLElBQUksTUFBTSxLQUFLLFFBQVEsTUFBTTtFQUM5QyxTQUFTLFNBQVMsSUFBSSxLQUFNLE1BQU8sR0FBSTtFQUN2QyxLQUFLLElBQUksU0FBUyxRQUFROztFQUcxQixJQUFJLFNBQVMsWUFBWSxTQUFTLFVBQVU7O0dBRTFDLE1BQU0sU0FBUyxJQUFJLE1BQU0sYUFBYSxLQUFNLEtBQU0sRUFBRTtHQUNwRCxNQUFNLFNBQVMsSUFBSSxNQUFNLHFCQUFxQjtJQUFFLE9BQU87SUFBVSxXQUFXO0dBQUksQ0FBQztHQUNqRixNQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUssUUFBUSxNQUFNO0dBQ3pDLElBQUksU0FBUyxJQUFJO0dBQ2pCLEtBQUssSUFBSSxHQUFHO0VBQ2QsT0FBTyxJQUFJLFNBQVMsV0FBVyxRQUFROztHQUVyQyxNQUFNLFlBQVksSUFBSSxNQUFNLGlCQUFpQixLQUFNLEtBQU0sSUFBSyxFQUFFO0dBQ2hFLE1BQU0sU0FBUyxJQUFJLE1BQU0sS0FBSyxXQUFXLFFBQVE7R0FDakQsT0FBTyxTQUFTLElBQUk7R0FDcEIsS0FBSyxJQUFJLE1BQU07O0dBR2YsTUFBTSxXQUFXLElBQUksTUFBTSxhQUFhLE1BQU8sS0FBTSxDQUFDO0dBQ3RELE1BQU0sVUFBVSxJQUFJLE1BQU0scUJBQXFCO0lBQUUsT0FBTztJQUFVLFdBQVc7SUFBSyxXQUFXO0dBQUksQ0FBQztHQUNsRyxNQUFNLFdBQVcsSUFBSSxNQUFNLEtBQUssVUFBVSxPQUFPO0dBQ2pELFNBQVMsU0FBUyxJQUFJLENBQUMsSUFBSyxLQUFNLEdBQUk7R0FDdEMsU0FBUyxTQUFTLElBQUksQ0FBQyxJQUFLLEdBQUcsQ0FBQyxFQUFHO0dBQ25DLE1BQU0sWUFBWSxJQUFJLE1BQU0sS0FBSyxVQUFVLE9BQU87R0FDbEQsVUFBVSxTQUFTLElBQUksSUFBSyxLQUFNLEdBQUk7R0FDdEMsVUFBVSxTQUFTLElBQUksQ0FBQyxJQUFLLEdBQUcsRUFBRztHQUNuQyxLQUFLLElBQUksVUFBVSxTQUFTO0VBQzlCOztFQUdBLE1BQU0sVUFBVSxJQUFJLE1BQU0sTUFBTTtFQUNoQyxRQUFRLFNBQVMsSUFBSSxFQUFFLGFBQWEsS0FBTSxNQUFPLEtBQU0sQ0FBQztFQUN4RCxNQUFNLElBQUksT0FBTztFQUVqQixNQUFNLFdBQVcsSUFBSSxNQUFNLE1BQU07RUFDakMsU0FBUyxTQUFTLElBQUksYUFBYSxLQUFNLEtBQU0sS0FBTSxDQUFDO0VBQ3RELE1BQU0sSUFBSSxRQUFRO0VBRWxCLE1BQU0sU0FBUyxJQUFJLE1BQU0saUJBQWlCLEtBQU0sS0FBTSxLQUFNLEVBQUU7RUFDOUQsT0FBTyxVQUFVLEdBQUcsQ0FBQyxLQUFNLENBQUM7RUFFNUIsTUFBTSxlQUFlLElBQUksTUFBTSxLQUFLLFFBQVEsT0FBTztFQUNuRCxhQUFhLGFBQWE7RUFDMUIsUUFBUSxJQUFJLFlBQVk7RUFFeEIsTUFBTSxnQkFBZ0IsSUFBSSxNQUFNLEtBQUssUUFBUSxPQUFPO0VBQ3BELGNBQWMsYUFBYTtFQUMzQixTQUFTLElBQUksYUFBYTtFQUUxQixNQUFNLGNBQWMsSUFBSSxNQUFNLE1BQU07RUFDcEMsWUFBWSxTQUFTLElBQUksR0FBRyxDQUFDLEtBQU0sQ0FBQztFQUNwQyxRQUFRLElBQUksV0FBVztFQUV2QixNQUFNLGVBQWUsSUFBSSxNQUFNLE1BQU07RUFDckMsYUFBYSxTQUFTLElBQUksR0FBRyxDQUFDLEtBQU0sQ0FBQztFQUNyQyxTQUFTLElBQUksWUFBWTtFQUV6QixNQUFNLGFBQWEsSUFBSSxNQUFNLGlCQUFpQixNQUFPLEtBQU0sS0FBTSxFQUFFO0VBQ25FLFdBQVcsVUFBVSxHQUFHLENBQUMsS0FBTSxDQUFDO0VBQ2hDLFlBQVksSUFBSSxJQUFJLE1BQU0sS0FBSyxZQUFZLFFBQVEsQ0FBQztFQUNwRCxhQUFhLElBQUksSUFBSSxNQUFNLEtBQUssWUFBWSxRQUFRLENBQUM7O0VBR3JELE1BQU0sYUFBYSxJQUFJLE1BQU0sTUFBTTtFQUNuQyxXQUFXLFNBQVMsSUFBSSxHQUFHLENBQUMsS0FBTSxHQUFJO0VBQ3RDLFdBQVcsU0FBUyxJQUFJLEtBQUssS0FBSztFQUNsQyxhQUFhLElBQUksVUFBVTtFQUUzQixJQUFJO0VBRUosSUFBSSxTQUFTLFVBQVU7O0dBRXJCLE1BQU0sSUFBSSxNQUFNLE1BQU07R0FDdEIsSUFBSSxTQUFTLElBQUksR0FBRyxDQUFDLEtBQU0sRUFBRztHQUM5QixZQUFZLElBQUksR0FBRztHQUVuQixNQUFNLFNBQVMsSUFBSSxNQUFNLGNBQWMsS0FBTSxLQUFNLEdBQUcsSUFBSSxLQUFLLEtBQUssR0FBSTtHQUN4RSxNQUFNLFNBQVMsSUFBSSxNQUFNLHFCQUFxQjtJQUFFLE9BQU87SUFBVSxXQUFXO0dBQUksQ0FBQztHQUNqRixNQUFNLFVBQVUsSUFBSSxNQUFNLEtBQUssUUFBUSxNQUFNO0dBQzdDLFFBQVEsU0FBUyxJQUFJLEtBQUssS0FBSztHQUMvQixJQUFJLElBQUksT0FBTzs7R0FHZixNQUFNLFlBQVksSUFBSSxNQUFNLGlCQUFpQixLQUFNLEtBQU0sSUFBSyxDQUFDO0dBQy9ELE1BQU0sWUFBWSxJQUFJLE1BQU0scUJBQXFCLEVBQUUsT0FBTyxRQUFTLENBQUM7R0FDcEUsTUFBTSxTQUFTLElBQUksTUFBTSxLQUFLLFdBQVcsU0FBUztHQUNsRCxPQUFPLFNBQVMsSUFBSSxLQUFNLEtBQU0sQ0FBQyxFQUFHO0dBQ3BDLE9BQU8sU0FBUyxJQUFJO0dBQ3BCLE1BQU0sSUFBSSxNQUFNO0VBQ2xCLE9BQU8sSUFBSSxTQUFTLFNBQVM7O0dBRTNCLE1BQU0sVUFBVSxJQUFJLE1BQU0saUJBQWlCLEtBQU0sTUFBTyxLQUFLLEVBQUU7R0FDL0QsUUFBUSxVQUFVLEdBQUcsSUFBSyxDQUFDO0dBQzNCLE1BQU0sV0FBVyxJQUFJLE1BQU0sS0FBSyxTQUFTLFFBQVE7R0FDakQsU0FBUyxhQUFhO0dBQ3RCLFdBQVcsSUFBSSxRQUFRO0VBQ3pCLE9BQU87O0dBRUwsTUFBTSxZQUFZLElBQUksTUFBTSxpQkFBaUIsTUFBTyxNQUFPLEtBQU0sQ0FBQztHQUNsRSxNQUFNLFNBQVMsSUFBSSxNQUFNLEtBQUssV0FBVyxPQUFPO0dBQ2hELE9BQU8sU0FBUyxJQUFJLENBQUM7R0FDckIsV0FBVyxJQUFJLE1BQU07R0FFckIsTUFBTSxXQUFXLElBQUksTUFBTSxZQUFZLEtBQU0sU0FBUyxNQUFNLElBQUssR0FBSTtHQUNyRSxTQUFTLFVBQVUsR0FBRyxTQUFTLE1BQU8sS0FBTSxDQUFDO0dBQzdDLE1BQU0sV0FBVyxJQUFJLE1BQU0scUJBQXFCO0lBQzlDLE9BQU8sU0FBUyxXQUFXO0lBQzNCLFdBQVc7SUFDWCxXQUFXO0dBQ2IsQ0FBQztHQUNELE1BQU0sUUFBUSxJQUFJLE1BQU0sS0FBSyxVQUFVLFFBQVE7R0FDL0MsTUFBTSxhQUFhO0dBQ25CLFdBQVcsSUFBSSxLQUFLO0VBQ3RCOztFQUdBLE1BQU0sV0FBVyxJQUFJLE1BQU0sY0FBYyxLQUFLLEVBQUc7RUFDakQsU0FBUyxVQUFVLElBQUssSUFBSyxDQUFDO0VBQzlCLE1BQU0sV0FBVyxJQUFJLE1BQU0sa0JBQWtCO0dBQzNDLEtBQUssaUJBQWlCLHFCQUFxQjtHQUMzQyxPQUFPLElBQUksTUFBTSxNQUFNLFNBQVMsV0FBVyxRQUFRO0dBQ25ELGFBQWE7R0FDYixTQUFTO0dBQ1QsTUFBTSxNQUFNO0dBQ1osWUFBWTtFQUNkLENBQUM7RUFDRCxNQUFNLGFBQWEsSUFBSSxNQUFNLEtBQUssVUFBVSxRQUFRO0VBQ3BELFdBQVcsU0FBUyxJQUFJLEtBQUssS0FBSztFQUNsQyxXQUFXLElBQUksVUFBVTs7RUFHekIsTUFBTSxVQUFVLElBQUksTUFBTSxNQUFNO0VBQ2hDLFFBQVEsU0FBUyxJQUFJLENBQUMsS0FBTSxDQUFDLElBQUssQ0FBQztFQUNuQyxNQUFNLElBQUksT0FBTztFQUVqQixNQUFNLFdBQVcsSUFBSSxNQUFNLE1BQU07RUFDakMsU0FBUyxTQUFTLElBQUksS0FBTSxDQUFDLElBQUssQ0FBQztFQUNuQyxNQUFNLElBQUksUUFBUTtFQUVsQixNQUFNLFNBQVMsSUFBSSxNQUFNLGlCQUFpQixLQUFNLE1BQU8sSUFBSyxFQUFFO0VBQzlELE9BQU8sVUFBVSxHQUFHLENBQUMsSUFBSyxDQUFDO0VBQzNCLFFBQVEsSUFBSSxJQUFJLE1BQU0sS0FBSyxRQUFRLE9BQU8sQ0FBQztFQUMzQyxTQUFTLElBQUksSUFBSSxNQUFNLEtBQUssUUFBUSxPQUFPLENBQUM7RUFFNUMsTUFBTSxXQUFXLElBQUksTUFBTSxNQUFNO0VBQ2pDLFNBQVMsU0FBUyxJQUFJLEdBQUcsQ0FBQyxJQUFLLENBQUM7RUFDaEMsUUFBUSxJQUFJLFFBQVE7RUFFcEIsTUFBTSxZQUFZLElBQUksTUFBTSxNQUFNO0VBQ2xDLFVBQVUsU0FBUyxJQUFJLEdBQUcsQ0FBQyxJQUFLLENBQUM7RUFDakMsU0FBUyxJQUFJLFNBQVM7RUFFdEIsTUFBTSxVQUFVLElBQUksTUFBTSxpQkFBaUIsS0FBTSxLQUFNLEtBQU0sRUFBRTtFQUMvRCxRQUFRLFVBQVUsR0FBRyxDQUFDLEtBQU0sQ0FBQztFQUM3QixTQUFTLElBQUksSUFBSSxNQUFNLEtBQUssU0FBUyxRQUFRLENBQUM7RUFDOUMsVUFBVSxJQUFJLElBQUksTUFBTSxLQUFLLFNBQVMsUUFBUSxDQUFDOztFQUcvQyxJQUFJO0VBQ0osSUFBSSxRQUFRO0dBQ1YsTUFBTSxVQUFVLElBQUksTUFBTSxlQUFlLEtBQUssSUFBSSxFQUFFO0dBQ3BELE1BQU0sVUFBVSxJQUFJLE1BQU0sa0JBQWtCO0lBQzFDLE9BQU8sY0FBYyxXQUFXLFNBQVc7SUFDM0MsYUFBYTtJQUNiLFNBQVM7SUFDVCxXQUFXO0dBQ2IsQ0FBQztHQUNELE9BQU8sSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0dBQ3RDLEtBQUssU0FBUyxJQUFJO0dBQ2xCLEtBQUssSUFBSSxJQUFJO0VBQ2Y7RUFFQSxNQUFNLFNBQVMsSUFBSSxNQUFNLE1BQU07RUFFL0IsT0FBTztHQUNMO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQSxVQUFVO0dBQ1YsYUFBYTtHQUNiLGNBQWM7R0FDZCxXQUFXO0VBQ2I7Q0FDRjs7OztDQUtBLE9BQWMsZ0JBQWdCLEtBQW1CLE9BQWU7RUFDOUQsSUFBSSxZQUFZLFFBQVEsSUFBSTtFQUM1QixNQUFNLElBQUksSUFBSTs7RUFHZCxJQUFJLElBQUksT0FBTyxTQUFTLFNBQVMsR0FBRztHQUNsQyxJQUFJLE9BQU8sU0FBUyxFQUFFLENBQUMsU0FBUyxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsSUFBSTtHQUN0RCxJQUFJLE9BQU8sU0FBUyxFQUFFLENBQUMsU0FBUyxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksRUFBRyxJQUFJO0VBQzlEO0VBRUEsSUFBSSxJQUFJLE1BQU07R0FDWixJQUFJLEtBQUssU0FBUyxLQUFLLFFBQVE7R0FDL0IsSUFBSSxLQUFLLFNBQVMsS0FBSyxRQUFRO0VBQ2pDO0VBRUEsUUFBUSxJQUFJLGFBQVo7R0FDRSxLQUFLLFFBQVE7O0lBRVgsTUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSTtJQUNwQyxJQUFJLE1BQU0sU0FBUyxJQUFJLE1BQU87SUFDOUIsSUFBSSxLQUFLLFNBQVMsSUFBSSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUk7O0lBRzFDLElBQUksUUFBUSxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssSUFBSSxRQUFRLFNBQVMsR0FBRyxJQUFLLEdBQUcsS0FBSztJQUNuRixJQUFJLFFBQVEsU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLElBQUksUUFBUSxTQUFTLEdBQUcsQ0FBQyxLQUFNLEdBQUcsS0FBSztJQUNyRixJQUFJLFNBQVMsU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLElBQUksU0FBUyxTQUFTLEdBQUcsQ0FBQyxJQUFLLEdBQUcsS0FBSztJQUN0RixJQUFJLFNBQVMsU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLElBQUksU0FBUyxTQUFTLEdBQUcsS0FBTSxHQUFHLEtBQUs7SUFFdEYsSUFBSSxZQUFZLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxJQUFJLFlBQVksU0FBUyxHQUFHLENBQUMsSUFBSyxHQUFHLEtBQUs7SUFDNUYsSUFBSSxhQUFhLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxJQUFJLGFBQWEsU0FBUyxHQUFHLENBQUMsSUFBSyxHQUFHLEtBQUs7SUFFOUYsSUFBSSxRQUFRLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxJQUFJLFFBQVEsU0FBUyxHQUFHLEtBQU0sR0FBRyxLQUFLO0lBQ3BGLElBQUksU0FBUyxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssSUFBSSxTQUFTLFNBQVMsR0FBRyxDQUFDLEtBQU0sR0FBRyxLQUFLO0lBQ3ZGLElBQUksU0FBUyxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssSUFBSSxTQUFTLFNBQVMsR0FBRyxHQUFHLEdBQUcsS0FBSztJQUNuRixJQUFJLFVBQVUsU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLElBQUksVUFBVSxTQUFTLEdBQUcsR0FBRyxHQUFHLEtBQUs7O0lBR3JGLEFBQUMsSUFBSSxXQUFXLFNBQXFDLFVBQVU7SUFDL0Q7R0FDRjtHQUVBLEtBQUssT0FBTztJQUNWLE1BQU0sV0FBVyxLQUFLLElBQUksSUFBSSxFQUFFO0lBQ2hDLE1BQU0sU0FBUyxLQUFLLElBQUksSUFBSSxFQUFFO0lBRTlCLElBQUksTUFBTSxTQUFTLElBQUksTUFBTyxLQUFLLElBQUksTUFBTSxJQUFJO0lBQ2pELElBQUksTUFBTSxTQUFTLElBQUk7O0lBR3ZCLElBQUksUUFBUSxTQUFTLElBQUksV0FBVztJQUNwQyxJQUFJLFNBQVMsU0FBUyxJQUFJLENBQUMsV0FBVztJQUV0QyxJQUFJLFNBQVMsU0FBUyxJQUFJLFdBQVcsSUFBSSxXQUFXLEtBQU07SUFDMUQsSUFBSSxVQUFVLFNBQVMsSUFBSSxXQUFXLElBQUksQ0FBQyxXQUFXLEtBQU07O0lBRzVELElBQUksUUFBUSxTQUFTLElBQUksQ0FBQyxXQUFXO0lBQ3JDLElBQUksU0FBUyxTQUFTLElBQUksV0FBVztJQUNyQyxJQUFJLFlBQVksU0FBUyxJQUFJLENBQUM7SUFDOUIsSUFBSSxhQUFhLFNBQVMsSUFBSSxDQUFDO0lBRS9CLEFBQUMsSUFBSSxXQUFXLFNBQXFDLFVBQVU7SUFDL0Q7R0FDRjtHQUVBLEtBQUssUUFBUTtJQUNYLElBQUksTUFBTSxTQUFTLElBQUk7SUFDdkIsSUFBSSxRQUFRLFNBQVMsSUFBSSxDQUFDO0lBQzFCLElBQUksU0FBUyxTQUFTLElBQUksQ0FBQztJQUMzQixJQUFJLFNBQVMsU0FBUyxJQUFJO0lBQzFCLElBQUksVUFBVSxTQUFTLElBQUk7SUFFM0IsSUFBSSxRQUFRLFNBQVMsSUFBSSxDQUFDO0lBQzFCLElBQUksU0FBUyxTQUFTLElBQUksQ0FBQztJQUMzQixBQUFDLElBQUksV0FBVyxTQUFxQyxVQUFVO0lBQy9EO0dBQ0Y7R0FFQSxLQUFLLFdBQVc7O0lBRWQsTUFBTSxJQUFJLElBQUk7SUFDZCxJQUFJLE1BQU0sU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLENBQUMsSUFBSyxJQUFLLENBQUM7SUFDeEQsSUFBSSxTQUFTLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxDQUFDLElBQUssQ0FBQyxLQUFLLENBQUM7SUFDNUQsSUFBSSxTQUFTLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxJQUFLLENBQUMsS0FBSyxDQUFDO0lBQzNELElBQUksU0FBUyxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssSUFBSyxDQUFDLElBQUssQ0FBQztJQUUzRCxNQUFNLFdBQVcsSUFBSSxXQUFXO0lBQ2hDLFNBQVMsVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLEVBQUUsSUFBSTtJQUMzQztHQUNGO0dBRUEsS0FBSyxXQUFXOztJQUVkLE1BQU0sSUFBSSxJQUFJO0lBQ2QsSUFBSSxNQUFNLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxJQUFLLENBQUMsSUFBSyxDQUFDO0lBQ3hELElBQUksU0FBUyxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSyxDQUFDO0lBQzVELElBQUksU0FBUyxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssQ0FBQyxJQUFLLElBQUssQ0FBQztJQUMzRCxJQUFJLFNBQVMsU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLENBQUMsSUFBSyxJQUFLLENBQUM7SUFFM0QsTUFBTSxXQUFXLElBQUksV0FBVztJQUNoQyxTQUFTLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxFQUFFLElBQUk7SUFDM0M7R0FDRjtHQUVBLEtBQUssV0FBVzs7SUFFZCxNQUFNLElBQUksSUFBSTtJQUNkLElBQUksTUFBTSxTQUFTLElBQUksTUFBTyxLQUFLLElBQUksSUFBSSxLQUFLLEVBQUUsSUFBSTtJQUN0RCxJQUFJLE1BQU0sU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLENBQUMsSUFBSyxJQUFLLENBQUM7SUFDeEQsSUFBSSxTQUFTLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFLLENBQUM7SUFDNUQsSUFBSSxTQUFTLFNBQVMsSUFBSTtJQUMxQixJQUFJLFFBQVEsU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUssQ0FBQztJQUUzRCxNQUFNLFdBQVcsSUFBSSxXQUFXO0lBQ2hDLFNBQVMsVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLEVBQUUsSUFBSTtJQUMzQztHQUNGO0dBRUEsS0FBSyxRQUFRO0lBQ1gsTUFBTSxJQUFJLElBQUk7SUFDZCxJQUFJLE1BQU0sU0FBUyxJQUFJLENBQUM7SUFDeEIsSUFBSSxTQUFTLFNBQVMsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLEtBQUssRUFBRSxJQUFJO0lBQ25ELElBQUksVUFBVSxTQUFTLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxLQUFLLEVBQUUsSUFBSTtJQUNwRCxJQUFJLFFBQVEsU0FBUyxJQUFJO0lBQ3pCO0dBQ0Y7R0FFQSxLQUFLLFNBQVM7O0lBRVosTUFBTSxJQUFJLElBQUk7SUFDZCxJQUFJLE1BQU0sU0FBUyxJQUFJLE1BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxFQUFFLElBQUk7SUFDdEQsSUFBSSxNQUFNLFNBQVMsSUFBSSxJQUFJLEtBQUssS0FBSztJQUNyQyxJQUFJLFFBQVEsU0FBUyxJQUFJLENBQUM7SUFDMUIsSUFBSSxTQUFTLFNBQVMsSUFBSSxDQUFDO0lBQzNCLElBQUksUUFBUSxTQUFTLElBQUksQ0FBQztJQUMxQixJQUFJLFNBQVMsU0FBUyxJQUFJLENBQUM7SUFDM0I7R0FDRjtHQUVBLEtBQUssVUFBVTtJQUNiLE1BQU0sSUFBSSxJQUFJO0lBQ2QsSUFBSSxNQUFNLFNBQVMsSUFBSTtJQUN2QixJQUFJLE1BQU0sU0FBUyxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksS0FBSyxFQUFFLElBQUk7SUFDaEQsSUFBSSxLQUFLLFNBQVMsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLEtBQUssRUFBRSxJQUFJO0lBQy9DLElBQUksU0FBUyxTQUFTLElBQUk7SUFDMUIsSUFBSSxRQUFRLFNBQVMsSUFBSTtJQUN6QjtHQUNGO0dBRUEsS0FBSyxXQUFXOztJQUVkLElBQUksTUFBTSxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssSUFBSSxNQUFNLFNBQVMsR0FBRyxHQUFHLEdBQUcsS0FBSztJQUM3RSxJQUFJLFNBQVMsU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLElBQUksU0FBUyxTQUFTLEdBQUcsQ0FBQyxLQUFLLEdBQUcsS0FBSztJQUN0RixJQUFJLFNBQVMsU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLElBQUksU0FBUyxTQUFTLEdBQUcsSUFBSyxHQUFHLEtBQUs7SUFDckYsSUFBSSxRQUFRLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxJQUFJLFFBQVEsU0FBUyxHQUFHLENBQUMsSUFBSyxHQUFHLEtBQUs7SUFDcEYsSUFBSSxLQUFLLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxJQUFJLEtBQUssU0FBUyxHQUFHLENBQUMsSUFBSyxHQUFHLEtBQUs7SUFDOUU7R0FDRjtHQUVBLEtBQUssUUFBUTs7SUFFWCxJQUFJLE1BQU0sU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLElBQUksTUFBTSxTQUFTLEdBQUcsSUFBSyxHQUFHLEtBQUs7SUFDL0UsSUFBSSxNQUFNLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxJQUFJLE1BQU0sU0FBUyxHQUFHLEtBQUssS0FBSyxHQUFHLEdBQUcsS0FBSztJQUN2RixJQUFJLFNBQVMsU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLElBQUksU0FBUyxTQUFTLEdBQUcsSUFBSyxHQUFHLEtBQUs7SUFDckYsSUFBSSxRQUFRLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxJQUFJLFFBQVEsU0FBUyxHQUFHLElBQUssR0FBRyxLQUFLO0lBQ25GLEFBQUMsSUFBSSxXQUFXLFNBQXFDLFVBQVU7SUFDL0Q7R0FDRjtFQUNGO0NBQ0Y7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDaGFyYWN0ZXJNb2RlbHMudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5pbXBvcnQgKiBhcyBUSFJFRSBmcm9tICd0aHJlZSc7XG5pbXBvcnQgeyBQbGF5ZXJTa2luLCBXZWFwb24sIEVuZW15VHlwZSB9IGZyb20gJy4uL3R5cGVzL2dhbWUnO1xuaW1wb3J0IHsgVGV4dHVyZUdlbmVyYXRvciB9IGZyb20gJy4vVGV4dHVyZUdlbmVyYXRvcic7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2hhcmFjdGVyUmlnIHtcbiAgcm9vdDogVEhSRUUuR3JvdXA7XG4gIHRvcnNvOiBUSFJFRS5Hcm91cDtcbiAgaGVhZDogVEhSRUUuR3JvdXA7XG4gIHJpYmJvbjogVEhSRUUuR3JvdXA7XG4gIGxlZnRBcm06IFRIUkVFLkdyb3VwO1xuICByaWdodEFybTogVEhSRUUuR3JvdXA7XG4gIGxlZnRGb3JlYXJtOiBUSFJFRS5Hcm91cDtcbiAgcmlnaHRGb3JlYXJtOiBUSFJFRS5Hcm91cDtcbiAgbGVmdExlZzogVEhSRUUuR3JvdXA7XG4gIHJpZ2h0TGVnOiBUSFJFRS5Hcm91cDtcbiAgbGVmdENhbGY6IFRIUkVFLkdyb3VwO1xuICByaWdodENhbGY6IFRIUkVFLkdyb3VwO1xuICBzd29yZEdyb3VwOiBUSFJFRS5Hcm91cDtcbiAgc2xhc2hUcmFpbDogVEhSRUUuTWVzaDtcbiAgc2hhZG93RGlzYzogVEhSRUUuTWVzaDtcbiAgYm93PzogVEhSRUUuR3JvdXA7XG4gIGF1cmE/OiBUSFJFRS5NZXNoO1xuICAvLyBBbmltYXRpb24gc3RhdGUgdHJhY2tpbmdcbiAgYW5pbVRpbWU6IG51bWJlcjtcbiAgY3VycmVudEFuaW06ICdpZGxlJyB8ICdydW4nIHwgJ2p1bXAnIHwgJ2F0dGFjazEnIHwgJ2F0dGFjazInIHwgJ2F0dGFjazMnIHwgJ2tpY2snIHwgJ2RvZGdlJyB8ICdmbGluY2gnIHwgJ3ZpY3RvcnknIHwgJ2RlYWQnO1xuICBhbmltUHJvZ3Jlc3M6IG51bWJlcjsgLy8gMCB0byAxXG4gIGFuaW1TcGVlZDogbnVtYmVyO1xufVxuXG5leHBvcnQgY2xhc3MgQ2hhcmFjdGVyRmFjdG9yeSB7XG4gIC8qKlxuICAgKiBCdWlsZHMgaGlnaC1maWRlbGl0eSBwcm9jZWR1cmFsIE5pbmphIGhlcm8gbW9kZWxcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgY3JlYXRlTmluamFQbGF5ZXIoc2tpbjogUGxheWVyU2tpbiwgd2VhcG9uOiBXZWFwb24pOiBDaGFyYWN0ZXJSaWcge1xuICAgIGNvbnN0IHJvb3QgPSBuZXcgVEhSRUUuR3JvdXAoKTtcblxuICAgIC8vIENvbnRhY3QgZ3JvdW5kIHNoYWRvdyBkaXNjXG4gICAgY29uc3Qgc2hhZG93R2VvID0gbmV3IFRIUkVFLkNpcmNsZUdlb21ldHJ5KDAuNTUsIDI0KTtcbiAgICBjb25zdCBzaGFkb3dNYXQgPSBuZXcgVEhSRUUuTWVzaEJhc2ljTWF0ZXJpYWwoe1xuICAgICAgY29sb3I6IDB4MDAwMDAwLFxuICAgICAgdHJhbnNwYXJlbnQ6IHRydWUsXG4gICAgICBvcGFjaXR5OiAwLjQ1LFxuICAgICAgZGVwdGhXcml0ZTogZmFsc2UsXG4gICAgfSk7XG4gICAgY29uc3Qgc2hhZG93RGlzYyA9IG5ldyBUSFJFRS5NZXNoKHNoYWRvd0dlbywgc2hhZG93TWF0KTtcbiAgICBzaGFkb3dEaXNjLnJvdGF0aW9uLnggPSAtTWF0aC5QSSAvIDI7XG4gICAgc2hhZG93RGlzYy5wb3NpdGlvbi55ID0gMC4wMjtcbiAgICByb290LmFkZChzaGFkb3dEaXNjKTtcblxuICAgIC8vIENvbW1vbiBtYXRlcmlhbHNcbiAgICBjb25zdCBzdWl0TWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiBuZXcgVEhSRUUuQ29sb3Ioc2tpbi5zdWl0Q29sb3IpLFxuICAgICAgcm91Z2huZXNzOiAwLjgsXG4gICAgICBtZXRhbG5lc3M6IDAuMTUsXG4gICAgfSk7XG5cbiAgICBjb25zdCBhY2NlbnRNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgY29sb3I6IG5ldyBUSFJFRS5Db2xvcihza2luLmFjY2VudENvbG9yKSxcbiAgICAgIHJvdWdobmVzczogMC41LFxuICAgICAgbWV0YWxuZXNzOiAwLjM1LFxuICAgIH0pO1xuXG4gICAgY29uc3QgbWV0YWxNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgY29sb3I6IDB4ZGRkZGRkLFxuICAgICAgcm91Z2huZXNzOiAwLjI1LFxuICAgICAgbWV0YWxuZXNzOiAwLjg1LFxuICAgIH0pO1xuXG4gICAgY29uc3QgZ29sZE1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7XG4gICAgICBjb2xvcjogMHhkZmFhMjIsXG4gICAgICByb3VnaG5lc3M6IDAuMyxcbiAgICAgIG1ldGFsbmVzczogMC45LFxuICAgIH0pO1xuXG4gICAgY29uc3Qgc2tpblRvbmVNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgY29sb3I6IDB4ZTBhYzY5LFxuICAgICAgcm91Z2huZXNzOiAwLjcsXG4gICAgICBtZXRhbG5lc3M6IDAuMDUsXG4gICAgfSk7XG5cbiAgICAvLyAxLiBUb3JzbyAmIFBlbHZpc1xuICAgIGNvbnN0IHRvcnNvID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgdG9yc28ucG9zaXRpb24ueSA9IDAuOTU7IC8vIEhpcCBoZWlnaHRcbiAgICByb290LmFkZCh0b3Jzbyk7XG5cbiAgICAvLyBQZWx2aXNcbiAgICBjb25zdCBwZWx2aXNHZW8gPSBuZXcgVEhSRUUuQm94R2VvbWV0cnkoMC4zOCwgMC4yMiwgMC4yNik7XG4gICAgY29uc3QgcGVsdmlzTWVzaCA9IG5ldyBUSFJFRS5NZXNoKHBlbHZpc0dlbywgc3VpdE1hdCk7XG4gICAgcGVsdmlzTWVzaC5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICBwZWx2aXNNZXNoLnJlY2VpdmVTaGFkb3cgPSB0cnVlO1xuICAgIHRvcnNvLmFkZChwZWx2aXNNZXNoKTtcblxuICAgIC8vIFVwcGVyIENoZXN0XG4gICAgY29uc3QgY2hlc3RHZW8gPSBuZXcgVEhSRUUuQm94R2VvbWV0cnkoMC40NiwgMC40NSwgMC4zKTtcbiAgICBjb25zdCBjaGVzdE1lc2ggPSBuZXcgVEhSRUUuTWVzaChjaGVzdEdlbywgc3VpdE1hdCk7XG4gICAgY2hlc3RNZXNoLnBvc2l0aW9uLnkgPSAwLjMyO1xuICAgIGNoZXN0TWVzaC5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICBjaGVzdE1lc2gucmVjZWl2ZVNoYWRvdyA9IHRydWU7XG4gICAgdG9yc28uYWRkKGNoZXN0TWVzaCk7XG5cbiAgICAvLyBOaW5qYSBWZXN0IC8gQ3Jvc3NlZCBIYXJuZXNzXG4gICAgY29uc3QgdmVzdEdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeSgwLjQ4LCAwLjMyLCAwLjMyKTtcbiAgICBjb25zdCB2ZXN0TWVzaCA9IG5ldyBUSFJFRS5NZXNoKHZlc3RHZW8sIGFjY2VudE1hdCk7XG4gICAgdmVzdE1lc2gucG9zaXRpb24ueSA9IDAuMzI7XG4gICAgdG9yc28uYWRkKHZlc3RNZXNoKTtcblxuICAgIC8vIE9iaSAvIFdhaXN0IFNhc2hcbiAgICBjb25zdCBvYmlHZW8gPSBuZXcgVEhSRUUuQ3lsaW5kZXJHZW9tZXRyeSgwLjI0LCAwLjIzLCAwLjE0LCAxNik7XG4gICAgY29uc3Qgb2JpTWVzaCA9IG5ldyBUSFJFRS5NZXNoKG9iaUdlbywgYWNjZW50TWF0KTtcbiAgICBvYmlNZXNoLnBvc2l0aW9uLnkgPSAwLjE7XG4gICAgdG9yc28uYWRkKG9iaU1lc2gpO1xuXG4gICAgLy8gT2JpIEtub3RcbiAgICBjb25zdCBrbm90R2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDAuMTIsIDAuMTQsIDAuMDgpO1xuICAgIGNvbnN0IGtub3RNZXNoID0gbmV3IFRIUkVFLk1lc2goa25vdEdlbywgYWNjZW50TWF0KTtcbiAgICBrbm90TWVzaC5wb3NpdGlvbi5zZXQoMCwgMC4xLCAwLjE2KTtcbiAgICB0b3Jzby5hZGQoa25vdE1lc2gpO1xuXG4gICAgLy8gMi4gSGVhZCAmIE5pbmphIE1hc2tcbiAgICBjb25zdCBoZWFkID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgaGVhZC5wb3NpdGlvbi55ID0gMC42MjtcbiAgICB0b3Jzby5hZGQoaGVhZCk7XG5cbiAgICAvLyBIb29kL0Nvd2xcbiAgICBjb25zdCBob29kR2VvID0gbmV3IFRIUkVFLlNwaGVyZUdlb21ldHJ5KDAuMiwgMTYsIDE2KTtcbiAgICBob29kR2VvLnNjYWxlKDEsIDEuMTUsIDEuMDUpO1xuICAgIGNvbnN0IGhvb2RNZXNoID0gbmV3IFRIUkVFLk1lc2goaG9vZEdlbywgc3VpdE1hdCk7XG4gICAgaG9vZE1lc2gucG9zaXRpb24ueSA9IDAuMTU7XG4gICAgaG9vZE1lc2guY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgaGVhZC5hZGQoaG9vZE1lc2gpO1xuXG4gICAgLy8gRmFjZSBBcGVydHVyZSAoZXllcyB2aXNpYmxlKVxuICAgIGNvbnN0IGV5ZUFwZXJ0dXJlR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDAuMiwgMC4wNywgMC4wNik7XG4gICAgY29uc3QgZXllQXBlcnR1cmVNZXNoID0gbmV3IFRIUkVFLk1lc2goZXllQXBlcnR1cmVHZW8sIHNraW5Ub25lTWF0KTtcbiAgICBleWVBcGVydHVyZU1lc2gucG9zaXRpb24uc2V0KDAsIDAuMTYsIDAuMTgpO1xuICAgIGhlYWQuYWRkKGV5ZUFwZXJ0dXJlTWVzaCk7XG5cbiAgICAvLyBQaWVyY2luZyBFeWVzXG4gICAgY29uc3QgZXllR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDAuMDQ1LCAwLjAxNSwgMC4wMik7XG4gICAgY29uc3QgZXllR2xvd01hdCA9IG5ldyBUSFJFRS5NZXNoQmFzaWNNYXRlcmlhbCh7IGNvbG9yOiAweDY3ZThmOSB9KTtcbiAgICBjb25zdCBsZWZ0RXllID0gbmV3IFRIUkVFLk1lc2goZXllR2VvLCBleWVHbG93TWF0KTtcbiAgICBsZWZ0RXllLnBvc2l0aW9uLnNldCgtMC4wNSwgMC4xNjUsIDAuMjA1KTtcbiAgICBjb25zdCByaWdodEV5ZSA9IG5ldyBUSFJFRS5NZXNoKGV5ZUdlbywgZXllR2xvd01hdCk7XG4gICAgcmlnaHRFeWUucG9zaXRpb24uc2V0KDAuMDUsIDAuMTY1LCAwLjIwNSk7XG4gICAgaGVhZC5hZGQobGVmdEV5ZSwgcmlnaHRFeWUpO1xuXG4gICAgLy8gRm9yZWhlYWQgUGxhdGUgKEhpdGFpLWF0ZSlcbiAgICBjb25zdCBwbGF0ZUdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeSgwLjE4LCAwLjA2NSwgMC4wMyk7XG4gICAgY29uc3QgcGxhdGVNZXNoID0gbmV3IFRIUkVFLk1lc2gocGxhdGVHZW8sIG1ldGFsTWF0KTtcbiAgICBwbGF0ZU1lc2gucG9zaXRpb24uc2V0KDAsIDAuMjUsIDAuMTkpO1xuICAgIGhlYWQuYWRkKHBsYXRlTWVzaCk7XG5cbiAgICAvLyBIZWFkYmFuZCBSaWJib24gKGZsb3dpbmcgYmVoaW5kKVxuICAgIGNvbnN0IHJpYmJvbiA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIHJpYmJvbi5wb3NpdGlvbi5zZXQoMCwgMC4yMywgLTAuMik7XG4gICAgY29uc3QgcmliYm9uR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDAuMDYsIDAuMzgsIDAuMDIpO1xuICAgIGNvbnN0IHJpYmJvbk1lc2gxID0gbmV3IFRIUkVFLk1lc2gocmliYm9uR2VvLCBhY2NlbnRNYXQpO1xuICAgIHJpYmJvbk1lc2gxLnBvc2l0aW9uLnNldCgtMC4wNCwgLTAuMTYsIDApO1xuICAgIHJpYmJvbk1lc2gxLnJvdGF0aW9uLnogPSAwLjE1O1xuICAgIGNvbnN0IHJpYmJvbk1lc2gyID0gbmV3IFRIUkVFLk1lc2gocmliYm9uR2VvLCBhY2NlbnRNYXQpO1xuICAgIHJpYmJvbk1lc2gyLnBvc2l0aW9uLnNldCgwLjA0LCAtMC4xNiwgMCk7XG4gICAgcmliYm9uTWVzaDIucm90YXRpb24ueiA9IC0wLjE1O1xuICAgIHJpYmJvbi5hZGQocmliYm9uTWVzaDEsIHJpYmJvbk1lc2gyKTtcbiAgICBoZWFkLmFkZChyaWJib24pO1xuXG4gICAgLy8gMy4gQXJtcyAmIEthdGFuYVxuICAgIC8vIExlZnQgQXJtXG4gICAgY29uc3QgbGVmdEFybSA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIGxlZnRBcm0ucG9zaXRpb24uc2V0KC0wLjMxLCAwLjQ4LCAwKTtcbiAgICB0b3Jzby5hZGQobGVmdEFybSk7XG5cbiAgICAvLyBTaG91bGRlciBQYXVsZHJvblxuICAgIGNvbnN0IHBhdWxkcm9uR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDAuMTQsIDAuMTIsIDAuMTYpO1xuICAgIGNvbnN0IGxlZnRQYXVsZHJvbiA9IG5ldyBUSFJFRS5NZXNoKHBhdWxkcm9uR2VvLCBhY2NlbnRNYXQpO1xuICAgIGxlZnRBcm0uYWRkKGxlZnRQYXVsZHJvbik7XG5cbiAgICBjb25zdCB1cHBlckFybUdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMDY1LCAwLjA2LCAwLjI4LCAxMik7XG4gICAgdXBwZXJBcm1HZW8udHJhbnNsYXRlKDAsIC0wLjE0LCAwKTtcbiAgICBjb25zdCBsZWZ0VXBwZXJBcm1NZXNoID0gbmV3IFRIUkVFLk1lc2godXBwZXJBcm1HZW8sIHN1aXRNYXQpO1xuICAgIGxlZnRVcHBlckFybU1lc2guY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgbGVmdEFybS5hZGQobGVmdFVwcGVyQXJtTWVzaCk7XG5cbiAgICBjb25zdCBsZWZ0Rm9yZWFybSA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIGxlZnRGb3JlYXJtLnBvc2l0aW9uLnNldCgwLCAtMC4yOCwgMCk7XG4gICAgbGVmdEFybS5hZGQobGVmdEZvcmVhcm0pO1xuXG4gICAgY29uc3QgZm9yZWFybUdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMDYsIDAuMDU1LCAwLjI2LCAxMik7XG4gICAgZm9yZWFybUdlby50cmFuc2xhdGUoMCwgLTAuMTMsIDApO1xuICAgIGNvbnN0IGxlZnRGb3JlYXJtTWVzaCA9IG5ldyBUSFJFRS5NZXNoKGZvcmVhcm1HZW8sIGFjY2VudE1hdCk7XG4gICAgbGVmdEZvcmVhcm0uYWRkKGxlZnRGb3JlYXJtTWVzaCk7XG5cbiAgICAvLyBSaWdodCBBcm0gKFdlYXBvbiBIYW5kKVxuICAgIGNvbnN0IHJpZ2h0QXJtID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgcmlnaHRBcm0ucG9zaXRpb24uc2V0KDAuMzEsIDAuNDgsIDApO1xuICAgIHRvcnNvLmFkZChyaWdodEFybSk7XG5cbiAgICBjb25zdCByaWdodFBhdWxkcm9uID0gbmV3IFRIUkVFLk1lc2gocGF1bGRyb25HZW8sIGFjY2VudE1hdCk7XG4gICAgcmlnaHRBcm0uYWRkKHJpZ2h0UGF1bGRyb24pO1xuXG4gICAgY29uc3QgcmlnaHRVcHBlckFybU1lc2ggPSBuZXcgVEhSRUUuTWVzaCh1cHBlckFybUdlbywgc3VpdE1hdCk7XG4gICAgcmlnaHRVcHBlckFybU1lc2guY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgcmlnaHRBcm0uYWRkKHJpZ2h0VXBwZXJBcm1NZXNoKTtcblxuICAgIGNvbnN0IHJpZ2h0Rm9yZWFybSA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIHJpZ2h0Rm9yZWFybS5wb3NpdGlvbi5zZXQoMCwgLTAuMjgsIDApO1xuICAgIHJpZ2h0QXJtLmFkZChyaWdodEZvcmVhcm0pO1xuXG4gICAgY29uc3QgcmlnaHRGb3JlYXJtTWVzaCA9IG5ldyBUSFJFRS5NZXNoKGZvcmVhcm1HZW8sIGFjY2VudE1hdCk7XG4gICAgcmlnaHRGb3JlYXJtLmFkZChyaWdodEZvcmVhcm1NZXNoKTtcblxuICAgIC8vIEhhbmRcbiAgICBjb25zdCBoYW5kR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDAuMDgsIDAuMDgsIDAuMDkpO1xuICAgIGNvbnN0IHJpZ2h0SGFuZCA9IG5ldyBUSFJFRS5NZXNoKGhhbmRHZW8sIHN1aXRNYXQpO1xuICAgIHJpZ2h0SGFuZC5wb3NpdGlvbi5zZXQoMCwgLTAuMjYsIDApO1xuICAgIHJpZ2h0Rm9yZWFybS5hZGQocmlnaHRIYW5kKTtcblxuICAgIC8vIEthdGFuYSBHcm91cCBhdHRhY2hlZCB0byByaWdodCBoYW5kXG4gICAgY29uc3Qgc3dvcmRHcm91cCA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIHN3b3JkR3JvdXAucG9zaXRpb24uc2V0KDAsIC0wLjI2LCAwLjA2KTtcbiAgICBzd29yZEdyb3VwLnJvdGF0aW9uLnggPSBNYXRoLlBJIC8gMjtcbiAgICByaWdodEZvcmVhcm0uYWRkKHN3b3JkR3JvdXApO1xuXG4gICAgLy8gVHN1a2EgKEhhbmRsZSlcbiAgICBjb25zdCBoYW5kbGVHZW8gPSBuZXcgVEhSRUUuQ3lsaW5kZXJHZW9tZXRyeSgwLjAyMiwgMC4wMjIsIDAuMjQsIDgpO1xuICAgIGNvbnN0IGhhbmRsZU1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7IGNvbG9yOiAweDE4MTgxYiwgcm91Z2huZXNzOiAwLjkgfSk7XG4gICAgY29uc3QgaGFuZGxlTWVzaCA9IG5ldyBUSFJFRS5NZXNoKGhhbmRsZUdlbywgaGFuZGxlTWF0KTtcbiAgICBoYW5kbGVNZXNoLnBvc2l0aW9uLnkgPSAtMC4xO1xuICAgIHN3b3JkR3JvdXAuYWRkKGhhbmRsZU1lc2gpO1xuXG4gICAgLy8gVHN1YmEgKEhhbmRndWFyZClcbiAgICBjb25zdCB0c3ViYUdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMDg1LCAwLjA4NSwgMC4wMTUsIDE2KTtcbiAgICBjb25zdCB0c3ViYU1lc2ggPSBuZXcgVEhSRUUuTWVzaCh0c3ViYUdlbywgZ29sZE1hdCk7XG4gICAgdHN1YmFNZXNoLnBvc2l0aW9uLnkgPSAwLjAyO1xuICAgIHN3b3JkR3JvdXAuYWRkKHRzdWJhTWVzaCk7XG5cbiAgICAvLyBLYXRhbmEgQmxhZGVcbiAgICBjb25zdCBibGFkZUdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeSgwLjAxOCwgMC45NSwgMC4wNSk7XG4gICAgYmxhZGVHZW8udHJhbnNsYXRlKDAsIDAuNDgsIDApO1xuICAgIGNvbnN0IGJsYWRlTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiBuZXcgVEhSRUUuQ29sb3Iod2VhcG9uLmJsYWRlQ29sb3IgfHwgMHhlMmU4ZjApLFxuICAgICAgbWV0YWxuZXNzOiAwLjk1LFxuICAgICAgcm91Z2huZXNzOiAwLjE1LFxuICAgICAgZW1pc3NpdmU6IG5ldyBUSFJFRS5Db2xvcih3ZWFwb24uZ2xvd0NvbG9yIHx8IDB4MDAwMDAwKSxcbiAgICAgIGVtaXNzaXZlSW50ZW5zaXR5OiAwLjM1LFxuICAgIH0pO1xuICAgIGNvbnN0IGJsYWRlTWVzaCA9IG5ldyBUSFJFRS5NZXNoKGJsYWRlR2VvLCBibGFkZU1hdCk7XG4gICAgYmxhZGVNZXNoLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgIHN3b3JkR3JvdXAuYWRkKGJsYWRlTWVzaCk7XG5cbiAgICAvLyBLYXRhbmEgVGlwIChDdXJ2ZWQgcG9pbnQpXG4gICAgY29uc3QgdGlwR2VvID0gbmV3IFRIUkVFLkNvbmVHZW9tZXRyeSgwLjAzLCAwLjEsIDQpO1xuICAgIHRpcEdlby50cmFuc2xhdGUoMCwgMC45OCwgMCk7XG4gICAgY29uc3QgdGlwTWVzaCA9IG5ldyBUSFJFRS5NZXNoKHRpcEdlbywgYmxhZGVNYXQpO1xuICAgIHRpcE1lc2gucm90YXRpb24ueSA9IE1hdGguUEkgLyA0O1xuICAgIHN3b3JkR3JvdXAuYWRkKHRpcE1lc2gpO1xuXG4gICAgLy8gU2xhc2ggQXJjIFRyYWlsIChkeW5hbWljYWxseSBzaG93biBkdXJpbmcgYXR0YWNrcylcbiAgICBjb25zdCBzbGFzaEdlbyA9IG5ldyBUSFJFRS5QbGFuZUdlb21ldHJ5KDEuNiwgMC42KTtcbiAgICBzbGFzaEdlby50cmFuc2xhdGUoMC40LCAwLjcsIDApO1xuICAgIGNvbnN0IHNsYXNoTWF0ID0gbmV3IFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKHtcbiAgICAgIG1hcDogVGV4dHVyZUdlbmVyYXRvci5nZXRTbGFzaFRyYWlsVGV4dHVyZSgpLFxuICAgICAgY29sb3I6IG5ldyBUSFJFRS5Db2xvcih3ZWFwb24udHJhaWxDb2xvciB8fCAnI2Y5NzMxNicpLFxuICAgICAgdHJhbnNwYXJlbnQ6IHRydWUsXG4gICAgICBvcGFjaXR5OiAwLFxuICAgICAgc2lkZTogVEhSRUUuRG91YmxlU2lkZSxcbiAgICAgIGRlcHRoV3JpdGU6IGZhbHNlLFxuICAgICAgYmxlbmRpbmc6IFRIUkVFLkFkZGl0aXZlQmxlbmRpbmcsXG4gICAgfSk7XG4gICAgY29uc3Qgc2xhc2hUcmFpbCA9IG5ldyBUSFJFRS5NZXNoKHNsYXNoR2VvLCBzbGFzaE1hdCk7XG4gICAgc2xhc2hUcmFpbC5yb3RhdGlvbi56ID0gTWF0aC5QSSAvIDQ7XG4gICAgc3dvcmRHcm91cC5hZGQoc2xhc2hUcmFpbCk7XG5cbiAgICAvLyA0LiBMZWdzXG4gICAgLy8gTGVmdCBMZWdcbiAgICBjb25zdCBsZWZ0TGVnID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgbGVmdExlZy5wb3NpdGlvbi5zZXQoLTAuMTMsIC0wLjEsIDApO1xuICAgIHRvcnNvLmFkZChsZWZ0TGVnKTtcblxuICAgIGNvbnN0IHRoaWdoR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC4wODUsIDAuMDc1LCAwLjQyLCAxMik7XG4gICAgdGhpZ2hHZW8udHJhbnNsYXRlKDAsIC0wLjIxLCAwKTtcbiAgICBjb25zdCBsZWZ0VGhpZ2hNZXNoID0gbmV3IFRIUkVFLk1lc2godGhpZ2hHZW8sIHN1aXRNYXQpO1xuICAgIGxlZnRUaGlnaE1lc2guY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgbGVmdExlZy5hZGQobGVmdFRoaWdoTWVzaCk7XG5cbiAgICBjb25zdCBsZWZ0Q2FsZiA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIGxlZnRDYWxmLnBvc2l0aW9uLnNldCgwLCAtMC40MiwgMCk7XG4gICAgbGVmdExlZy5hZGQobGVmdENhbGYpO1xuXG4gICAgY29uc3QgY2FsZkdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMDc1LCAwLjA2NSwgMC40LCAxMik7XG4gICAgY2FsZkdlby50cmFuc2xhdGUoMCwgLTAuMiwgMCk7XG4gICAgY29uc3QgbGVmdENhbGZNZXNoID0gbmV3IFRIUkVFLk1lc2goY2FsZkdlbywgYWNjZW50TWF0KTtcbiAgICBsZWZ0Q2FsZk1lc2guY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgbGVmdENhbGYuYWRkKGxlZnRDYWxmTWVzaCk7XG5cbiAgICAvLyBUYWJpIEJvb3RcbiAgICBjb25zdCBmb290R2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDAuMTIsIDAuMDksIDAuMjIpO1xuICAgIGZvb3RHZW8udHJhbnNsYXRlKDAsIC0wLjQyLCAwLjA0KTtcbiAgICBjb25zdCBsZWZ0Rm9vdE1lc2ggPSBuZXcgVEhSRUUuTWVzaChmb290R2VvLCBzdWl0TWF0KTtcbiAgICBsZWZ0Q2FsZi5hZGQobGVmdEZvb3RNZXNoKTtcblxuICAgIC8vIFJpZ2h0IExlZ1xuICAgIGNvbnN0IHJpZ2h0TGVnID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgcmlnaHRMZWcucG9zaXRpb24uc2V0KDAuMTMsIC0wLjEsIDApO1xuICAgIHRvcnNvLmFkZChyaWdodExlZyk7XG5cbiAgICBjb25zdCByaWdodFRoaWdoTWVzaCA9IG5ldyBUSFJFRS5NZXNoKHRoaWdoR2VvLCBzdWl0TWF0KTtcbiAgICByaWdodFRoaWdoTWVzaC5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICByaWdodExlZy5hZGQocmlnaHRUaGlnaE1lc2gpO1xuXG4gICAgY29uc3QgcmlnaHRDYWxmID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgcmlnaHRDYWxmLnBvc2l0aW9uLnNldCgwLCAtMC40MiwgMCk7XG4gICAgcmlnaHRMZWcuYWRkKHJpZ2h0Q2FsZik7XG5cbiAgICBjb25zdCByaWdodENhbGZNZXNoID0gbmV3IFRIUkVFLk1lc2goY2FsZkdlbywgYWNjZW50TWF0KTtcbiAgICByaWdodENhbGZNZXNoLmNhc3RTaGFkb3cgPSB0cnVlO1xuICAgIHJpZ2h0Q2FsZi5hZGQocmlnaHRDYWxmTWVzaCk7XG5cbiAgICBjb25zdCByaWdodEZvb3RNZXNoID0gbmV3IFRIUkVFLk1lc2goZm9vdEdlbywgc3VpdE1hdCk7XG4gICAgcmlnaHRDYWxmLmFkZChyaWdodEZvb3RNZXNoKTtcblxuICAgIHJldHVybiB7XG4gICAgICByb290LFxuICAgICAgdG9yc28sXG4gICAgICBoZWFkLFxuICAgICAgcmliYm9uLFxuICAgICAgbGVmdEFybSxcbiAgICAgIHJpZ2h0QXJtLFxuICAgICAgbGVmdEZvcmVhcm0sXG4gICAgICByaWdodEZvcmVhcm0sXG4gICAgICBsZWZ0TGVnLFxuICAgICAgcmlnaHRMZWcsXG4gICAgICBsZWZ0Q2FsZixcbiAgICAgIHJpZ2h0Q2FsZixcbiAgICAgIHN3b3JkR3JvdXAsXG4gICAgICBzbGFzaFRyYWlsLFxuICAgICAgc2hhZG93RGlzYyxcbiAgICAgIGFuaW1UaW1lOiAwLFxuICAgICAgY3VycmVudEFuaW06ICdpZGxlJyxcbiAgICAgIGFuaW1Qcm9ncmVzczogMCxcbiAgICAgIGFuaW1TcGVlZDogMSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIEJ1aWxkcyBkaXN0aW5jdCBlbmVteSBjaGFyYWN0ZXJzOiBOb3JtYWwgQXNoaWdhcnUsIEZhc3QgTmluamEsIEhlYXZ5IEJydXRlLCBBcmNoZXIsIG9yIEJvc3NcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgY3JlYXRlRW5lbXkodHlwZTogRW5lbXlUeXBlLCBpc0Jvc3MgPSBmYWxzZSwgYm9zc1RoZW1lPzogc3RyaW5nKTogQ2hhcmFjdGVyUmlnIHtcbiAgICBjb25zdCByb290ID0gbmV3IFRIUkVFLkdyb3VwKCk7XG5cbiAgICAvLyBTY2FsZSBtdWx0aXBsaWVyIGZvciBib3NzZXNcbiAgICBjb25zdCBzY2FsZSA9IGlzQm9zcyA/IDEuNDUgOiAodHlwZSA9PT0gJ2hlYXZ5JyA/IDEuMjUgOiAxLjApO1xuICAgIHJvb3Quc2NhbGUuc2V0KHNjYWxlLCBzY2FsZSwgc2NhbGUpO1xuXG4gICAgLy8gQ29udGFjdCBncm91bmQgc2hhZG93IGRpc2NcbiAgICBjb25zdCBzaGFkb3dHZW8gPSBuZXcgVEhSRUUuQ2lyY2xlR2VvbWV0cnkoMC41NSAqIHNjYWxlLCAyNCk7XG4gICAgY29uc3Qgc2hhZG93TWF0ID0gbmV3IFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiAweDAwMDAwMCxcbiAgICAgIHRyYW5zcGFyZW50OiB0cnVlLFxuICAgICAgb3BhY2l0eTogMC40NSxcbiAgICAgIGRlcHRoV3JpdGU6IGZhbHNlLFxuICAgIH0pO1xuICAgIGNvbnN0IHNoYWRvd0Rpc2MgPSBuZXcgVEhSRUUuTWVzaChzaGFkb3dHZW8sIHNoYWRvd01hdCk7XG4gICAgc2hhZG93RGlzYy5yb3RhdGlvbi54ID0gLU1hdGguUEkgLyAyO1xuICAgIHNoYWRvd0Rpc2MucG9zaXRpb24ueSA9IDAuMDI7XG4gICAgcm9vdC5hZGQoc2hhZG93RGlzYyk7XG5cbiAgICAvLyBDb2xvcnMgcGVyIGVuZW15IHR5cGVcbiAgICBsZXQgc3VpdENvbG9yID0gMHgyNzI3MmE7XG4gICAgbGV0IGFybW9yQ29sb3IgPSAweDk5MWIxYjtcbiAgICBsZXQgZXllQ29sb3IgPSAweGVmNDQ0NDtcblxuICAgIGlmICh0eXBlID09PSAnZmFzdCcpIHtcbiAgICAgIHN1aXRDb2xvciA9IDB4MGYxNzJhO1xuICAgICAgYXJtb3JDb2xvciA9IDB4NmIyMWE4O1xuICAgICAgZXllQ29sb3IgPSAweGE4NTVmNztcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdoZWF2eScpIHtcbiAgICAgIHN1aXRDb2xvciA9IDB4MTgxODFiO1xuICAgICAgYXJtb3JDb2xvciA9IDB4M2YzZjQ2O1xuICAgICAgZXllQ29sb3IgPSAweGY1OWUwYjtcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdhcmNoZXInKSB7XG4gICAgICBzdWl0Q29sb3IgPSAweDFlMjkzYjtcbiAgICAgIGFybW9yQ29sb3IgPSAweGI0NTMwOTtcbiAgICAgIGV5ZUNvbG9yID0gMHhmYWNjMTU7XG4gICAgfSBlbHNlIGlmIChpc0Jvc3MpIHtcbiAgICAgIHN1aXRDb2xvciA9IGJvc3NUaGVtZSA9PT0gJ3JhaWRlbicgPyAweDA5MDkwYiA6IDB4NDUwYTBhO1xuICAgICAgYXJtb3JDb2xvciA9IGJvc3NUaGVtZSA9PT0gJ3JhaWRlbicgPyAweGQ5NzcwNiA6IDB4YjkxYzFjO1xuICAgICAgZXllQ29sb3IgPSBib3NzVGhlbWUgPT09ICdyYWlkZW4nID8gMHgzOGJkZjggOiAweGZmMjIyMjtcbiAgICB9XG5cbiAgICBjb25zdCBzdWl0TWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHsgY29sb3I6IHN1aXRDb2xvciwgcm91Z2huZXNzOiAwLjgsIG1ldGFsbmVzczogMC4yIH0pO1xuICAgIGNvbnN0IGFybW9yTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHsgY29sb3I6IGFybW9yQ29sb3IsIHJvdWdobmVzczogMC40LCBtZXRhbG5lc3M6IDAuNiB9KTtcbiAgICBjb25zdCBtZXRhbE1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7IGNvbG9yOiAweDg4ODg5OSwgcm91Z2huZXNzOiAwLjMsIG1ldGFsbmVzczogMC44NSB9KTtcblxuICAgIC8vIFRvcnNvXG4gICAgY29uc3QgdG9yc28gPSBuZXcgVEhSRUUuR3JvdXAoKTtcbiAgICB0b3Jzby5wb3NpdGlvbi55ID0gMC45NTtcbiAgICByb290LmFkZCh0b3Jzbyk7XG5cbiAgICBjb25zdCBjaGVzdFdpZHRoID0gdHlwZSA9PT0gJ2hlYXZ5JyB8fCBpc0Jvc3MgPyAwLjYyIDogMC40NjtcbiAgICBjb25zdCBjaGVzdEdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeShjaGVzdFdpZHRoLCAwLjQ4LCAwLjMyKTtcbiAgICBjb25zdCBjaGVzdE1lc2ggPSBuZXcgVEhSRUUuTWVzaChjaGVzdEdlbywgc3VpdE1hdCk7XG4gICAgY2hlc3RNZXNoLnBvc2l0aW9uLnkgPSAwLjMyO1xuICAgIGNoZXN0TWVzaC5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICB0b3Jzby5hZGQoY2hlc3RNZXNoKTtcblxuICAgIC8vIEFybW9yIGJyZWFzdHBsYXRlIChEbylcbiAgICBjb25zdCBkb0dlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeShjaGVzdFdpZHRoICsgMC4wNCwgMC4zNCwgMC4zNCk7XG4gICAgY29uc3QgZG9NZXNoID0gbmV3IFRIUkVFLk1lc2goZG9HZW8sIGFybW9yTWF0KTtcbiAgICBkb01lc2gucG9zaXRpb24ueSA9IDAuMzQ7XG4gICAgdG9yc28uYWRkKGRvTWVzaCk7XG5cbiAgICAvLyBIZWFkXG4gICAgY29uc3QgaGVhZCA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIGhlYWQucG9zaXRpb24ueSA9IDAuNjI7XG4gICAgdG9yc28uYWRkKGhlYWQpO1xuXG4gICAgY29uc3QgaGVhZEdlbyA9IG5ldyBUSFJFRS5TcGhlcmVHZW9tZXRyeSgwLjE5LCAxNiwgMTYpO1xuICAgIGNvbnN0IGhlYWRNZXNoID0gbmV3IFRIUkVFLk1lc2goaGVhZEdlbywgc3VpdE1hdCk7XG4gICAgaGVhZE1lc2gucG9zaXRpb24ueSA9IDAuMTU7XG4gICAgaGVhZE1lc2guY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgaGVhZC5hZGQoaGVhZE1lc2gpO1xuXG4gICAgLy8gRXllc1xuICAgIGNvbnN0IGV5ZUdlbyA9IG5ldyBUSFJFRS5Cb3hHZW9tZXRyeSgwLjA0NSwgMC4wMiwgMC4wMik7XG4gICAgY29uc3QgZXllTWF0ID0gbmV3IFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKHsgY29sb3I6IGV5ZUNvbG9yIH0pO1xuICAgIGNvbnN0IGxlZnRFeWUgPSBuZXcgVEhSRUUuTWVzaChleWVHZW8sIGV5ZU1hdCk7XG4gICAgbGVmdEV5ZS5wb3NpdGlvbi5zZXQoLTAuMDYsIDAuMTY1LCAwLjE5KTtcbiAgICBjb25zdCByaWdodEV5ZSA9IG5ldyBUSFJFRS5NZXNoKGV5ZUdlbywgZXllTWF0KTtcbiAgICByaWdodEV5ZS5wb3NpdGlvbi5zZXQoMC4wNiwgMC4xNjUsIDAuMTkpO1xuICAgIGhlYWQuYWRkKGxlZnRFeWUsIHJpZ2h0RXllKTtcblxuICAgIC8vIEhlYWRnZWFyIHBlciB0eXBlXG4gICAgaWYgKHR5cGUgPT09ICdub3JtYWwnIHx8IHR5cGUgPT09ICdhcmNoZXInKSB7XG4gICAgICAvLyBDb25pY2FsIEppbmdhc2EgU3RyYXcgSGF0XG4gICAgICBjb25zdCBoYXRHZW8gPSBuZXcgVEhSRUUuQ29uZUdlb21ldHJ5KDAuNDIsIDAuMTYsIDE4KTtcbiAgICAgIGNvbnN0IGhhdE1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7IGNvbG9yOiAweDkyNDAwZSwgcm91Z2huZXNzOiAwLjkgfSk7XG4gICAgICBjb25zdCBoYXQgPSBuZXcgVEhSRUUuTWVzaChoYXRHZW8sIGhhdE1hdCk7XG4gICAgICBoYXQucG9zaXRpb24ueSA9IDAuMjg7XG4gICAgICBoZWFkLmFkZChoYXQpO1xuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ2hlYXZ5JyB8fCBpc0Jvc3MpIHtcbiAgICAgIC8vIFNhbXVyYWkgS2FidXRvIEhlbG1ldCB3aXRoIGhvcm5lZCBjcmVzdFxuICAgICAgY29uc3Qga2FidXRvR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC4yNCwgMC4yNiwgMC4yLCAxNik7XG4gICAgICBjb25zdCBrYWJ1dG8gPSBuZXcgVEhSRUUuTWVzaChrYWJ1dG9HZW8sIGFybW9yTWF0KTtcbiAgICAgIGthYnV0by5wb3NpdGlvbi55ID0gMC4yNDtcbiAgICAgIGhlYWQuYWRkKGthYnV0byk7XG5cbiAgICAgIC8vIEhvcm5lZCBjcmVzdCAoTWFlZGF0ZSlcbiAgICAgIGNvbnN0IGNyZXN0R2VvID0gbmV3IFRIUkVFLkNvbmVHZW9tZXRyeSgwLjAzNSwgMC4zMiwgNCk7XG4gICAgICBjb25zdCBnb2xkTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHsgY29sb3I6IDB4ZjU5ZTBiLCBtZXRhbG5lc3M6IDAuOSwgcm91Z2huZXNzOiAwLjIgfSk7XG4gICAgICBjb25zdCBsZWZ0SG9ybiA9IG5ldyBUSFJFRS5NZXNoKGNyZXN0R2VvLCBnb2xkTWF0KTtcbiAgICAgIGxlZnRIb3JuLnBvc2l0aW9uLnNldCgtMC4xLCAwLjM2LCAwLjE1KTtcbiAgICAgIGxlZnRIb3JuLnJvdGF0aW9uLnNldCgtMC4yLCAwLCAtMC40KTtcbiAgICAgIGNvbnN0IHJpZ2h0SG9ybiA9IG5ldyBUSFJFRS5NZXNoKGNyZXN0R2VvLCBnb2xkTWF0KTtcbiAgICAgIHJpZ2h0SG9ybi5wb3NpdGlvbi5zZXQoMC4xLCAwLjM2LCAwLjE1KTtcbiAgICAgIHJpZ2h0SG9ybi5yb3RhdGlvbi5zZXQoLTAuMiwgMCwgMC40KTtcbiAgICAgIGhlYWQuYWRkKGxlZnRIb3JuLCByaWdodEhvcm4pO1xuICAgIH1cblxuICAgIC8vIEFybXNcbiAgICBjb25zdCBsZWZ0QXJtID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgbGVmdEFybS5wb3NpdGlvbi5zZXQoLShjaGVzdFdpZHRoICogMC41ICsgMC4wOCksIDAuNDgsIDApO1xuICAgIHRvcnNvLmFkZChsZWZ0QXJtKTtcblxuICAgIGNvbnN0IHJpZ2h0QXJtID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgcmlnaHRBcm0ucG9zaXRpb24uc2V0KGNoZXN0V2lkdGggKiAwLjUgKyAwLjA4LCAwLjQ4LCAwKTtcbiAgICB0b3Jzby5hZGQocmlnaHRBcm0pO1xuXG4gICAgY29uc3QgYXJtR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC4wNywgMC4wNiwgMC4yOCwgMTApO1xuICAgIGFybUdlby50cmFuc2xhdGUoMCwgLTAuMTQsIDApO1xuXG4gICAgY29uc3QgbGVmdFVwcGVyQXJtID0gbmV3IFRIUkVFLk1lc2goYXJtR2VvLCBzdWl0TWF0KTtcbiAgICBsZWZ0VXBwZXJBcm0uY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgbGVmdEFybS5hZGQobGVmdFVwcGVyQXJtKTtcblxuICAgIGNvbnN0IHJpZ2h0VXBwZXJBcm0gPSBuZXcgVEhSRUUuTWVzaChhcm1HZW8sIHN1aXRNYXQpO1xuICAgIHJpZ2h0VXBwZXJBcm0uY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgcmlnaHRBcm0uYWRkKHJpZ2h0VXBwZXJBcm0pO1xuXG4gICAgY29uc3QgbGVmdEZvcmVhcm0gPSBuZXcgVEhSRUUuR3JvdXAoKTtcbiAgICBsZWZ0Rm9yZWFybS5wb3NpdGlvbi5zZXQoMCwgLTAuMjgsIDApO1xuICAgIGxlZnRBcm0uYWRkKGxlZnRGb3JlYXJtKTtcblxuICAgIGNvbnN0IHJpZ2h0Rm9yZWFybSA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIHJpZ2h0Rm9yZWFybS5wb3NpdGlvbi5zZXQoMCwgLTAuMjgsIDApO1xuICAgIHJpZ2h0QXJtLmFkZChyaWdodEZvcmVhcm0pO1xuXG4gICAgY29uc3QgZm9yZWFybUdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMDY1LCAwLjA2LCAwLjI2LCAxMCk7XG4gICAgZm9yZWFybUdlby50cmFuc2xhdGUoMCwgLTAuMTMsIDApO1xuICAgIGxlZnRGb3JlYXJtLmFkZChuZXcgVEhSRUUuTWVzaChmb3JlYXJtR2VvLCBhcm1vck1hdCkpO1xuICAgIHJpZ2h0Rm9yZWFybS5hZGQobmV3IFRIUkVFLk1lc2goZm9yZWFybUdlbywgYXJtb3JNYXQpKTtcblxuICAgIC8vIFdlYXBvblxuICAgIGNvbnN0IHN3b3JkR3JvdXAgPSBuZXcgVEhSRUUuR3JvdXAoKTtcbiAgICBzd29yZEdyb3VwLnBvc2l0aW9uLnNldCgwLCAtMC4yNiwgMC4wNik7XG4gICAgc3dvcmRHcm91cC5yb3RhdGlvbi54ID0gTWF0aC5QSSAvIDI7XG4gICAgcmlnaHRGb3JlYXJtLmFkZChzd29yZEdyb3VwKTtcblxuICAgIGxldCBib3c6IFRIUkVFLkdyb3VwIHwgdW5kZWZpbmVkO1xuXG4gICAgaWYgKHR5cGUgPT09ICdhcmNoZXInKSB7XG4gICAgICAvLyBZdW1pIEJvdyBpbiBsZWZ0IGhhbmRcbiAgICAgIGJvdyA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgICAgYm93LnBvc2l0aW9uLnNldCgwLCAtMC4yNiwgMC4xKTtcbiAgICAgIGxlZnRGb3JlYXJtLmFkZChib3cpO1xuXG4gICAgICBjb25zdCBib3dHZW8gPSBuZXcgVEhSRUUuVG9ydXNHZW9tZXRyeSgwLjU1LCAwLjAyLCA4LCAyNCwgTWF0aC5QSSAqIDAuNjUpO1xuICAgICAgY29uc3QgYm93TWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHsgY29sb3I6IDB4NzgzNTBmLCByb3VnaG5lc3M6IDAuNyB9KTtcbiAgICAgIGNvbnN0IGJvd01lc2ggPSBuZXcgVEhSRUUuTWVzaChib3dHZW8sIGJvd01hdCk7XG4gICAgICBib3dNZXNoLnJvdGF0aW9uLnogPSBNYXRoLlBJIC8gMjtcbiAgICAgIGJvdy5hZGQoYm93TWVzaCk7XG5cbiAgICAgIC8vIFF1aXZlciBvbiBiYWNrXG4gICAgICBjb25zdCBxdWl2ZXJHZW8gPSBuZXcgVEhSRUUuQ3lsaW5kZXJHZW9tZXRyeSgwLjA3LCAwLjA2LCAwLjUsIDgpO1xuICAgICAgY29uc3QgcXVpdmVyTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHsgY29sb3I6IDB4NDUxYTAzIH0pO1xuICAgICAgY29uc3QgcXVpdmVyID0gbmV3IFRIUkVFLk1lc2gocXVpdmVyR2VvLCBxdWl2ZXJNYXQpO1xuICAgICAgcXVpdmVyLnBvc2l0aW9uLnNldCgwLjEyLCAwLjM1LCAtMC4yKTtcbiAgICAgIHF1aXZlci5yb3RhdGlvbi56ID0gMC4zNTtcbiAgICAgIHRvcnNvLmFkZChxdWl2ZXIpO1xuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ2hlYXZ5Jykge1xuICAgICAgLy8gU3Bpa2VkIEthbmFibyBDbHViXG4gICAgICBjb25zdCBjbHViR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC4wNiwgMC4wMzUsIDEuMSwgMTApO1xuICAgICAgY2x1Ykdlby50cmFuc2xhdGUoMCwgMC41LCAwKTtcbiAgICAgIGNvbnN0IGNsdWJNZXNoID0gbmV3IFRIUkVFLk1lc2goY2x1YkdlbywgbWV0YWxNYXQpO1xuICAgICAgY2x1Yk1lc2guY2FzdFNoYWRvdyA9IHRydWU7XG4gICAgICBzd29yZEdyb3VwLmFkZChjbHViTWVzaCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFN3b3JkXG4gICAgICBjb25zdCBoYW5kbGVHZW8gPSBuZXcgVEhSRUUuQ3lsaW5kZXJHZW9tZXRyeSgwLjAyMiwgMC4wMjIsIDAuMjIsIDgpO1xuICAgICAgY29uc3QgaGFuZGxlID0gbmV3IFRIUkVFLk1lc2goaGFuZGxlR2VvLCBzdWl0TWF0KTtcbiAgICAgIGhhbmRsZS5wb3NpdGlvbi55ID0gLTAuMTtcbiAgICAgIHN3b3JkR3JvdXAuYWRkKGhhbmRsZSk7XG5cbiAgICAgIGNvbnN0IGJsYWRlR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDAuMDIsIGlzQm9zcyA/IDEuMyA6IDAuOSwgMC4wNSk7XG4gICAgICBibGFkZUdlby50cmFuc2xhdGUoMCwgaXNCb3NzID8gMC42NSA6IDAuNDUsIDApO1xuICAgICAgY29uc3QgYmxhZGVNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgICBjb2xvcjogaXNCb3NzID8gMHhmZjQ0NDQgOiAweGNjY2NjYyxcbiAgICAgICAgbWV0YWxuZXNzOiAwLjksXG4gICAgICAgIHJvdWdobmVzczogMC4yLFxuICAgICAgfSk7XG4gICAgICBjb25zdCBibGFkZSA9IG5ldyBUSFJFRS5NZXNoKGJsYWRlR2VvLCBibGFkZU1hdCk7XG4gICAgICBibGFkZS5jYXN0U2hhZG93ID0gdHJ1ZTtcbiAgICAgIHN3b3JkR3JvdXAuYWRkKGJsYWRlKTtcbiAgICB9XG5cbiAgICAvLyBTbGFzaCBUcmFpbCBmb3IgZW5lbWllc1xuICAgIGNvbnN0IHNsYXNoR2VvID0gbmV3IFRIUkVFLlBsYW5lR2VvbWV0cnkoMS42LCAwLjYpO1xuICAgIHNsYXNoR2VvLnRyYW5zbGF0ZSgwLjQsIDAuNywgMCk7XG4gICAgY29uc3Qgc2xhc2hNYXQgPSBuZXcgVEhSRUUuTWVzaEJhc2ljTWF0ZXJpYWwoe1xuICAgICAgbWFwOiBUZXh0dXJlR2VuZXJhdG9yLmdldFNsYXNoVHJhaWxUZXh0dXJlKCksXG4gICAgICBjb2xvcjogbmV3IFRIUkVFLkNvbG9yKGlzQm9zcyA/IDB4ZGMyNjI2IDogMHg5OTFiMWIpLFxuICAgICAgdHJhbnNwYXJlbnQ6IHRydWUsXG4gICAgICBvcGFjaXR5OiAwLFxuICAgICAgc2lkZTogVEhSRUUuRG91YmxlU2lkZSxcbiAgICAgIGRlcHRoV3JpdGU6IGZhbHNlLFxuICAgIH0pO1xuICAgIGNvbnN0IHNsYXNoVHJhaWwgPSBuZXcgVEhSRUUuTWVzaChzbGFzaEdlbywgc2xhc2hNYXQpO1xuICAgIHNsYXNoVHJhaWwucm90YXRpb24ueiA9IE1hdGguUEkgLyA0O1xuICAgIHN3b3JkR3JvdXAuYWRkKHNsYXNoVHJhaWwpO1xuXG4gICAgLy8gTGVnc1xuICAgIGNvbnN0IGxlZnRMZWcgPSBuZXcgVEhSRUUuR3JvdXAoKTtcbiAgICBsZWZ0TGVnLnBvc2l0aW9uLnNldCgtMC4xNiwgLTAuMSwgMCk7XG4gICAgdG9yc28uYWRkKGxlZnRMZWcpO1xuXG4gICAgY29uc3QgcmlnaHRMZWcgPSBuZXcgVEhSRUUuR3JvdXAoKTtcbiAgICByaWdodExlZy5wb3NpdGlvbi5zZXQoMC4xNiwgLTAuMSwgMCk7XG4gICAgdG9yc28uYWRkKHJpZ2h0TGVnKTtcblxuICAgIGNvbnN0IGxlZ0dlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDAuMDksIDAuMDc1LCAwLjQsIDEwKTtcbiAgICBsZWdHZW8udHJhbnNsYXRlKDAsIC0wLjIsIDApO1xuICAgIGxlZnRMZWcuYWRkKG5ldyBUSFJFRS5NZXNoKGxlZ0dlbywgc3VpdE1hdCkpO1xuICAgIHJpZ2h0TGVnLmFkZChuZXcgVEhSRUUuTWVzaChsZWdHZW8sIHN1aXRNYXQpKTtcblxuICAgIGNvbnN0IGxlZnRDYWxmID0gbmV3IFRIUkVFLkdyb3VwKCk7XG4gICAgbGVmdENhbGYucG9zaXRpb24uc2V0KDAsIC0wLjQsIDApO1xuICAgIGxlZnRMZWcuYWRkKGxlZnRDYWxmKTtcblxuICAgIGNvbnN0IHJpZ2h0Q2FsZiA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuICAgIHJpZ2h0Q2FsZi5wb3NpdGlvbi5zZXQoMCwgLTAuNCwgMCk7XG4gICAgcmlnaHRMZWcuYWRkKHJpZ2h0Q2FsZik7XG5cbiAgICBjb25zdCBjYWxmR2VvID0gbmV3IFRIUkVFLkN5bGluZGVyR2VvbWV0cnkoMC4wOCwgMC4wNywgMC4zOCwgMTApO1xuICAgIGNhbGZHZW8udHJhbnNsYXRlKDAsIC0wLjE5LCAwKTtcbiAgICBsZWZ0Q2FsZi5hZGQobmV3IFRIUkVFLk1lc2goY2FsZkdlbywgYXJtb3JNYXQpKTtcbiAgICByaWdodENhbGYuYWRkKG5ldyBUSFJFRS5NZXNoKGNhbGZHZW8sIGFybW9yTWF0KSk7XG5cbiAgICAvLyBCb3NzIGRlbW9uaWMgYXVyYVxuICAgIGxldCBhdXJhOiBUSFJFRS5NZXNoIHwgdW5kZWZpbmVkO1xuICAgIGlmIChpc0Jvc3MpIHtcbiAgICAgIGNvbnN0IGF1cmFHZW8gPSBuZXcgVEhSRUUuU3BoZXJlR2VvbWV0cnkoMS40LCAxNiwgMTYpO1xuICAgICAgY29uc3QgYXVyYU1hdCA9IG5ldyBUSFJFRS5NZXNoQmFzaWNNYXRlcmlhbCh7XG4gICAgICAgIGNvbG9yOiBib3NzVGhlbWUgPT09ICdyYWlkZW4nID8gMHgwZWE1ZTkgOiAweGVmNDQ0NCxcbiAgICAgICAgdHJhbnNwYXJlbnQ6IHRydWUsXG4gICAgICAgIG9wYWNpdHk6IDAuMTUsXG4gICAgICAgIHdpcmVmcmFtZTogdHJ1ZSxcbiAgICAgIH0pO1xuICAgICAgYXVyYSA9IG5ldyBUSFJFRS5NZXNoKGF1cmFHZW8sIGF1cmFNYXQpO1xuICAgICAgYXVyYS5wb3NpdGlvbi55ID0gMS4wO1xuICAgICAgcm9vdC5hZGQoYXVyYSk7XG4gICAgfVxuXG4gICAgY29uc3QgcmliYm9uID0gbmV3IFRIUkVFLkdyb3VwKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgcm9vdCxcbiAgICAgIHRvcnNvLFxuICAgICAgaGVhZCxcbiAgICAgIHJpYmJvbixcbiAgICAgIGxlZnRBcm0sXG4gICAgICByaWdodEFybSxcbiAgICAgIGxlZnRGb3JlYXJtLFxuICAgICAgcmlnaHRGb3JlYXJtLFxuICAgICAgbGVmdExlZyxcbiAgICAgIHJpZ2h0TGVnLFxuICAgICAgbGVmdENhbGYsXG4gICAgICByaWdodENhbGYsXG4gICAgICBzd29yZEdyb3VwLFxuICAgICAgc2xhc2hUcmFpbCxcbiAgICAgIHNoYWRvd0Rpc2MsXG4gICAgICBib3csXG4gICAgICBhdXJhLFxuICAgICAgYW5pbVRpbWU6IDAsXG4gICAgICBjdXJyZW50QW5pbTogJ2lkbGUnLFxuICAgICAgYW5pbVByb2dyZXNzOiAwLFxuICAgICAgYW5pbVNwZWVkOiAxLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogQXBwbGllcyBraW5lbWF0aWNzICYgYW5pbWF0aW9uIGZyYW1lcyB0byByaWdcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgdXBkYXRlQW5pbWF0aW9uKHJpZzogQ2hhcmFjdGVyUmlnLCBkZWx0YTogbnVtYmVyKSB7XG4gICAgcmlnLmFuaW1UaW1lICs9IGRlbHRhICogcmlnLmFuaW1TcGVlZDtcbiAgICBjb25zdCB0ID0gcmlnLmFuaW1UaW1lO1xuXG4gICAgLy8gSGVhZGJhbmQgcmliYm9uIHN1YnRsZSB3YXZlXG4gICAgaWYgKHJpZy5yaWJib24uY2hpbGRyZW4ubGVuZ3RoID4gMCkge1xuICAgICAgcmlnLnJpYmJvbi5jaGlsZHJlblswXS5yb3RhdGlvbi54ID0gTWF0aC5zaW4odCAqIDUpICogMC4xNTtcbiAgICAgIHJpZy5yaWJib24uY2hpbGRyZW5bMV0ucm90YXRpb24ueCA9IE1hdGguc2luKHQgKiA1ICsgMC41KSAqIDAuMTU7XG4gICAgfVxuXG4gICAgaWYgKHJpZy5hdXJhKSB7XG4gICAgICByaWcuYXVyYS5yb3RhdGlvbi55ICs9IGRlbHRhICogMC44O1xuICAgICAgcmlnLmF1cmEucm90YXRpb24ueCArPSBkZWx0YSAqIDAuNDtcbiAgICB9XG5cbiAgICBzd2l0Y2ggKHJpZy5jdXJyZW50QW5pbSkge1xuICAgICAgY2FzZSAnaWRsZSc6IHtcbiAgICAgICAgLy8gU3VidGxlIGJyZWF0aGluZyBzd2F5XG4gICAgICAgIGNvbnN0IGJyZWF0aGUgPSBNYXRoLnNpbih0ICogMi41KSAqIDAuMDI1O1xuICAgICAgICByaWcudG9yc28ucG9zaXRpb24ueSA9IDAuOTUgKyBicmVhdGhlO1xuICAgICAgICByaWcuaGVhZC5yb3RhdGlvbi54ID0gTWF0aC5zaW4odCAqIDEuNSkgKiAwLjAzO1xuXG4gICAgICAgIC8vIEFybSByZWxheGF0aW9uXG4gICAgICAgIHJpZy5sZWZ0QXJtLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcubGVmdEFybS5yb3RhdGlvbi54LCAwLjEsIDgsIGRlbHRhKTtcbiAgICAgICAgcmlnLmxlZnRBcm0ucm90YXRpb24ueiA9IFRIUkVFLk1hdGhVdGlscy5kYW1wKHJpZy5sZWZ0QXJtLnJvdGF0aW9uLnosIC0wLjE1LCA4LCBkZWx0YSk7XG4gICAgICAgIHJpZy5yaWdodEFybS5yb3RhdGlvbi54ID0gVEhSRUUuTWF0aFV0aWxzLmRhbXAocmlnLnJpZ2h0QXJtLnJvdGF0aW9uLngsIC0wLjIsIDgsIGRlbHRhKTtcbiAgICAgICAgcmlnLnJpZ2h0QXJtLnJvdGF0aW9uLnogPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcucmlnaHRBcm0ucm90YXRpb24ueiwgMC4xNSwgOCwgZGVsdGEpO1xuXG4gICAgICAgIHJpZy5sZWZ0Rm9yZWFybS5yb3RhdGlvbi54ID0gVEhSRUUuTWF0aFV0aWxzLmRhbXAocmlnLmxlZnRGb3JlYXJtLnJvdGF0aW9uLngsIC0wLjMsIDgsIGRlbHRhKTtcbiAgICAgICAgcmlnLnJpZ2h0Rm9yZWFybS5yb3RhdGlvbi54ID0gVEhSRUUuTWF0aFV0aWxzLmRhbXAocmlnLnJpZ2h0Rm9yZWFybS5yb3RhdGlvbi54LCAtMC41LCA4LCBkZWx0YSk7XG5cbiAgICAgICAgcmlnLmxlZnRMZWcucm90YXRpb24ueCA9IFRIUkVFLk1hdGhVdGlscy5kYW1wKHJpZy5sZWZ0TGVnLnJvdGF0aW9uLngsIDAuMDUsIDgsIGRlbHRhKTtcbiAgICAgICAgcmlnLnJpZ2h0TGVnLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcucmlnaHRMZWcucm90YXRpb24ueCwgLTAuMDUsIDgsIGRlbHRhKTtcbiAgICAgICAgcmlnLmxlZnRDYWxmLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcubGVmdENhbGYucm90YXRpb24ueCwgMCwgOCwgZGVsdGEpO1xuICAgICAgICByaWcucmlnaHRDYWxmLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcucmlnaHRDYWxmLnJvdGF0aW9uLngsIDAsIDgsIGRlbHRhKTtcblxuICAgICAgICAvLyBIaWRlIHNsYXNoIHRyYWlsXG4gICAgICAgIChyaWcuc2xhc2hUcmFpbC5tYXRlcmlhbCBhcyBUSFJFRS5NZXNoQmFzaWNNYXRlcmlhbCkub3BhY2l0eSA9IDA7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuXG4gICAgICBjYXNlICdydW4nOiB7XG4gICAgICAgIGNvbnN0IHJ1bkN5Y2xlID0gTWF0aC5zaW4odCAqIDEyKTtcbiAgICAgICAgY29uc3QgcnVuQ29zID0gTWF0aC5jb3ModCAqIDEyKTtcblxuICAgICAgICByaWcudG9yc28ucG9zaXRpb24ueSA9IDAuOTUgKyBNYXRoLmFicyhydW5Db3MpICogMC4wODtcbiAgICAgICAgcmlnLnRvcnNvLnJvdGF0aW9uLnggPSAwLjE4OyAvLyBGb3J3YXJkIHJ1biBsZWFuXG5cbiAgICAgICAgLy8gT3Bwb3NpdGUgbGVnIG1vdmVtZW50XG4gICAgICAgIHJpZy5sZWZ0TGVnLnJvdGF0aW9uLnggPSBydW5DeWNsZSAqIDAuNztcbiAgICAgICAgcmlnLnJpZ2h0TGVnLnJvdGF0aW9uLnggPSAtcnVuQ3ljbGUgKiAwLjc7XG5cbiAgICAgICAgcmlnLmxlZnRDYWxmLnJvdGF0aW9uLnggPSBydW5DeWNsZSA+IDAgPyBydW5DeWNsZSAqIDAuOCA6IDAuMTtcbiAgICAgICAgcmlnLnJpZ2h0Q2FsZi5yb3RhdGlvbi54ID0gcnVuQ3ljbGUgPCAwID8gLXJ1bkN5Y2xlICogMC44IDogMC4xO1xuXG4gICAgICAgIC8vIFB1bXBpbmcgYXJtc1xuICAgICAgICByaWcubGVmdEFybS5yb3RhdGlvbi54ID0gLXJ1bkN5Y2xlICogMC44O1xuICAgICAgICByaWcucmlnaHRBcm0ucm90YXRpb24ueCA9IHJ1bkN5Y2xlICogMC44O1xuICAgICAgICByaWcubGVmdEZvcmVhcm0ucm90YXRpb24ueCA9IC0wLjU7XG4gICAgICAgIHJpZy5yaWdodEZvcmVhcm0ucm90YXRpb24ueCA9IC0wLjY7XG5cbiAgICAgICAgKHJpZy5zbGFzaFRyYWlsLm1hdGVyaWFsIGFzIFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKS5vcGFjaXR5ID0gMDtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIGNhc2UgJ2p1bXAnOiB7XG4gICAgICAgIHJpZy50b3Jzby5yb3RhdGlvbi54ID0gMC4xO1xuICAgICAgICByaWcubGVmdExlZy5yb3RhdGlvbi54ID0gLTAuNDtcbiAgICAgICAgcmlnLnJpZ2h0TGVnLnJvdGF0aW9uLnggPSAtMC41O1xuICAgICAgICByaWcubGVmdENhbGYucm90YXRpb24ueCA9IDAuODtcbiAgICAgICAgcmlnLnJpZ2h0Q2FsZi5yb3RhdGlvbi54ID0gMC43O1xuXG4gICAgICAgIHJpZy5sZWZ0QXJtLnJvdGF0aW9uLnggPSAtMS4yO1xuICAgICAgICByaWcucmlnaHRBcm0ucm90YXRpb24ueCA9IC0xLjQ7XG4gICAgICAgIChyaWcuc2xhc2hUcmFpbC5tYXRlcmlhbCBhcyBUSFJFRS5NZXNoQmFzaWNNYXRlcmlhbCkub3BhY2l0eSA9IDA7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuXG4gICAgICBjYXNlICdhdHRhY2sxJzoge1xuICAgICAgICAvLyBIb3Jpem9udGFsIHNsYXNoIGNvbWJvIDFcbiAgICAgICAgY29uc3QgcCA9IHJpZy5hbmltUHJvZ3Jlc3M7XG4gICAgICAgIHJpZy50b3Jzby5yb3RhdGlvbi55ID0gVEhSRUUuTWF0aFV0aWxzLmxlcnAoLTAuNCwgMC42LCBwKTtcbiAgICAgICAgcmlnLnJpZ2h0QXJtLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMubGVycCgtMC41LCAtMS4yLCBwKTtcbiAgICAgICAgcmlnLnJpZ2h0QXJtLnJvdGF0aW9uLnkgPSBUSFJFRS5NYXRoVXRpbHMubGVycCgwLjgsIC0xLjEsIHApO1xuICAgICAgICByaWcucmlnaHRBcm0ucm90YXRpb24ueiA9IFRIUkVFLk1hdGhVdGlscy5sZXJwKDAuNSwgLTAuMywgcCk7XG5cbiAgICAgICAgY29uc3QgdHJhaWxNYXQgPSByaWcuc2xhc2hUcmFpbC5tYXRlcmlhbCBhcyBUSFJFRS5NZXNoQmFzaWNNYXRlcmlhbDtcbiAgICAgICAgdHJhaWxNYXQub3BhY2l0eSA9IE1hdGguc2luKHAgKiBNYXRoLlBJKSAqIDAuOTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIGNhc2UgJ2F0dGFjazInOiB7XG4gICAgICAgIC8vIFJldmVyc2UgZGlhZ29uYWwgcmlzaW5nIHNsYXNoIGNvbWJvIDJcbiAgICAgICAgY29uc3QgcCA9IHJpZy5hbmltUHJvZ3Jlc3M7XG4gICAgICAgIHJpZy50b3Jzby5yb3RhdGlvbi55ID0gVEhSRUUuTWF0aFV0aWxzLmxlcnAoMC41LCAtMC42LCBwKTtcbiAgICAgICAgcmlnLnJpZ2h0QXJtLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMubGVycCgtMS40LCAtMC4zLCBwKTtcbiAgICAgICAgcmlnLnJpZ2h0QXJtLnJvdGF0aW9uLnkgPSBUSFJFRS5NYXRoVXRpbHMubGVycCgtMC45LCAwLjksIHApO1xuICAgICAgICByaWcucmlnaHRBcm0ucm90YXRpb24ueiA9IFRIUkVFLk1hdGhVdGlscy5sZXJwKC0wLjUsIDAuNCwgcCk7XG5cbiAgICAgICAgY29uc3QgdHJhaWxNYXQgPSByaWcuc2xhc2hUcmFpbC5tYXRlcmlhbCBhcyBUSFJFRS5NZXNoQmFzaWNNYXRlcmlhbDtcbiAgICAgICAgdHJhaWxNYXQub3BhY2l0eSA9IE1hdGguc2luKHAgKiBNYXRoLlBJKSAqIDAuOTU7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuXG4gICAgICBjYXNlICdhdHRhY2szJzoge1xuICAgICAgICAvLyBMZWFwaW5nIE92ZXJoZWFkIFNwaW4gU2xhbSBjb21ibyAzXG4gICAgICAgIGNvbnN0IHAgPSByaWcuYW5pbVByb2dyZXNzO1xuICAgICAgICByaWcudG9yc28ucG9zaXRpb24ueSA9IDAuOTUgKyBNYXRoLnNpbihwICogTWF0aC5QSSkgKiAwLjQ7XG4gICAgICAgIHJpZy50b3Jzby5yb3RhdGlvbi54ID0gVEhSRUUuTWF0aFV0aWxzLmxlcnAoLTAuMywgMC41LCBwKTtcbiAgICAgICAgcmlnLnJpZ2h0QXJtLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMubGVycCgtMi40LCAtMC40LCBwKTtcbiAgICAgICAgcmlnLnJpZ2h0QXJtLnJvdGF0aW9uLnkgPSAwO1xuICAgICAgICByaWcubGVmdEFybS5yb3RhdGlvbi54ID0gVEhSRUUuTWF0aFV0aWxzLmxlcnAoLTEuOCwgLTAuMiwgcCk7XG5cbiAgICAgICAgY29uc3QgdHJhaWxNYXQgPSByaWcuc2xhc2hUcmFpbC5tYXRlcmlhbCBhcyBUSFJFRS5NZXNoQmFzaWNNYXRlcmlhbDtcbiAgICAgICAgdHJhaWxNYXQub3BhY2l0eSA9IE1hdGguc2luKHAgKiBNYXRoLlBJKSAqIDEuMDtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIGNhc2UgJ2tpY2snOiB7XG4gICAgICAgIGNvbnN0IHAgPSByaWcuYW5pbVByb2dyZXNzO1xuICAgICAgICByaWcudG9yc28ucm90YXRpb24ueCA9IC0wLjI7XG4gICAgICAgIHJpZy5yaWdodExlZy5yb3RhdGlvbi54ID0gLU1hdGguc2luKHAgKiBNYXRoLlBJKSAqIDEuNDtcbiAgICAgICAgcmlnLnJpZ2h0Q2FsZi5yb3RhdGlvbi54ID0gLU1hdGguc2luKHAgKiBNYXRoLlBJKSAqIDAuMztcbiAgICAgICAgcmlnLmxlZnRMZWcucm90YXRpb24ueCA9IDAuMjtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIGNhc2UgJ2RvZGdlJzoge1xuICAgICAgICAvLyBOaW5qYSB0dW1ibGUgcm9sbFxuICAgICAgICBjb25zdCBwID0gcmlnLmFuaW1Qcm9ncmVzcztcbiAgICAgICAgcmlnLnRvcnNvLnBvc2l0aW9uLnkgPSAwLjQ1ICsgTWF0aC5zaW4ocCAqIE1hdGguUEkpICogMC4yO1xuICAgICAgICByaWcudG9yc28ucm90YXRpb24ueCA9IHAgKiBNYXRoLlBJICogMjtcbiAgICAgICAgcmlnLmxlZnRMZWcucm90YXRpb24ueCA9IC0wLjg7XG4gICAgICAgIHJpZy5yaWdodExlZy5yb3RhdGlvbi54ID0gLTAuODtcbiAgICAgICAgcmlnLmxlZnRBcm0ucm90YXRpb24ueCA9IC0xLjI7XG4gICAgICAgIHJpZy5yaWdodEFybS5yb3RhdGlvbi54ID0gLTEuMjtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIGNhc2UgJ2ZsaW5jaCc6IHtcbiAgICAgICAgY29uc3QgcCA9IHJpZy5hbmltUHJvZ3Jlc3M7XG4gICAgICAgIHJpZy50b3Jzby5wb3NpdGlvbi55ID0gMC45NTtcbiAgICAgICAgcmlnLnRvcnNvLnJvdGF0aW9uLnggPSAtTWF0aC5zaW4ocCAqIE1hdGguUEkpICogMC40O1xuICAgICAgICByaWcuaGVhZC5yb3RhdGlvbi54ID0gLU1hdGguc2luKHAgKiBNYXRoLlBJKSAqIDAuMztcbiAgICAgICAgcmlnLnJpZ2h0QXJtLnJvdGF0aW9uLnggPSAwLjU7XG4gICAgICAgIHJpZy5sZWZ0QXJtLnJvdGF0aW9uLnggPSAwLjU7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuXG4gICAgICBjYXNlICd2aWN0b3J5Jzoge1xuICAgICAgICAvLyBLYXRhbmEgaGVsZCBoaWdoIGluIHNhbHV0ZVxuICAgICAgICByaWcudG9yc28ucm90YXRpb24ueSA9IFRIUkVFLk1hdGhVdGlscy5kYW1wKHJpZy50b3Jzby5yb3RhdGlvbi55LCAwLCA1LCBkZWx0YSk7XG4gICAgICAgIHJpZy5yaWdodEFybS5yb3RhdGlvbi54ID0gVEhSRUUuTWF0aFV0aWxzLmRhbXAocmlnLnJpZ2h0QXJtLnJvdGF0aW9uLngsIC0yLjgsIDYsIGRlbHRhKTtcbiAgICAgICAgcmlnLnJpZ2h0QXJtLnJvdGF0aW9uLnogPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcucmlnaHRBcm0ucm90YXRpb24ueiwgMC4yLCA2LCBkZWx0YSk7XG4gICAgICAgIHJpZy5sZWZ0QXJtLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcubGVmdEFybS5yb3RhdGlvbi54LCAtMC4zLCA2LCBkZWx0YSk7XG4gICAgICAgIHJpZy5oZWFkLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcuaGVhZC5yb3RhdGlvbi54LCAtMC4yLCA2LCBkZWx0YSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuXG4gICAgICBjYXNlICdkZWFkJzoge1xuICAgICAgICAvLyBGYWxsZW4gd2FycmlvclxuICAgICAgICByaWcudG9yc28ucG9zaXRpb24ueSA9IFRIUkVFLk1hdGhVdGlscy5kYW1wKHJpZy50b3Jzby5wb3NpdGlvbi55LCAwLjIsIDQsIGRlbHRhKTtcbiAgICAgICAgcmlnLnRvcnNvLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcudG9yc28ucm90YXRpb24ueCwgTWF0aC5QSSAvIDIsIDQsIGRlbHRhKTtcbiAgICAgICAgcmlnLnJpZ2h0QXJtLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcucmlnaHRBcm0ucm90YXRpb24ueCwgMC44LCA0LCBkZWx0YSk7XG4gICAgICAgIHJpZy5sZWZ0QXJtLnJvdGF0aW9uLnggPSBUSFJFRS5NYXRoVXRpbHMuZGFtcChyaWcubGVmdEFybS5yb3RhdGlvbi54LCAwLjgsIDQsIGRlbHRhKTtcbiAgICAgICAgKHJpZy5zbGFzaFRyYWlsLm1hdGVyaWFsIGFzIFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKS5vcGFjaXR5ID0gMDtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXX0=