/**
* @license
* SPDX-License-Identifier: Apache-2.0
*/
import * as THREE from "/node_modules/.vite/deps/three.js?v=677b64f2";
import { RoomEnvironment } from "/node_modules/.vite/deps/three_examples_jsm_environments_RoomEnvironment__js.js?v=677b64f2";
import { CharacterFactory } from "/src/engine/CharacterModels.ts";
import { EnvironmentBuilder } from "/src/engine/EnvironmentBuilder.ts";
import { ParticleSystem } from "/src/engine/ParticleSystem.ts";
import { TextureGenerator } from "/src/engine/TextureGenerator.ts";
import { soundManager } from "/src/audio/SoundEffects.ts";
export class GameEngine {
	constructor(container, level, weapon, skin, initialCoins) {
		this.playerPos = new THREE.Vector3(0, 0, 0);
		this.playerVelocity = new THREE.Vector3(0, 0, 0);
		this.playerRotation = 0;
		this.isGrounded = true;
		this.isInvulnerable = false;
		this.invulnerabilityTimer = 0;
		this.stats = {
			maxHealth: 500,
			currentHealth: 500,
			maxEnergy: 100,
			currentEnergy: 50,
			coins: 0,
			selectedWeaponId: "",
			selectedSkinId: "",
			comboCount: 0,
			comboTimer: 0,
			kills: 0,
			specialCooldown: 0,
			specialMaxCooldown: 60
		};
		this.collectibles = [];
		this.nextCollectibleId = 1;
		this.currentComboStep = 0;
		this.comboWindowTimer = 0;
		this.attackTimer = 0;
		this.isAttacking = false;
		this.specialCooldown = 0;
		this.enemies = [];
		this.nextEnemyId = 1;
		this.bossSpawned = false;
		this.bossInstance = null;
		this.cameraAngleX = 0;
		this.cameraAngleY = .35;
		this.cameraDistance = 5.2;
		this.screenShake = 0;
		this.input = {
			moveX: 0,
			moveZ: 0,
			attack: false,
			heavyAttack: false,
			jump: false,
			dodge: false,
			special: false,
			cameraRotateX: 0,
			cameraRotateY: 0
		};
		this.clock = new THREE.Clock();
		this.animFrameId = 0;
		this.isRunning = false;
		this.isPaused = false;
		this.isSoftwareGl = false;
		this.tick = () => {
			if (!this.isRunning) return;
			const delta = Math.min(this.clock.getDelta(), .05);
			if (!this.isPaused) {
				this.updatePlayer(delta);
				this.updateEnemies(delta);
				this.updateProjectiles(delta);
				this.updateCollectibles(delta);
				this.updateCamera(delta);
				this.particles.update(delta, this.playerPos, this.camera);
			}
			this.renderer.render(this.scene, this.camera);
			if (this.isSoftwareGl) {
				this.afterDraw(this.tick);
			} else {
				this.animFrameId = requestAnimationFrame(this.tick);
			}
		};
		this.handleResize = () => {
			if (!this.container) return;
			const width = this.container.clientWidth;
			const height = this.container.clientHeight;
			this.camera.aspect = width / height;
			this.camera.updateProjectionMatrix();
			this.renderer.setSize(width, height);
		};
		this.container = container;
		this.currentLevel = level;
		this.currentWeapon = weapon;
		this.currentSkin = skin;
		this.stats.coins = initialCoins;
		// Detect software WebGL
		this.isSoftwareGl = (() => {
			const gl = document.createElement("canvas").getContext("webgl2");
			if (!gl) return true;
			const ext = gl.getExtension("WEBGL_debug_renderer_info");
			const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
			const gpu = String(gl.getParameter(param));
			gl.getExtension("WEBGL_lose_context")?.loseContext();
			return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
		})();
		// 1. Renderer Setup
		this.renderer = new THREE.WebGLRenderer({
			antialias: !this.isSoftwareGl,
			powerPreference: "high-performance"
		});
		this.renderer.outputColorSpace = THREE.SRGBColorSpace;
		this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
		this.renderer.toneMappingExposure = 1.15;
		this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
		this.renderer.shadowMap.enabled = !this.isSoftwareGl;
		this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
		this.renderer.setSize(container.clientWidth, container.clientHeight);
		container.appendChild(this.renderer.domElement);
		// 2. Scene & Fog Setup
		this.scene = new THREE.Scene();
		this.scene.background = new THREE.Color(level.skyColor);
		this.scene.fog = new THREE.FogExp2(level.fogColor, .022);
		// 3. Mandatory Studio Environment Reflection
		const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
		this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), .04).texture;
		pmremGenerator.dispose();
		// 4. Camera Setup
		this.camera = new THREE.PerspectiveCamera(55, container.clientWidth / container.clientHeight, .1, 150);
		// 5. Lighting Setup
		this.setupLighting();
		// 6. Build 3D World & Terrain
		this.buildWorld();
		// 7. Particle System
		this.particles = new ParticleSystem(this.scene);
		// 8. Player Rig
		this.playerRig = CharacterFactory.createNinjaPlayer(skin, weapon);
		this.scene.add(this.playerRig.root);
		this.playerPos.set(0, 0, 5);
		this.playerRig.root.position.copy(this.playerPos);
		// 9. Spawn Initial Enemies
		this.spawnInitialEnemies();
		// 10. Start Sound BGM
		soundManager.startBgm();
		// Resize Handler
		window.addEventListener("resize", this.handleResize);
		// Start Loop
		this.isRunning = true;
		this.tick();
	}
	setupLighting() {
		// Hemisphere fill
		const hemiLight = new THREE.HemisphereLight(this.currentLevel.lightColor, 1841431, .85);
		this.scene.add(hemiLight);
		// Key Directional Light with Shadows
		const keyLight = new THREE.DirectionalLight(this.currentLevel.lightColor, 1.8);
		keyLight.position.set(25, 35, 20);
		keyLight.castShadow = !this.isSoftwareGl;
		keyLight.shadow.mapSize.width = 1024;
		keyLight.shadow.mapSize.height = 1024;
		keyLight.shadow.camera.near = .5;
		keyLight.shadow.camera.far = 80;
		const d = 28;
		keyLight.shadow.camera.left = -d;
		keyLight.shadow.camera.right = d;
		keyLight.shadow.camera.top = d;
		keyLight.shadow.camera.bottom = -d;
		keyLight.shadow.bias = -5e-4;
		keyLight.shadow.normalBias = .02;
		this.scene.add(keyLight);
	}
	buildWorld() {
		const theme = this.currentLevel.environmentTheme;
		if (theme === "forest") {
			this.buildForestLevel();
		} else if (theme === "village") {
			this.buildVillageLevel();
		} else if (theme === "temple") {
			this.buildTempleLevel();
		} else if (theme === "fortress") {
			this.buildFortressLevel();
		} else if (theme === "arena") {
			this.buildArenaLevel();
		} else {
			this.buildForestLevel();
		}
	}
	// LEVEL 1: Sacred Cherry Blossom Forest
	buildForestLevel() {
		const groundGeo = new THREE.PlaneGeometry(160, 160, 16, 16);
		const groundMat = new THREE.MeshStandardMaterial({
			color: 1332013,
			roughness: .9
		});
		const ground = new THREE.Mesh(groundGeo, groundMat);
		ground.rotation.x = -Math.PI / 2;
		ground.receiveShadow = !this.isSoftwareGl;
		this.scene.add(ground);
		// Stone Path
		const pathGeo = new THREE.PlaneGeometry(6, 75);
		const pathMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getStonePavementTexture(),
			roughness: .8
		});
		const path = new THREE.Mesh(pathGeo, pathMat);
		path.rotation.x = -Math.PI / 2;
		path.position.set(0, .02, 0);
		this.scene.add(path);
		// Torii Gate Entrance
		const torii = EnvironmentBuilder.createToriiGate();
		torii.position.set(0, 0, 18);
		this.scene.add(torii);
		// Master Ryu's Training Pagoda
		const dojo = EnvironmentBuilder.createPagoda(2);
		dojo.position.set(0, 0, -32);
		this.scene.add(dojo);
		// Lush Sakura Blossom Grove
		const sakuraTrees = [
			[
				-9,
				0,
				14
			],
			[
				9,
				0,
				14
			],
			[
				-12,
				0,
				4
			],
			[
				12,
				0,
				2
			],
			[
				-10,
				0,
				-8
			],
			[
				11,
				0,
				-10
			],
			[
				-8,
				0,
				-22
			],
			[
				8,
				0,
				-22
			],
			[
				-16,
				0,
				20
			],
			[
				16,
				0,
				22
			],
			[
				-18,
				0,
				-18
			],
			[
				18,
				0,
				-16
			]
		];
		sakuraTrees.forEach((p) => {
			const tree = EnvironmentBuilder.createSakuraTree();
			tree.position.set(p[0], p[1], p[2]);
			const s = .85 + Math.random() * .35;
			tree.scale.set(s, s, s);
			tree.rotation.y = Math.random() * Math.PI * 2;
			this.scene.add(tree);
		});
		// Stone Lanterns
		[
			-4,
			8,
			-16
		].forEach((z) => {
			const l1 = EnvironmentBuilder.createStoneLantern(!this.isSoftwareGl);
			l1.group.position.set(-4, 0, z);
			const l2 = EnvironmentBuilder.createStoneLantern(!this.isSoftwareGl);
			l2.group.position.set(4, 0, z);
			this.scene.add(l1.group, l2.group);
		});
		this.buildPerimeterMountains(1981023);
	}
	// LEVEL 2: Burning Enemy Village
	buildVillageLevel() {
		const groundGeo = new THREE.PlaneGeometry(160, 160, 16, 16);
		const groundMat = new THREE.MeshStandardMaterial({
			color: 4005905,
			roughness: .95
		});
		const ground = new THREE.Mesh(groundGeo, groundMat);
		ground.rotation.x = -Math.PI / 2;
		ground.receiveShadow = !this.isSoftwareGl;
		this.scene.add(ground);
		// Village Dirt Road
		const roadGeo = new THREE.PlaneGeometry(8, 80);
		const roadMat = new THREE.MeshStandardMaterial({
			color: 2232841,
			roughness: .9
		});
		const road = new THREE.Mesh(roadGeo, roadMat);
		road.rotation.x = -Math.PI / 2;
		road.position.set(0, .02, 0);
		this.scene.add(road);
		// Thatched Village Huts (Minka)
		const hutPositions = [
			[
				-10,
				0,
				8
			],
			[
				10,
				0,
				6
			],
			[
				-11,
				0,
				-12
			],
			[
				11,
				0,
				-10
			]
		];
		hutPositions.forEach((p) => {
			const hut = EnvironmentBuilder.createVillageHut();
			hut.position.set(p[0], p[1], p[2]);
			hut.rotation.y = Math.random() * .4 - .2;
			this.scene.add(hut);
		});
		// Flaming Bonfires & Enemy Tents
		const camps = [{
			t: new THREE.Vector3(-6, 0, -2),
			f: new THREE.Vector3(-4, 0, 0)
		}, {
			t: new THREE.Vector3(6, 0, -18),
			f: new THREE.Vector3(4, 0, -16)
		}];
		camps.forEach((c) => {
			const tent = EnvironmentBuilder.createEnemyTent();
			tent.position.copy(c.t);
			const fire = EnvironmentBuilder.createCampfire();
			fire.group.position.copy(c.f);
			this.scene.add(tent, fire.group);
		});
		// 2 Village Lookout Watchtowers
		const tower1 = EnvironmentBuilder.createWatchtower();
		tower1.position.set(-8, 0, 16);
		const tower2 = EnvironmentBuilder.createWatchtower();
		tower2.position.set(8, 0, -26);
		this.scene.add(tower1, tower2);
		// Wooden Arched Bridge across a trench
		const bridge = EnvironmentBuilder.createArchedBridge(10, 3.5);
		bridge.position.set(0, 0, 2);
		this.scene.add(bridge);
		// Spiked Barricades
		const bar1 = EnvironmentBuilder.createSpikedBarricade();
		bar1.position.set(-6, 0, 14);
		const bar2 = EnvironmentBuilder.createSpikedBarricade();
		bar2.position.set(6, 0, 14);
		this.scene.add(bar1, bar2);
		// Weathered Pines
		[
			[
				-16,
				0,
				0
			],
			[
				16,
				0,
				-4
			],
			[
				-14,
				0,
				-28
			],
			[
				15,
				0,
				20
			]
		].forEach((p) => {
			const pine = EnvironmentBuilder.createPineTree();
			pine.position.set(p[0], p[1], p[2]);
			this.scene.add(pine);
		});
		this.buildPerimeterMountains(4528643);
	}
	// LEVEL 3: Cursed Midnight Pagoda Temple
	buildTempleLevel() {
		const groundGeo = new THREE.PlaneGeometry(160, 160, 16, 16);
		const groundMat = new THREE.MeshStandardMaterial({
			color: 593174,
			roughness: .8
		});
		const ground = new THREE.Mesh(groundGeo, groundMat);
		ground.rotation.x = -Math.PI / 2;
		ground.receiveShadow = !this.isSoftwareGl;
		this.scene.add(ground);
		// Dark slate temple courtyard
		const courtGeo = new THREE.PlaneGeometry(28, 70);
		const courtMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getStonePavementTexture(),
			roughness: .7,
			color: 6583435
		});
		const court = new THREE.Mesh(courtGeo, courtMat);
		court.rotation.x = -Math.PI / 2;
		court.position.set(0, .02, -5);
		this.scene.add(court);
		// Giant 4-Tier Dark Pagoda at the center
		const pagoda = EnvironmentBuilder.createPagoda(4);
		pagoda.position.set(0, 0, -32);
		this.scene.add(pagoda);
		// Stone Dragon Statues guarding entrance
		const dragon1 = EnvironmentBuilder.createDragonStatue();
		dragon1.position.set(-4.5, 0, -18);
		dragon1.rotation.y = .3;
		const dragon2 = EnvironmentBuilder.createDragonStatue();
		dragon2.position.set(4.5, 0, -18);
		dragon2.rotation.y = -.3;
		this.scene.add(dragon1, dragon2);
		// Row of 8 Cyan Spirit Lanterns
		[
			-24,
			-14,
			-4,
			6,
			16
		].forEach((z) => {
			const l1 = EnvironmentBuilder.createStoneLantern(!this.isSoftwareGl);
			l1.group.position.set(-6, 0, z);
			if (l1.light) l1.light.color.setHex(440020);
			const l2 = EnvironmentBuilder.createStoneLantern(!this.isSoftwareGl);
			l2.group.position.set(6, 0, z);
			if (l2.light) l2.light.color.setHex(440020);
			this.scene.add(l1.group, l2.group);
		});
		// Dark Torii Gate
		const torii = EnvironmentBuilder.createToriiGate();
		torii.position.set(0, 0, 18);
		this.scene.add(torii);
		// Eerie Black Pines
		[
			[
				-14,
				0,
				10
			],
			[
				14,
				0,
				12
			],
			[
				-16,
				0,
				-10
			],
			[
				16,
				0,
				-8
			],
			[
				-12,
				0,
				-28
			],
			[
				12,
				0,
				-28
			]
		].forEach((p) => {
			const pine = EnvironmentBuilder.createPineTree();
			pine.position.set(p[0], p[1], p[2]);
			this.scene.add(pine);
		});
		this.buildPerimeterMountains(132631);
	}
	// LEVEL 4: Iron Dragon Citadel / Mountain Fortress
	buildFortressLevel() {
		const groundGeo = new THREE.PlaneGeometry(160, 160, 16, 16);
		const groundMat = new THREE.MeshStandardMaterial({
			color: 1579035,
			roughness: .9
		});
		const ground = new THREE.Mesh(groundGeo, groundMat);
		ground.rotation.x = -Math.PI / 2;
		ground.receiveShadow = !this.isSoftwareGl;
		this.scene.add(ground);
		// Fortress Paved Road
		const roadGeo = new THREE.PlaneGeometry(10, 80);
		const roadMat = new THREE.MeshStandardMaterial({
			map: TextureGenerator.getStonePavementTexture(),
			roughness: .75
		});
		const road = new THREE.Mesh(roadGeo, roadMat);
		road.rotation.x = -Math.PI / 2;
		road.position.set(0, .02, 0);
		this.scene.add(road);
		// 3 Watchtowers
		const t1 = EnvironmentBuilder.createWatchtower();
		t1.position.set(-10, 0, 10);
		const t2 = EnvironmentBuilder.createWatchtower();
		t2.position.set(10, 0, 8);
		const t3 = EnvironmentBuilder.createWatchtower();
		t3.position.set(0, 0, -32);
		this.scene.add(t1, t2, t3);
		// Defensive Spiked Barricades
		[
			-4,
			12,
			-20
		].forEach((z) => {
			const b1 = EnvironmentBuilder.createSpikedBarricade();
			b1.position.set(-7, 0, z);
			const b2 = EnvironmentBuilder.createSpikedBarricade();
			b2.position.set(7, 0, z);
			this.scene.add(b1, b2);
		});
		// 4 Iron Fire Braziers
		[
			-10,
			4,
			-18,
			-26
		].forEach((z) => {
			const brz = EnvironmentBuilder.createBrazier(16096779);
			brz.group.position.set(z % 2 === 0 ? -5 : 5, 0, z);
			this.scene.add(brz.group);
		});
		// Fortress suspension bridge
		const bridge = EnvironmentBuilder.createArchedBridge(12, 4);
		bridge.position.set(0, 0, -8);
		this.scene.add(bridge);
		// War Tents
		const tent1 = EnvironmentBuilder.createEnemyTent();
		tent1.position.set(-12, 0, -18);
		const tent2 = EnvironmentBuilder.createEnemyTent();
		tent2.position.set(12, 0, -18);
		this.scene.add(tent1, tent2);
		this.buildPerimeterMountains(2696484);
	}
	// LEVEL 5: Blood Moon Final Boss Arena
	buildArenaLevel() {
		// Floating Obsidian Altar Platform
		const arenaGeo = new THREE.CylinderGeometry(28, 30, 2.5, 24);
		const obsMat = new THREE.MeshStandardMaterial({
			color: 592139,
			metalness: .85,
			roughness: .2
		});
		const arena = new THREE.Mesh(arenaGeo, obsMat);
		arena.position.set(0, -1.25, -6);
		arena.receiveShadow = !this.isSoftwareGl;
		this.scene.add(arena);
		// Inner Runed Duel Ring
		const ringGeo = new THREE.RingGeometry(8, 8.5, 32);
		const ringMat = new THREE.MeshBasicMaterial({
			color: 15680580,
			side: THREE.DoubleSide
		});
		const ring = new THREE.Mesh(ringGeo, ringMat);
		ring.rotation.x = -Math.PI / 2;
		ring.position.set(0, .05, -6);
		this.scene.add(ring);
		// Volcanic Obsidian Monolith Spikes
		for (let i = 0; i < 8; i++) {
			const angle = i * Math.PI * 2 / 8;
			const mono = EnvironmentBuilder.createObsidianMonolith();
			mono.position.set(Math.cos(angle) * 24, 0, Math.sin(angle) * 24 - 6);
			mono.rotation.y = angle;
			this.scene.add(mono);
		}
		// 4 Demonic Blood-Red Braziers
		for (let b = 0; b < 4; b++) {
			const angle = b * Math.PI * 2 / 4 + Math.PI / 4;
			const brz = EnvironmentBuilder.createBrazier(14427686);
			brz.group.position.set(Math.cos(angle) * 14, 0, Math.sin(angle) * 14 - 6);
			this.scene.add(brz.group);
		}
		// Broken Ancient Torii Pillars
		const torii = EnvironmentBuilder.createToriiGate();
		torii.position.set(0, 0, 14);
		torii.rotation.z = .08;
		this.scene.add(torii);
		// Bottomless void backdrop: Jagged volcanic crags
		this.buildPerimeterMountains(4524554);
	}
	buildPerimeterMountains(color) {
		const rockMat = new THREE.MeshStandardMaterial({
			color,
			roughness: .9
		});
		for (let r = 0; r < 24; r++) {
			const angle = r * Math.PI * 2 / 24;
			const dist = 52 + Math.random() * 8;
			const mountainGeo = new THREE.ConeGeometry(8 + Math.random() * 6, 22 + Math.random() * 10, 5);
			const mountain = new THREE.Mesh(mountainGeo, rockMat);
			mountain.position.set(Math.cos(angle) * dist, 8, Math.sin(angle) * dist);
			mountain.scale.set(1 + Math.random() * .5, 1, 1 + Math.random() * .5);
			this.scene.add(mountain);
		}
	}
	// LEVEL-SPECIFIC ENEMY SPAWNING WITH SCALING DIFFICULTY
	spawnInitialEnemies() {
		const lvl = this.currentLevel.id;
		if (lvl === 1) {
			// Level 1: 6 Enemies (Ashigaru recruits + 2 light ninjas)
			const spawns = [
				{
					type: "normal",
					pos: new THREE.Vector3(-4, 0, 8)
				},
				{
					type: "normal",
					pos: new THREE.Vector3(4, 0, 8)
				},
				{
					type: "normal",
					pos: new THREE.Vector3(-6, 0, -4)
				},
				{
					type: "normal",
					pos: new THREE.Vector3(6, 0, -4)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(-5, 0, -16)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(5, 0, -18)
				}
			];
			spawns.forEach((s) => this.spawnEnemy(s.type, s.pos));
		} else if (lvl === 2) {
			// Level 2: 8 Enemies (Raiders + Agile dual-dagger ninjas + torch heavy)
			const spawns = [
				{
					type: "normal",
					pos: new THREE.Vector3(-5, 0, 10)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(5, 0, 10)
				},
				{
					type: "normal",
					pos: new THREE.Vector3(-7, 0, -2)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(7, 0, -2)
				},
				{
					type: "heavy",
					pos: new THREE.Vector3(0, 0, -10)
				},
				{
					type: "normal",
					pos: new THREE.Vector3(-6, 0, -18)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(6, 0, -18)
				},
				{
					type: "normal",
					pos: new THREE.Vector3(0, 0, -24)
				}
			];
			spawns.forEach((s) => this.spawnEnemy(s.type, s.pos));
		} else if (lvl === 3) {
			// Level 3: 10 Enemies (Temple Ninjas + Marksman Archers)
			const spawns = [
				{
					type: "fast",
					pos: new THREE.Vector3(-5, 0, 8)
				},
				{
					type: "archer",
					pos: new THREE.Vector3(8, 0, 8)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(-8, 0, 0)
				},
				{
					type: "normal",
					pos: new THREE.Vector3(0, 0, -4)
				},
				{
					type: "archer",
					pos: new THREE.Vector3(-9, 0, -12)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(6, 0, -12)
				},
				{
					type: "archer",
					pos: new THREE.Vector3(8, 0, -20)
				},
				{
					type: "normal",
					pos: new THREE.Vector3(-4, 0, -22)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(4, 0, -24)
				},
				{
					type: "archer",
					pos: new THREE.Vector3(0, 0, -28)
				}
			];
			spawns.forEach((s) => this.spawnEnemy(s.type, s.pos));
		} else if (lvl === 4) {
			// Level 4: 12 Enemies (Heavy Armored Samurai + Archers + Ninjas)
			const spawns = [
				{
					type: "heavy",
					pos: new THREE.Vector3(-6, 0, 10)
				},
				{
					type: "archer",
					pos: new THREE.Vector3(8, 0, 10)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(-7, 0, 2)
				},
				{
					type: "heavy",
					pos: new THREE.Vector3(6, 0, 0)
				},
				{
					type: "archer",
					pos: new THREE.Vector3(-9, 0, -8)
				},
				{
					type: "normal",
					pos: new THREE.Vector3(8, 0, -8)
				},
				{
					type: "heavy",
					pos: new THREE.Vector3(-5, 0, -16)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(5, 0, -16)
				},
				{
					type: "heavy",
					pos: new THREE.Vector3(0, 0, -22)
				},
				{
					type: "archer",
					pos: new THREE.Vector3(-8, 0, -24)
				},
				{
					type: "heavy",
					pos: new THREE.Vector3(8, 0, -26)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(0, 0, -28)
				}
			];
			spawns.forEach((s) => this.spawnEnemy(s.type, s.pos));
		} else {
			// Level 5: 14 Enemies (Elite Blood Samurai, Executioners, Void Assassins)
			const spawns = [
				{
					type: "fast",
					pos: new THREE.Vector3(-6, 0, 6)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(6, 0, 6)
				},
				{
					type: "heavy",
					pos: new THREE.Vector3(-8, 0, 0)
				},
				{
					type: "heavy",
					pos: new THREE.Vector3(8, 0, 0)
				},
				{
					type: "normal",
					pos: new THREE.Vector3(0, 0, -4)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(-9, 0, -10)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(9, 0, -10)
				},
				{
					type: "heavy",
					pos: new THREE.Vector3(-6, 0, -16)
				},
				{
					type: "heavy",
					pos: new THREE.Vector3(6, 0, -16)
				},
				{
					type: "archer",
					pos: new THREE.Vector3(-8, 0, -20)
				},
				{
					type: "archer",
					pos: new THREE.Vector3(8, 0, -20)
				},
				{
					type: "heavy",
					pos: new THREE.Vector3(0, 0, -22)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(-5, 0, -25)
				},
				{
					type: "fast",
					pos: new THREE.Vector3(5, 0, -25)
				}
			];
			spawns.forEach((s) => this.spawnEnemy(s.type, s.pos));
		}
		// In each level, only 1 or 2 enemies have the Power Badge ("power ka nishan") over their heads!
		// Defeating only these specific marked enemies will drop collectible power!
		const powerIndices = lvl <= 2 ? [1] : [2, Math.min(5, this.enemies.length - 1)];
		powerIndices.forEach((idx) => {
			const enemy = this.enemies[idx];
			if (enemy && !enemy.isBoss) {
				enemy.hasPowerCarrierBadge = true;
				enemy.powerBadgeMesh = this.createPowerCarrierBadge();
				enemy.powerBadgeMesh.position.set(enemy.rig.root.position.x, enemy.rig.root.position.y + 2.3, enemy.rig.root.position.z);
				this.scene.add(enemy.powerBadgeMesh);
			}
		});
	}
	spawnEnemy(type, pos, isBoss = false) {
		const lvl = this.currentLevel.id;
		// Increasing difficulty multiplier per level (Lvl 1: 1.0x, Lvl 2: 1.25x, Lvl 3: 1.5x, Lvl 4: 1.8x, Lvl 5: 2.2x)
		const diffMultiplier = 1 + (lvl - 1) * .28;
		const rig = CharacterFactory.createEnemy(type, isBoss, this.currentLevel.environmentTheme === "arena" ? "raiden" : undefined);
		this.scene.add(rig.root);
		rig.root.position.copy(pos);
		let baseHealth = 65;
		let basePower = 9;
		let speed = 4;
		let range = 2;
		if (type === "fast") {
			baseHealth = 55;
			basePower = 11;
			speed = 5.8 + lvl * .2;
			range = 1.9;
		} else if (type === "heavy") {
			baseHealth = 135;
			basePower = 20;
			speed = 2.8 + lvl * .15;
			range = 2.4;
		} else if (type === "archer") {
			baseHealth = 60;
			basePower = 15;
			speed = 3.8;
			range = 16;
		} else if (isBoss) {
			baseHealth = 320 + lvl * 180;
			basePower = 18 + lvl * 6;
			speed = 4.8 + lvl * .25;
			range = 2.6;
		}
		const finalHealth = Math.round(baseHealth * diffMultiplier);
		const finalPower = Math.round(basePower * diffMultiplier);
		const enemy = {
			id: this.nextEnemyId++,
			type,
			name: isBoss ? this.currentLevel.bossName : `Enemy ${type.toUpperCase()}`,
			isBoss,
			rig,
			health: finalHealth,
			maxHealth: finalHealth,
			attackPower: finalPower,
			speed,
			range,
			state: "idle",
			stateTimer: Math.random() * 2,
			attackCooldown: 1.8,
			attackWindup: 0,
			patrolPoint: pos.clone(),
			targetPos: pos.clone(),
			dissolveTimer: 0
		};
		this.enemies.push(enemy);
		if (isBoss) {
			this.bossInstance = enemy;
			if (this.onBossHealthUpdate) {
				this.onBossHealthUpdate(enemy.health, enemy.maxHealth, enemy.name);
			}
		}
		return enemy;
	}
	// --- Input Handlers ---
	updateInput(newInput) {
		Object.assign(this.input, newInput);
		if (newInput.attack) {
			this.triggerAttack();
		}
		if (newInput.heavyAttack) {
			this.triggerHeavyKick();
		}
		if (newInput.jump) {
			this.triggerJump();
		}
		if (newInput.dodge) {
			this.triggerDodge();
		}
		if (newInput.special) {
			this.triggerSpecialPower();
		}
	}
	triggerAttack() {
		if (this.isAttacking || !this.isGrounded) return;
		this.isAttacking = true;
		this.currentComboStep = this.currentComboStep % 3 + 1;
		this.comboWindowTimer = 1.2;
		this.attackTimer = 0;
		const animName = `attack${this.currentComboStep}`;
		this.playerRig.currentAnim = animName;
		this.playerRig.animProgress = 0;
		// Sound
		soundManager.playSwordSlash(this.currentComboStep);
		// Small forward lunge
		const forward = new THREE.Vector3(Math.sin(this.playerRotation), 0, Math.cos(this.playerRotation));
		this.playerVelocity.addScaledVector(forward, 4.5);
		// Hit detection halfway through attack animation
		setTimeout(() => {
			this.performPlayerAttackHitcheck(this.currentComboStep);
		}, 120);
		// Reset attack state when animation completes
		setTimeout(() => {
			this.isAttacking = false;
			if (this.playerRig.currentAnim.startsWith("attack")) {
				this.playerRig.currentAnim = "idle";
			}
		}, 320 / this.currentWeapon.speed);
	}
	triggerHeavyKick() {
		if (this.isAttacking || !this.isGrounded) return;
		this.isAttacking = true;
		this.playerRig.currentAnim = "kick";
		this.playerRig.animProgress = 0;
		soundManager.playHeavyImpact();
		setTimeout(() => {
			this.performHeavyKickHitcheck();
		}, 140);
		setTimeout(() => {
			this.isAttacking = false;
			this.playerRig.currentAnim = "idle";
		}, 400);
	}
	triggerJump() {
		if (!this.isGrounded || this.isAttacking) return;
		this.isGrounded = false;
		this.playerVelocity.y = 8.8;
		this.playerRig.currentAnim = "jump";
	}
	triggerDodge() {
		if (this.isInvulnerable || this.isAttacking) return;
		this.isInvulnerable = true;
		this.invulnerabilityTimer = .45;
		this.playerRig.currentAnim = "dodge";
		this.playerRig.animProgress = 0;
		soundManager.playDodgeRoll();
		this.particles.spawnSmokePuff(this.playerPos, 6583435, 8);
		// Dash burst forward
		const forward = new THREE.Vector3(Math.sin(this.playerRotation), 0, Math.cos(this.playerRotation));
		this.playerVelocity.copy(forward.multiplyScalar(14));
		setTimeout(() => {
			this.playerRig.currentAnim = "idle";
		}, 450);
	}
	triggerSpecialPower() {
		if (this.stats.specialCooldown > 0 || this.isAttacking) return;
		// 1-minute (60 seconds) cooldown timer
		this.stats.specialCooldown = 60;
		this.notifyStats();
		this.isAttacking = true;
		this.playerRig.currentAnim = "attack3";
		this.playerRig.animProgress = 0;
		soundManager.playSpecialBlast();
		const forward = new THREE.Vector3(Math.sin(this.playerRotation), 0, Math.cos(this.playerRotation));
		this.particles.spawnSpecialEnergyWave(this.playerPos, forward, this.currentWeapon.trailColor, this.currentWeapon.damage * 2.8);
		this.particles.spawnHitSparks(this.playerPos, 3718648, 20);
		this.screenShake = .5;
		setTimeout(() => {
			this.isAttacking = false;
			this.playerRig.currentAnim = "idle";
		}, 500);
	}
	// --- Hit Detection & Combat Logic ---
	performPlayerAttackHitcheck(comboStep) {
		const attackRange = this.currentWeapon.range + (comboStep === 3 ? .6 : 0);
		const forward = new THREE.Vector3(Math.sin(this.playerRotation), 0, Math.cos(this.playerRotation));
		let hitAny = false;
		this.enemies.forEach((enemy) => {
			if (enemy.health <= 0) return;
			const toEnemy = enemy.rig.root.position.clone().sub(this.playerPos);
			const dist = toEnemy.length();
			if (dist <= attackRange) {
				toEnemy.normalize();
				const dot = forward.dot(toEnemy);
				// Within 140 degree forward cone
				if (dot > .25) {
					hitAny = true;
					this.applyDamageToEnemy(enemy, comboStep);
				}
			}
		});
		if (hitAny) {
			soundManager.playSwordClash();
			this.screenShake = Math.max(this.screenShake, .25);
		}
	}
	performHeavyKickHitcheck() {
		const forward = new THREE.Vector3(Math.sin(this.playerRotation), 0, Math.cos(this.playerRotation));
		this.enemies.forEach((enemy) => {
			if (enemy.health <= 0) return;
			const toEnemy = enemy.rig.root.position.clone().sub(this.playerPos);
			const dist = toEnemy.length();
			if (dist <= 2.5 && forward.dot(toEnemy.normalize()) > .4) {
				// Heavy Kick deals blunt damage and knocks enemies back hard
				const damage = 35 + (this.currentSkin.defenseBonus > .2 ? 15 : 0);
				this.damageEnemyDirect(enemy, damage, true, 8);
				soundManager.playHeavyImpact();
				this.screenShake = .35;
			}
		});
	}
	applyDamageToEnemy(enemy, comboStep) {
		let baseDmg = this.currentWeapon.damage * (.85 + comboStep * .25);
		const isCrit = Math.random() < this.currentWeapon.critChance;
		if (isCrit) {
			baseDmg *= 1.8;
		}
		const knockback = comboStep === 3 ? 6 : 2.5;
		this.damageEnemyDirect(enemy, Math.round(baseDmg), isCrit, knockback);
		// Increase Chi energy on hit
		this.stats.currentEnergy = Math.min(this.stats.maxEnergy, this.stats.currentEnergy + (this.currentWeapon.id === "katana_sakura" ? 30 : 20));
		// Increment combo
		this.stats.comboCount++;
		this.stats.comboTimer = 2.5;
		this.notifyStats();
	}
	damageEnemyDirect(enemy, damage, isCrit, knockbackPower) {
		enemy.health = Math.max(0, enemy.health - damage);
		// Recoil / Flinch
		if (enemy.health > 0) {
			enemy.rig.currentAnim = "flinch";
			enemy.rig.animProgress = 0;
			setTimeout(() => {
				if (enemy.health > 0 && enemy.rig.currentAnim === "flinch") {
					enemy.rig.currentAnim = "idle";
				}
			}, 300);
		}
		// Knockback
		const knockDir = enemy.rig.root.position.clone().sub(this.playerPos).normalize();
		knockDir.y = 0;
		enemy.rig.root.position.addScaledVector(knockDir, knockbackPower * .15);
		// Sparks & Blood VFX
		this.particles.spawnHitSparks(enemy.rig.root.position, isCrit ? 16711748 : 16347926, isCrit ? 16 : 8);
		// Emit Floating Damage Text
		this.emitFloatingDamage(enemy.rig.root.position, `${isCrit ? "CRIT! " : ""}-${damage}`, isCrit ? "#ef4444" : "#fbbf24", isCrit);
		// Update Boss UI if boss
		if (enemy.isBoss && this.onBossHealthUpdate) {
			this.onBossHealthUpdate(enemy.health, enemy.maxHealth, enemy.name);
		}
		// Check Death
		if (enemy.health <= 0 && enemy.state !== "dead") {
			this.handleEnemyDeath(enemy);
		}
	}
	handleEnemyDeath(enemy) {
		enemy.state = "dead";
		enemy.rig.currentAnim = "dead";
		enemy.dissolveTimer = 2;
		soundManager.playCoin();
		this.particles.spawnSmokePuff(enemy.rig.root.position, 1976635, 12);
		const coinReward = enemy.isBoss ? 200 : enemy.type === "heavy" ? 45 : 25;
		this.stats.coins += coinReward;
		this.stats.kills++;
		this.notifyStats();
		// If this enemy was marked with the Power Badge ("power ka nishan"), drop the power collect item!
		if (enemy.hasPowerCarrierBadge) {
			if (enemy.powerBadgeMesh) {
				this.scene.remove(enemy.powerBadgeMesh);
				enemy.powerBadgeMesh = undefined;
			}
			this.spawnHealthPickup(enemy.rig.root.position, 120);
			this.emitFloatingDamage(enemy.rig.root.position, "★ POWER ORB DROPPED! ★", "#10b981", true);
		}
		// Check Boss Spawning condition
		if (!this.bossSpawned && this.stats.kills >= this.currentLevel.targetKills) {
			this.spawnBoss();
		}
		// Check Victory condition (Boss slain)
		if (enemy.isBoss) {
			this.handleVictory();
		}
	}
	/**
	* Creates a floating 3D "Power Ka Nishan" (Power Indicator Badge)
	* that hovers over the 1 or 2 designated power-carrier enemies in each level.
	*/
	createPowerCarrierBadge() {
		const group = new THREE.Group();
		// 1. Glowing 3D Emerald Diamond / Crystal
		const crystalGeo = new THREE.OctahedronGeometry(.32, 0);
		const crystalMat = new THREE.MeshStandardMaterial({
			color: 1096065,
			emissive: 366185,
			emissiveIntensity: 1.4,
			metalness: .1,
			roughness: .2
		});
		const crystal = new THREE.Mesh(crystalGeo, crystalMat);
		crystal.scale.set(.8, 1.4, .8);
		crystal.name = "badge_crystal";
		group.add(crystal);
		// 2. Glowing White Cross Symbol (Medical/Health/Power Sign)
		const crossHGeo = new THREE.BoxGeometry(.48, .13, .13);
		const crossVGeo = new THREE.BoxGeometry(.13, .48, .13);
		const crossMat = new THREE.MeshBasicMaterial({ color: 16777215 });
		const crossH = new THREE.Mesh(crossHGeo, crossMat);
		const crossV = new THREE.Mesh(crossVGeo, crossMat);
		group.add(crossH);
		group.add(crossV);
		// 3. Orbiting Gold Ring
		const ringGeo = new THREE.TorusGeometry(.5, .035, 8, 20);
		const ringMat = new THREE.MeshBasicMaterial({
			color: 16436245,
			wireframe: true
		});
		const ring = new THREE.Mesh(ringGeo, ringMat);
		ring.rotation.x = Math.PI / 2.5;
		ring.name = "badge_ring";
		group.add(ring);
		// 4. Floating Sprite Label: "✚ POWER ✚"
		const canvas = document.createElement("canvas");
		canvas.width = 256;
		canvas.height = 64;
		const ctx = canvas.getContext("2d");
		if (ctx) {
			ctx.fillStyle = "rgba(6, 78, 59, 0.85)";
			ctx.fillRect(8, 8, 240, 48);
			ctx.lineWidth = 4;
			ctx.strokeStyle = "#10b981";
			ctx.strokeRect(8, 8, 240, 48);
			ctx.fillStyle = "#6ee7b7";
			ctx.font = "bold 24px sans-serif";
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillText("✚ POWER ✚", 128, 32);
		}
		const texture = new THREE.CanvasTexture(canvas);
		const spriteMat = new THREE.SpriteMaterial({
			map: texture,
			transparent: true,
			depthTest: false
		});
		const sprite = new THREE.Sprite(spriteMat);
		sprite.scale.set(1.4, .35, 1);
		sprite.position.y = .55;
		sprite.name = "badge_sprite";
		group.add(sprite);
		// 5. Soft emerald point light so the enemy is highlighted across the level
		const light = new THREE.PointLight(1096065, 1.8, 6);
		light.position.set(0, 0, 0);
		group.add(light);
		return group;
	}
	/**
	* Spawns a floating collectible Health/Power Orb at given position
	*/
	spawnHealthPickup(pos, healAmount) {
		const group = new THREE.Group();
		// Glowing Emerald Jade Health Core
		const coreGeo = new THREE.DodecahedronGeometry(.35, 1);
		const coreMat = new THREE.MeshStandardMaterial({
			color: 1096065,
			emissive: 366185,
			emissiveIntensity: .9,
			metalness: .2,
			roughness: .2
		});
		const coreMesh = new THREE.Mesh(coreGeo, coreMat);
		group.add(coreMesh);
		// Orbiting Golden / Celestial Ring
		const ringGeo = new THREE.TorusGeometry(.52, .04, 8, 20);
		const ringMat = new THREE.MeshBasicMaterial({
			color: 16436245,
			wireframe: true
		});
		const ringMesh = new THREE.Mesh(ringGeo, ringMat);
		ringMesh.rotation.x = Math.PI / 3;
		group.add(ringMesh);
		// Soft emerald point light aura
		const light = new THREE.PointLight(1096065, 2, 7);
		light.position.set(0, 0, 0);
		group.add(light);
		// Float 0.85m above ground
		const spawnPos = pos.clone();
		spawnPos.y = .85;
		group.position.copy(spawnPos);
		this.scene.add(group);
		this.collectibles.push({
			id: this.nextCollectibleId++,
			mesh: group,
			healAmount,
			position: spawnPos,
			baseY: .85,
			bobTime: Math.random() * Math.PI
		});
	}
	spawnBoss() {
		this.bossSpawned = true;
		soundManager.playBossRoar?.();
		const bossPos = new THREE.Vector3(0, 0, -28);
		this.spawnEnemy("boss", bossPos, true);
		this.screenShake = .6;
	}
	handleVictory() {
		soundManager.playVictoryGong();
		this.playerRig.currentAnim = "victory";
		// Calculate stars
		let stars = 1;
		if (this.stats.currentHealth > 50) stars = 2;
		if (this.stats.currentHealth > 75 && this.stats.comboCount >= 8) stars = 3;
		setTimeout(() => {
			if (this.onVictory) {
				this.onVictory(this.currentLevel.rewardCoins, stars);
			}
		}, 1500);
	}
	damagePlayer(damage, attackerPos) {
		if (this.isInvulnerable || this.stats.currentHealth <= 0) return;
		// Post-hit invulnerability window (0.55s)
		this.isInvulnerable = true;
		this.invulnerabilityTimer = .55;
		// Balanced incoming damage for 500 HP: power depletes at an active combat pace
		const finalDamage = Math.max(16, Math.round(damage * 1.65 * (1 - this.currentSkin.defenseBonus)));
		this.stats.currentHealth = Math.max(0, this.stats.currentHealth - finalDamage);
		// Hit flinch
		this.playerRig.currentAnim = "flinch";
		this.playerRig.animProgress = 0;
		soundManager.playHeavyImpact();
		this.screenShake = .4;
		this.particles.spawnHitSparks(this.playerPos, 14427686, 12);
		this.emitFloatingDamage(this.playerPos, `-${finalDamage}`, "#ef4444", false);
		// Knockback
		const knockDir = this.playerPos.clone().sub(attackerPos).normalize();
		knockDir.y = 0;
		this.playerVelocity.addScaledVector(knockDir, 6);
		this.notifyStats();
		if (this.stats.currentHealth <= 0) {
			this.handlePlayerDeath();
		} else {
			setTimeout(() => {
				if (this.playerRig.currentAnim === "flinch") {
					this.playerRig.currentAnim = "idle";
				}
			}, 350);
		}
	}
	handlePlayerDeath() {
		this.playerRig.currentAnim = "dead";
		soundManager.playGameOver();
		setTimeout(() => {
			if (this.onGameOver) {
				this.onGameOver();
			}
		}, 1500);
	}
	emitFloatingDamage(pos, text, color, isCrit) {
		// Project 3D coordinate to screen coordinates
		const v = pos.clone();
		v.y += 1.8;
		v.project(this.camera);
		const x = (v.x * .5 + .5) * this.container.clientWidth;
		const y = (-v.y * .5 + .5) * this.container.clientHeight;
		if (this.onFloatingDamage) {
			this.onFloatingDamage({
				id: Math.random(),
				text,
				color,
				isCrit,
				screenX: x,
				screenY: y,
				opacity: 1,
				scale: isCrit ? 1.4 : 1
			});
		}
	}
	notifyStats() {
		if (this.onStatsChange) {
			this.onStatsChange({ ...this.stats });
		}
	}
	afterDraw(cb) {
		const gl = this.renderer.getContext();
		const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
		gl.flush();
		const poll = () => {
			const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
			if (state === gl.UNSIGNALED) {
				this.animFrameId = window.setTimeout(poll, 5);
			} else {
				if (sync) gl.deleteSync(sync);
				this.animFrameId = window.setTimeout(cb, 60);
			}
		};
		this.animFrameId = window.setTimeout(poll, 5);
	}
	updateCollectibles(delta) {
		for (let i = this.collectibles.length - 1; i >= 0; i--) {
			const item = this.collectibles[i];
			item.bobTime += delta;
			// Bobbing & Rotating animation
			item.mesh.rotation.y += delta * 2.5;
			if (item.mesh.children.length > 1) {
				item.mesh.children[1].rotation.z += delta * 3;
			}
			item.mesh.position.y = item.baseY + Math.sin(item.bobTime * 3.5) * .15;
			// Distance to player
			const dist = this.playerPos.distanceTo(item.mesh.position);
			// Magnetize toward player if within 3.5 meters
			if (dist < 3.5) {
				const target = this.playerPos.clone();
				target.y += .85;
				item.mesh.position.lerp(target, delta * 7);
			}
			// Collect when in close contact (within 1.4m)
			if (dist < 1.4) {
				// Collect Power / Health!
				this.stats.currentHealth = Math.min(this.stats.maxHealth, this.stats.currentHealth + item.healAmount);
				soundManager.playHealthPickup();
				this.particles.spawnHitSparks(this.playerPos, 1096065, 16);
				this.emitFloatingDamage(this.playerPos, `+${item.healAmount} POWER`, "#10b981", true);
				this.notifyStats();
				// Remove from scene and list
				this.scene.remove(item.mesh);
				this.collectibles.splice(i, 1);
			}
		}
	}
	updatePlayer(delta) {
		if (this.stats.currentHealth <= 0) return;
		// Invulnerability timer
		if (this.isInvulnerable) {
			this.invulnerabilityTimer -= delta;
			if (this.invulnerabilityTimer <= 0) {
				this.isInvulnerable = false;
			}
		}
		// Steady Chi energy generation (+4 Chi/sec) so special power is available
		if (this.stats.currentEnergy < this.stats.maxEnergy) {
			this.stats.currentEnergy = Math.min(this.stats.maxEnergy, this.stats.currentEnergy + delta * 4.5);
		}
		// Special Dragon Blast 1-minute (60 seconds) cooldown countdown
		if (this.stats.specialCooldown > 0) {
			const prevSec = Math.ceil(this.stats.specialCooldown);
			this.stats.specialCooldown = Math.max(0, this.stats.specialCooldown - delta);
			const newSec = Math.ceil(this.stats.specialCooldown);
			if (prevSec !== newSec || this.stats.specialCooldown === 0) {
				this.notifyStats();
			}
		}
		// Combo timer
		if (this.comboWindowTimer > 0) {
			this.comboWindowTimer -= delta;
			if (this.comboWindowTimer <= 0) {
				this.currentComboStep = 0;
			}
		}
		if (this.stats.comboTimer > 0) {
			this.stats.comboTimer -= delta;
			if (this.stats.comboTimer <= 0) {
				this.stats.comboCount = 0;
				this.notifyStats();
			}
		}
		// Movement calculation relative to camera angle
		const mx = this.input.moveX;
		const mz = this.input.moveZ;
		const isMoving = Math.abs(mx) > .05 || Math.abs(mz) > .05;
		if (isMoving && !this.isAttacking && this.playerRig.currentAnim !== "dodge") {
			const baseSpeed = 6 + this.currentSkin.speedBonus * 6;
			// Camera visual forward on ground plane
			const camForward = new THREE.Vector3();
			this.camera.getWorldDirection(camForward);
			camForward.y = 0;
			camForward.normalize();
			// Camera visual screen-right in world coordinates
			const camRight = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
			camRight.y = 0;
			camRight.normalize();
			// Compose movement: mx (+1 = Right, -1 = Left), mz (+1 = Forward, -1 = Backward)
			const moveDir = new THREE.Vector3().addScaledVector(camRight, mx).addScaledVector(camForward, mz);
			if (moveDir.lengthSq() > .001) {
				moveDir.normalize();
			}
			const targetVelX = moveDir.x * baseSpeed;
			const targetVelZ = moveDir.z * baseSpeed;
			this.playerVelocity.x = THREE.MathUtils.damp(this.playerVelocity.x, targetVelX, 10, delta);
			this.playerVelocity.z = THREE.MathUtils.damp(this.playerVelocity.z, targetVelZ, 10, delta);
			// Smoothly rotate player toward movement direction
			this.playerRotation = Math.atan2(moveDir.x, moveDir.z);
			this.playerRig.root.rotation.y = this.playerRotation;
			if (this.isGrounded && this.playerRig.currentAnim !== "run") {
				this.playerRig.currentAnim = "run";
			}
		} else if (this.isGrounded && !this.isAttacking && this.playerRig.currentAnim !== "dodge") {
			this.playerVelocity.x = THREE.MathUtils.damp(this.playerVelocity.x, 0, 12, delta);
			this.playerVelocity.z = THREE.MathUtils.damp(this.playerVelocity.z, 0, 12, delta);
			if (this.playerRig.currentAnim === "run") {
				this.playerRig.currentAnim = "idle";
			}
		}
		// Gravity & Vertical Physics
		if (!this.isGrounded) {
			this.playerVelocity.y -= 22 * delta;
			this.playerPos.y += this.playerVelocity.y * delta;
			if (this.playerPos.y <= 0) {
				this.playerPos.y = 0;
				this.playerVelocity.y = 0;
				this.isGrounded = true;
				this.playerRig.currentAnim = isMoving ? "run" : "idle";
			}
		}
		// Apply horizontal velocity
		this.playerPos.x += this.playerVelocity.x * delta;
		this.playerPos.z += this.playerVelocity.z * delta;
		// Clamp within arena perimeter
		const maxBound = 48;
		this.playerPos.x = THREE.MathUtils.clamp(this.playerPos.x, -maxBound, maxBound);
		this.playerPos.z = THREE.MathUtils.clamp(this.playerPos.z, -maxBound, maxBound);
		this.playerRig.root.position.copy(this.playerPos);
		// Update animation frames
		if (this.isAttacking || this.playerRig.currentAnim === "dodge" || this.playerRig.currentAnim === "kick" || this.playerRig.currentAnim === "flinch") {
			this.playerRig.animProgress = Math.min(1, this.playerRig.animProgress + delta * 3.5);
		}
		CharacterFactory.updateAnimation(this.playerRig, delta);
	}
	updateEnemies(delta) {
		for (let i = this.enemies.length - 1; i >= 0; i--) {
			const enemy = this.enemies[i];
			if (enemy.state === "dead") {
				if (enemy.powerBadgeMesh) {
					this.scene.remove(enemy.powerBadgeMesh);
					enemy.powerBadgeMesh = undefined;
				}
				enemy.dissolveTimer -= delta;
				CharacterFactory.updateAnimation(enemy.rig, delta);
				if (enemy.dissolveTimer <= 0) {
					this.scene.remove(enemy.rig.root);
					this.enemies.splice(i, 1);
				}
				continue;
			}
			enemy.attackCooldown -= delta;
			const toPlayer = this.playerPos.clone().sub(enemy.rig.root.position);
			const distToPlayer = toPlayer.length();
			// Enemy AI State Machine
			if (distToPlayer < 24) {
				// Player detected
				enemy.state = "chase";
				enemy.rig.root.lookAt(this.playerPos.x, enemy.rig.root.position.y, this.playerPos.z);
				if (distToPlayer > enemy.range) {
					// Move towards player
					const moveDir = toPlayer.clone().normalize();
					enemy.rig.root.position.addScaledVector(moveDir, enemy.speed * delta);
					if (enemy.rig.currentAnim !== "run") {
						enemy.rig.currentAnim = "run";
					}
				} else {
					// In attack range
					if (enemy.attackCooldown <= 0) {
						this.executeEnemyAttack(enemy);
					} else {
						enemy.rig.currentAnim = "idle";
					}
				}
			} else {
				// Patrol or idle
				enemy.state = "idle";
				enemy.rig.currentAnim = "idle";
			}
			CharacterFactory.updateAnimation(enemy.rig, delta);
			// Update floating Power Badge position if marked
			if (enemy.hasPowerCarrierBadge && enemy.powerBadgeMesh) {
				const time = performance.now() * .003;
				enemy.powerBadgeMesh.position.set(enemy.rig.root.position.x, enemy.rig.root.position.y + 2.3 + Math.sin(time * 3) * .1, enemy.rig.root.position.z);
				const crystal = enemy.powerBadgeMesh.getObjectByName("badge_crystal");
				if (crystal) crystal.rotation.y += delta * 2;
				const ring = enemy.powerBadgeMesh.getObjectByName("badge_ring");
				if (ring) ring.rotation.z += delta * 2.5;
			}
		}
	}
	executeEnemyAttack(enemy) {
		enemy.attackCooldown = enemy.isBoss ? 2.5 : enemy.type === "fast" ? 1.8 : 3;
		enemy.rig.currentAnim = "attack1";
		enemy.rig.animProgress = 0;
		if (enemy.type === "archer") {
			soundManager.playArrowShoot();
			const dir = this.playerPos.clone().sub(enemy.rig.root.position).normalize();
			this.particles.spawnArrow(enemy.rig.root.position, dir, enemy.attackPower);
		} else {
			soundManager.playSwordSlash();
			// Damage player if still in range when swing connects
			setTimeout(() => {
				if (enemy.health > 0) {
					const dist = this.playerPos.distanceTo(enemy.rig.root.position);
					if (dist <= enemy.range + .6) {
						this.damagePlayer(enemy.attackPower, enemy.rig.root.position);
					}
				}
			}, 200);
		}
	}
	updateProjectiles(delta) {
		this.particles.projectiles.forEach((proj, idx) => {
			// Check collision with player if hostile projectile
			if (!proj.fromPlayer) {
				const dist = proj.mesh.position.distanceTo(this.playerPos);
				if (dist < 1.4) {
					this.damagePlayer(proj.damage, proj.mesh.position);
					this.scene.remove(proj.mesh);
					this.particles.projectiles.splice(idx, 1);
				}
			} else {
				// Player energy wave hits enemies
				this.enemies.forEach((enemy) => {
					if (enemy.health <= 0) return;
					const dist = proj.mesh.position.distanceTo(enemy.rig.root.position);
					if (dist < 2.5) {
						this.damageEnemyDirect(enemy, proj.damage, true, 8);
						soundManager.playSwordClash();
					}
				});
			}
		});
	}
	updateCamera(delta) {
		// Camera rotation inputs
		if (this.input.cameraRotateX !== 0) {
			this.cameraAngleX += this.input.cameraRotateX * delta * 2.2;
		}
		if (this.input.cameraRotateY !== 0) {
			this.cameraAngleY = THREE.MathUtils.clamp(this.cameraAngleY + this.input.cameraRotateY * delta * 1.5, .1, .9);
		}
		// Calculate ideal camera position behind player
		const offsetZ = Math.cos(this.cameraAngleX) * Math.cos(this.cameraAngleY) * this.cameraDistance;
		const offsetX = Math.sin(this.cameraAngleX) * Math.cos(this.cameraAngleY) * this.cameraDistance;
		const offsetY = Math.sin(this.cameraAngleY) * this.cameraDistance + 1.6;
		const targetCamPos = new THREE.Vector3(this.playerPos.x - offsetX, this.playerPos.y + offsetY, this.playerPos.z - offsetZ);
		// Screen Shake effect
		if (this.screenShake > 0) {
			targetCamPos.x += (Math.random() - .5) * this.screenShake;
			targetCamPos.y += (Math.random() - .5) * this.screenShake;
			this.screenShake = Math.max(0, this.screenShake - delta * 2.5);
		}
		// Silky smooth camera damping
		this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, targetCamPos.x, 10, delta);
		this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, targetCamPos.y, 10, delta);
		this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, targetCamPos.z, 10, delta);
		// Look at player chest
		const lookTarget = new THREE.Vector3(this.playerPos.x, this.playerPos.y + 1.4, this.playerPos.z);
		this.camera.lookAt(lookTarget);
	}
	pause() {
		this.isPaused = true;
	}
	resume() {
		this.isPaused = false;
	}
	dispose() {
		this.isRunning = false;
		soundManager.stopBgm();
		window.removeEventListener("resize", this.handleResize);
		cancelAnimationFrame(this.animFrameId);
		clearTimeout(this.animFrameId);
		this.collectibles.forEach((c) => {
			this.scene.remove(c.mesh);
		});
		this.collectibles = [];
		this.enemies.forEach((e) => {
			if (e.powerBadgeMesh) {
				this.scene.remove(e.powerBadgeMesh);
			}
		});
		this.particles.dispose();
		this.renderer.dispose();
		if (this.container && this.renderer.domElement) {
			this.container.removeChild(this.renderer.domElement);
		}
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLFlBQVksV0FBVztBQUN2QixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHdCQUFzQztBQUMvQyxTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLG9CQUFvQjtBQTBDN0IsT0FBTyxNQUFNLFdBQVc7Q0F5RnRCLFlBQ0UsV0FDQSxPQUNBLFFBQ0EsTUFDQSxjQUNBO21CQS9FaUIsSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUM7d0JBQ3BCLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDO3dCQUN6QjtvQkFDSjt3QkFDSTs4QkFDTTtlQUdGO0dBQzFCLFdBQVc7R0FDWCxlQUFlO0dBQ2YsV0FBVztHQUNYLGVBQWU7R0FDZixPQUFPO0dBQ1Asa0JBQWtCO0dBQ2xCLGdCQUFnQjtHQUNoQixZQUFZO0dBQ1osWUFBWTtHQUNaLE9BQU87R0FDUCxpQkFBaUI7R0FDakIsb0JBQW9CO0VBQ3RCO3NCQUd5QyxDQUFDOzJCQUNkOzBCQUdGOzBCQUNBO3FCQUNMO3FCQUNBO3lCQUNJO2lCQUdTLENBQUM7cUJBQ2I7cUJBQ0Q7c0JBQ3VCO3NCQUd0QjtzQkFDQTt3QkFDRTtxQkFDSDtlQUdLO0dBQ3hCLE9BQU87R0FDUCxPQUFPO0dBQ1AsUUFBUTtHQUNSLGFBQWE7R0FDYixNQUFNO0dBQ04sT0FBTztHQUNQLFNBQVM7R0FDVCxlQUFlO0dBQ2YsZUFBZTtFQUNqQjtlQUdnQixJQUFJLE1BQU0sTUFBTTtxQkFDVjttQkFDRjtrQkFDRDtzQkFDSTtvQkFzcENIO0dBQ2xCLElBQUksQ0FBQyxLQUFLLFdBQVc7R0FFckIsTUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLLE1BQU0sU0FBUyxHQUFHLEdBQUk7R0FFbEQsSUFBSSxDQUFDLEtBQUssVUFBVTtJQUNsQixLQUFLLGFBQWEsS0FBSztJQUN2QixLQUFLLGNBQWMsS0FBSztJQUN4QixLQUFLLGtCQUFrQixLQUFLO0lBQzVCLEtBQUssbUJBQW1CLEtBQUs7SUFDN0IsS0FBSyxhQUFhLEtBQUs7SUFDdkIsS0FBSyxVQUFVLE9BQU8sT0FBTyxLQUFLLFdBQVcsS0FBSyxNQUFNO0dBQzFEO0dBRUEsS0FBSyxTQUFTLE9BQU8sS0FBSyxPQUFPLEtBQUssTUFBTTtHQUU1QyxJQUFJLEtBQUssY0FBYztJQUNyQixLQUFLLFVBQVUsS0FBSyxJQUFJO0dBQzFCLE9BQU87SUFDTCxLQUFLLGNBQWMsc0JBQXNCLEtBQUssSUFBSTtHQUNwRDtFQUNGOzRCQXdWNEI7R0FDMUIsSUFBSSxDQUFDLEtBQUssV0FBVztHQUNyQixNQUFNLFFBQVEsS0FBSyxVQUFVO0dBQzdCLE1BQU0sU0FBUyxLQUFLLFVBQVU7R0FFOUIsS0FBSyxPQUFPLFNBQVMsUUFBUTtHQUM3QixLQUFLLE9BQU8sdUJBQXVCO0dBQ25DLEtBQUssU0FBUyxRQUFRLE9BQU8sTUFBTTtFQUNyQztFQTMvQ0UsS0FBSyxZQUFZO0VBQ2pCLEtBQUssZUFBZTtFQUNwQixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLGNBQWM7RUFDbkIsS0FBSyxNQUFNLFFBQVE7O0VBR25CLEtBQUssc0JBQXNCO0dBQ3pCLE1BQU0sS0FBSyxTQUFTLGNBQWMsUUFBUSxDQUFDLENBQUMsV0FBVyxRQUFRO0dBQy9ELElBQUksQ0FBQyxJQUFJLE9BQU87R0FDaEIsTUFBTSxNQUFNLEdBQUcsYUFBYSwyQkFBMkI7R0FDdkQsTUFBTSxRQUFRLE1BQU0sSUFBSSwwQkFBMEIsR0FBRztHQUNyRCxNQUFNLE1BQU0sT0FBTyxHQUFHLGFBQWEsS0FBSyxDQUFDO0dBQ3pDLEdBQUcsYUFBYSxvQkFBb0IsQ0FBQyxFQUFFLFlBQVk7R0FDbkQsT0FBTyx1REFBdUQsS0FBSyxHQUFHO0VBQ3hFLEVBQUMsQ0FBRTs7RUFHSCxLQUFLLFdBQVcsSUFBSSxNQUFNLGNBQWM7R0FDdEMsV0FBVyxDQUFDLEtBQUs7R0FDakIsaUJBQWlCO0VBQ25CLENBQUM7RUFDRCxLQUFLLFNBQVMsbUJBQW1CLE1BQU07RUFDdkMsS0FBSyxTQUFTLGNBQWMsTUFBTTtFQUNsQyxLQUFLLFNBQVMsc0JBQXNCO0VBQ3BDLEtBQUssU0FBUyxjQUFjLEtBQUssZUFBZSxJQUFJLEtBQUssSUFBSSxPQUFPLGtCQUFrQixDQUFDLENBQUM7RUFDeEYsS0FBSyxTQUFTLFVBQVUsVUFBVSxDQUFDLEtBQUs7RUFDeEMsS0FBSyxTQUFTLFVBQVUsT0FBTyxNQUFNO0VBQ3JDLEtBQUssU0FBUyxRQUFRLFVBQVUsYUFBYSxVQUFVLFlBQVk7RUFDbkUsVUFBVSxZQUFZLEtBQUssU0FBUyxVQUFVOztFQUc5QyxLQUFLLFFBQVEsSUFBSSxNQUFNLE1BQU07RUFDN0IsS0FBSyxNQUFNLGFBQWEsSUFBSSxNQUFNLE1BQU0sTUFBTSxRQUFRO0VBQ3RELEtBQUssTUFBTSxNQUFNLElBQUksTUFBTSxRQUFRLE1BQU0sVUFBVSxJQUFLOztFQUd4RCxNQUFNLGlCQUFpQixJQUFJLE1BQU0sZUFBZSxLQUFLLFFBQVE7RUFDN0QsS0FBSyxNQUFNLGNBQWMsZUFBZSxVQUFVLElBQUksZ0JBQWdCLEdBQUcsR0FBSSxDQUFDLENBQUM7RUFDL0UsZUFBZSxRQUFROztFQUd2QixLQUFLLFNBQVMsSUFBSSxNQUFNLGtCQUN0QixJQUNBLFVBQVUsY0FBYyxVQUFVLGNBQ2xDLElBQ0EsR0FDRjs7RUFHQSxLQUFLLGNBQWM7O0VBR25CLEtBQUssV0FBVzs7RUFHaEIsS0FBSyxZQUFZLElBQUksZUFBZSxLQUFLLEtBQUs7O0VBRzlDLEtBQUssWUFBWSxpQkFBaUIsa0JBQWtCLE1BQU0sTUFBTTtFQUNoRSxLQUFLLE1BQU0sSUFBSSxLQUFLLFVBQVUsSUFBSTtFQUNsQyxLQUFLLFVBQVUsSUFBSSxHQUFHLEdBQUcsQ0FBQztFQUMxQixLQUFLLFVBQVUsS0FBSyxTQUFTLEtBQUssS0FBSyxTQUFTOztFQUdoRCxLQUFLLG9CQUFvQjs7RUFHekIsYUFBYSxTQUFTOztFQUd0QixPQUFPLGlCQUFpQixVQUFVLEtBQUssWUFBWTs7RUFHbkQsS0FBSyxZQUFZO0VBQ2pCLEtBQUssS0FBSztDQUNaO0NBRUEsQUFBUSxnQkFBZ0I7O0VBRXRCLE1BQU0sWUFBWSxJQUFJLE1BQU0sZ0JBQzFCLEtBQUssYUFBYSxZQUNsQixTQUNBLEdBQ0Y7RUFDQSxLQUFLLE1BQU0sSUFBSSxTQUFTOztFQUd4QixNQUFNLFdBQVcsSUFBSSxNQUFNLGlCQUFpQixLQUFLLGFBQWEsWUFBWSxHQUFHO0VBQzdFLFNBQVMsU0FBUyxJQUFJLElBQUksSUFBSSxFQUFFO0VBQ2hDLFNBQVMsYUFBYSxDQUFDLEtBQUs7RUFDNUIsU0FBUyxPQUFPLFFBQVEsUUFBUTtFQUNoQyxTQUFTLE9BQU8sUUFBUSxTQUFTO0VBQ2pDLFNBQVMsT0FBTyxPQUFPLE9BQU87RUFDOUIsU0FBUyxPQUFPLE9BQU8sTUFBTTtFQUM3QixNQUFNLElBQUk7RUFDVixTQUFTLE9BQU8sT0FBTyxPQUFPLENBQUM7RUFDL0IsU0FBUyxPQUFPLE9BQU8sUUFBUTtFQUMvQixTQUFTLE9BQU8sT0FBTyxNQUFNO0VBQzdCLFNBQVMsT0FBTyxPQUFPLFNBQVMsQ0FBQztFQUNqQyxTQUFTLE9BQU8sT0FBTyxDQUFDO0VBQ3hCLFNBQVMsT0FBTyxhQUFhO0VBQzdCLEtBQUssTUFBTSxJQUFJLFFBQVE7Q0FDekI7Q0FFQSxBQUFRLGFBQWE7RUFDbkIsTUFBTSxRQUFRLEtBQUssYUFBYTtFQUNoQyxJQUFJLFVBQVUsVUFBVTtHQUN0QixLQUFLLGlCQUFpQjtFQUN4QixPQUFPLElBQUksVUFBVSxXQUFXO0dBQzlCLEtBQUssa0JBQWtCO0VBQ3pCLE9BQU8sSUFBSSxVQUFVLFVBQVU7R0FDN0IsS0FBSyxpQkFBaUI7RUFDeEIsT0FBTyxJQUFJLFVBQVUsWUFBWTtHQUMvQixLQUFLLG1CQUFtQjtFQUMxQixPQUFPLElBQUksVUFBVSxTQUFTO0dBQzVCLEtBQUssZ0JBQWdCO0VBQ3ZCLE9BQU87R0FDTCxLQUFLLGlCQUFpQjtFQUN4QjtDQUNGOztDQUdBLEFBQVEsbUJBQW1CO0VBQ3pCLE1BQU0sWUFBWSxJQUFJLE1BQU0sY0FBYyxLQUFLLEtBQUssSUFBSSxFQUFFO0VBQzFELE1BQU0sWUFBWSxJQUFJLE1BQU0scUJBQXFCO0dBQUUsT0FBTztHQUFVLFdBQVc7RUFBSSxDQUFDO0VBQ3BGLE1BQU0sU0FBUyxJQUFJLE1BQU0sS0FBSyxXQUFXLFNBQVM7RUFDbEQsT0FBTyxTQUFTLElBQUksQ0FBQyxLQUFLLEtBQUs7RUFDL0IsT0FBTyxnQkFBZ0IsQ0FBQyxLQUFLO0VBQzdCLEtBQUssTUFBTSxJQUFJLE1BQU07O0VBR3JCLE1BQU0sVUFBVSxJQUFJLE1BQU0sY0FBYyxHQUFHLEVBQUU7RUFDN0MsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FDN0MsS0FBSyxpQkFBaUIsd0JBQXdCO0dBQzlDLFdBQVc7RUFDYixDQUFDO0VBQ0QsTUFBTSxPQUFPLElBQUksTUFBTSxLQUFLLFNBQVMsT0FBTztFQUM1QyxLQUFLLFNBQVMsSUFBSSxDQUFDLEtBQUssS0FBSztFQUM3QixLQUFLLFNBQVMsSUFBSSxHQUFHLEtBQU0sQ0FBQztFQUM1QixLQUFLLE1BQU0sSUFBSSxJQUFJOztFQUduQixNQUFNLFFBQVEsbUJBQW1CLGdCQUFnQjtFQUNqRCxNQUFNLFNBQVMsSUFBSSxHQUFHLEdBQUcsRUFBRTtFQUMzQixLQUFLLE1BQU0sSUFBSSxLQUFLOztFQUdwQixNQUFNLE9BQU8sbUJBQW1CLGFBQWEsQ0FBQztFQUM5QyxLQUFLLFNBQVMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0VBQzNCLEtBQUssTUFBTSxJQUFJLElBQUk7O0VBR25CLE1BQU0sY0FBYztHQUNsQjtJQUFDLENBQUM7SUFBRztJQUFHO0dBQUU7R0FBRztJQUFDO0lBQUc7SUFBRztHQUFFO0dBQUc7SUFBQyxDQUFDO0lBQUk7SUFBRztHQUFDO0dBQUc7SUFBQztJQUFJO0lBQUc7R0FBQztHQUMvQztJQUFDLENBQUM7SUFBSTtJQUFHLENBQUM7R0FBQztHQUFHO0lBQUM7SUFBSTtJQUFHLENBQUM7R0FBRTtHQUFHO0lBQUMsQ0FBQztJQUFHO0lBQUcsQ0FBQztHQUFFO0dBQUc7SUFBQztJQUFHO0lBQUcsQ0FBQztHQUFFO0dBQ3BEO0lBQUMsQ0FBQztJQUFJO0lBQUc7R0FBRTtHQUFHO0lBQUM7SUFBSTtJQUFHO0dBQUU7R0FBRztJQUFDLENBQUM7SUFBSTtJQUFHLENBQUM7R0FBRTtHQUFHO0lBQUM7SUFBSTtJQUFHLENBQUM7R0FBRTtFQUN2RDtFQUNBLFlBQVksU0FBUSxNQUFLO0dBQ3ZCLE1BQU0sT0FBTyxtQkFBbUIsaUJBQWlCO0dBQ2pELEtBQUssU0FBUyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFO0dBQ2xDLE1BQU0sSUFBSSxNQUFPLEtBQUssT0FBTyxJQUFJO0dBQ2pDLEtBQUssTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDO0dBQ3RCLEtBQUssU0FBUyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUssS0FBSztHQUM1QyxLQUFLLE1BQU0sSUFBSSxJQUFJO0VBQ3JCLENBQUM7O0VBR0Q7R0FBQyxDQUFDO0dBQUc7R0FBRyxDQUFDO0VBQUUsQ0FBQyxDQUFDLFNBQVEsTUFBSztHQUN4QixNQUFNLEtBQUssbUJBQW1CLG1CQUFtQixDQUFDLEtBQUssWUFBWTtHQUNuRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUM7R0FDOUIsTUFBTSxLQUFLLG1CQUFtQixtQkFBbUIsQ0FBQyxLQUFLLFlBQVk7R0FDbkUsR0FBRyxNQUFNLFNBQVMsSUFBSSxHQUFHLEdBQUcsQ0FBQztHQUM3QixLQUFLLE1BQU0sSUFBSSxHQUFHLE9BQU8sR0FBRyxLQUFLO0VBQ25DLENBQUM7RUFFRCxLQUFLLHdCQUF3QixPQUFRO0NBQ3ZDOztDQUdBLEFBQVEsb0JBQW9CO0VBQzFCLE1BQU0sWUFBWSxJQUFJLE1BQU0sY0FBYyxLQUFLLEtBQUssSUFBSSxFQUFFO0VBQzFELE1BQU0sWUFBWSxJQUFJLE1BQU0scUJBQXFCO0dBQUUsT0FBTztHQUFVLFdBQVc7RUFBSyxDQUFDO0VBQ3JGLE1BQU0sU0FBUyxJQUFJLE1BQU0sS0FBSyxXQUFXLFNBQVM7RUFDbEQsT0FBTyxTQUFTLElBQUksQ0FBQyxLQUFLLEtBQUs7RUFDL0IsT0FBTyxnQkFBZ0IsQ0FBQyxLQUFLO0VBQzdCLEtBQUssTUFBTSxJQUFJLE1BQU07O0VBR3JCLE1BQU0sVUFBVSxJQUFJLE1BQU0sY0FBYyxHQUFHLEVBQUU7RUFDN0MsTUFBTSxVQUFVLElBQUksTUFBTSxxQkFBcUI7R0FBRSxPQUFPO0dBQVUsV0FBVztFQUFJLENBQUM7RUFDbEYsTUFBTSxPQUFPLElBQUksTUFBTSxLQUFLLFNBQVMsT0FBTztFQUM1QyxLQUFLLFNBQVMsSUFBSSxDQUFDLEtBQUssS0FBSztFQUM3QixLQUFLLFNBQVMsSUFBSSxHQUFHLEtBQU0sQ0FBQztFQUM1QixLQUFLLE1BQU0sSUFBSSxJQUFJOztFQUduQixNQUFNLGVBQWU7R0FDbkI7SUFBQyxDQUFDO0lBQUk7SUFBRztHQUFDO0dBQUc7SUFBQztJQUFJO0lBQUc7R0FBQztHQUFHO0lBQUMsQ0FBQztJQUFJO0lBQUcsQ0FBQztHQUFFO0dBQUc7SUFBQztJQUFJO0lBQUcsQ0FBQztHQUFFO0VBQ3JEO0VBQ0EsYUFBYSxTQUFRLE1BQUs7R0FDeEIsTUFBTSxNQUFNLG1CQUFtQixpQkFBaUI7R0FDaEQsSUFBSSxTQUFTLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUU7R0FDakMsSUFBSSxTQUFTLElBQUksS0FBSyxPQUFPLElBQUksS0FBTTtHQUN2QyxLQUFLLE1BQU0sSUFBSSxHQUFHO0VBQ3BCLENBQUM7O0VBR0QsTUFBTSxRQUFRLENBQ1o7R0FBRSxHQUFHLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztHQUFHLEdBQUcsSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQztFQUFFLEdBQ2xFO0dBQUUsR0FBRyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0dBQUcsR0FBRyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0VBQUUsQ0FDckU7RUFDQSxNQUFNLFNBQVEsTUFBSztHQUNqQixNQUFNLE9BQU8sbUJBQW1CLGdCQUFnQjtHQUNoRCxLQUFLLFNBQVMsS0FBSyxFQUFFLENBQUM7R0FDdEIsTUFBTSxPQUFPLG1CQUFtQixlQUFlO0dBQy9DLEtBQUssTUFBTSxTQUFTLEtBQUssRUFBRSxDQUFDO0dBQzVCLEtBQUssTUFBTSxJQUFJLE1BQU0sS0FBSyxLQUFLO0VBQ2pDLENBQUM7O0VBR0QsTUFBTSxTQUFTLG1CQUFtQixpQkFBaUI7RUFDbkQsT0FBTyxTQUFTLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRTtFQUM3QixNQUFNLFNBQVMsbUJBQW1CLGlCQUFpQjtFQUNuRCxPQUFPLFNBQVMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0VBQzdCLEtBQUssTUFBTSxJQUFJLFFBQVEsTUFBTTs7RUFHN0IsTUFBTSxTQUFTLG1CQUFtQixtQkFBbUIsSUFBSSxHQUFHO0VBQzVELE9BQU8sU0FBUyxJQUFJLEdBQUcsR0FBRyxDQUFDO0VBQzNCLEtBQUssTUFBTSxJQUFJLE1BQU07O0VBR3JCLE1BQU0sT0FBTyxtQkFBbUIsc0JBQXNCO0VBQ3RELEtBQUssU0FBUyxJQUFJLENBQUMsR0FBRyxHQUFHLEVBQUU7RUFDM0IsTUFBTSxPQUFPLG1CQUFtQixzQkFBc0I7RUFDdEQsS0FBSyxTQUFTLElBQUksR0FBRyxHQUFHLEVBQUU7RUFDMUIsS0FBSyxNQUFNLElBQUksTUFBTSxJQUFJOztFQUd6QjtHQUFDO0lBQUMsQ0FBQztJQUFJO0lBQUc7R0FBQztHQUFHO0lBQUM7SUFBSTtJQUFHLENBQUM7R0FBQztHQUFHO0lBQUMsQ0FBQztJQUFJO0lBQUcsQ0FBQztHQUFFO0dBQUc7SUFBQztJQUFJO0lBQUc7R0FBRTtFQUFDLENBQUMsQ0FBQyxTQUFRLE1BQUs7R0FDbEUsTUFBTSxPQUFPLG1CQUFtQixlQUFlO0dBQy9DLEtBQUssU0FBUyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFO0dBQ2xDLEtBQUssTUFBTSxJQUFJLElBQUk7RUFDckIsQ0FBQztFQUVELEtBQUssd0JBQXdCLE9BQVE7Q0FDdkM7O0NBR0EsQUFBUSxtQkFBbUI7RUFDekIsTUFBTSxZQUFZLElBQUksTUFBTSxjQUFjLEtBQUssS0FBSyxJQUFJLEVBQUU7RUFDMUQsTUFBTSxZQUFZLElBQUksTUFBTSxxQkFBcUI7R0FBRSxPQUFPO0dBQVUsV0FBVztFQUFJLENBQUM7RUFDcEYsTUFBTSxTQUFTLElBQUksTUFBTSxLQUFLLFdBQVcsU0FBUztFQUNsRCxPQUFPLFNBQVMsSUFBSSxDQUFDLEtBQUssS0FBSztFQUMvQixPQUFPLGdCQUFnQixDQUFDLEtBQUs7RUFDN0IsS0FBSyxNQUFNLElBQUksTUFBTTs7RUFHckIsTUFBTSxXQUFXLElBQUksTUFBTSxjQUFjLElBQUksRUFBRTtFQUMvQyxNQUFNLFdBQVcsSUFBSSxNQUFNLHFCQUFxQjtHQUM5QyxLQUFLLGlCQUFpQix3QkFBd0I7R0FDOUMsV0FBVztHQUNYLE9BQU87RUFDVCxDQUFDO0VBQ0QsTUFBTSxRQUFRLElBQUksTUFBTSxLQUFLLFVBQVUsUUFBUTtFQUMvQyxNQUFNLFNBQVMsSUFBSSxDQUFDLEtBQUssS0FBSztFQUM5QixNQUFNLFNBQVMsSUFBSSxHQUFHLEtBQU0sQ0FBQyxDQUFDO0VBQzlCLEtBQUssTUFBTSxJQUFJLEtBQUs7O0VBR3BCLE1BQU0sU0FBUyxtQkFBbUIsYUFBYSxDQUFDO0VBQ2hELE9BQU8sU0FBUyxJQUFJLEdBQUcsR0FBRyxDQUFDLEVBQUU7RUFDN0IsS0FBSyxNQUFNLElBQUksTUFBTTs7RUFHckIsTUFBTSxVQUFVLG1CQUFtQixtQkFBbUI7RUFDdEQsUUFBUSxTQUFTLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxFQUFFO0VBQ2pDLFFBQVEsU0FBUyxJQUFJO0VBQ3JCLE1BQU0sVUFBVSxtQkFBbUIsbUJBQW1CO0VBQ3RELFFBQVEsU0FBUyxJQUFJLEtBQUssR0FBRyxDQUFDLEVBQUU7RUFDaEMsUUFBUSxTQUFTLElBQUksQ0FBQztFQUN0QixLQUFLLE1BQU0sSUFBSSxTQUFTLE9BQU87O0VBRy9CO0dBQUMsQ0FBQztHQUFJLENBQUM7R0FBSSxDQUFDO0dBQUc7R0FBRztFQUFFLENBQUMsQ0FBQyxTQUFRLE1BQUs7R0FDakMsTUFBTSxLQUFLLG1CQUFtQixtQkFBbUIsQ0FBQyxLQUFLLFlBQVk7R0FDbkUsR0FBRyxNQUFNLFNBQVMsSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDO0dBQzlCLElBQUksR0FBRyxPQUFPLEdBQUcsTUFBTSxNQUFNLE9BQU8sTUFBUTtHQUU1QyxNQUFNLEtBQUssbUJBQW1CLG1CQUFtQixDQUFDLEtBQUssWUFBWTtHQUNuRSxHQUFHLE1BQU0sU0FBUyxJQUFJLEdBQUcsR0FBRyxDQUFDO0dBQzdCLElBQUksR0FBRyxPQUFPLEdBQUcsTUFBTSxNQUFNLE9BQU8sTUFBUTtHQUM1QyxLQUFLLE1BQU0sSUFBSSxHQUFHLE9BQU8sR0FBRyxLQUFLO0VBQ25DLENBQUM7O0VBR0QsTUFBTSxRQUFRLG1CQUFtQixnQkFBZ0I7RUFDakQsTUFBTSxTQUFTLElBQUksR0FBRyxHQUFHLEVBQUU7RUFDM0IsS0FBSyxNQUFNLElBQUksS0FBSzs7RUFHcEI7R0FBQztJQUFDLENBQUM7SUFBSTtJQUFHO0dBQUU7R0FBRztJQUFDO0lBQUk7SUFBRztHQUFFO0dBQUc7SUFBQyxDQUFDO0lBQUk7SUFBRyxDQUFDO0dBQUU7R0FBRztJQUFDO0lBQUk7SUFBRyxDQUFDO0dBQUM7R0FBRztJQUFDLENBQUM7SUFBSTtJQUFHLENBQUM7R0FBRTtHQUFHO0lBQUM7SUFBSTtJQUFHLENBQUM7R0FBRTtFQUFDLENBQUMsQ0FBQyxTQUFRLE1BQUs7R0FDaEcsTUFBTSxPQUFPLG1CQUFtQixlQUFlO0dBQy9DLEtBQUssU0FBUyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFO0dBQ2xDLEtBQUssTUFBTSxJQUFJLElBQUk7RUFDckIsQ0FBQztFQUVELEtBQUssd0JBQXdCLE1BQVE7Q0FDdkM7O0NBR0EsQUFBUSxxQkFBcUI7RUFDM0IsTUFBTSxZQUFZLElBQUksTUFBTSxjQUFjLEtBQUssS0FBSyxJQUFJLEVBQUU7RUFDMUQsTUFBTSxZQUFZLElBQUksTUFBTSxxQkFBcUI7R0FBRSxPQUFPO0dBQVUsV0FBVztFQUFJLENBQUM7RUFDcEYsTUFBTSxTQUFTLElBQUksTUFBTSxLQUFLLFdBQVcsU0FBUztFQUNsRCxPQUFPLFNBQVMsSUFBSSxDQUFDLEtBQUssS0FBSztFQUMvQixPQUFPLGdCQUFnQixDQUFDLEtBQUs7RUFDN0IsS0FBSyxNQUFNLElBQUksTUFBTTs7RUFHckIsTUFBTSxVQUFVLElBQUksTUFBTSxjQUFjLElBQUksRUFBRTtFQUM5QyxNQUFNLFVBQVUsSUFBSSxNQUFNLHFCQUFxQjtHQUM3QyxLQUFLLGlCQUFpQix3QkFBd0I7R0FDOUMsV0FBVztFQUNiLENBQUM7RUFDRCxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0VBQzVDLEtBQUssU0FBUyxJQUFJLENBQUMsS0FBSyxLQUFLO0VBQzdCLEtBQUssU0FBUyxJQUFJLEdBQUcsS0FBTSxDQUFDO0VBQzVCLEtBQUssTUFBTSxJQUFJLElBQUk7O0VBR25CLE1BQU0sS0FBSyxtQkFBbUIsaUJBQWlCO0VBQy9DLEdBQUcsU0FBUyxJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUU7RUFDMUIsTUFBTSxLQUFLLG1CQUFtQixpQkFBaUI7RUFDL0MsR0FBRyxTQUFTLElBQUksSUFBSSxHQUFHLENBQUM7RUFDeEIsTUFBTSxLQUFLLG1CQUFtQixpQkFBaUI7RUFDL0MsR0FBRyxTQUFTLElBQUksR0FBRyxHQUFHLENBQUMsRUFBRTtFQUN6QixLQUFLLE1BQU0sSUFBSSxJQUFJLElBQUksRUFBRTs7RUFHekI7R0FBQyxDQUFDO0dBQUc7R0FBSSxDQUFDO0VBQUUsQ0FBQyxDQUFDLFNBQVEsTUFBSztHQUN6QixNQUFNLEtBQUssbUJBQW1CLHNCQUFzQjtHQUNwRCxHQUFHLFNBQVMsSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDO0dBQ3hCLE1BQU0sS0FBSyxtQkFBbUIsc0JBQXNCO0dBQ3BELEdBQUcsU0FBUyxJQUFJLEdBQUcsR0FBRyxDQUFDO0dBQ3ZCLEtBQUssTUFBTSxJQUFJLElBQUksRUFBRTtFQUN2QixDQUFDOztFQUdEO0dBQUMsQ0FBQztHQUFJO0dBQUcsQ0FBQztHQUFJLENBQUM7RUFBRSxDQUFDLENBQUMsU0FBUSxNQUFLO0dBQzlCLE1BQU0sTUFBTSxtQkFBbUIsY0FBYyxRQUFRO0dBQ3JELElBQUksTUFBTSxTQUFTLElBQUksSUFBSSxNQUFNLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO0dBQ2pELEtBQUssTUFBTSxJQUFJLElBQUksS0FBSztFQUMxQixDQUFDOztFQUdELE1BQU0sU0FBUyxtQkFBbUIsbUJBQW1CLElBQUksQ0FBQztFQUMxRCxPQUFPLFNBQVMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0VBQzVCLEtBQUssTUFBTSxJQUFJLE1BQU07O0VBR3JCLE1BQU0sUUFBUSxtQkFBbUIsZ0JBQWdCO0VBQ2pELE1BQU0sU0FBUyxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsRUFBRTtFQUM5QixNQUFNLFFBQVEsbUJBQW1CLGdCQUFnQjtFQUNqRCxNQUFNLFNBQVMsSUFBSSxJQUFJLEdBQUcsQ0FBQyxFQUFFO0VBQzdCLEtBQUssTUFBTSxJQUFJLE9BQU8sS0FBSztFQUUzQixLQUFLLHdCQUF3QixPQUFRO0NBQ3ZDOztDQUdBLEFBQVEsa0JBQWtCOztFQUV4QixNQUFNLFdBQVcsSUFBSSxNQUFNLGlCQUFpQixJQUFJLElBQUksS0FBSyxFQUFFO0VBQzNELE1BQU0sU0FBUyxJQUFJLE1BQU0scUJBQXFCO0dBQzVDLE9BQU87R0FDUCxXQUFXO0dBQ1gsV0FBVztFQUNiLENBQUM7RUFDRCxNQUFNLFFBQVEsSUFBSSxNQUFNLEtBQUssVUFBVSxNQUFNO0VBQzdDLE1BQU0sU0FBUyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztFQUMvQixNQUFNLGdCQUFnQixDQUFDLEtBQUs7RUFDNUIsS0FBSyxNQUFNLElBQUksS0FBSzs7RUFHcEIsTUFBTSxVQUFVLElBQUksTUFBTSxhQUFhLEdBQUcsS0FBSyxFQUFFO0VBQ2pELE1BQU0sVUFBVSxJQUFJLE1BQU0sa0JBQWtCO0dBQUUsT0FBTztHQUFVLE1BQU0sTUFBTTtFQUFXLENBQUM7RUFDdkYsTUFBTSxPQUFPLElBQUksTUFBTSxLQUFLLFNBQVMsT0FBTztFQUM1QyxLQUFLLFNBQVMsSUFBSSxDQUFDLEtBQUssS0FBSztFQUM3QixLQUFLLFNBQVMsSUFBSSxHQUFHLEtBQU0sQ0FBQyxDQUFDO0VBQzdCLEtBQUssTUFBTSxJQUFJLElBQUk7O0VBR25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7R0FDMUIsTUFBTSxRQUFTLElBQUksS0FBSyxLQUFLLElBQUs7R0FDbEMsTUFBTSxPQUFPLG1CQUFtQix1QkFBdUI7R0FDdkQsS0FBSyxTQUFTLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLENBQUM7R0FDbkUsS0FBSyxTQUFTLElBQUk7R0FDbEIsS0FBSyxNQUFNLElBQUksSUFBSTtFQUNyQjs7RUFHQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0dBQzFCLE1BQU0sUUFBUyxJQUFJLEtBQUssS0FBSyxJQUFLLElBQUksS0FBSyxLQUFLO0dBQ2hELE1BQU0sTUFBTSxtQkFBbUIsY0FBYyxRQUFRO0dBQ3JELElBQUksTUFBTSxTQUFTLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLENBQUM7R0FDeEUsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLO0VBQzFCOztFQUdBLE1BQU0sUUFBUSxtQkFBbUIsZ0JBQWdCO0VBQ2pELE1BQU0sU0FBUyxJQUFJLEdBQUcsR0FBRyxFQUFFO0VBQzNCLE1BQU0sU0FBUyxJQUFJO0VBQ25CLEtBQUssTUFBTSxJQUFJLEtBQUs7O0VBR3BCLEtBQUssd0JBQXdCLE9BQVE7Q0FDdkM7Q0FFQSxBQUFRLHdCQUF3QixPQUFlO0VBQzdDLE1BQU0sVUFBVSxJQUFJLE1BQU0scUJBQXFCO0dBQzdDO0dBQ0EsV0FBVztFQUNiLENBQUM7RUFFRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0dBQzNCLE1BQU0sUUFBUyxJQUFJLEtBQUssS0FBSyxJQUFLO0dBQ2xDLE1BQU0sT0FBTyxLQUFLLEtBQUssT0FBTyxJQUFJO0dBQ2xDLE1BQU0sY0FBYyxJQUFJLE1BQU0sYUFBYSxJQUFJLEtBQUssT0FBTyxJQUFJLEdBQUcsS0FBSyxLQUFLLE9BQU8sSUFBSSxJQUFJLENBQUM7R0FDNUYsTUFBTSxXQUFXLElBQUksTUFBTSxLQUFLLGFBQWEsT0FBTztHQUNwRCxTQUFTLFNBQVMsSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSyxJQUFJLElBQUk7R0FDdkUsU0FBUyxNQUFNLElBQUksSUFBSSxLQUFLLE9BQU8sSUFBSSxJQUFLLEdBQUcsSUFBSSxLQUFLLE9BQU8sSUFBSSxFQUFHO0dBQ3RFLEtBQUssTUFBTSxJQUFJLFFBQVE7RUFDekI7Q0FDRjs7Q0FHQSxBQUFRLHNCQUFzQjtFQUM1QixNQUFNLE1BQU0sS0FBSyxhQUFhO0VBRTlCLElBQUksUUFBUSxHQUFHOztHQUViLE1BQU0sU0FBb0Q7SUFDeEQ7S0FBRSxNQUFNO0tBQVUsS0FBSyxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsR0FBRyxDQUFDO0lBQUU7SUFDbkQ7S0FBRSxNQUFNO0tBQVUsS0FBSyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQztJQUFFO0lBQ2xEO0tBQUUsTUFBTTtLQUFVLEtBQUssSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQUU7SUFDcEQ7S0FBRSxNQUFNO0tBQVUsS0FBSyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQUU7SUFDbkQ7S0FBRSxNQUFNO0tBQVEsS0FBSyxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQUU7SUFBRTtJQUNuRDtLQUFFLE1BQU07S0FBUSxLQUFLLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLEVBQUU7SUFBRTtHQUNwRDtHQUNBLE9BQU8sU0FBUSxNQUFLLEtBQUssV0FBVyxFQUFFLE1BQU0sRUFBRSxHQUFHLENBQUM7RUFDcEQsT0FBTyxJQUFJLFFBQVEsR0FBRzs7R0FFcEIsTUFBTSxTQUFvRDtJQUN4RDtLQUFFLE1BQU07S0FBVSxLQUFLLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxHQUFHLEVBQUU7SUFBRTtJQUNwRDtLQUFFLE1BQU07S0FBUSxLQUFLLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxFQUFFO0lBQUU7SUFDakQ7S0FBRSxNQUFNO0tBQVUsS0FBSyxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFBRTtJQUNwRDtLQUFFLE1BQU07S0FBUSxLQUFLLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFBRTtJQUNqRDtLQUFFLE1BQU07S0FBUyxLQUFLLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLEVBQUU7SUFBRTtJQUNuRDtLQUFFLE1BQU07S0FBVSxLQUFLLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRTtJQUFFO0lBQ3JEO0tBQUUsTUFBTTtLQUFRLEtBQUssSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsRUFBRTtJQUFFO0lBQ2xEO0tBQUUsTUFBTTtLQUFVLEtBQUssSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsRUFBRTtJQUFFO0dBQ3REO0dBQ0EsT0FBTyxTQUFRLE1BQUssS0FBSyxXQUFXLEVBQUUsTUFBTSxFQUFFLEdBQUcsQ0FBQztFQUNwRCxPQUFPLElBQUksUUFBUSxHQUFHOztHQUVwQixNQUFNLFNBQW9EO0lBQ3hEO0tBQUUsTUFBTTtLQUFRLEtBQUssSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUFFO0lBQ2pEO0tBQUUsTUFBTTtLQUFVLEtBQUssSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUM7SUFBRTtJQUNsRDtLQUFFLE1BQU07S0FBUSxLQUFLLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxHQUFHLENBQUM7SUFBRTtJQUNqRDtLQUFFLE1BQU07S0FBVSxLQUFLLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFBRTtJQUNuRDtLQUFFLE1BQU07S0FBVSxLQUFLLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRTtJQUFFO0lBQ3JEO0tBQUUsTUFBTTtLQUFRLEtBQUssSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsRUFBRTtJQUFFO0lBQ2xEO0tBQUUsTUFBTTtLQUFVLEtBQUssSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsRUFBRTtJQUFFO0lBQ3BEO0tBQUUsTUFBTTtLQUFVLEtBQUssSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQUU7SUFDckQ7S0FBRSxNQUFNO0tBQVEsS0FBSyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQUU7SUFDbEQ7S0FBRSxNQUFNO0tBQVUsS0FBSyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQUU7R0FDdEQ7R0FDQSxPQUFPLFNBQVEsTUFBSyxLQUFLLFdBQVcsRUFBRSxNQUFNLEVBQUUsR0FBRyxDQUFDO0VBQ3BELE9BQU8sSUFBSSxRQUFRLEdBQUc7O0dBRXBCLE1BQU0sU0FBb0Q7SUFDeEQ7S0FBRSxNQUFNO0tBQVMsS0FBSyxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsR0FBRyxFQUFFO0lBQUU7SUFDbkQ7S0FBRSxNQUFNO0tBQVUsS0FBSyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsRUFBRTtJQUFFO0lBQ25EO0tBQUUsTUFBTTtLQUFRLEtBQUssSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUFFO0lBQ2pEO0tBQUUsTUFBTTtLQUFTLEtBQUssSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUM7SUFBRTtJQUNqRDtLQUFFLE1BQU07S0FBVSxLQUFLLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUFFO0lBQ3BEO0tBQUUsTUFBTTtLQUFVLEtBQUssSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUFFO0lBQ25EO0tBQUUsTUFBTTtLQUFTLEtBQUssSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQUU7SUFDcEQ7S0FBRSxNQUFNO0tBQVEsS0FBSyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQUU7SUFDbEQ7S0FBRSxNQUFNO0tBQVMsS0FBSyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQUU7SUFDbkQ7S0FBRSxNQUFNO0tBQVUsS0FBSyxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQUU7SUFBRTtJQUNyRDtLQUFFLE1BQU07S0FBUyxLQUFLLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLEVBQUU7SUFBRTtJQUNuRDtLQUFFLE1BQU07S0FBUSxLQUFLLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLEVBQUU7SUFBRTtHQUNwRDtHQUNBLE9BQU8sU0FBUSxNQUFLLEtBQUssV0FBVyxFQUFFLE1BQU0sRUFBRSxHQUFHLENBQUM7RUFDcEQsT0FBTzs7R0FFTCxNQUFNLFNBQW9EO0lBQ3hEO0tBQUUsTUFBTTtLQUFRLEtBQUssSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUFFO0lBQ2pEO0tBQUUsTUFBTTtLQUFRLEtBQUssSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUM7SUFBRTtJQUNoRDtLQUFFLE1BQU07S0FBUyxLQUFLLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxHQUFHLENBQUM7SUFBRTtJQUNsRDtLQUFFLE1BQU07S0FBUyxLQUFLLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDO0lBQUU7SUFDakQ7S0FBRSxNQUFNO0tBQVUsS0FBSyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQUU7SUFDbkQ7S0FBRSxNQUFNO0tBQVEsS0FBSyxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQUU7SUFBRTtJQUNuRDtLQUFFLE1BQU07S0FBUSxLQUFLLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLEVBQUU7SUFBRTtJQUNsRDtLQUFFLE1BQU07S0FBUyxLQUFLLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRTtJQUFFO0lBQ3BEO0tBQUUsTUFBTTtLQUFTLEtBQUssSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsRUFBRTtJQUFFO0lBQ25EO0tBQUUsTUFBTTtLQUFVLEtBQUssSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQUU7SUFDckQ7S0FBRSxNQUFNO0tBQVUsS0FBSyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQUU7SUFDcEQ7S0FBRSxNQUFNO0tBQVMsS0FBSyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQUU7SUFDbkQ7S0FBRSxNQUFNO0tBQVEsS0FBSyxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQUU7SUFBRTtJQUNuRDtLQUFFLE1BQU07S0FBUSxLQUFLLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLEVBQUU7SUFBRTtHQUNwRDtHQUNBLE9BQU8sU0FBUSxNQUFLLEtBQUssV0FBVyxFQUFFLE1BQU0sRUFBRSxHQUFHLENBQUM7RUFDcEQ7OztFQUlBLE1BQU0sZUFBZSxPQUFPLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssUUFBUSxTQUFTLENBQUMsQ0FBQztFQUM5RSxhQUFhLFNBQVEsUUFBTztHQUMxQixNQUFNLFFBQVEsS0FBSyxRQUFRO0dBQzNCLElBQUksU0FBUyxDQUFDLE1BQU0sUUFBUTtJQUMxQixNQUFNLHVCQUF1QjtJQUM3QixNQUFNLGlCQUFpQixLQUFLLHdCQUF3QjtJQUNwRCxNQUFNLGVBQWUsU0FBUyxJQUM1QixNQUFNLElBQUksS0FBSyxTQUFTLEdBQ3hCLE1BQU0sSUFBSSxLQUFLLFNBQVMsSUFBSSxLQUM1QixNQUFNLElBQUksS0FBSyxTQUFTLENBQzFCO0lBQ0EsS0FBSyxNQUFNLElBQUksTUFBTSxjQUFjO0dBQ3JDO0VBQ0YsQ0FBQztDQUNIO0NBRUEsQUFBTyxXQUFXLE1BQWlCLEtBQW9CLFNBQVMsT0FBc0I7RUFDcEYsTUFBTSxNQUFNLEtBQUssYUFBYTs7RUFFOUIsTUFBTSxpQkFBaUIsS0FBTyxNQUFNLEtBQUs7RUFFekMsTUFBTSxNQUFNLGlCQUFpQixZQUMzQixNQUNBLFFBQ0EsS0FBSyxhQUFhLHFCQUFxQixVQUFVLFdBQVcsU0FDOUQ7RUFDQSxLQUFLLE1BQU0sSUFBSSxJQUFJLElBQUk7RUFDdkIsSUFBSSxLQUFLLFNBQVMsS0FBSyxHQUFHO0VBRTFCLElBQUksYUFBYTtFQUNqQixJQUFJLFlBQVk7RUFDaEIsSUFBSSxRQUFRO0VBQ1osSUFBSSxRQUFRO0VBRVosSUFBSSxTQUFTLFFBQVE7R0FDbkIsYUFBYTtHQUNiLFlBQVk7R0FDWixRQUFRLE1BQU8sTUFBTTtHQUNyQixRQUFRO0VBQ1YsT0FBTyxJQUFJLFNBQVMsU0FBUztHQUMzQixhQUFhO0dBQ2IsWUFBWTtHQUNaLFFBQVEsTUFBTyxNQUFNO0dBQ3JCLFFBQVE7RUFDVixPQUFPLElBQUksU0FBUyxVQUFVO0dBQzVCLGFBQWE7R0FDYixZQUFZO0dBQ1osUUFBUTtHQUNSLFFBQVE7RUFDVixPQUFPLElBQUksUUFBUTtHQUNqQixhQUFhLE1BQU0sTUFBTTtHQUN6QixZQUFZLEtBQUssTUFBTTtHQUN2QixRQUFRLE1BQU0sTUFBTTtHQUNwQixRQUFRO0VBQ1Y7RUFFQSxNQUFNLGNBQWMsS0FBSyxNQUFNLGFBQWEsY0FBYztFQUMxRCxNQUFNLGFBQWEsS0FBSyxNQUFNLFlBQVksY0FBYztFQUV4RCxNQUFNLFFBQXVCO0dBQzNCLElBQUksS0FBSztHQUNUO0dBQ0EsTUFBTSxTQUFTLEtBQUssYUFBYSxXQUFXLFNBQVMsS0FBSyxZQUFZO0dBQ3RFO0dBQ0E7R0FDQSxRQUFRO0dBQ1IsV0FBVztHQUNYLGFBQWE7R0FDYjtHQUNBO0dBQ0EsT0FBTztHQUNQLFlBQVksS0FBSyxPQUFPLElBQUk7R0FDNUIsZ0JBQWdCO0dBQ2hCLGNBQWM7R0FDZCxhQUFhLElBQUksTUFBTTtHQUN2QixXQUFXLElBQUksTUFBTTtHQUNyQixlQUFlO0VBQ2pCO0VBRUEsS0FBSyxRQUFRLEtBQUssS0FBSztFQUV2QixJQUFJLFFBQVE7R0FDVixLQUFLLGVBQWU7R0FDcEIsSUFBSSxLQUFLLG9CQUFvQjtJQUMzQixLQUFLLG1CQUFtQixNQUFNLFFBQVEsTUFBTSxXQUFXLE1BQU0sSUFBSTtHQUNuRTtFQUNGO0VBRUEsT0FBTztDQUNUOztDQUlBLEFBQU8sWUFBWSxVQUE4QjtFQUMvQyxPQUFPLE9BQU8sS0FBSyxPQUFPLFFBQVE7RUFFbEMsSUFBSSxTQUFTLFFBQVE7R0FDbkIsS0FBSyxjQUFjO0VBQ3JCO0VBQ0EsSUFBSSxTQUFTLGFBQWE7R0FDeEIsS0FBSyxpQkFBaUI7RUFDeEI7RUFDQSxJQUFJLFNBQVMsTUFBTTtHQUNqQixLQUFLLFlBQVk7RUFDbkI7RUFDQSxJQUFJLFNBQVMsT0FBTztHQUNsQixLQUFLLGFBQWE7RUFDcEI7RUFDQSxJQUFJLFNBQVMsU0FBUztHQUNwQixLQUFLLG9CQUFvQjtFQUMzQjtDQUNGO0NBRUEsQUFBTyxnQkFBZ0I7RUFDckIsSUFBSSxLQUFLLGVBQWUsQ0FBQyxLQUFLLFlBQVk7RUFFMUMsS0FBSyxjQUFjO0VBQ25CLEtBQUssbUJBQW9CLEtBQUssbUJBQW1CLElBQUs7RUFDdEQsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxjQUFjO0VBRW5CLE1BQU0sV0FBVyxTQUFTLEtBQUs7RUFDL0IsS0FBSyxVQUFVLGNBQWM7RUFDN0IsS0FBSyxVQUFVLGVBQWU7O0VBRzlCLGFBQWEsZUFBZSxLQUFLLGdCQUFnQjs7RUFHakQsTUFBTSxVQUFVLElBQUksTUFBTSxRQUN4QixLQUFLLElBQUksS0FBSyxjQUFjLEdBQzVCLEdBQ0EsS0FBSyxJQUFJLEtBQUssY0FBYyxDQUM5QjtFQUNBLEtBQUssZUFBZSxnQkFBZ0IsU0FBUyxHQUFHOztFQUdoRCxpQkFBaUI7R0FDZixLQUFLLDRCQUE0QixLQUFLLGdCQUFnQjtFQUN4RCxHQUFHLEdBQUc7O0VBR04saUJBQWlCO0dBQ2YsS0FBSyxjQUFjO0dBQ25CLElBQUksS0FBSyxVQUFVLFlBQVksV0FBVyxRQUFRLEdBQUc7SUFDbkQsS0FBSyxVQUFVLGNBQWM7R0FDL0I7RUFDRixHQUFHLE1BQU0sS0FBSyxjQUFjLEtBQUs7Q0FDbkM7Q0FFQSxBQUFPLG1CQUFtQjtFQUN4QixJQUFJLEtBQUssZUFBZSxDQUFDLEtBQUssWUFBWTtFQUUxQyxLQUFLLGNBQWM7RUFDbkIsS0FBSyxVQUFVLGNBQWM7RUFDN0IsS0FBSyxVQUFVLGVBQWU7RUFFOUIsYUFBYSxnQkFBZ0I7RUFFN0IsaUJBQWlCO0dBQ2YsS0FBSyx5QkFBeUI7RUFDaEMsR0FBRyxHQUFHO0VBRU4saUJBQWlCO0dBQ2YsS0FBSyxjQUFjO0dBQ25CLEtBQUssVUFBVSxjQUFjO0VBQy9CLEdBQUcsR0FBRztDQUNSO0NBRUEsQUFBTyxjQUFjO0VBQ25CLElBQUksQ0FBQyxLQUFLLGNBQWMsS0FBSyxhQUFhO0VBQzFDLEtBQUssYUFBYTtFQUNsQixLQUFLLGVBQWUsSUFBSTtFQUN4QixLQUFLLFVBQVUsY0FBYztDQUMvQjtDQUVBLEFBQU8sZUFBZTtFQUNwQixJQUFJLEtBQUssa0JBQWtCLEtBQUssYUFBYTtFQUU3QyxLQUFLLGlCQUFpQjtFQUN0QixLQUFLLHVCQUF1QjtFQUM1QixLQUFLLFVBQVUsY0FBYztFQUM3QixLQUFLLFVBQVUsZUFBZTtFQUU5QixhQUFhLGNBQWM7RUFDM0IsS0FBSyxVQUFVLGVBQWUsS0FBSyxXQUFXLFNBQVUsQ0FBQzs7RUFHekQsTUFBTSxVQUFVLElBQUksTUFBTSxRQUN4QixLQUFLLElBQUksS0FBSyxjQUFjLEdBQzVCLEdBQ0EsS0FBSyxJQUFJLEtBQUssY0FBYyxDQUM5QjtFQUNBLEtBQUssZUFBZSxLQUFLLFFBQVEsZUFBZSxFQUFFLENBQUM7RUFFbkQsaUJBQWlCO0dBQ2YsS0FBSyxVQUFVLGNBQWM7RUFDL0IsR0FBRyxHQUFHO0NBQ1I7Q0FFQSxBQUFPLHNCQUFzQjtFQUMzQixJQUFJLEtBQUssTUFBTSxrQkFBa0IsS0FBSyxLQUFLLGFBQWE7O0VBR3hELEtBQUssTUFBTSxrQkFBa0I7RUFDN0IsS0FBSyxZQUFZO0VBRWpCLEtBQUssY0FBYztFQUNuQixLQUFLLFVBQVUsY0FBYztFQUM3QixLQUFLLFVBQVUsZUFBZTtFQUU5QixhQUFhLGlCQUFpQjtFQUU5QixNQUFNLFVBQVUsSUFBSSxNQUFNLFFBQ3hCLEtBQUssSUFBSSxLQUFLLGNBQWMsR0FDNUIsR0FDQSxLQUFLLElBQUksS0FBSyxjQUFjLENBQzlCO0VBRUEsS0FBSyxVQUFVLHVCQUNiLEtBQUssV0FDTCxTQUNBLEtBQUssY0FBYyxZQUNuQixLQUFLLGNBQWMsU0FBUyxHQUM5QjtFQUNBLEtBQUssVUFBVSxlQUFlLEtBQUssV0FBVyxTQUFVLEVBQUU7RUFDMUQsS0FBSyxjQUFjO0VBRW5CLGlCQUFpQjtHQUNmLEtBQUssY0FBYztHQUNuQixLQUFLLFVBQVUsY0FBYztFQUMvQixHQUFHLEdBQUc7Q0FDUjs7Q0FJQSxBQUFRLDRCQUE0QixXQUFtQjtFQUNyRCxNQUFNLGNBQWMsS0FBSyxjQUFjLFNBQVMsY0FBYyxJQUFJLEtBQU07RUFDeEUsTUFBTSxVQUFVLElBQUksTUFBTSxRQUN4QixLQUFLLElBQUksS0FBSyxjQUFjLEdBQzVCLEdBQ0EsS0FBSyxJQUFJLEtBQUssY0FBYyxDQUM5QjtFQUVBLElBQUksU0FBUztFQUViLEtBQUssUUFBUSxTQUFRLFVBQVM7R0FDNUIsSUFBSSxNQUFNLFVBQVUsR0FBRztHQUV2QixNQUFNLFVBQVUsTUFBTSxJQUFJLEtBQUssU0FBUyxNQUFNLENBQUMsQ0FBQyxJQUFJLEtBQUssU0FBUztHQUNsRSxNQUFNLE9BQU8sUUFBUSxPQUFPO0dBRTVCLElBQUksUUFBUSxhQUFhO0lBQ3ZCLFFBQVEsVUFBVTtJQUNsQixNQUFNLE1BQU0sUUFBUSxJQUFJLE9BQU87O0lBRy9CLElBQUksTUFBTSxLQUFNO0tBQ2QsU0FBUztLQUNULEtBQUssbUJBQW1CLE9BQU8sU0FBUztJQUMxQztHQUNGO0VBQ0YsQ0FBQztFQUVELElBQUksUUFBUTtHQUNWLGFBQWEsZUFBZTtHQUM1QixLQUFLLGNBQWMsS0FBSyxJQUFJLEtBQUssYUFBYSxHQUFJO0VBQ3BEO0NBQ0Y7Q0FFQSxBQUFRLDJCQUEyQjtFQUNqQyxNQUFNLFVBQVUsSUFBSSxNQUFNLFFBQ3hCLEtBQUssSUFBSSxLQUFLLGNBQWMsR0FDNUIsR0FDQSxLQUFLLElBQUksS0FBSyxjQUFjLENBQzlCO0VBRUEsS0FBSyxRQUFRLFNBQVEsVUFBUztHQUM1QixJQUFJLE1BQU0sVUFBVSxHQUFHO0dBRXZCLE1BQU0sVUFBVSxNQUFNLElBQUksS0FBSyxTQUFTLE1BQU0sQ0FBQyxDQUFDLElBQUksS0FBSyxTQUFTO0dBQ2xFLE1BQU0sT0FBTyxRQUFRLE9BQU87R0FFNUIsSUFBSSxRQUFRLE9BQU8sUUFBUSxJQUFJLFFBQVEsVUFBVSxDQUFDLElBQUksSUFBSzs7SUFFekQsTUFBTSxTQUFTLE1BQU0sS0FBSyxZQUFZLGVBQWUsS0FBTSxLQUFLO0lBQ2hFLEtBQUssa0JBQWtCLE9BQU8sUUFBUSxNQUFNLENBQUM7SUFDN0MsYUFBYSxnQkFBZ0I7SUFDN0IsS0FBSyxjQUFjO0dBQ3JCO0VBQ0YsQ0FBQztDQUNIO0NBRUEsQUFBUSxtQkFBbUIsT0FBc0IsV0FBbUI7RUFDbEUsSUFBSSxVQUFVLEtBQUssY0FBYyxVQUFVLE1BQU8sWUFBWTtFQUM5RCxNQUFNLFNBQVMsS0FBSyxPQUFPLElBQUksS0FBSyxjQUFjO0VBQ2xELElBQUksUUFBUTtHQUNWLFdBQVc7RUFDYjtFQUVBLE1BQU0sWUFBWSxjQUFjLElBQUksSUFBSTtFQUN4QyxLQUFLLGtCQUFrQixPQUFPLEtBQUssTUFBTSxPQUFPLEdBQUcsUUFBUSxTQUFTOztFQUdwRSxLQUFLLE1BQU0sZ0JBQWdCLEtBQUssSUFDOUIsS0FBSyxNQUFNLFdBQ1gsS0FBSyxNQUFNLGlCQUFpQixLQUFLLGNBQWMsT0FBTyxrQkFBa0IsS0FBSyxHQUMvRTs7RUFHQSxLQUFLLE1BQU07RUFDWCxLQUFLLE1BQU0sYUFBYTtFQUN4QixLQUFLLFlBQVk7Q0FDbkI7Q0FFQSxBQUFPLGtCQUNMLE9BQ0EsUUFDQSxRQUNBLGdCQUNBO0VBQ0EsTUFBTSxTQUFTLEtBQUssSUFBSSxHQUFHLE1BQU0sU0FBUyxNQUFNOztFQUdoRCxJQUFJLE1BQU0sU0FBUyxHQUFHO0dBQ3BCLE1BQU0sSUFBSSxjQUFjO0dBQ3hCLE1BQU0sSUFBSSxlQUFlO0dBQ3pCLGlCQUFpQjtJQUNmLElBQUksTUFBTSxTQUFTLEtBQUssTUFBTSxJQUFJLGdCQUFnQixVQUFVO0tBQzFELE1BQU0sSUFBSSxjQUFjO0lBQzFCO0dBQ0YsR0FBRyxHQUFHO0VBQ1I7O0VBR0EsTUFBTSxXQUFXLE1BQU0sSUFBSSxLQUFLLFNBQVMsTUFBTSxDQUFDLENBQUMsSUFBSSxLQUFLLFNBQVMsQ0FBQyxDQUFDLFVBQVU7RUFDL0UsU0FBUyxJQUFJO0VBQ2IsTUFBTSxJQUFJLEtBQUssU0FBUyxnQkFBZ0IsVUFBVSxpQkFBaUIsR0FBSTs7RUFHdkUsS0FBSyxVQUFVLGVBQ2IsTUFBTSxJQUFJLEtBQUssVUFDZixTQUFTLFdBQVcsVUFDcEIsU0FBUyxLQUFLLENBQ2hCOztFQUdBLEtBQUssbUJBQ0gsTUFBTSxJQUFJLEtBQUssVUFDZixHQUFHLFNBQVMsV0FBVyxHQUFHLEdBQUcsVUFDN0IsU0FBUyxZQUFZLFdBQ3JCLE1BQ0Y7O0VBR0EsSUFBSSxNQUFNLFVBQVUsS0FBSyxvQkFBb0I7R0FDM0MsS0FBSyxtQkFBbUIsTUFBTSxRQUFRLE1BQU0sV0FBVyxNQUFNLElBQUk7RUFDbkU7O0VBR0EsSUFBSSxNQUFNLFVBQVUsS0FBSyxNQUFNLFVBQVUsUUFBUTtHQUMvQyxLQUFLLGlCQUFpQixLQUFLO0VBQzdCO0NBQ0Y7Q0FFQSxBQUFRLGlCQUFpQixPQUFzQjtFQUM3QyxNQUFNLFFBQVE7RUFDZCxNQUFNLElBQUksY0FBYztFQUN4QixNQUFNLGdCQUFnQjtFQUV0QixhQUFhLFNBQVM7RUFDdEIsS0FBSyxVQUFVLGVBQWUsTUFBTSxJQUFJLEtBQUssVUFBVSxTQUFVLEVBQUU7RUFFbkUsTUFBTSxhQUFhLE1BQU0sU0FBUyxNQUFPLE1BQU0sU0FBUyxVQUFVLEtBQUs7RUFDdkUsS0FBSyxNQUFNLFNBQVM7RUFDcEIsS0FBSyxNQUFNO0VBQ1gsS0FBSyxZQUFZOztFQUdqQixJQUFJLE1BQU0sc0JBQXNCO0dBQzlCLElBQUksTUFBTSxnQkFBZ0I7SUFDeEIsS0FBSyxNQUFNLE9BQU8sTUFBTSxjQUFjO0lBQ3RDLE1BQU0saUJBQWlCO0dBQ3pCO0dBQ0EsS0FBSyxrQkFBa0IsTUFBTSxJQUFJLEtBQUssVUFBVSxHQUFHO0dBQ25ELEtBQUssbUJBQ0gsTUFBTSxJQUFJLEtBQUssVUFDZiwwQkFDQSxXQUNBLElBQ0Y7RUFDRjs7RUFHQSxJQUFJLENBQUMsS0FBSyxlQUFlLEtBQUssTUFBTSxTQUFTLEtBQUssYUFBYSxhQUFhO0dBQzFFLEtBQUssVUFBVTtFQUNqQjs7RUFHQSxJQUFJLE1BQU0sUUFBUTtHQUNoQixLQUFLLGNBQWM7RUFDckI7Q0FDRjs7Ozs7Q0FNQSxBQUFPLDBCQUF1QztFQUM1QyxNQUFNLFFBQVEsSUFBSSxNQUFNLE1BQU07O0VBRzlCLE1BQU0sYUFBYSxJQUFJLE1BQU0sbUJBQW1CLEtBQU0sQ0FBQztFQUN2RCxNQUFNLGFBQWEsSUFBSSxNQUFNLHFCQUFxQjtHQUNoRCxPQUFPO0dBQ1AsVUFBVTtHQUNWLG1CQUFtQjtHQUNuQixXQUFXO0dBQ1gsV0FBVztFQUNiLENBQUM7RUFDRCxNQUFNLFVBQVUsSUFBSSxNQUFNLEtBQUssWUFBWSxVQUFVO0VBQ3JELFFBQVEsTUFBTSxJQUFJLElBQUssS0FBSyxFQUFHO0VBQy9CLFFBQVEsT0FBTztFQUNmLE1BQU0sSUFBSSxPQUFPOztFQUdqQixNQUFNLFlBQVksSUFBSSxNQUFNLFlBQVksS0FBTSxLQUFNLEdBQUk7RUFDeEQsTUFBTSxZQUFZLElBQUksTUFBTSxZQUFZLEtBQU0sS0FBTSxHQUFJO0VBQ3hELE1BQU0sV0FBVyxJQUFJLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxTQUFTLENBQUM7RUFDaEUsTUFBTSxTQUFTLElBQUksTUFBTSxLQUFLLFdBQVcsUUFBUTtFQUNqRCxNQUFNLFNBQVMsSUFBSSxNQUFNLEtBQUssV0FBVyxRQUFRO0VBQ2pELE1BQU0sSUFBSSxNQUFNO0VBQ2hCLE1BQU0sSUFBSSxNQUFNOztFQUdoQixNQUFNLFVBQVUsSUFBSSxNQUFNLGNBQWMsSUFBSyxNQUFPLEdBQUcsRUFBRTtFQUN6RCxNQUFNLFVBQVUsSUFBSSxNQUFNLGtCQUFrQjtHQUFFLE9BQU87R0FBVSxXQUFXO0VBQUssQ0FBQztFQUNoRixNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0VBQzVDLEtBQUssU0FBUyxJQUFJLEtBQUssS0FBSztFQUM1QixLQUFLLE9BQU87RUFDWixNQUFNLElBQUksSUFBSTs7RUFHZCxNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7RUFDOUMsT0FBTyxRQUFRO0VBQ2YsT0FBTyxTQUFTO0VBQ2hCLE1BQU0sTUFBTSxPQUFPLFdBQVcsSUFBSTtFQUNsQyxJQUFJLEtBQUs7R0FDUCxJQUFJLFlBQVk7R0FDaEIsSUFBSSxTQUFTLEdBQUcsR0FBRyxLQUFLLEVBQUU7R0FDMUIsSUFBSSxZQUFZO0dBQ2hCLElBQUksY0FBYztHQUNsQixJQUFJLFdBQVcsR0FBRyxHQUFHLEtBQUssRUFBRTtHQUU1QixJQUFJLFlBQVk7R0FDaEIsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksZUFBZTtHQUNuQixJQUFJLFNBQVMsYUFBYSxLQUFLLEVBQUU7RUFDbkM7RUFDQSxNQUFNLFVBQVUsSUFBSSxNQUFNLGNBQWMsTUFBTTtFQUM5QyxNQUFNLFlBQVksSUFBSSxNQUFNLGVBQWU7R0FDekMsS0FBSztHQUNMLGFBQWE7R0FDYixXQUFXO0VBQ2IsQ0FBQztFQUNELE1BQU0sU0FBUyxJQUFJLE1BQU0sT0FBTyxTQUFTO0VBQ3pDLE9BQU8sTUFBTSxJQUFJLEtBQUssS0FBTSxDQUFDO0VBQzdCLE9BQU8sU0FBUyxJQUFJO0VBQ3BCLE9BQU8sT0FBTztFQUNkLE1BQU0sSUFBSSxNQUFNOztFQUdoQixNQUFNLFFBQVEsSUFBSSxNQUFNLFdBQVcsU0FBVSxLQUFLLENBQUM7RUFDbkQsTUFBTSxTQUFTLElBQUksR0FBRyxHQUFHLENBQUM7RUFDMUIsTUFBTSxJQUFJLEtBQUs7RUFFZixPQUFPO0NBQ1Q7Ozs7Q0FLQSxBQUFPLGtCQUFrQixLQUFvQixZQUFvQjtFQUMvRCxNQUFNLFFBQVEsSUFBSSxNQUFNLE1BQU07O0VBRzlCLE1BQU0sVUFBVSxJQUFJLE1BQU0scUJBQXFCLEtBQU0sQ0FBQztFQUN0RCxNQUFNLFVBQVUsSUFBSSxNQUFNLHFCQUFxQjtHQUM3QyxPQUFPO0dBQ1AsVUFBVTtHQUNWLG1CQUFtQjtHQUNuQixXQUFXO0dBQ1gsV0FBVztFQUNiLENBQUM7RUFDRCxNQUFNLFdBQVcsSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0VBQ2hELE1BQU0sSUFBSSxRQUFROztFQUdsQixNQUFNLFVBQVUsSUFBSSxNQUFNLGNBQWMsS0FBTSxLQUFNLEdBQUcsRUFBRTtFQUN6RCxNQUFNLFVBQVUsSUFBSSxNQUFNLGtCQUFrQjtHQUMxQyxPQUFPO0dBQ1AsV0FBVztFQUNiLENBQUM7RUFDRCxNQUFNLFdBQVcsSUFBSSxNQUFNLEtBQUssU0FBUyxPQUFPO0VBQ2hELFNBQVMsU0FBUyxJQUFJLEtBQUssS0FBSztFQUNoQyxNQUFNLElBQUksUUFBUTs7RUFHbEIsTUFBTSxRQUFRLElBQUksTUFBTSxXQUFXLFNBQVUsR0FBSyxDQUFDO0VBQ25ELE1BQU0sU0FBUyxJQUFJLEdBQUcsR0FBRyxDQUFDO0VBQzFCLE1BQU0sSUFBSSxLQUFLOztFQUdmLE1BQU0sV0FBVyxJQUFJLE1BQU07RUFDM0IsU0FBUyxJQUFJO0VBQ2IsTUFBTSxTQUFTLEtBQUssUUFBUTtFQUM1QixLQUFLLE1BQU0sSUFBSSxLQUFLO0VBRXBCLEtBQUssYUFBYSxLQUFLO0dBQ3JCLElBQUksS0FBSztHQUNULE1BQU07R0FDTjtHQUNBLFVBQVU7R0FDVixPQUFPO0dBQ1AsU0FBUyxLQUFLLE9BQU8sSUFBSSxLQUFLO0VBQ2hDLENBQUM7Q0FDSDtDQUVBLEFBQVEsWUFBWTtFQUNsQixLQUFLLGNBQWM7RUFDbkIsYUFBYSxlQUFlO0VBQzVCLE1BQU0sVUFBVSxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0VBQzNDLEtBQUssV0FBVyxRQUFRLFNBQVMsSUFBSTtFQUNyQyxLQUFLLGNBQWM7Q0FDckI7Q0FFQSxBQUFRLGdCQUFnQjtFQUN0QixhQUFhLGdCQUFnQjtFQUM3QixLQUFLLFVBQVUsY0FBYzs7RUFHN0IsSUFBSSxRQUFRO0VBQ1osSUFBSSxLQUFLLE1BQU0sZ0JBQWdCLElBQUksUUFBUTtFQUMzQyxJQUFJLEtBQUssTUFBTSxnQkFBZ0IsTUFBTSxLQUFLLE1BQU0sY0FBYyxHQUFHLFFBQVE7RUFFekUsaUJBQWlCO0dBQ2YsSUFBSSxLQUFLLFdBQVc7SUFDbEIsS0FBSyxVQUFVLEtBQUssYUFBYSxhQUFhLEtBQUs7R0FDckQ7RUFDRixHQUFHLElBQUk7Q0FDVDtDQUVBLEFBQU8sYUFBYSxRQUFnQixhQUE0QjtFQUM5RCxJQUFJLEtBQUssa0JBQWtCLEtBQUssTUFBTSxpQkFBaUIsR0FBRzs7RUFHMUQsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyx1QkFBdUI7O0VBRzVCLE1BQU0sY0FBYyxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sU0FBUyxRQUFRLElBQUksS0FBSyxZQUFZLGFBQWEsQ0FBQztFQUNoRyxLQUFLLE1BQU0sZ0JBQWdCLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxnQkFBZ0IsV0FBVzs7RUFHN0UsS0FBSyxVQUFVLGNBQWM7RUFDN0IsS0FBSyxVQUFVLGVBQWU7RUFDOUIsYUFBYSxnQkFBZ0I7RUFDN0IsS0FBSyxjQUFjO0VBRW5CLEtBQUssVUFBVSxlQUFlLEtBQUssV0FBVyxVQUFVLEVBQUU7RUFFMUQsS0FBSyxtQkFDSCxLQUFLLFdBQ0wsSUFBSSxlQUNKLFdBQ0EsS0FDRjs7RUFHQSxNQUFNLFdBQVcsS0FBSyxVQUFVLE1BQU0sQ0FBQyxDQUFDLElBQUksV0FBVyxDQUFDLENBQUMsVUFBVTtFQUNuRSxTQUFTLElBQUk7RUFDYixLQUFLLGVBQWUsZ0JBQWdCLFVBQVUsQ0FBQztFQUUvQyxLQUFLLFlBQVk7RUFFakIsSUFBSSxLQUFLLE1BQU0saUJBQWlCLEdBQUc7R0FDakMsS0FBSyxrQkFBa0I7RUFDekIsT0FBTztHQUNMLGlCQUFpQjtJQUNmLElBQUksS0FBSyxVQUFVLGdCQUFnQixVQUFVO0tBQzNDLEtBQUssVUFBVSxjQUFjO0lBQy9CO0dBQ0YsR0FBRyxHQUFHO0VBQ1I7Q0FDRjtDQUVBLEFBQVEsb0JBQW9CO0VBQzFCLEtBQUssVUFBVSxjQUFjO0VBQzdCLGFBQWEsYUFBYTtFQUMxQixpQkFBaUI7R0FDZixJQUFJLEtBQUssWUFBWTtJQUNuQixLQUFLLFdBQVc7R0FDbEI7RUFDRixHQUFHLElBQUk7Q0FDVDtDQUVBLEFBQVEsbUJBQW1CLEtBQW9CLE1BQWMsT0FBZSxRQUFpQjs7RUFFM0YsTUFBTSxJQUFJLElBQUksTUFBTTtFQUNwQixFQUFFLEtBQUs7RUFDUCxFQUFFLFFBQVEsS0FBSyxNQUFNO0VBRXJCLE1BQU0sS0FBSyxFQUFFLElBQUksS0FBTSxNQUFPLEtBQUssVUFBVTtFQUM3QyxNQUFNLEtBQUssQ0FBQyxFQUFFLElBQUksS0FBTSxNQUFPLEtBQUssVUFBVTtFQUU5QyxJQUFJLEtBQUssa0JBQWtCO0dBQ3pCLEtBQUssaUJBQWlCO0lBQ3BCLElBQUksS0FBSyxPQUFPO0lBQ2hCO0lBQ0E7SUFDQTtJQUNBLFNBQVM7SUFDVCxTQUFTO0lBQ1QsU0FBUztJQUNULE9BQU8sU0FBUyxNQUFNO0dBQ3hCLENBQUM7RUFDSDtDQUNGO0NBRUEsQUFBTyxjQUFjO0VBQ25CLElBQUksS0FBSyxlQUFlO0dBQ3RCLEtBQUssY0FBYyxFQUFFLEdBQUcsS0FBSyxNQUFNLENBQUM7RUFDdEM7Q0FDRjtDQTJCQSxBQUFRLFVBQVUsSUFBZ0I7RUFDaEMsTUFBTSxLQUFLLEtBQUssU0FBUyxXQUFXO0VBQ3BDLE1BQU0sT0FBTyxHQUFHLFVBQVUsR0FBRyw0QkFBNEIsQ0FBQztFQUMxRCxHQUFHLE1BQU07RUFDVCxNQUFNLGFBQWE7R0FDakIsTUFBTSxRQUFRLFFBQVEsR0FBRyxpQkFBaUIsTUFBTSxHQUFHLFdBQVc7R0FDOUQsSUFBSSxVQUFVLEdBQUcsWUFBWTtJQUMzQixLQUFLLGNBQWMsT0FBTyxXQUFXLE1BQU0sQ0FBQztHQUM5QyxPQUFPO0lBQ0wsSUFBSSxNQUFNLEdBQUcsV0FBVyxJQUFJO0lBQzVCLEtBQUssY0FBYyxPQUFPLFdBQVcsSUFBSSxFQUFFO0dBQzdDO0VBQ0Y7RUFDQSxLQUFLLGNBQWMsT0FBTyxXQUFXLE1BQU0sQ0FBQztDQUM5QztDQUVBLEFBQVEsbUJBQW1CLE9BQWU7RUFDeEMsS0FBSyxJQUFJLElBQUksS0FBSyxhQUFhLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztHQUN0RCxNQUFNLE9BQU8sS0FBSyxhQUFhO0dBQy9CLEtBQUssV0FBVzs7R0FHaEIsS0FBSyxLQUFLLFNBQVMsS0FBSyxRQUFRO0dBQ2hDLElBQUksS0FBSyxLQUFLLFNBQVMsU0FBUyxHQUFHO0lBQ2pDLEtBQUssS0FBSyxTQUFTLEVBQUUsQ0FBQyxTQUFTLEtBQUssUUFBUTtHQUM5QztHQUNBLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxRQUFRLEtBQUssSUFBSSxLQUFLLFVBQVUsR0FBRyxJQUFJOztHQUduRSxNQUFNLE9BQU8sS0FBSyxVQUFVLFdBQVcsS0FBSyxLQUFLLFFBQVE7O0dBR3pELElBQUksT0FBTyxLQUFLO0lBQ2QsTUFBTSxTQUFTLEtBQUssVUFBVSxNQUFNO0lBQ3BDLE9BQU8sS0FBSztJQUNaLEtBQUssS0FBSyxTQUFTLEtBQUssUUFBUSxRQUFRLENBQUc7R0FDN0M7O0dBR0EsSUFBSSxPQUFPLEtBQUs7O0lBRWQsS0FBSyxNQUFNLGdCQUFnQixLQUFLLElBQUksS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLGdCQUFnQixLQUFLLFVBQVU7SUFFcEcsYUFBYSxpQkFBaUI7SUFDOUIsS0FBSyxVQUFVLGVBQWUsS0FBSyxXQUFXLFNBQVUsRUFBRTtJQUUxRCxLQUFLLG1CQUNILEtBQUssV0FDTCxJQUFJLEtBQUssV0FBVyxTQUNwQixXQUNBLElBQ0Y7SUFFQSxLQUFLLFlBQVk7O0lBR2pCLEtBQUssTUFBTSxPQUFPLEtBQUssSUFBSTtJQUMzQixLQUFLLGFBQWEsT0FBTyxHQUFHLENBQUM7R0FDL0I7RUFDRjtDQUNGO0NBRUEsQUFBUSxhQUFhLE9BQWU7RUFDbEMsSUFBSSxLQUFLLE1BQU0saUJBQWlCLEdBQUc7O0VBR25DLElBQUksS0FBSyxnQkFBZ0I7R0FDdkIsS0FBSyx3QkFBd0I7R0FDN0IsSUFBSSxLQUFLLHdCQUF3QixHQUFHO0lBQ2xDLEtBQUssaUJBQWlCO0dBQ3hCO0VBQ0Y7O0VBR0EsSUFBSSxLQUFLLE1BQU0sZ0JBQWdCLEtBQUssTUFBTSxXQUFXO0dBQ25ELEtBQUssTUFBTSxnQkFBZ0IsS0FBSyxJQUFJLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxnQkFBZ0IsUUFBUSxHQUFHO0VBQ2xHOztFQUdBLElBQUksS0FBSyxNQUFNLGtCQUFrQixHQUFHO0dBQ2xDLE1BQU0sVUFBVSxLQUFLLEtBQUssS0FBSyxNQUFNLGVBQWU7R0FDcEQsS0FBSyxNQUFNLGtCQUFrQixLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sa0JBQWtCLEtBQUs7R0FDM0UsTUFBTSxTQUFTLEtBQUssS0FBSyxLQUFLLE1BQU0sZUFBZTtHQUNuRCxJQUFJLFlBQVksVUFBVSxLQUFLLE1BQU0sb0JBQW9CLEdBQUc7SUFDMUQsS0FBSyxZQUFZO0dBQ25CO0VBQ0Y7O0VBR0EsSUFBSSxLQUFLLG1CQUFtQixHQUFHO0dBQzdCLEtBQUssb0JBQW9CO0dBQ3pCLElBQUksS0FBSyxvQkFBb0IsR0FBRztJQUM5QixLQUFLLG1CQUFtQjtHQUMxQjtFQUNGO0VBRUEsSUFBSSxLQUFLLE1BQU0sYUFBYSxHQUFHO0dBQzdCLEtBQUssTUFBTSxjQUFjO0dBQ3pCLElBQUksS0FBSyxNQUFNLGNBQWMsR0FBRztJQUM5QixLQUFLLE1BQU0sYUFBYTtJQUN4QixLQUFLLFlBQVk7R0FDbkI7RUFDRjs7RUFHQSxNQUFNLEtBQUssS0FBSyxNQUFNO0VBQ3RCLE1BQU0sS0FBSyxLQUFLLE1BQU07RUFDdEIsTUFBTSxXQUFXLEtBQUssSUFBSSxFQUFFLElBQUksT0FBUSxLQUFLLElBQUksRUFBRSxJQUFJO0VBRXZELElBQUksWUFBWSxDQUFDLEtBQUssZUFBZSxLQUFLLFVBQVUsZ0JBQWdCLFNBQVM7R0FDM0UsTUFBTSxZQUFhLElBQU0sS0FBSyxZQUFZLGFBQWE7O0dBR3ZELE1BQU0sYUFBYSxJQUFJLE1BQU0sUUFBUTtHQUNyQyxLQUFLLE9BQU8sa0JBQWtCLFVBQVU7R0FDeEMsV0FBVyxJQUFJO0dBQ2YsV0FBVyxVQUFVOztHQUdyQixNQUFNLFdBQVcsSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixLQUFLLE9BQU8sVUFBVTtHQUNsRixTQUFTLElBQUk7R0FDYixTQUFTLFVBQVU7O0dBR25CLE1BQU0sVUFBVSxJQUFJLE1BQU0sUUFBUSxDQUFDLENBQ2hDLGdCQUFnQixVQUFVLEVBQUUsQ0FBQyxDQUM3QixnQkFBZ0IsWUFBWSxFQUFFO0dBRWpDLElBQUksUUFBUSxTQUFTLElBQUksTUFBTztJQUM5QixRQUFRLFVBQVU7R0FDcEI7R0FFQSxNQUFNLGFBQWEsUUFBUSxJQUFJO0dBQy9CLE1BQU0sYUFBYSxRQUFRLElBQUk7R0FFL0IsS0FBSyxlQUFlLElBQUksTUFBTSxVQUFVLEtBQUssS0FBSyxlQUFlLEdBQUcsWUFBWSxJQUFJLEtBQUs7R0FDekYsS0FBSyxlQUFlLElBQUksTUFBTSxVQUFVLEtBQUssS0FBSyxlQUFlLEdBQUcsWUFBWSxJQUFJLEtBQUs7O0dBR3pGLEtBQUssaUJBQWlCLEtBQUssTUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDO0dBQ3JELEtBQUssVUFBVSxLQUFLLFNBQVMsSUFBSSxLQUFLO0dBRXRDLElBQUksS0FBSyxjQUFjLEtBQUssVUFBVSxnQkFBZ0IsT0FBTztJQUMzRCxLQUFLLFVBQVUsY0FBYztHQUMvQjtFQUNGLE9BQU8sSUFBSSxLQUFLLGNBQWMsQ0FBQyxLQUFLLGVBQWUsS0FBSyxVQUFVLGdCQUFnQixTQUFTO0dBQ3pGLEtBQUssZUFBZSxJQUFJLE1BQU0sVUFBVSxLQUFLLEtBQUssZUFBZSxHQUFHLEdBQUcsSUFBSSxLQUFLO0dBQ2hGLEtBQUssZUFBZSxJQUFJLE1BQU0sVUFBVSxLQUFLLEtBQUssZUFBZSxHQUFHLEdBQUcsSUFBSSxLQUFLO0dBRWhGLElBQUksS0FBSyxVQUFVLGdCQUFnQixPQUFPO0lBQ3hDLEtBQUssVUFBVSxjQUFjO0dBQy9CO0VBQ0Y7O0VBR0EsSUFBSSxDQUFDLEtBQUssWUFBWTtHQUNwQixLQUFLLGVBQWUsS0FBSyxLQUFPO0dBQ2hDLEtBQUssVUFBVSxLQUFLLEtBQUssZUFBZSxJQUFJO0dBRTVDLElBQUksS0FBSyxVQUFVLEtBQUssR0FBRztJQUN6QixLQUFLLFVBQVUsSUFBSTtJQUNuQixLQUFLLGVBQWUsSUFBSTtJQUN4QixLQUFLLGFBQWE7SUFDbEIsS0FBSyxVQUFVLGNBQWMsV0FBVyxRQUFRO0dBQ2xEO0VBQ0Y7O0VBR0EsS0FBSyxVQUFVLEtBQUssS0FBSyxlQUFlLElBQUk7RUFDNUMsS0FBSyxVQUFVLEtBQUssS0FBSyxlQUFlLElBQUk7O0VBRzVDLE1BQU0sV0FBVztFQUNqQixLQUFLLFVBQVUsSUFBSSxNQUFNLFVBQVUsTUFBTSxLQUFLLFVBQVUsR0FBRyxDQUFDLFVBQVUsUUFBUTtFQUM5RSxLQUFLLFVBQVUsSUFBSSxNQUFNLFVBQVUsTUFBTSxLQUFLLFVBQVUsR0FBRyxDQUFDLFVBQVUsUUFBUTtFQUU5RSxLQUFLLFVBQVUsS0FBSyxTQUFTLEtBQUssS0FBSyxTQUFTOztFQUdoRCxJQUFJLEtBQUssZUFBZSxLQUFLLFVBQVUsZ0JBQWdCLFdBQVcsS0FBSyxVQUFVLGdCQUFnQixVQUFVLEtBQUssVUFBVSxnQkFBZ0IsVUFBVTtHQUNsSixLQUFLLFVBQVUsZUFBZSxLQUFLLElBQUksR0FBSyxLQUFLLFVBQVUsZUFBZSxRQUFRLEdBQUc7RUFDdkY7RUFDQSxpQkFBaUIsZ0JBQWdCLEtBQUssV0FBVyxLQUFLO0NBQ3hEO0NBRUEsQUFBUSxjQUFjLE9BQWU7RUFDbkMsS0FBSyxJQUFJLElBQUksS0FBSyxRQUFRLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztHQUNqRCxNQUFNLFFBQVEsS0FBSyxRQUFRO0dBRTNCLElBQUksTUFBTSxVQUFVLFFBQVE7SUFDMUIsSUFBSSxNQUFNLGdCQUFnQjtLQUN4QixLQUFLLE1BQU0sT0FBTyxNQUFNLGNBQWM7S0FDdEMsTUFBTSxpQkFBaUI7SUFDekI7SUFDQSxNQUFNLGlCQUFpQjtJQUN2QixpQkFBaUIsZ0JBQWdCLE1BQU0sS0FBSyxLQUFLO0lBRWpELElBQUksTUFBTSxpQkFBaUIsR0FBRztLQUM1QixLQUFLLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtLQUNoQyxLQUFLLFFBQVEsT0FBTyxHQUFHLENBQUM7SUFDMUI7SUFDQTtHQUNGO0dBRUEsTUFBTSxrQkFBa0I7R0FDeEIsTUFBTSxXQUFXLEtBQUssVUFBVSxNQUFNLENBQUMsQ0FBQyxJQUFJLE1BQU0sSUFBSSxLQUFLLFFBQVE7R0FDbkUsTUFBTSxlQUFlLFNBQVMsT0FBTzs7R0FHckMsSUFBSSxlQUFlLElBQUk7O0lBRXJCLE1BQU0sUUFBUTtJQUNkLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSyxVQUFVLEdBQUcsTUFBTSxJQUFJLEtBQUssU0FBUyxHQUFHLEtBQUssVUFBVSxDQUFDO0lBRW5GLElBQUksZUFBZSxNQUFNLE9BQU87O0tBRTlCLE1BQU0sVUFBVSxTQUFTLE1BQU0sQ0FBQyxDQUFDLFVBQVU7S0FDM0MsTUFBTSxJQUFJLEtBQUssU0FBUyxnQkFBZ0IsU0FBUyxNQUFNLFFBQVEsS0FBSztLQUNwRSxJQUFJLE1BQU0sSUFBSSxnQkFBZ0IsT0FBTztNQUNuQyxNQUFNLElBQUksY0FBYztLQUMxQjtJQUNGLE9BQU87O0tBRUwsSUFBSSxNQUFNLGtCQUFrQixHQUFHO01BQzdCLEtBQUssbUJBQW1CLEtBQUs7S0FDL0IsT0FBTztNQUNMLE1BQU0sSUFBSSxjQUFjO0tBQzFCO0lBQ0Y7R0FDRixPQUFPOztJQUVMLE1BQU0sUUFBUTtJQUNkLE1BQU0sSUFBSSxjQUFjO0dBQzFCO0dBRUEsaUJBQWlCLGdCQUFnQixNQUFNLEtBQUssS0FBSzs7R0FHakQsSUFBSSxNQUFNLHdCQUF3QixNQUFNLGdCQUFnQjtJQUN0RCxNQUFNLE9BQU8sWUFBWSxJQUFJLElBQUk7SUFDakMsTUFBTSxlQUFlLFNBQVMsSUFDNUIsTUFBTSxJQUFJLEtBQUssU0FBUyxHQUN4QixNQUFNLElBQUksS0FBSyxTQUFTLElBQUksTUFBTSxLQUFLLElBQUksT0FBTyxDQUFDLElBQUksSUFDdkQsTUFBTSxJQUFJLEtBQUssU0FBUyxDQUMxQjtJQUNBLE1BQU0sVUFBVSxNQUFNLGVBQWUsZ0JBQWdCLGVBQWU7SUFDcEUsSUFBSSxTQUFTLFFBQVEsU0FBUyxLQUFLLFFBQVE7SUFDM0MsTUFBTSxPQUFPLE1BQU0sZUFBZSxnQkFBZ0IsWUFBWTtJQUM5RCxJQUFJLE1BQU0sS0FBSyxTQUFTLEtBQUssUUFBUTtHQUN2QztFQUNGO0NBQ0Y7Q0FFQSxBQUFRLG1CQUFtQixPQUFzQjtFQUMvQyxNQUFNLGlCQUFpQixNQUFNLFNBQVMsTUFBTyxNQUFNLFNBQVMsU0FBUyxNQUFNO0VBQzNFLE1BQU0sSUFBSSxjQUFjO0VBQ3hCLE1BQU0sSUFBSSxlQUFlO0VBRXpCLElBQUksTUFBTSxTQUFTLFVBQVU7R0FDM0IsYUFBYSxlQUFlO0dBQzVCLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxDQUFDLENBQUMsSUFBSSxNQUFNLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxVQUFVO0dBQzFFLEtBQUssVUFBVSxXQUFXLE1BQU0sSUFBSSxLQUFLLFVBQVUsS0FBSyxNQUFNLFdBQVc7RUFDM0UsT0FBTztHQUNMLGFBQWEsZUFBZTs7R0FHNUIsaUJBQWlCO0lBQ2YsSUFBSSxNQUFNLFNBQVMsR0FBRztLQUNwQixNQUFNLE9BQU8sS0FBSyxVQUFVLFdBQVcsTUFBTSxJQUFJLEtBQUssUUFBUTtLQUM5RCxJQUFJLFFBQVEsTUFBTSxRQUFRLElBQUs7TUFDN0IsS0FBSyxhQUFhLE1BQU0sYUFBYSxNQUFNLElBQUksS0FBSyxRQUFRO0tBQzlEO0lBQ0Y7R0FDRixHQUFHLEdBQUc7RUFDUjtDQUNGO0NBRUEsQUFBUSxrQkFBa0IsT0FBZTtFQUN2QyxLQUFLLFVBQVUsWUFBWSxTQUFTLE1BQU0sUUFBUTs7R0FFaEQsSUFBSSxDQUFDLEtBQUssWUFBWTtJQUNwQixNQUFNLE9BQU8sS0FBSyxLQUFLLFNBQVMsV0FBVyxLQUFLLFNBQVM7SUFDekQsSUFBSSxPQUFPLEtBQUs7S0FDZCxLQUFLLGFBQWEsS0FBSyxRQUFRLEtBQUssS0FBSyxRQUFRO0tBQ2pELEtBQUssTUFBTSxPQUFPLEtBQUssSUFBSTtLQUMzQixLQUFLLFVBQVUsWUFBWSxPQUFPLEtBQUssQ0FBQztJQUMxQztHQUNGLE9BQU87O0lBRUwsS0FBSyxRQUFRLFNBQVEsVUFBUztLQUM1QixJQUFJLE1BQU0sVUFBVSxHQUFHO0tBQ3ZCLE1BQU0sT0FBTyxLQUFLLEtBQUssU0FBUyxXQUFXLE1BQU0sSUFBSSxLQUFLLFFBQVE7S0FDbEUsSUFBSSxPQUFPLEtBQUs7TUFDZCxLQUFLLGtCQUFrQixPQUFPLEtBQUssUUFBUSxNQUFNLENBQUM7TUFDbEQsYUFBYSxlQUFlO0tBQzlCO0lBQ0YsQ0FBQztHQUNIO0VBQ0YsQ0FBQztDQUNIO0NBRUEsQUFBUSxhQUFhLE9BQWU7O0VBRWxDLElBQUksS0FBSyxNQUFNLGtCQUFrQixHQUFHO0dBQ2xDLEtBQUssZ0JBQWdCLEtBQUssTUFBTSxnQkFBZ0IsUUFBUTtFQUMxRDtFQUNBLElBQUksS0FBSyxNQUFNLGtCQUFrQixHQUFHO0dBQ2xDLEtBQUssZUFBZSxNQUFNLFVBQVUsTUFDbEMsS0FBSyxlQUFlLEtBQUssTUFBTSxnQkFBZ0IsUUFBUSxLQUN2RCxJQUNBLEVBQ0Y7RUFDRjs7RUFHQSxNQUFNLFVBQVUsS0FBSyxJQUFJLEtBQUssWUFBWSxJQUFJLEtBQUssSUFBSSxLQUFLLFlBQVksSUFBSSxLQUFLO0VBQ2pGLE1BQU0sVUFBVSxLQUFLLElBQUksS0FBSyxZQUFZLElBQUksS0FBSyxJQUFJLEtBQUssWUFBWSxJQUFJLEtBQUs7RUFDakYsTUFBTSxVQUFVLEtBQUssSUFBSSxLQUFLLFlBQVksSUFBSSxLQUFLLGlCQUFpQjtFQUVwRSxNQUFNLGVBQWUsSUFBSSxNQUFNLFFBQzdCLEtBQUssVUFBVSxJQUFJLFNBQ25CLEtBQUssVUFBVSxJQUFJLFNBQ25CLEtBQUssVUFBVSxJQUFJLE9BQ3JCOztFQUdBLElBQUksS0FBSyxjQUFjLEdBQUc7R0FDeEIsYUFBYSxNQUFNLEtBQUssT0FBTyxJQUFJLE1BQU8sS0FBSztHQUMvQyxhQUFhLE1BQU0sS0FBSyxPQUFPLElBQUksTUFBTyxLQUFLO0dBQy9DLEtBQUssY0FBYyxLQUFLLElBQUksR0FBRyxLQUFLLGNBQWMsUUFBUSxHQUFHO0VBQy9EOztFQUdBLEtBQUssT0FBTyxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssS0FBSyxPQUFPLFNBQVMsR0FBRyxhQUFhLEdBQUcsSUFBSSxLQUFLO0VBQy9GLEtBQUssT0FBTyxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssS0FBSyxPQUFPLFNBQVMsR0FBRyxhQUFhLEdBQUcsSUFBSSxLQUFLO0VBQy9GLEtBQUssT0FBTyxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssS0FBSyxPQUFPLFNBQVMsR0FBRyxhQUFhLEdBQUcsSUFBSSxLQUFLOztFQUcvRixNQUFNLGFBQWEsSUFBSSxNQUFNLFFBQVEsS0FBSyxVQUFVLEdBQUcsS0FBSyxVQUFVLElBQUksS0FBSyxLQUFLLFVBQVUsQ0FBQztFQUMvRixLQUFLLE9BQU8sT0FBTyxVQUFVO0NBQy9CO0NBWUEsQUFBTyxRQUFRO0VBQ2IsS0FBSyxXQUFXO0NBQ2xCO0NBRUEsQUFBTyxTQUFTO0VBQ2QsS0FBSyxXQUFXO0NBQ2xCO0NBRUEsQUFBTyxVQUFVO0VBQ2YsS0FBSyxZQUFZO0VBQ2pCLGFBQWEsUUFBUTtFQUNyQixPQUFPLG9CQUFvQixVQUFVLEtBQUssWUFBWTtFQUN0RCxxQkFBcUIsS0FBSyxXQUFXO0VBQ3JDLGFBQWEsS0FBSyxXQUFXO0VBRTdCLEtBQUssYUFBYSxTQUFRLE1BQUs7R0FDN0IsS0FBSyxNQUFNLE9BQU8sRUFBRSxJQUFJO0VBQzFCLENBQUM7RUFDRCxLQUFLLGVBQWUsQ0FBQztFQUVyQixLQUFLLFFBQVEsU0FBUSxNQUFLO0dBQ3hCLElBQUksRUFBRSxnQkFBZ0I7SUFDcEIsS0FBSyxNQUFNLE9BQU8sRUFBRSxjQUFjO0dBQ3BDO0VBQ0YsQ0FBQztFQUVELEtBQUssVUFBVSxRQUFRO0VBQ3ZCLEtBQUssU0FBUyxRQUFRO0VBQ3RCLElBQUksS0FBSyxhQUFhLEtBQUssU0FBUyxZQUFZO0dBQzlDLEtBQUssVUFBVSxZQUFZLEtBQUssU0FBUyxVQUFVO0VBQ3JEO0NBQ0Y7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJHYW1lRW5naW5lLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0ICogYXMgVEhSRUUgZnJvbSAndGhyZWUnO1xuaW1wb3J0IHsgUm9vbUVudmlyb25tZW50IH0gZnJvbSAndGhyZWUvZXhhbXBsZXMvanNtL2Vudmlyb25tZW50cy9Sb29tRW52aXJvbm1lbnQuanMnO1xuaW1wb3J0IHsgQ2hhcmFjdGVyRmFjdG9yeSwgQ2hhcmFjdGVyUmlnIH0gZnJvbSAnLi9DaGFyYWN0ZXJNb2RlbHMnO1xuaW1wb3J0IHsgRW52aXJvbm1lbnRCdWlsZGVyIH0gZnJvbSAnLi9FbnZpcm9ubWVudEJ1aWxkZXInO1xuaW1wb3J0IHsgUGFydGljbGVTeXN0ZW0gfSBmcm9tICcuL1BhcnRpY2xlU3lzdGVtJztcbmltcG9ydCB7IFRleHR1cmVHZW5lcmF0b3IgfSBmcm9tICcuL1RleHR1cmVHZW5lcmF0b3InO1xuaW1wb3J0IHsgc291bmRNYW5hZ2VyIH0gZnJvbSAnLi4vYXVkaW8vU291bmRFZmZlY3RzJztcbmltcG9ydCB7XG4gIFdlYXBvbixcbiAgUGxheWVyU2tpbixcbiAgTGV2ZWxDb25maWcsXG4gIFBsYXllclN0YXRzLFxuICBVc2VySW5wdXQsXG4gIEZsb2F0aW5nRGFtYWdlLFxuICBFbmVteVR5cGUsXG59IGZyb20gJy4uL3R5cGVzL2dhbWUnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEVuZW15SW5zdGFuY2Uge1xuICBpZDogbnVtYmVyO1xuICB0eXBlOiBFbmVteVR5cGU7XG4gIG5hbWU6IHN0cmluZztcbiAgaXNCb3NzOiBib29sZWFuO1xuICByaWc6IENoYXJhY3RlclJpZztcbiAgaGVhbHRoOiBudW1iZXI7XG4gIG1heEhlYWx0aDogbnVtYmVyO1xuICBhdHRhY2tQb3dlcjogbnVtYmVyO1xuICBzcGVlZDogbnVtYmVyO1xuICByYW5nZTogbnVtYmVyO1xuICBzdGF0ZTogJ2lkbGUnIHwgJ3BhdHJvbCcgfCAnY2hhc2UnIHwgJ2F0dGFjaycgfCAnZmxpbmNoJyB8ICdkZWFkJztcbiAgc3RhdGVUaW1lcjogbnVtYmVyO1xuICBhdHRhY2tDb29sZG93bjogbnVtYmVyO1xuICBhdHRhY2tXaW5kdXA6IG51bWJlcjtcbiAgcGF0cm9sUG9pbnQ6IFRIUkVFLlZlY3RvcjM7XG4gIHRhcmdldFBvczogVEhSRUUuVmVjdG9yMztcbiAgZGlzc29sdmVUaW1lcjogbnVtYmVyO1xuICBoYXNQb3dlckNhcnJpZXJCYWRnZT86IGJvb2xlYW47XG4gIHBvd2VyQmFkZ2VNZXNoPzogVEhSRUUuR3JvdXA7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29sbGVjdGlibGVJdGVtIHtcbiAgaWQ6IG51bWJlcjtcbiAgbWVzaDogVEhSRUUuR3JvdXA7XG4gIGhlYWxBbW91bnQ6IG51bWJlcjtcbiAgcG9zaXRpb246IFRIUkVFLlZlY3RvcjM7XG4gIGJhc2VZOiBudW1iZXI7XG4gIGJvYlRpbWU6IG51bWJlcjtcbn1cblxuZXhwb3J0IGNsYXNzIEdhbWVFbmdpbmUge1xuICBwdWJsaWMgY29udGFpbmVyOiBIVE1MRWxlbWVudDtcbiAgcHVibGljIHJlbmRlcmVyOiBUSFJFRS5XZWJHTFJlbmRlcmVyO1xuICBwdWJsaWMgc2NlbmU6IFRIUkVFLlNjZW5lO1xuICBwdWJsaWMgY2FtZXJhOiBUSFJFRS5QZXJzcGVjdGl2ZUNhbWVyYTtcblxuICAvLyBMZXZlbCBjb25maWd1cmF0aW9uXG4gIHB1YmxpYyBjdXJyZW50TGV2ZWw6IExldmVsQ29uZmlnO1xuICBwdWJsaWMgY3VycmVudFdlYXBvbjogV2VhcG9uO1xuICBwdWJsaWMgY3VycmVudFNraW46IFBsYXllclNraW47XG5cbiAgLy8gUGFydGljbGUgU3lzdGVtXG4gIHB1YmxpYyBwYXJ0aWNsZXM6IFBhcnRpY2xlU3lzdGVtO1xuXG4gIC8vIFBsYXllclxuICBwdWJsaWMgcGxheWVyUmlnOiBDaGFyYWN0ZXJSaWc7XG4gIHB1YmxpYyBwbGF5ZXJQb3MgPSBuZXcgVEhSRUUuVmVjdG9yMygwLCAwLCAwKTtcbiAgcHVibGljIHBsYXllclZlbG9jaXR5ID0gbmV3IFRIUkVFLlZlY3RvcjMoMCwgMCwgMCk7XG4gIHB1YmxpYyBwbGF5ZXJSb3RhdGlvbiA9IDA7XG4gIHB1YmxpYyBpc0dyb3VuZGVkID0gdHJ1ZTtcbiAgcHVibGljIGlzSW52dWxuZXJhYmxlID0gZmFsc2U7XG4gIHB1YmxpYyBpbnZ1bG5lcmFiaWxpdHlUaW1lciA9IDA7XG5cbiAgLy8gU3RhdHNcbiAgcHVibGljIHN0YXRzOiBQbGF5ZXJTdGF0cyA9IHtcbiAgICBtYXhIZWFsdGg6IDUwMCxcbiAgICBjdXJyZW50SGVhbHRoOiA1MDAsXG4gICAgbWF4RW5lcmd5OiAxMDAsXG4gICAgY3VycmVudEVuZXJneTogNTAsXG4gICAgY29pbnM6IDAsXG4gICAgc2VsZWN0ZWRXZWFwb25JZDogJycsXG4gICAgc2VsZWN0ZWRTa2luSWQ6ICcnLFxuICAgIGNvbWJvQ291bnQ6IDAsXG4gICAgY29tYm9UaW1lcjogMCxcbiAgICBraWxsczogMCxcbiAgICBzcGVjaWFsQ29vbGRvd246IDAsXG4gICAgc3BlY2lhbE1heENvb2xkb3duOiA2MCxcbiAgfTtcblxuICAvLyBDb2xsZWN0aWJsZSBQb3dlciBPcmJzIGRyb3BwZWQgYnkgZW5lbWllc1xuICBwdWJsaWMgY29sbGVjdGlibGVzOiBDb2xsZWN0aWJsZUl0ZW1bXSA9IFtdO1xuICBwcml2YXRlIG5leHRDb2xsZWN0aWJsZUlkID0gMTtcblxuICAvLyBDb21iYXQgQ29tYm9cbiAgcHVibGljIGN1cnJlbnRDb21ib1N0ZXAgPSAwO1xuICBwdWJsaWMgY29tYm9XaW5kb3dUaW1lciA9IDA7XG4gIHB1YmxpYyBhdHRhY2tUaW1lciA9IDA7XG4gIHB1YmxpYyBpc0F0dGFja2luZyA9IGZhbHNlO1xuICBwdWJsaWMgc3BlY2lhbENvb2xkb3duID0gMDtcblxuICAvLyBFbmVtaWVzXG4gIHB1YmxpYyBlbmVtaWVzOiBFbmVteUluc3RhbmNlW10gPSBbXTtcbiAgcHJpdmF0ZSBuZXh0RW5lbXlJZCA9IDE7XG4gIHB1YmxpYyBib3NzU3Bhd25lZCA9IGZhbHNlO1xuICBwdWJsaWMgYm9zc0luc3RhbmNlOiBFbmVteUluc3RhbmNlIHwgbnVsbCA9IG51bGw7XG5cbiAgLy8gQ2FtZXJhIE9yYml0XG4gIHB1YmxpYyBjYW1lcmFBbmdsZVggPSAwOyAvLyBZYXdcbiAgcHVibGljIGNhbWVyYUFuZ2xlWSA9IDAuMzU7IC8vIFBpdGNoXG4gIHB1YmxpYyBjYW1lcmFEaXN0YW5jZSA9IDUuMjtcbiAgcHVibGljIHNjcmVlblNoYWtlID0gMDtcblxuICAvLyBJbnB1dFxuICBwdWJsaWMgaW5wdXQ6IFVzZXJJbnB1dCA9IHtcbiAgICBtb3ZlWDogMCxcbiAgICBtb3ZlWjogMCxcbiAgICBhdHRhY2s6IGZhbHNlLFxuICAgIGhlYXZ5QXR0YWNrOiBmYWxzZSxcbiAgICBqdW1wOiBmYWxzZSxcbiAgICBkb2RnZTogZmFsc2UsXG4gICAgc3BlY2lhbDogZmFsc2UsXG4gICAgY2FtZXJhUm90YXRlWDogMCxcbiAgICBjYW1lcmFSb3RhdGVZOiAwLFxuICB9O1xuXG4gIC8vIEdhbWUgTG9vcFxuICBwcml2YXRlIGNsb2NrID0gbmV3IFRIUkVFLkNsb2NrKCk7XG4gIHByaXZhdGUgYW5pbUZyYW1lSWQgPSAwO1xuICBwcml2YXRlIGlzUnVubmluZyA9IGZhbHNlO1xuICBwcml2YXRlIGlzUGF1c2VkID0gZmFsc2U7XG4gIHByaXZhdGUgaXNTb2Z0d2FyZUdsID0gZmFsc2U7XG5cbiAgLy8gQ2FsbGJhY2tzIHRvIFJlYWN0IFVJXG4gIHB1YmxpYyBvblN0YXRzQ2hhbmdlPzogKHN0YXRzOiBQbGF5ZXJTdGF0cykgPT4gdm9pZDtcbiAgcHVibGljIG9uRmxvYXRpbmdEYW1hZ2U/OiAoZGFtYWdlOiBGbG9hdGluZ0RhbWFnZSkgPT4gdm9pZDtcbiAgcHVibGljIG9uR2FtZU92ZXI/OiAoKSA9PiB2b2lkO1xuICBwdWJsaWMgb25WaWN0b3J5PzogKGNvaW5zOiBudW1iZXIsIHN0YXJzOiBudW1iZXIpID0+IHZvaWQ7XG4gIHB1YmxpYyBvbkJvc3NIZWFsdGhVcGRhdGU/OiAoaGVhbHRoOiBudW1iZXIsIG1heEhlYWx0aDogbnVtYmVyLCBuYW1lOiBzdHJpbmcpID0+IHZvaWQ7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgY29udGFpbmVyOiBIVE1MRWxlbWVudCxcbiAgICBsZXZlbDogTGV2ZWxDb25maWcsXG4gICAgd2VhcG9uOiBXZWFwb24sXG4gICAgc2tpbjogUGxheWVyU2tpbixcbiAgICBpbml0aWFsQ29pbnM6IG51bWJlclxuICApIHtcbiAgICB0aGlzLmNvbnRhaW5lciA9IGNvbnRhaW5lcjtcbiAgICB0aGlzLmN1cnJlbnRMZXZlbCA9IGxldmVsO1xuICAgIHRoaXMuY3VycmVudFdlYXBvbiA9IHdlYXBvbjtcbiAgICB0aGlzLmN1cnJlbnRTa2luID0gc2tpbjtcbiAgICB0aGlzLnN0YXRzLmNvaW5zID0gaW5pdGlhbENvaW5zO1xuXG4gICAgLy8gRGV0ZWN0IHNvZnR3YXJlIFdlYkdMXG4gICAgdGhpcy5pc1NvZnR3YXJlR2wgPSAoKCkgPT4ge1xuICAgICAgY29uc3QgZ2wgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKS5nZXRDb250ZXh0KCd3ZWJnbDInKTtcbiAgICAgIGlmICghZ2wpIHJldHVybiB0cnVlO1xuICAgICAgY29uc3QgZXh0ID0gZ2wuZ2V0RXh0ZW5zaW9uKCdXRUJHTF9kZWJ1Z19yZW5kZXJlcl9pbmZvJyk7XG4gICAgICBjb25zdCBwYXJhbSA9IGV4dCA/IGV4dC5VTk1BU0tFRF9SRU5ERVJFUl9XRUJHTCA6IGdsLlJFTkRFUkVSO1xuICAgICAgY29uc3QgZ3B1ID0gU3RyaW5nKGdsLmdldFBhcmFtZXRlcihwYXJhbSkpO1xuICAgICAgZ2wuZ2V0RXh0ZW5zaW9uKCdXRUJHTF9sb3NlX2NvbnRleHQnKT8ubG9zZUNvbnRleHQoKTtcbiAgICAgIHJldHVybiAvU3dpZnRTaGFkZXJ8bGx2bXBpcGV8c29mdHBpcGV8U29mdHdhcmV8QmFzaWMgUmVuZGVyL2kudGVzdChncHUpO1xuICAgIH0pKCk7XG5cbiAgICAvLyAxLiBSZW5kZXJlciBTZXR1cFxuICAgIHRoaXMucmVuZGVyZXIgPSBuZXcgVEhSRUUuV2ViR0xSZW5kZXJlcih7XG4gICAgICBhbnRpYWxpYXM6ICF0aGlzLmlzU29mdHdhcmVHbCxcbiAgICAgIHBvd2VyUHJlZmVyZW5jZTogJ2hpZ2gtcGVyZm9ybWFuY2UnLFxuICAgIH0pO1xuICAgIHRoaXMucmVuZGVyZXIub3V0cHV0Q29sb3JTcGFjZSA9IFRIUkVFLlNSR0JDb2xvclNwYWNlO1xuICAgIHRoaXMucmVuZGVyZXIudG9uZU1hcHBpbmcgPSBUSFJFRS5BQ0VTRmlsbWljVG9uZU1hcHBpbmc7XG4gICAgdGhpcy5yZW5kZXJlci50b25lTWFwcGluZ0V4cG9zdXJlID0gMS4xNTtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFBpeGVsUmF0aW8odGhpcy5pc1NvZnR3YXJlR2wgPyAxIDogTWF0aC5taW4od2luZG93LmRldmljZVBpeGVsUmF0aW8sIDIpKTtcbiAgICB0aGlzLnJlbmRlcmVyLnNoYWRvd01hcC5lbmFibGVkID0gIXRoaXMuaXNTb2Z0d2FyZUdsO1xuICAgIHRoaXMucmVuZGVyZXIuc2hhZG93TWFwLnR5cGUgPSBUSFJFRS5QQ0ZTb2Z0U2hhZG93TWFwO1xuICAgIHRoaXMucmVuZGVyZXIuc2V0U2l6ZShjb250YWluZXIuY2xpZW50V2lkdGgsIGNvbnRhaW5lci5jbGllbnRIZWlnaHQpO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZCh0aGlzLnJlbmRlcmVyLmRvbUVsZW1lbnQpO1xuXG4gICAgLy8gMi4gU2NlbmUgJiBGb2cgU2V0dXBcbiAgICB0aGlzLnNjZW5lID0gbmV3IFRIUkVFLlNjZW5lKCk7XG4gICAgdGhpcy5zY2VuZS5iYWNrZ3JvdW5kID0gbmV3IFRIUkVFLkNvbG9yKGxldmVsLnNreUNvbG9yKTtcbiAgICB0aGlzLnNjZW5lLmZvZyA9IG5ldyBUSFJFRS5Gb2dFeHAyKGxldmVsLmZvZ0NvbG9yLCAwLjAyMik7XG5cbiAgICAvLyAzLiBNYW5kYXRvcnkgU3R1ZGlvIEVudmlyb25tZW50IFJlZmxlY3Rpb25cbiAgICBjb25zdCBwbXJlbUdlbmVyYXRvciA9IG5ldyBUSFJFRS5QTVJFTUdlbmVyYXRvcih0aGlzLnJlbmRlcmVyKTtcbiAgICB0aGlzLnNjZW5lLmVudmlyb25tZW50ID0gcG1yZW1HZW5lcmF0b3IuZnJvbVNjZW5lKG5ldyBSb29tRW52aXJvbm1lbnQoKSwgMC4wNCkudGV4dHVyZTtcbiAgICBwbXJlbUdlbmVyYXRvci5kaXNwb3NlKCk7XG5cbiAgICAvLyA0LiBDYW1lcmEgU2V0dXBcbiAgICB0aGlzLmNhbWVyYSA9IG5ldyBUSFJFRS5QZXJzcGVjdGl2ZUNhbWVyYShcbiAgICAgIDU1LFxuICAgICAgY29udGFpbmVyLmNsaWVudFdpZHRoIC8gY29udGFpbmVyLmNsaWVudEhlaWdodCxcbiAgICAgIDAuMSxcbiAgICAgIDE1MFxuICAgICk7XG5cbiAgICAvLyA1LiBMaWdodGluZyBTZXR1cFxuICAgIHRoaXMuc2V0dXBMaWdodGluZygpO1xuXG4gICAgLy8gNi4gQnVpbGQgM0QgV29ybGQgJiBUZXJyYWluXG4gICAgdGhpcy5idWlsZFdvcmxkKCk7XG5cbiAgICAvLyA3LiBQYXJ0aWNsZSBTeXN0ZW1cbiAgICB0aGlzLnBhcnRpY2xlcyA9IG5ldyBQYXJ0aWNsZVN5c3RlbSh0aGlzLnNjZW5lKTtcblxuICAgIC8vIDguIFBsYXllciBSaWdcbiAgICB0aGlzLnBsYXllclJpZyA9IENoYXJhY3RlckZhY3RvcnkuY3JlYXRlTmluamFQbGF5ZXIoc2tpbiwgd2VhcG9uKTtcbiAgICB0aGlzLnNjZW5lLmFkZCh0aGlzLnBsYXllclJpZy5yb290KTtcbiAgICB0aGlzLnBsYXllclBvcy5zZXQoMCwgMCwgNSk7XG4gICAgdGhpcy5wbGF5ZXJSaWcucm9vdC5wb3NpdGlvbi5jb3B5KHRoaXMucGxheWVyUG9zKTtcblxuICAgIC8vIDkuIFNwYXduIEluaXRpYWwgRW5lbWllc1xuICAgIHRoaXMuc3Bhd25Jbml0aWFsRW5lbWllcygpO1xuXG4gICAgLy8gMTAuIFN0YXJ0IFNvdW5kIEJHTVxuICAgIHNvdW5kTWFuYWdlci5zdGFydEJnbSgpO1xuXG4gICAgLy8gUmVzaXplIEhhbmRsZXJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5oYW5kbGVSZXNpemUpO1xuXG4gICAgLy8gU3RhcnQgTG9vcFxuICAgIHRoaXMuaXNSdW5uaW5nID0gdHJ1ZTtcbiAgICB0aGlzLnRpY2soKTtcbiAgfVxuXG4gIHByaXZhdGUgc2V0dXBMaWdodGluZygpIHtcbiAgICAvLyBIZW1pc3BoZXJlIGZpbGxcbiAgICBjb25zdCBoZW1pTGlnaHQgPSBuZXcgVEhSRUUuSGVtaXNwaGVyZUxpZ2h0KFxuICAgICAgdGhpcy5jdXJyZW50TGV2ZWwubGlnaHRDb2xvcixcbiAgICAgIDB4MWMxOTE3LFxuICAgICAgMC44NVxuICAgICk7XG4gICAgdGhpcy5zY2VuZS5hZGQoaGVtaUxpZ2h0KTtcblxuICAgIC8vIEtleSBEaXJlY3Rpb25hbCBMaWdodCB3aXRoIFNoYWRvd3NcbiAgICBjb25zdCBrZXlMaWdodCA9IG5ldyBUSFJFRS5EaXJlY3Rpb25hbExpZ2h0KHRoaXMuY3VycmVudExldmVsLmxpZ2h0Q29sb3IsIDEuOCk7XG4gICAga2V5TGlnaHQucG9zaXRpb24uc2V0KDI1LCAzNSwgMjApO1xuICAgIGtleUxpZ2h0LmNhc3RTaGFkb3cgPSAhdGhpcy5pc1NvZnR3YXJlR2w7XG4gICAga2V5TGlnaHQuc2hhZG93Lm1hcFNpemUud2lkdGggPSAxMDI0O1xuICAgIGtleUxpZ2h0LnNoYWRvdy5tYXBTaXplLmhlaWdodCA9IDEwMjQ7XG4gICAga2V5TGlnaHQuc2hhZG93LmNhbWVyYS5uZWFyID0gMC41O1xuICAgIGtleUxpZ2h0LnNoYWRvdy5jYW1lcmEuZmFyID0gODA7XG4gICAgY29uc3QgZCA9IDI4O1xuICAgIGtleUxpZ2h0LnNoYWRvdy5jYW1lcmEubGVmdCA9IC1kO1xuICAgIGtleUxpZ2h0LnNoYWRvdy5jYW1lcmEucmlnaHQgPSBkO1xuICAgIGtleUxpZ2h0LnNoYWRvdy5jYW1lcmEudG9wID0gZDtcbiAgICBrZXlMaWdodC5zaGFkb3cuY2FtZXJhLmJvdHRvbSA9IC1kO1xuICAgIGtleUxpZ2h0LnNoYWRvdy5iaWFzID0gLTAuMDAwNTtcbiAgICBrZXlMaWdodC5zaGFkb3cubm9ybWFsQmlhcyA9IDAuMDI7XG4gICAgdGhpcy5zY2VuZS5hZGQoa2V5TGlnaHQpO1xuICB9XG5cbiAgcHJpdmF0ZSBidWlsZFdvcmxkKCkge1xuICAgIGNvbnN0IHRoZW1lID0gdGhpcy5jdXJyZW50TGV2ZWwuZW52aXJvbm1lbnRUaGVtZTtcbiAgICBpZiAodGhlbWUgPT09ICdmb3Jlc3QnKSB7XG4gICAgICB0aGlzLmJ1aWxkRm9yZXN0TGV2ZWwoKTtcbiAgICB9IGVsc2UgaWYgKHRoZW1lID09PSAndmlsbGFnZScpIHtcbiAgICAgIHRoaXMuYnVpbGRWaWxsYWdlTGV2ZWwoKTtcbiAgICB9IGVsc2UgaWYgKHRoZW1lID09PSAndGVtcGxlJykge1xuICAgICAgdGhpcy5idWlsZFRlbXBsZUxldmVsKCk7XG4gICAgfSBlbHNlIGlmICh0aGVtZSA9PT0gJ2ZvcnRyZXNzJykge1xuICAgICAgdGhpcy5idWlsZEZvcnRyZXNzTGV2ZWwoKTtcbiAgICB9IGVsc2UgaWYgKHRoZW1lID09PSAnYXJlbmEnKSB7XG4gICAgICB0aGlzLmJ1aWxkQXJlbmFMZXZlbCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmJ1aWxkRm9yZXN0TGV2ZWwoKTtcbiAgICB9XG4gIH1cblxuICAvLyBMRVZFTCAxOiBTYWNyZWQgQ2hlcnJ5IEJsb3Nzb20gRm9yZXN0XG4gIHByaXZhdGUgYnVpbGRGb3Jlc3RMZXZlbCgpIHtcbiAgICBjb25zdCBncm91bmRHZW8gPSBuZXcgVEhSRUUuUGxhbmVHZW9tZXRyeSgxNjAsIDE2MCwgMTYsIDE2KTtcbiAgICBjb25zdCBncm91bmRNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoeyBjb2xvcjogMHgxNDUzMmQsIHJvdWdobmVzczogMC45IH0pO1xuICAgIGNvbnN0IGdyb3VuZCA9IG5ldyBUSFJFRS5NZXNoKGdyb3VuZEdlbywgZ3JvdW5kTWF0KTtcbiAgICBncm91bmQucm90YXRpb24ueCA9IC1NYXRoLlBJIC8gMjtcbiAgICBncm91bmQucmVjZWl2ZVNoYWRvdyA9ICF0aGlzLmlzU29mdHdhcmVHbDtcbiAgICB0aGlzLnNjZW5lLmFkZChncm91bmQpO1xuXG4gICAgLy8gU3RvbmUgUGF0aFxuICAgIGNvbnN0IHBhdGhHZW8gPSBuZXcgVEhSRUUuUGxhbmVHZW9tZXRyeSg2LCA3NSk7XG4gICAgY29uc3QgcGF0aE1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7XG4gICAgICBtYXA6IFRleHR1cmVHZW5lcmF0b3IuZ2V0U3RvbmVQYXZlbWVudFRleHR1cmUoKSxcbiAgICAgIHJvdWdobmVzczogMC44LFxuICAgIH0pO1xuICAgIGNvbnN0IHBhdGggPSBuZXcgVEhSRUUuTWVzaChwYXRoR2VvLCBwYXRoTWF0KTtcbiAgICBwYXRoLnJvdGF0aW9uLnggPSAtTWF0aC5QSSAvIDI7XG4gICAgcGF0aC5wb3NpdGlvbi5zZXQoMCwgMC4wMiwgMCk7XG4gICAgdGhpcy5zY2VuZS5hZGQocGF0aCk7XG5cbiAgICAvLyBUb3JpaSBHYXRlIEVudHJhbmNlXG4gICAgY29uc3QgdG9yaWkgPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlVG9yaWlHYXRlKCk7XG4gICAgdG9yaWkucG9zaXRpb24uc2V0KDAsIDAsIDE4KTtcbiAgICB0aGlzLnNjZW5lLmFkZCh0b3JpaSk7XG5cbiAgICAvLyBNYXN0ZXIgUnl1J3MgVHJhaW5pbmcgUGFnb2RhXG4gICAgY29uc3QgZG9qbyA9IEVudmlyb25tZW50QnVpbGRlci5jcmVhdGVQYWdvZGEoMik7XG4gICAgZG9qby5wb3NpdGlvbi5zZXQoMCwgMCwgLTMyKTtcbiAgICB0aGlzLnNjZW5lLmFkZChkb2pvKTtcblxuICAgIC8vIEx1c2ggU2FrdXJhIEJsb3Nzb20gR3JvdmVcbiAgICBjb25zdCBzYWt1cmFUcmVlcyA9IFtcbiAgICAgIFstOSwgMCwgMTRdLCBbOSwgMCwgMTRdLCBbLTEyLCAwLCA0XSwgWzEyLCAwLCAyXSxcbiAgICAgIFstMTAsIDAsIC04XSwgWzExLCAwLCAtMTBdLCBbLTgsIDAsIC0yMl0sIFs4LCAwLCAtMjJdLFxuICAgICAgWy0xNiwgMCwgMjBdLCBbMTYsIDAsIDIyXSwgWy0xOCwgMCwgLTE4XSwgWzE4LCAwLCAtMTZdXG4gICAgXTtcbiAgICBzYWt1cmFUcmVlcy5mb3JFYWNoKHAgPT4ge1xuICAgICAgY29uc3QgdHJlZSA9IEVudmlyb25tZW50QnVpbGRlci5jcmVhdGVTYWt1cmFUcmVlKCk7XG4gICAgICB0cmVlLnBvc2l0aW9uLnNldChwWzBdLCBwWzFdLCBwWzJdKTtcbiAgICAgIGNvbnN0IHMgPSAwLjg1ICsgTWF0aC5yYW5kb20oKSAqIDAuMzU7XG4gICAgICB0cmVlLnNjYWxlLnNldChzLCBzLCBzKTtcbiAgICAgIHRyZWUucm90YXRpb24ueSA9IE1hdGgucmFuZG9tKCkgKiBNYXRoLlBJICogMjtcbiAgICAgIHRoaXMuc2NlbmUuYWRkKHRyZWUpO1xuICAgIH0pO1xuXG4gICAgLy8gU3RvbmUgTGFudGVybnNcbiAgICBbLTQsIDgsIC0xNl0uZm9yRWFjaCh6ID0+IHtcbiAgICAgIGNvbnN0IGwxID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZVN0b25lTGFudGVybighdGhpcy5pc1NvZnR3YXJlR2wpO1xuICAgICAgbDEuZ3JvdXAucG9zaXRpb24uc2V0KC00LCAwLCB6KTtcbiAgICAgIGNvbnN0IGwyID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZVN0b25lTGFudGVybighdGhpcy5pc1NvZnR3YXJlR2wpO1xuICAgICAgbDIuZ3JvdXAucG9zaXRpb24uc2V0KDQsIDAsIHopO1xuICAgICAgdGhpcy5zY2VuZS5hZGQobDEuZ3JvdXAsIGwyLmdyb3VwKTtcbiAgICB9KTtcblxuICAgIHRoaXMuYnVpbGRQZXJpbWV0ZXJNb3VudGFpbnMoMHgxZTNhNWYpO1xuICB9XG5cbiAgLy8gTEVWRUwgMjogQnVybmluZyBFbmVteSBWaWxsYWdlXG4gIHByaXZhdGUgYnVpbGRWaWxsYWdlTGV2ZWwoKSB7XG4gICAgY29uc3QgZ3JvdW5kR2VvID0gbmV3IFRIUkVFLlBsYW5lR2VvbWV0cnkoMTYwLCAxNjAsIDE2LCAxNik7XG4gICAgY29uc3QgZ3JvdW5kTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHsgY29sb3I6IDB4M2QyMDExLCByb3VnaG5lc3M6IDAuOTUgfSk7XG4gICAgY29uc3QgZ3JvdW5kID0gbmV3IFRIUkVFLk1lc2goZ3JvdW5kR2VvLCBncm91bmRNYXQpO1xuICAgIGdyb3VuZC5yb3RhdGlvbi54ID0gLU1hdGguUEkgLyAyO1xuICAgIGdyb3VuZC5yZWNlaXZlU2hhZG93ID0gIXRoaXMuaXNTb2Z0d2FyZUdsO1xuICAgIHRoaXMuc2NlbmUuYWRkKGdyb3VuZCk7XG5cbiAgICAvLyBWaWxsYWdlIERpcnQgUm9hZFxuICAgIGNvbnN0IHJvYWRHZW8gPSBuZXcgVEhSRUUuUGxhbmVHZW9tZXRyeSg4LCA4MCk7XG4gICAgY29uc3Qgcm9hZE1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7IGNvbG9yOiAweDIyMTIwOSwgcm91Z2huZXNzOiAwLjkgfSk7XG4gICAgY29uc3Qgcm9hZCA9IG5ldyBUSFJFRS5NZXNoKHJvYWRHZW8sIHJvYWRNYXQpO1xuICAgIHJvYWQucm90YXRpb24ueCA9IC1NYXRoLlBJIC8gMjtcbiAgICByb2FkLnBvc2l0aW9uLnNldCgwLCAwLjAyLCAwKTtcbiAgICB0aGlzLnNjZW5lLmFkZChyb2FkKTtcblxuICAgIC8vIFRoYXRjaGVkIFZpbGxhZ2UgSHV0cyAoTWlua2EpXG4gICAgY29uc3QgaHV0UG9zaXRpb25zID0gW1xuICAgICAgWy0xMCwgMCwgOF0sIFsxMCwgMCwgNl0sIFstMTEsIDAsIC0xMl0sIFsxMSwgMCwgLTEwXVxuICAgIF07XG4gICAgaHV0UG9zaXRpb25zLmZvckVhY2gocCA9PiB7XG4gICAgICBjb25zdCBodXQgPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlVmlsbGFnZUh1dCgpO1xuICAgICAgaHV0LnBvc2l0aW9uLnNldChwWzBdLCBwWzFdLCBwWzJdKTtcbiAgICAgIGh1dC5yb3RhdGlvbi55ID0gTWF0aC5yYW5kb20oKSAqIDAuNCAtIDAuMjtcbiAgICAgIHRoaXMuc2NlbmUuYWRkKGh1dCk7XG4gICAgfSk7XG5cbiAgICAvLyBGbGFtaW5nIEJvbmZpcmVzICYgRW5lbXkgVGVudHNcbiAgICBjb25zdCBjYW1wcyA9IFtcbiAgICAgIHsgdDogbmV3IFRIUkVFLlZlY3RvcjMoLTYsIDAsIC0yKSwgZjogbmV3IFRIUkVFLlZlY3RvcjMoLTQsIDAsIDApIH0sXG4gICAgICB7IHQ6IG5ldyBUSFJFRS5WZWN0b3IzKDYsIDAsIC0xOCksIGY6IG5ldyBUSFJFRS5WZWN0b3IzKDQsIDAsIC0xNikgfSxcbiAgICBdO1xuICAgIGNhbXBzLmZvckVhY2goYyA9PiB7XG4gICAgICBjb25zdCB0ZW50ID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZUVuZW15VGVudCgpO1xuICAgICAgdGVudC5wb3NpdGlvbi5jb3B5KGMudCk7XG4gICAgICBjb25zdCBmaXJlID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZUNhbXBmaXJlKCk7XG4gICAgICBmaXJlLmdyb3VwLnBvc2l0aW9uLmNvcHkoYy5mKTtcbiAgICAgIHRoaXMuc2NlbmUuYWRkKHRlbnQsIGZpcmUuZ3JvdXApO1xuICAgIH0pO1xuXG4gICAgLy8gMiBWaWxsYWdlIExvb2tvdXQgV2F0Y2h0b3dlcnNcbiAgICBjb25zdCB0b3dlcjEgPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlV2F0Y2h0b3dlcigpO1xuICAgIHRvd2VyMS5wb3NpdGlvbi5zZXQoLTgsIDAsIDE2KTtcbiAgICBjb25zdCB0b3dlcjIgPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlV2F0Y2h0b3dlcigpO1xuICAgIHRvd2VyMi5wb3NpdGlvbi5zZXQoOCwgMCwgLTI2KTtcbiAgICB0aGlzLnNjZW5lLmFkZCh0b3dlcjEsIHRvd2VyMik7XG5cbiAgICAvLyBXb29kZW4gQXJjaGVkIEJyaWRnZSBhY3Jvc3MgYSB0cmVuY2hcbiAgICBjb25zdCBicmlkZ2UgPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlQXJjaGVkQnJpZGdlKDEwLCAzLjUpO1xuICAgIGJyaWRnZS5wb3NpdGlvbi5zZXQoMCwgMCwgMik7XG4gICAgdGhpcy5zY2VuZS5hZGQoYnJpZGdlKTtcblxuICAgIC8vIFNwaWtlZCBCYXJyaWNhZGVzXG4gICAgY29uc3QgYmFyMSA9IEVudmlyb25tZW50QnVpbGRlci5jcmVhdGVTcGlrZWRCYXJyaWNhZGUoKTtcbiAgICBiYXIxLnBvc2l0aW9uLnNldCgtNiwgMCwgMTQpO1xuICAgIGNvbnN0IGJhcjIgPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlU3Bpa2VkQmFycmljYWRlKCk7XG4gICAgYmFyMi5wb3NpdGlvbi5zZXQoNiwgMCwgMTQpO1xuICAgIHRoaXMuc2NlbmUuYWRkKGJhcjEsIGJhcjIpO1xuXG4gICAgLy8gV2VhdGhlcmVkIFBpbmVzXG4gICAgW1stMTYsIDAsIDBdLCBbMTYsIDAsIC00XSwgWy0xNCwgMCwgLTI4XSwgWzE1LCAwLCAyMF1dLmZvckVhY2gocCA9PiB7XG4gICAgICBjb25zdCBwaW5lID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZVBpbmVUcmVlKCk7XG4gICAgICBwaW5lLnBvc2l0aW9uLnNldChwWzBdLCBwWzFdLCBwWzJdKTtcbiAgICAgIHRoaXMuc2NlbmUuYWRkKHBpbmUpO1xuICAgIH0pO1xuXG4gICAgdGhpcy5idWlsZFBlcmltZXRlck1vdW50YWlucygweDQ1MWEwMyk7XG4gIH1cblxuICAvLyBMRVZFTCAzOiBDdXJzZWQgTWlkbmlnaHQgUGFnb2RhIFRlbXBsZVxuICBwcml2YXRlIGJ1aWxkVGVtcGxlTGV2ZWwoKSB7XG4gICAgY29uc3QgZ3JvdW5kR2VvID0gbmV3IFRIUkVFLlBsYW5lR2VvbWV0cnkoMTYwLCAxNjAsIDE2LCAxNik7XG4gICAgY29uc3QgZ3JvdW5kTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHsgY29sb3I6IDB4MDkwZDE2LCByb3VnaG5lc3M6IDAuOCB9KTtcbiAgICBjb25zdCBncm91bmQgPSBuZXcgVEhSRUUuTWVzaChncm91bmRHZW8sIGdyb3VuZE1hdCk7XG4gICAgZ3JvdW5kLnJvdGF0aW9uLnggPSAtTWF0aC5QSSAvIDI7XG4gICAgZ3JvdW5kLnJlY2VpdmVTaGFkb3cgPSAhdGhpcy5pc1NvZnR3YXJlR2w7XG4gICAgdGhpcy5zY2VuZS5hZGQoZ3JvdW5kKTtcblxuICAgIC8vIERhcmsgc2xhdGUgdGVtcGxlIGNvdXJ0eWFyZFxuICAgIGNvbnN0IGNvdXJ0R2VvID0gbmV3IFRIUkVFLlBsYW5lR2VvbWV0cnkoMjgsIDcwKTtcbiAgICBjb25zdCBjb3VydE1hdCA9IG5ldyBUSFJFRS5NZXNoU3RhbmRhcmRNYXRlcmlhbCh7XG4gICAgICBtYXA6IFRleHR1cmVHZW5lcmF0b3IuZ2V0U3RvbmVQYXZlbWVudFRleHR1cmUoKSxcbiAgICAgIHJvdWdobmVzczogMC43LFxuICAgICAgY29sb3I6IDB4NjQ3NDhiLFxuICAgIH0pO1xuICAgIGNvbnN0IGNvdXJ0ID0gbmV3IFRIUkVFLk1lc2goY291cnRHZW8sIGNvdXJ0TWF0KTtcbiAgICBjb3VydC5yb3RhdGlvbi54ID0gLU1hdGguUEkgLyAyO1xuICAgIGNvdXJ0LnBvc2l0aW9uLnNldCgwLCAwLjAyLCAtNSk7XG4gICAgdGhpcy5zY2VuZS5hZGQoY291cnQpO1xuXG4gICAgLy8gR2lhbnQgNC1UaWVyIERhcmsgUGFnb2RhIGF0IHRoZSBjZW50ZXJcbiAgICBjb25zdCBwYWdvZGEgPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlUGFnb2RhKDQpO1xuICAgIHBhZ29kYS5wb3NpdGlvbi5zZXQoMCwgMCwgLTMyKTtcbiAgICB0aGlzLnNjZW5lLmFkZChwYWdvZGEpO1xuXG4gICAgLy8gU3RvbmUgRHJhZ29uIFN0YXR1ZXMgZ3VhcmRpbmcgZW50cmFuY2VcbiAgICBjb25zdCBkcmFnb24xID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZURyYWdvblN0YXR1ZSgpO1xuICAgIGRyYWdvbjEucG9zaXRpb24uc2V0KC00LjUsIDAsIC0xOCk7XG4gICAgZHJhZ29uMS5yb3RhdGlvbi55ID0gMC4zO1xuICAgIGNvbnN0IGRyYWdvbjIgPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlRHJhZ29uU3RhdHVlKCk7XG4gICAgZHJhZ29uMi5wb3NpdGlvbi5zZXQoNC41LCAwLCAtMTgpO1xuICAgIGRyYWdvbjIucm90YXRpb24ueSA9IC0wLjM7XG4gICAgdGhpcy5zY2VuZS5hZGQoZHJhZ29uMSwgZHJhZ29uMik7XG5cbiAgICAvLyBSb3cgb2YgOCBDeWFuIFNwaXJpdCBMYW50ZXJuc1xuICAgIFstMjQsIC0xNCwgLTQsIDYsIDE2XS5mb3JFYWNoKHogPT4ge1xuICAgICAgY29uc3QgbDEgPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlU3RvbmVMYW50ZXJuKCF0aGlzLmlzU29mdHdhcmVHbCk7XG4gICAgICBsMS5ncm91cC5wb3NpdGlvbi5zZXQoLTYsIDAsIHopO1xuICAgICAgaWYgKGwxLmxpZ2h0KSBsMS5saWdodC5jb2xvci5zZXRIZXgoMHgwNmI2ZDQpOyAvLyBDeWFuIHNwaXJpdCBnbG93XG5cbiAgICAgIGNvbnN0IGwyID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZVN0b25lTGFudGVybighdGhpcy5pc1NvZnR3YXJlR2wpO1xuICAgICAgbDIuZ3JvdXAucG9zaXRpb24uc2V0KDYsIDAsIHopO1xuICAgICAgaWYgKGwyLmxpZ2h0KSBsMi5saWdodC5jb2xvci5zZXRIZXgoMHgwNmI2ZDQpO1xuICAgICAgdGhpcy5zY2VuZS5hZGQobDEuZ3JvdXAsIGwyLmdyb3VwKTtcbiAgICB9KTtcblxuICAgIC8vIERhcmsgVG9yaWkgR2F0ZVxuICAgIGNvbnN0IHRvcmlpID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZVRvcmlpR2F0ZSgpO1xuICAgIHRvcmlpLnBvc2l0aW9uLnNldCgwLCAwLCAxOCk7XG4gICAgdGhpcy5zY2VuZS5hZGQodG9yaWkpO1xuXG4gICAgLy8gRWVyaWUgQmxhY2sgUGluZXNcbiAgICBbWy0xNCwgMCwgMTBdLCBbMTQsIDAsIDEyXSwgWy0xNiwgMCwgLTEwXSwgWzE2LCAwLCAtOF0sIFstMTIsIDAsIC0yOF0sIFsxMiwgMCwgLTI4XV0uZm9yRWFjaChwID0+IHtcbiAgICAgIGNvbnN0IHBpbmUgPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlUGluZVRyZWUoKTtcbiAgICAgIHBpbmUucG9zaXRpb24uc2V0KHBbMF0sIHBbMV0sIHBbMl0pO1xuICAgICAgdGhpcy5zY2VuZS5hZGQocGluZSk7XG4gICAgfSk7XG5cbiAgICB0aGlzLmJ1aWxkUGVyaW1ldGVyTW91bnRhaW5zKDB4MDIwNjE3KTtcbiAgfVxuXG4gIC8vIExFVkVMIDQ6IElyb24gRHJhZ29uIENpdGFkZWwgLyBNb3VudGFpbiBGb3J0cmVzc1xuICBwcml2YXRlIGJ1aWxkRm9ydHJlc3NMZXZlbCgpIHtcbiAgICBjb25zdCBncm91bmRHZW8gPSBuZXcgVEhSRUUuUGxhbmVHZW9tZXRyeSgxNjAsIDE2MCwgMTYsIDE2KTtcbiAgICBjb25zdCBncm91bmRNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoeyBjb2xvcjogMHgxODE4MWIsIHJvdWdobmVzczogMC45IH0pO1xuICAgIGNvbnN0IGdyb3VuZCA9IG5ldyBUSFJFRS5NZXNoKGdyb3VuZEdlbywgZ3JvdW5kTWF0KTtcbiAgICBncm91bmQucm90YXRpb24ueCA9IC1NYXRoLlBJIC8gMjtcbiAgICBncm91bmQucmVjZWl2ZVNoYWRvdyA9ICF0aGlzLmlzU29mdHdhcmVHbDtcbiAgICB0aGlzLnNjZW5lLmFkZChncm91bmQpO1xuXG4gICAgLy8gRm9ydHJlc3MgUGF2ZWQgUm9hZFxuICAgIGNvbnN0IHJvYWRHZW8gPSBuZXcgVEhSRUUuUGxhbmVHZW9tZXRyeSgxMCwgODApO1xuICAgIGNvbnN0IHJvYWRNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgbWFwOiBUZXh0dXJlR2VuZXJhdG9yLmdldFN0b25lUGF2ZW1lbnRUZXh0dXJlKCksXG4gICAgICByb3VnaG5lc3M6IDAuNzUsXG4gICAgfSk7XG4gICAgY29uc3Qgcm9hZCA9IG5ldyBUSFJFRS5NZXNoKHJvYWRHZW8sIHJvYWRNYXQpO1xuICAgIHJvYWQucm90YXRpb24ueCA9IC1NYXRoLlBJIC8gMjtcbiAgICByb2FkLnBvc2l0aW9uLnNldCgwLCAwLjAyLCAwKTtcbiAgICB0aGlzLnNjZW5lLmFkZChyb2FkKTtcblxuICAgIC8vIDMgV2F0Y2h0b3dlcnNcbiAgICBjb25zdCB0MSA9IEVudmlyb25tZW50QnVpbGRlci5jcmVhdGVXYXRjaHRvd2VyKCk7XG4gICAgdDEucG9zaXRpb24uc2V0KC0xMCwgMCwgMTApO1xuICAgIGNvbnN0IHQyID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZVdhdGNodG93ZXIoKTtcbiAgICB0Mi5wb3NpdGlvbi5zZXQoMTAsIDAsIDgpO1xuICAgIGNvbnN0IHQzID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZVdhdGNodG93ZXIoKTtcbiAgICB0My5wb3NpdGlvbi5zZXQoMCwgMCwgLTMyKTtcbiAgICB0aGlzLnNjZW5lLmFkZCh0MSwgdDIsIHQzKTtcblxuICAgIC8vIERlZmVuc2l2ZSBTcGlrZWQgQmFycmljYWRlc1xuICAgIFstNCwgMTIsIC0yMF0uZm9yRWFjaCh6ID0+IHtcbiAgICAgIGNvbnN0IGIxID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZVNwaWtlZEJhcnJpY2FkZSgpO1xuICAgICAgYjEucG9zaXRpb24uc2V0KC03LCAwLCB6KTtcbiAgICAgIGNvbnN0IGIyID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZVNwaWtlZEJhcnJpY2FkZSgpO1xuICAgICAgYjIucG9zaXRpb24uc2V0KDcsIDAsIHopO1xuICAgICAgdGhpcy5zY2VuZS5hZGQoYjEsIGIyKTtcbiAgICB9KTtcblxuICAgIC8vIDQgSXJvbiBGaXJlIEJyYXppZXJzXG4gICAgWy0xMCwgNCwgLTE4LCAtMjZdLmZvckVhY2goeiA9PiB7XG4gICAgICBjb25zdCBicnogPSBFbnZpcm9ubWVudEJ1aWxkZXIuY3JlYXRlQnJhemllcigweGY1OWUwYik7XG4gICAgICBicnouZ3JvdXAucG9zaXRpb24uc2V0KHogJSAyID09PSAwID8gLTUgOiA1LCAwLCB6KTtcbiAgICAgIHRoaXMuc2NlbmUuYWRkKGJyei5ncm91cCk7XG4gICAgfSk7XG5cbiAgICAvLyBGb3J0cmVzcyBzdXNwZW5zaW9uIGJyaWRnZVxuICAgIGNvbnN0IGJyaWRnZSA9IEVudmlyb25tZW50QnVpbGRlci5jcmVhdGVBcmNoZWRCcmlkZ2UoMTIsIDQpO1xuICAgIGJyaWRnZS5wb3NpdGlvbi5zZXQoMCwgMCwgLTgpO1xuICAgIHRoaXMuc2NlbmUuYWRkKGJyaWRnZSk7XG5cbiAgICAvLyBXYXIgVGVudHNcbiAgICBjb25zdCB0ZW50MSA9IEVudmlyb25tZW50QnVpbGRlci5jcmVhdGVFbmVteVRlbnQoKTtcbiAgICB0ZW50MS5wb3NpdGlvbi5zZXQoLTEyLCAwLCAtMTgpO1xuICAgIGNvbnN0IHRlbnQyID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZUVuZW15VGVudCgpO1xuICAgIHRlbnQyLnBvc2l0aW9uLnNldCgxMiwgMCwgLTE4KTtcbiAgICB0aGlzLnNjZW5lLmFkZCh0ZW50MSwgdGVudDIpO1xuXG4gICAgdGhpcy5idWlsZFBlcmltZXRlck1vdW50YWlucygweDI5MjUyNCk7XG4gIH1cblxuICAvLyBMRVZFTCA1OiBCbG9vZCBNb29uIEZpbmFsIEJvc3MgQXJlbmFcbiAgcHJpdmF0ZSBidWlsZEFyZW5hTGV2ZWwoKSB7XG4gICAgLy8gRmxvYXRpbmcgT2JzaWRpYW4gQWx0YXIgUGxhdGZvcm1cbiAgICBjb25zdCBhcmVuYUdlbyA9IG5ldyBUSFJFRS5DeWxpbmRlckdlb21ldHJ5KDI4LCAzMCwgMi41LCAyNCk7XG4gICAgY29uc3Qgb2JzTWF0ID0gbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtcbiAgICAgIGNvbG9yOiAweDA5MDkwYixcbiAgICAgIG1ldGFsbmVzczogMC44NSxcbiAgICAgIHJvdWdobmVzczogMC4yLFxuICAgIH0pO1xuICAgIGNvbnN0IGFyZW5hID0gbmV3IFRIUkVFLk1lc2goYXJlbmFHZW8sIG9ic01hdCk7XG4gICAgYXJlbmEucG9zaXRpb24uc2V0KDAsIC0xLjI1LCAtNik7XG4gICAgYXJlbmEucmVjZWl2ZVNoYWRvdyA9ICF0aGlzLmlzU29mdHdhcmVHbDtcbiAgICB0aGlzLnNjZW5lLmFkZChhcmVuYSk7XG5cbiAgICAvLyBJbm5lciBSdW5lZCBEdWVsIFJpbmdcbiAgICBjb25zdCByaW5nR2VvID0gbmV3IFRIUkVFLlJpbmdHZW9tZXRyeSg4LCA4LjUsIDMyKTtcbiAgICBjb25zdCByaW5nTWF0ID0gbmV3IFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKHsgY29sb3I6IDB4ZWY0NDQ0LCBzaWRlOiBUSFJFRS5Eb3VibGVTaWRlIH0pO1xuICAgIGNvbnN0IHJpbmcgPSBuZXcgVEhSRUUuTWVzaChyaW5nR2VvLCByaW5nTWF0KTtcbiAgICByaW5nLnJvdGF0aW9uLnggPSAtTWF0aC5QSSAvIDI7XG4gICAgcmluZy5wb3NpdGlvbi5zZXQoMCwgMC4wNSwgLTYpO1xuICAgIHRoaXMuc2NlbmUuYWRkKHJpbmcpO1xuXG4gICAgLy8gVm9sY2FuaWMgT2JzaWRpYW4gTW9ub2xpdGggU3Bpa2VzXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCA4OyBpKyspIHtcbiAgICAgIGNvbnN0IGFuZ2xlID0gKGkgKiBNYXRoLlBJICogMikgLyA4O1xuICAgICAgY29uc3QgbW9ubyA9IEVudmlyb25tZW50QnVpbGRlci5jcmVhdGVPYnNpZGlhbk1vbm9saXRoKCk7XG4gICAgICBtb25vLnBvc2l0aW9uLnNldChNYXRoLmNvcyhhbmdsZSkgKiAyNCwgMCwgTWF0aC5zaW4oYW5nbGUpICogMjQgLSA2KTtcbiAgICAgIG1vbm8ucm90YXRpb24ueSA9IGFuZ2xlO1xuICAgICAgdGhpcy5zY2VuZS5hZGQobW9ubyk7XG4gICAgfVxuXG4gICAgLy8gNCBEZW1vbmljIEJsb29kLVJlZCBCcmF6aWVyc1xuICAgIGZvciAobGV0IGIgPSAwOyBiIDwgNDsgYisrKSB7XG4gICAgICBjb25zdCBhbmdsZSA9IChiICogTWF0aC5QSSAqIDIpIC8gNCArIE1hdGguUEkgLyA0O1xuICAgICAgY29uc3QgYnJ6ID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZUJyYXppZXIoMHhkYzI2MjYpO1xuICAgICAgYnJ6Lmdyb3VwLnBvc2l0aW9uLnNldChNYXRoLmNvcyhhbmdsZSkgKiAxNCwgMCwgTWF0aC5zaW4oYW5nbGUpICogMTQgLSA2KTtcbiAgICAgIHRoaXMuc2NlbmUuYWRkKGJyei5ncm91cCk7XG4gICAgfVxuXG4gICAgLy8gQnJva2VuIEFuY2llbnQgVG9yaWkgUGlsbGFyc1xuICAgIGNvbnN0IHRvcmlpID0gRW52aXJvbm1lbnRCdWlsZGVyLmNyZWF0ZVRvcmlpR2F0ZSgpO1xuICAgIHRvcmlpLnBvc2l0aW9uLnNldCgwLCAwLCAxNCk7XG4gICAgdG9yaWkucm90YXRpb24ueiA9IDAuMDg7XG4gICAgdGhpcy5zY2VuZS5hZGQodG9yaWkpO1xuXG4gICAgLy8gQm90dG9tbGVzcyB2b2lkIGJhY2tkcm9wOiBKYWdnZWQgdm9sY2FuaWMgY3JhZ3NcbiAgICB0aGlzLmJ1aWxkUGVyaW1ldGVyTW91bnRhaW5zKDB4NDUwYTBhKTtcbiAgfVxuXG4gIHByaXZhdGUgYnVpbGRQZXJpbWV0ZXJNb3VudGFpbnMoY29sb3I6IG51bWJlcikge1xuICAgIGNvbnN0IHJvY2tNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgY29sb3IsXG4gICAgICByb3VnaG5lc3M6IDAuOSxcbiAgICB9KTtcblxuICAgIGZvciAobGV0IHIgPSAwOyByIDwgMjQ7IHIrKykge1xuICAgICAgY29uc3QgYW5nbGUgPSAociAqIE1hdGguUEkgKiAyKSAvIDI0O1xuICAgICAgY29uc3QgZGlzdCA9IDUyICsgTWF0aC5yYW5kb20oKSAqIDg7XG4gICAgICBjb25zdCBtb3VudGFpbkdlbyA9IG5ldyBUSFJFRS5Db25lR2VvbWV0cnkoOCArIE1hdGgucmFuZG9tKCkgKiA2LCAyMiArIE1hdGgucmFuZG9tKCkgKiAxMCwgNSk7XG4gICAgICBjb25zdCBtb3VudGFpbiA9IG5ldyBUSFJFRS5NZXNoKG1vdW50YWluR2VvLCByb2NrTWF0KTtcbiAgICAgIG1vdW50YWluLnBvc2l0aW9uLnNldChNYXRoLmNvcyhhbmdsZSkgKiBkaXN0LCA4LCBNYXRoLnNpbihhbmdsZSkgKiBkaXN0KTtcbiAgICAgIG1vdW50YWluLnNjYWxlLnNldCgxICsgTWF0aC5yYW5kb20oKSAqIDAuNSwgMSwgMSArIE1hdGgucmFuZG9tKCkgKiAwLjUpO1xuICAgICAgdGhpcy5zY2VuZS5hZGQobW91bnRhaW4pO1xuICAgIH1cbiAgfVxuXG4gIC8vIExFVkVMLVNQRUNJRklDIEVORU1ZIFNQQVdOSU5HIFdJVEggU0NBTElORyBESUZGSUNVTFRZXG4gIHByaXZhdGUgc3Bhd25Jbml0aWFsRW5lbWllcygpIHtcbiAgICBjb25zdCBsdmwgPSB0aGlzLmN1cnJlbnRMZXZlbC5pZDtcblxuICAgIGlmIChsdmwgPT09IDEpIHtcbiAgICAgIC8vIExldmVsIDE6IDYgRW5lbWllcyAoQXNoaWdhcnUgcmVjcnVpdHMgKyAyIGxpZ2h0IG5pbmphcylcbiAgICAgIGNvbnN0IHNwYXduczogeyB0eXBlOiBFbmVteVR5cGU7IHBvczogVEhSRUUuVmVjdG9yMyB9W10gPSBbXG4gICAgICAgIHsgdHlwZTogJ25vcm1hbCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoLTQsIDAsIDgpIH0sXG4gICAgICAgIHsgdHlwZTogJ25vcm1hbCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoNCwgMCwgOCkgfSxcbiAgICAgICAgeyB0eXBlOiAnbm9ybWFsJywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygtNiwgMCwgLTQpIH0sXG4gICAgICAgIHsgdHlwZTogJ25vcm1hbCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoNiwgMCwgLTQpIH0sXG4gICAgICAgIHsgdHlwZTogJ2Zhc3QnLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKC01LCAwLCAtMTYpIH0sXG4gICAgICAgIHsgdHlwZTogJ2Zhc3QnLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKDUsIDAsIC0xOCkgfSxcbiAgICAgIF07XG4gICAgICBzcGF3bnMuZm9yRWFjaChzID0+IHRoaXMuc3Bhd25FbmVteShzLnR5cGUsIHMucG9zKSk7XG4gICAgfSBlbHNlIGlmIChsdmwgPT09IDIpIHtcbiAgICAgIC8vIExldmVsIDI6IDggRW5lbWllcyAoUmFpZGVycyArIEFnaWxlIGR1YWwtZGFnZ2VyIG5pbmphcyArIHRvcmNoIGhlYXZ5KVxuICAgICAgY29uc3Qgc3Bhd25zOiB7IHR5cGU6IEVuZW15VHlwZTsgcG9zOiBUSFJFRS5WZWN0b3IzIH1bXSA9IFtcbiAgICAgICAgeyB0eXBlOiAnbm9ybWFsJywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygtNSwgMCwgMTApIH0sXG4gICAgICAgIHsgdHlwZTogJ2Zhc3QnLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKDUsIDAsIDEwKSB9LFxuICAgICAgICB7IHR5cGU6ICdub3JtYWwnLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKC03LCAwLCAtMikgfSxcbiAgICAgICAgeyB0eXBlOiAnZmFzdCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoNywgMCwgLTIpIH0sXG4gICAgICAgIHsgdHlwZTogJ2hlYXZ5JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygwLCAwLCAtMTApIH0sXG4gICAgICAgIHsgdHlwZTogJ25vcm1hbCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoLTYsIDAsIC0xOCkgfSxcbiAgICAgICAgeyB0eXBlOiAnZmFzdCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoNiwgMCwgLTE4KSB9LFxuICAgICAgICB7IHR5cGU6ICdub3JtYWwnLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKDAsIDAsIC0yNCkgfSxcbiAgICAgIF07XG4gICAgICBzcGF3bnMuZm9yRWFjaChzID0+IHRoaXMuc3Bhd25FbmVteShzLnR5cGUsIHMucG9zKSk7XG4gICAgfSBlbHNlIGlmIChsdmwgPT09IDMpIHtcbiAgICAgIC8vIExldmVsIDM6IDEwIEVuZW1pZXMgKFRlbXBsZSBOaW5qYXMgKyBNYXJrc21hbiBBcmNoZXJzKVxuICAgICAgY29uc3Qgc3Bhd25zOiB7IHR5cGU6IEVuZW15VHlwZTsgcG9zOiBUSFJFRS5WZWN0b3IzIH1bXSA9IFtcbiAgICAgICAgeyB0eXBlOiAnZmFzdCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoLTUsIDAsIDgpIH0sXG4gICAgICAgIHsgdHlwZTogJ2FyY2hlcicsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoOCwgMCwgOCkgfSxcbiAgICAgICAgeyB0eXBlOiAnZmFzdCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoLTgsIDAsIDApIH0sXG4gICAgICAgIHsgdHlwZTogJ25vcm1hbCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoMCwgMCwgLTQpIH0sXG4gICAgICAgIHsgdHlwZTogJ2FyY2hlcicsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoLTksIDAsIC0xMikgfSxcbiAgICAgICAgeyB0eXBlOiAnZmFzdCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoNiwgMCwgLTEyKSB9LFxuICAgICAgICB7IHR5cGU6ICdhcmNoZXInLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKDgsIDAsIC0yMCkgfSxcbiAgICAgICAgeyB0eXBlOiAnbm9ybWFsJywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygtNCwgMCwgLTIyKSB9LFxuICAgICAgICB7IHR5cGU6ICdmYXN0JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMyg0LCAwLCAtMjQpIH0sXG4gICAgICAgIHsgdHlwZTogJ2FyY2hlcicsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoMCwgMCwgLTI4KSB9LFxuICAgICAgXTtcbiAgICAgIHNwYXducy5mb3JFYWNoKHMgPT4gdGhpcy5zcGF3bkVuZW15KHMudHlwZSwgcy5wb3MpKTtcbiAgICB9IGVsc2UgaWYgKGx2bCA9PT0gNCkge1xuICAgICAgLy8gTGV2ZWwgNDogMTIgRW5lbWllcyAoSGVhdnkgQXJtb3JlZCBTYW11cmFpICsgQXJjaGVycyArIE5pbmphcylcbiAgICAgIGNvbnN0IHNwYXduczogeyB0eXBlOiBFbmVteVR5cGU7IHBvczogVEhSRUUuVmVjdG9yMyB9W10gPSBbXG4gICAgICAgIHsgdHlwZTogJ2hlYXZ5JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygtNiwgMCwgMTApIH0sXG4gICAgICAgIHsgdHlwZTogJ2FyY2hlcicsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoOCwgMCwgMTApIH0sXG4gICAgICAgIHsgdHlwZTogJ2Zhc3QnLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKC03LCAwLCAyKSB9LFxuICAgICAgICB7IHR5cGU6ICdoZWF2eScsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoNiwgMCwgMCkgfSxcbiAgICAgICAgeyB0eXBlOiAnYXJjaGVyJywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygtOSwgMCwgLTgpIH0sXG4gICAgICAgIHsgdHlwZTogJ25vcm1hbCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoOCwgMCwgLTgpIH0sXG4gICAgICAgIHsgdHlwZTogJ2hlYXZ5JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygtNSwgMCwgLTE2KSB9LFxuICAgICAgICB7IHR5cGU6ICdmYXN0JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMyg1LCAwLCAtMTYpIH0sXG4gICAgICAgIHsgdHlwZTogJ2hlYXZ5JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygwLCAwLCAtMjIpIH0sXG4gICAgICAgIHsgdHlwZTogJ2FyY2hlcicsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoLTgsIDAsIC0yNCkgfSxcbiAgICAgICAgeyB0eXBlOiAnaGVhdnknLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKDgsIDAsIC0yNikgfSxcbiAgICAgICAgeyB0eXBlOiAnZmFzdCcsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoMCwgMCwgLTI4KSB9LFxuICAgICAgXTtcbiAgICAgIHNwYXducy5mb3JFYWNoKHMgPT4gdGhpcy5zcGF3bkVuZW15KHMudHlwZSwgcy5wb3MpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gTGV2ZWwgNTogMTQgRW5lbWllcyAoRWxpdGUgQmxvb2QgU2FtdXJhaSwgRXhlY3V0aW9uZXJzLCBWb2lkIEFzc2Fzc2lucylcbiAgICAgIGNvbnN0IHNwYXduczogeyB0eXBlOiBFbmVteVR5cGU7IHBvczogVEhSRUUuVmVjdG9yMyB9W10gPSBbXG4gICAgICAgIHsgdHlwZTogJ2Zhc3QnLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKC02LCAwLCA2KSB9LFxuICAgICAgICB7IHR5cGU6ICdmYXN0JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMyg2LCAwLCA2KSB9LFxuICAgICAgICB7IHR5cGU6ICdoZWF2eScsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoLTgsIDAsIDApIH0sXG4gICAgICAgIHsgdHlwZTogJ2hlYXZ5JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMyg4LCAwLCAwKSB9LFxuICAgICAgICB7IHR5cGU6ICdub3JtYWwnLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKDAsIDAsIC00KSB9LFxuICAgICAgICB7IHR5cGU6ICdmYXN0JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygtOSwgMCwgLTEwKSB9LFxuICAgICAgICB7IHR5cGU6ICdmYXN0JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMyg5LCAwLCAtMTApIH0sXG4gICAgICAgIHsgdHlwZTogJ2hlYXZ5JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygtNiwgMCwgLTE2KSB9LFxuICAgICAgICB7IHR5cGU6ICdoZWF2eScsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoNiwgMCwgLTE2KSB9LFxuICAgICAgICB7IHR5cGU6ICdhcmNoZXInLCBwb3M6IG5ldyBUSFJFRS5WZWN0b3IzKC04LCAwLCAtMjApIH0sXG4gICAgICAgIHsgdHlwZTogJ2FyY2hlcicsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoOCwgMCwgLTIwKSB9LFxuICAgICAgICB7IHR5cGU6ICdoZWF2eScsIHBvczogbmV3IFRIUkVFLlZlY3RvcjMoMCwgMCwgLTIyKSB9LFxuICAgICAgICB7IHR5cGU6ICdmYXN0JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMygtNSwgMCwgLTI1KSB9LFxuICAgICAgICB7IHR5cGU6ICdmYXN0JywgcG9zOiBuZXcgVEhSRUUuVmVjdG9yMyg1LCAwLCAtMjUpIH0sXG4gICAgICBdO1xuICAgICAgc3Bhd25zLmZvckVhY2gocyA9PiB0aGlzLnNwYXduRW5lbXkocy50eXBlLCBzLnBvcykpO1xuICAgIH1cblxuICAgIC8vIEluIGVhY2ggbGV2ZWwsIG9ubHkgMSBvciAyIGVuZW1pZXMgaGF2ZSB0aGUgUG93ZXIgQmFkZ2UgKFwicG93ZXIga2EgbmlzaGFuXCIpIG92ZXIgdGhlaXIgaGVhZHMhXG4gICAgLy8gRGVmZWF0aW5nIG9ubHkgdGhlc2Ugc3BlY2lmaWMgbWFya2VkIGVuZW1pZXMgd2lsbCBkcm9wIGNvbGxlY3RpYmxlIHBvd2VyIVxuICAgIGNvbnN0IHBvd2VySW5kaWNlcyA9IGx2bCA8PSAyID8gWzFdIDogWzIsIE1hdGgubWluKDUsIHRoaXMuZW5lbWllcy5sZW5ndGggLSAxKV07XG4gICAgcG93ZXJJbmRpY2VzLmZvckVhY2goaWR4ID0+IHtcbiAgICAgIGNvbnN0IGVuZW15ID0gdGhpcy5lbmVtaWVzW2lkeF07XG4gICAgICBpZiAoZW5lbXkgJiYgIWVuZW15LmlzQm9zcykge1xuICAgICAgICBlbmVteS5oYXNQb3dlckNhcnJpZXJCYWRnZSA9IHRydWU7XG4gICAgICAgIGVuZW15LnBvd2VyQmFkZ2VNZXNoID0gdGhpcy5jcmVhdGVQb3dlckNhcnJpZXJCYWRnZSgpO1xuICAgICAgICBlbmVteS5wb3dlckJhZGdlTWVzaC5wb3NpdGlvbi5zZXQoXG4gICAgICAgICAgZW5lbXkucmlnLnJvb3QucG9zaXRpb24ueCxcbiAgICAgICAgICBlbmVteS5yaWcucm9vdC5wb3NpdGlvbi55ICsgMi4zLFxuICAgICAgICAgIGVuZW15LnJpZy5yb290LnBvc2l0aW9uLnpcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5zY2VuZS5hZGQoZW5lbXkucG93ZXJCYWRnZU1lc2gpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIHNwYXduRW5lbXkodHlwZTogRW5lbXlUeXBlLCBwb3M6IFRIUkVFLlZlY3RvcjMsIGlzQm9zcyA9IGZhbHNlKTogRW5lbXlJbnN0YW5jZSB7XG4gICAgY29uc3QgbHZsID0gdGhpcy5jdXJyZW50TGV2ZWwuaWQ7XG4gICAgLy8gSW5jcmVhc2luZyBkaWZmaWN1bHR5IG11bHRpcGxpZXIgcGVyIGxldmVsIChMdmwgMTogMS4weCwgTHZsIDI6IDEuMjV4LCBMdmwgMzogMS41eCwgTHZsIDQ6IDEuOHgsIEx2bCA1OiAyLjJ4KVxuICAgIGNvbnN0IGRpZmZNdWx0aXBsaWVyID0gMS4wICsgKGx2bCAtIDEpICogMC4yODtcblxuICAgIGNvbnN0IHJpZyA9IENoYXJhY3RlckZhY3RvcnkuY3JlYXRlRW5lbXkoXG4gICAgICB0eXBlLFxuICAgICAgaXNCb3NzLFxuICAgICAgdGhpcy5jdXJyZW50TGV2ZWwuZW52aXJvbm1lbnRUaGVtZSA9PT0gJ2FyZW5hJyA/ICdyYWlkZW4nIDogdW5kZWZpbmVkXG4gICAgKTtcbiAgICB0aGlzLnNjZW5lLmFkZChyaWcucm9vdCk7XG4gICAgcmlnLnJvb3QucG9zaXRpb24uY29weShwb3MpO1xuXG4gICAgbGV0IGJhc2VIZWFsdGggPSA2NTtcbiAgICBsZXQgYmFzZVBvd2VyID0gOTtcbiAgICBsZXQgc3BlZWQgPSA0LjA7XG4gICAgbGV0IHJhbmdlID0gMi4wO1xuXG4gICAgaWYgKHR5cGUgPT09ICdmYXN0Jykge1xuICAgICAgYmFzZUhlYWx0aCA9IDU1O1xuICAgICAgYmFzZVBvd2VyID0gMTE7XG4gICAgICBzcGVlZCA9IDUuOCArIChsdmwgKiAwLjIpO1xuICAgICAgcmFuZ2UgPSAxLjk7XG4gICAgfSBlbHNlIGlmICh0eXBlID09PSAnaGVhdnknKSB7XG4gICAgICBiYXNlSGVhbHRoID0gMTM1O1xuICAgICAgYmFzZVBvd2VyID0gMjA7XG4gICAgICBzcGVlZCA9IDIuOCArIChsdmwgKiAwLjE1KTtcbiAgICAgIHJhbmdlID0gMi40O1xuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ2FyY2hlcicpIHtcbiAgICAgIGJhc2VIZWFsdGggPSA2MDtcbiAgICAgIGJhc2VQb3dlciA9IDE1O1xuICAgICAgc3BlZWQgPSAzLjg7XG4gICAgICByYW5nZSA9IDE2LjA7XG4gICAgfSBlbHNlIGlmIChpc0Jvc3MpIHtcbiAgICAgIGJhc2VIZWFsdGggPSAzMjAgKyBsdmwgKiAxODA7XG4gICAgICBiYXNlUG93ZXIgPSAxOCArIGx2bCAqIDY7XG4gICAgICBzcGVlZCA9IDQuOCArIGx2bCAqIDAuMjU7XG4gICAgICByYW5nZSA9IDIuNjtcbiAgICB9XG5cbiAgICBjb25zdCBmaW5hbEhlYWx0aCA9IE1hdGgucm91bmQoYmFzZUhlYWx0aCAqIGRpZmZNdWx0aXBsaWVyKTtcbiAgICBjb25zdCBmaW5hbFBvd2VyID0gTWF0aC5yb3VuZChiYXNlUG93ZXIgKiBkaWZmTXVsdGlwbGllcik7XG5cbiAgICBjb25zdCBlbmVteTogRW5lbXlJbnN0YW5jZSA9IHtcbiAgICAgIGlkOiB0aGlzLm5leHRFbmVteUlkKyssXG4gICAgICB0eXBlLFxuICAgICAgbmFtZTogaXNCb3NzID8gdGhpcy5jdXJyZW50TGV2ZWwuYm9zc05hbWUgOiBgRW5lbXkgJHt0eXBlLnRvVXBwZXJDYXNlKCl9YCxcbiAgICAgIGlzQm9zcyxcbiAgICAgIHJpZyxcbiAgICAgIGhlYWx0aDogZmluYWxIZWFsdGgsXG4gICAgICBtYXhIZWFsdGg6IGZpbmFsSGVhbHRoLFxuICAgICAgYXR0YWNrUG93ZXI6IGZpbmFsUG93ZXIsXG4gICAgICBzcGVlZCxcbiAgICAgIHJhbmdlLFxuICAgICAgc3RhdGU6ICdpZGxlJyxcbiAgICAgIHN0YXRlVGltZXI6IE1hdGgucmFuZG9tKCkgKiAyLFxuICAgICAgYXR0YWNrQ29vbGRvd246IDEuOCxcbiAgICAgIGF0dGFja1dpbmR1cDogMCxcbiAgICAgIHBhdHJvbFBvaW50OiBwb3MuY2xvbmUoKSxcbiAgICAgIHRhcmdldFBvczogcG9zLmNsb25lKCksXG4gICAgICBkaXNzb2x2ZVRpbWVyOiAwLFxuICAgIH07XG5cbiAgICB0aGlzLmVuZW1pZXMucHVzaChlbmVteSk7XG5cbiAgICBpZiAoaXNCb3NzKSB7XG4gICAgICB0aGlzLmJvc3NJbnN0YW5jZSA9IGVuZW15O1xuICAgICAgaWYgKHRoaXMub25Cb3NzSGVhbHRoVXBkYXRlKSB7XG4gICAgICAgIHRoaXMub25Cb3NzSGVhbHRoVXBkYXRlKGVuZW15LmhlYWx0aCwgZW5lbXkubWF4SGVhbHRoLCBlbmVteS5uYW1lKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZW5lbXk7XG4gIH1cblxuICAvLyAtLS0gSW5wdXQgSGFuZGxlcnMgLS0tXG5cbiAgcHVibGljIHVwZGF0ZUlucHV0KG5ld0lucHV0OiBQYXJ0aWFsPFVzZXJJbnB1dD4pIHtcbiAgICBPYmplY3QuYXNzaWduKHRoaXMuaW5wdXQsIG5ld0lucHV0KTtcblxuICAgIGlmIChuZXdJbnB1dC5hdHRhY2spIHtcbiAgICAgIHRoaXMudHJpZ2dlckF0dGFjaygpO1xuICAgIH1cbiAgICBpZiAobmV3SW5wdXQuaGVhdnlBdHRhY2spIHtcbiAgICAgIHRoaXMudHJpZ2dlckhlYXZ5S2ljaygpO1xuICAgIH1cbiAgICBpZiAobmV3SW5wdXQuanVtcCkge1xuICAgICAgdGhpcy50cmlnZ2VySnVtcCgpO1xuICAgIH1cbiAgICBpZiAobmV3SW5wdXQuZG9kZ2UpIHtcbiAgICAgIHRoaXMudHJpZ2dlckRvZGdlKCk7XG4gICAgfVxuICAgIGlmIChuZXdJbnB1dC5zcGVjaWFsKSB7XG4gICAgICB0aGlzLnRyaWdnZXJTcGVjaWFsUG93ZXIoKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgdHJpZ2dlckF0dGFjaygpIHtcbiAgICBpZiAodGhpcy5pc0F0dGFja2luZyB8fCAhdGhpcy5pc0dyb3VuZGVkKSByZXR1cm47XG5cbiAgICB0aGlzLmlzQXR0YWNraW5nID0gdHJ1ZTtcbiAgICB0aGlzLmN1cnJlbnRDb21ib1N0ZXAgPSAodGhpcy5jdXJyZW50Q29tYm9TdGVwICUgMykgKyAxO1xuICAgIHRoaXMuY29tYm9XaW5kb3dUaW1lciA9IDEuMjtcbiAgICB0aGlzLmF0dGFja1RpbWVyID0gMDtcblxuICAgIGNvbnN0IGFuaW1OYW1lID0gYGF0dGFjayR7dGhpcy5jdXJyZW50Q29tYm9TdGVwfWAgYXMgJ2F0dGFjazEnIHwgJ2F0dGFjazInIHwgJ2F0dGFjazMnO1xuICAgIHRoaXMucGxheWVyUmlnLmN1cnJlbnRBbmltID0gYW5pbU5hbWU7XG4gICAgdGhpcy5wbGF5ZXJSaWcuYW5pbVByb2dyZXNzID0gMDtcblxuICAgIC8vIFNvdW5kXG4gICAgc291bmRNYW5hZ2VyLnBsYXlTd29yZFNsYXNoKHRoaXMuY3VycmVudENvbWJvU3RlcCk7XG5cbiAgICAvLyBTbWFsbCBmb3J3YXJkIGx1bmdlXG4gICAgY29uc3QgZm9yd2FyZCA9IG5ldyBUSFJFRS5WZWN0b3IzKFxuICAgICAgTWF0aC5zaW4odGhpcy5wbGF5ZXJSb3RhdGlvbiksXG4gICAgICAwLFxuICAgICAgTWF0aC5jb3ModGhpcy5wbGF5ZXJSb3RhdGlvbilcbiAgICApO1xuICAgIHRoaXMucGxheWVyVmVsb2NpdHkuYWRkU2NhbGVkVmVjdG9yKGZvcndhcmQsIDQuNSk7XG5cbiAgICAvLyBIaXQgZGV0ZWN0aW9uIGhhbGZ3YXkgdGhyb3VnaCBhdHRhY2sgYW5pbWF0aW9uXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0aGlzLnBlcmZvcm1QbGF5ZXJBdHRhY2tIaXRjaGVjayh0aGlzLmN1cnJlbnRDb21ib1N0ZXApO1xuICAgIH0sIDEyMCk7XG5cbiAgICAvLyBSZXNldCBhdHRhY2sgc3RhdGUgd2hlbiBhbmltYXRpb24gY29tcGxldGVzXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0aGlzLmlzQXR0YWNraW5nID0gZmFsc2U7XG4gICAgICBpZiAodGhpcy5wbGF5ZXJSaWcuY3VycmVudEFuaW0uc3RhcnRzV2l0aCgnYXR0YWNrJykpIHtcbiAgICAgICAgdGhpcy5wbGF5ZXJSaWcuY3VycmVudEFuaW0gPSAnaWRsZSc7XG4gICAgICB9XG4gICAgfSwgMzIwIC8gdGhpcy5jdXJyZW50V2VhcG9uLnNwZWVkKTtcbiAgfVxuXG4gIHB1YmxpYyB0cmlnZ2VySGVhdnlLaWNrKCkge1xuICAgIGlmICh0aGlzLmlzQXR0YWNraW5nIHx8ICF0aGlzLmlzR3JvdW5kZWQpIHJldHVybjtcblxuICAgIHRoaXMuaXNBdHRhY2tpbmcgPSB0cnVlO1xuICAgIHRoaXMucGxheWVyUmlnLmN1cnJlbnRBbmltID0gJ2tpY2snO1xuICAgIHRoaXMucGxheWVyUmlnLmFuaW1Qcm9ncmVzcyA9IDA7XG5cbiAgICBzb3VuZE1hbmFnZXIucGxheUhlYXZ5SW1wYWN0KCk7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMucGVyZm9ybUhlYXZ5S2lja0hpdGNoZWNrKCk7XG4gICAgfSwgMTQwKTtcblxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5pc0F0dGFja2luZyA9IGZhbHNlO1xuICAgICAgdGhpcy5wbGF5ZXJSaWcuY3VycmVudEFuaW0gPSAnaWRsZSc7XG4gICAgfSwgNDAwKTtcbiAgfVxuXG4gIHB1YmxpYyB0cmlnZ2VySnVtcCgpIHtcbiAgICBpZiAoIXRoaXMuaXNHcm91bmRlZCB8fCB0aGlzLmlzQXR0YWNraW5nKSByZXR1cm47XG4gICAgdGhpcy5pc0dyb3VuZGVkID0gZmFsc2U7XG4gICAgdGhpcy5wbGF5ZXJWZWxvY2l0eS55ID0gOC44O1xuICAgIHRoaXMucGxheWVyUmlnLmN1cnJlbnRBbmltID0gJ2p1bXAnO1xuICB9XG5cbiAgcHVibGljIHRyaWdnZXJEb2RnZSgpIHtcbiAgICBpZiAodGhpcy5pc0ludnVsbmVyYWJsZSB8fCB0aGlzLmlzQXR0YWNraW5nKSByZXR1cm47XG5cbiAgICB0aGlzLmlzSW52dWxuZXJhYmxlID0gdHJ1ZTtcbiAgICB0aGlzLmludnVsbmVyYWJpbGl0eVRpbWVyID0gMC40NTtcbiAgICB0aGlzLnBsYXllclJpZy5jdXJyZW50QW5pbSA9ICdkb2RnZSc7XG4gICAgdGhpcy5wbGF5ZXJSaWcuYW5pbVByb2dyZXNzID0gMDtcblxuICAgIHNvdW5kTWFuYWdlci5wbGF5RG9kZ2VSb2xsKCk7XG4gICAgdGhpcy5wYXJ0aWNsZXMuc3Bhd25TbW9rZVB1ZmYodGhpcy5wbGF5ZXJQb3MsIDB4NjQ3NDhiLCA4KTtcblxuICAgIC8vIERhc2ggYnVyc3QgZm9yd2FyZFxuICAgIGNvbnN0IGZvcndhcmQgPSBuZXcgVEhSRUUuVmVjdG9yMyhcbiAgICAgIE1hdGguc2luKHRoaXMucGxheWVyUm90YXRpb24pLFxuICAgICAgMCxcbiAgICAgIE1hdGguY29zKHRoaXMucGxheWVyUm90YXRpb24pXG4gICAgKTtcbiAgICB0aGlzLnBsYXllclZlbG9jaXR5LmNvcHkoZm9yd2FyZC5tdWx0aXBseVNjYWxhcigxNCkpO1xuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0aGlzLnBsYXllclJpZy5jdXJyZW50QW5pbSA9ICdpZGxlJztcbiAgICB9LCA0NTApO1xuICB9XG5cbiAgcHVibGljIHRyaWdnZXJTcGVjaWFsUG93ZXIoKSB7XG4gICAgaWYgKHRoaXMuc3RhdHMuc3BlY2lhbENvb2xkb3duID4gMCB8fCB0aGlzLmlzQXR0YWNraW5nKSByZXR1cm47XG5cbiAgICAvLyAxLW1pbnV0ZSAoNjAgc2Vjb25kcykgY29vbGRvd24gdGltZXJcbiAgICB0aGlzLnN0YXRzLnNwZWNpYWxDb29sZG93biA9IDYwLjA7XG4gICAgdGhpcy5ub3RpZnlTdGF0cygpO1xuXG4gICAgdGhpcy5pc0F0dGFja2luZyA9IHRydWU7XG4gICAgdGhpcy5wbGF5ZXJSaWcuY3VycmVudEFuaW0gPSAnYXR0YWNrMyc7XG4gICAgdGhpcy5wbGF5ZXJSaWcuYW5pbVByb2dyZXNzID0gMDtcblxuICAgIHNvdW5kTWFuYWdlci5wbGF5U3BlY2lhbEJsYXN0KCk7XG5cbiAgICBjb25zdCBmb3J3YXJkID0gbmV3IFRIUkVFLlZlY3RvcjMoXG4gICAgICBNYXRoLnNpbih0aGlzLnBsYXllclJvdGF0aW9uKSxcbiAgICAgIDAsXG4gICAgICBNYXRoLmNvcyh0aGlzLnBsYXllclJvdGF0aW9uKVxuICAgICk7XG5cbiAgICB0aGlzLnBhcnRpY2xlcy5zcGF3blNwZWNpYWxFbmVyZ3lXYXZlKFxuICAgICAgdGhpcy5wbGF5ZXJQb3MsXG4gICAgICBmb3J3YXJkLFxuICAgICAgdGhpcy5jdXJyZW50V2VhcG9uLnRyYWlsQ29sb3IsXG4gICAgICB0aGlzLmN1cnJlbnRXZWFwb24uZGFtYWdlICogMi44XG4gICAgKTtcbiAgICB0aGlzLnBhcnRpY2xlcy5zcGF3bkhpdFNwYXJrcyh0aGlzLnBsYXllclBvcywgMHgzOGJkZjgsIDIwKTtcbiAgICB0aGlzLnNjcmVlblNoYWtlID0gMC41O1xuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0aGlzLmlzQXR0YWNraW5nID0gZmFsc2U7XG4gICAgICB0aGlzLnBsYXllclJpZy5jdXJyZW50QW5pbSA9ICdpZGxlJztcbiAgICB9LCA1MDApO1xuICB9XG5cbiAgLy8gLS0tIEhpdCBEZXRlY3Rpb24gJiBDb21iYXQgTG9naWMgLS0tXG5cbiAgcHJpdmF0ZSBwZXJmb3JtUGxheWVyQXR0YWNrSGl0Y2hlY2soY29tYm9TdGVwOiBudW1iZXIpIHtcbiAgICBjb25zdCBhdHRhY2tSYW5nZSA9IHRoaXMuY3VycmVudFdlYXBvbi5yYW5nZSArIChjb21ib1N0ZXAgPT09IDMgPyAwLjYgOiAwKTtcbiAgICBjb25zdCBmb3J3YXJkID0gbmV3IFRIUkVFLlZlY3RvcjMoXG4gICAgICBNYXRoLnNpbih0aGlzLnBsYXllclJvdGF0aW9uKSxcbiAgICAgIDAsXG4gICAgICBNYXRoLmNvcyh0aGlzLnBsYXllclJvdGF0aW9uKVxuICAgICk7XG5cbiAgICBsZXQgaGl0QW55ID0gZmFsc2U7XG5cbiAgICB0aGlzLmVuZW1pZXMuZm9yRWFjaChlbmVteSA9PiB7XG4gICAgICBpZiAoZW5lbXkuaGVhbHRoIDw9IDApIHJldHVybjtcblxuICAgICAgY29uc3QgdG9FbmVteSA9IGVuZW15LnJpZy5yb290LnBvc2l0aW9uLmNsb25lKCkuc3ViKHRoaXMucGxheWVyUG9zKTtcbiAgICAgIGNvbnN0IGRpc3QgPSB0b0VuZW15Lmxlbmd0aCgpO1xuXG4gICAgICBpZiAoZGlzdCA8PSBhdHRhY2tSYW5nZSkge1xuICAgICAgICB0b0VuZW15Lm5vcm1hbGl6ZSgpO1xuICAgICAgICBjb25zdCBkb3QgPSBmb3J3YXJkLmRvdCh0b0VuZW15KTtcblxuICAgICAgICAvLyBXaXRoaW4gMTQwIGRlZ3JlZSBmb3J3YXJkIGNvbmVcbiAgICAgICAgaWYgKGRvdCA+IDAuMjUpIHtcbiAgICAgICAgICBoaXRBbnkgPSB0cnVlO1xuICAgICAgICAgIHRoaXMuYXBwbHlEYW1hZ2VUb0VuZW15KGVuZW15LCBjb21ib1N0ZXApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBpZiAoaGl0QW55KSB7XG4gICAgICBzb3VuZE1hbmFnZXIucGxheVN3b3JkQ2xhc2goKTtcbiAgICAgIHRoaXMuc2NyZWVuU2hha2UgPSBNYXRoLm1heCh0aGlzLnNjcmVlblNoYWtlLCAwLjI1KTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHBlcmZvcm1IZWF2eUtpY2tIaXRjaGVjaygpIHtcbiAgICBjb25zdCBmb3J3YXJkID0gbmV3IFRIUkVFLlZlY3RvcjMoXG4gICAgICBNYXRoLnNpbih0aGlzLnBsYXllclJvdGF0aW9uKSxcbiAgICAgIDAsXG4gICAgICBNYXRoLmNvcyh0aGlzLnBsYXllclJvdGF0aW9uKVxuICAgICk7XG5cbiAgICB0aGlzLmVuZW1pZXMuZm9yRWFjaChlbmVteSA9PiB7XG4gICAgICBpZiAoZW5lbXkuaGVhbHRoIDw9IDApIHJldHVybjtcblxuICAgICAgY29uc3QgdG9FbmVteSA9IGVuZW15LnJpZy5yb290LnBvc2l0aW9uLmNsb25lKCkuc3ViKHRoaXMucGxheWVyUG9zKTtcbiAgICAgIGNvbnN0IGRpc3QgPSB0b0VuZW15Lmxlbmd0aCgpO1xuXG4gICAgICBpZiAoZGlzdCA8PSAyLjUgJiYgZm9yd2FyZC5kb3QodG9FbmVteS5ub3JtYWxpemUoKSkgPiAwLjQpIHtcbiAgICAgICAgLy8gSGVhdnkgS2ljayBkZWFscyBibHVudCBkYW1hZ2UgYW5kIGtub2NrcyBlbmVtaWVzIGJhY2sgaGFyZFxuICAgICAgICBjb25zdCBkYW1hZ2UgPSAzNSArICh0aGlzLmN1cnJlbnRTa2luLmRlZmVuc2VCb251cyA+IDAuMiA/IDE1IDogMCk7XG4gICAgICAgIHRoaXMuZGFtYWdlRW5lbXlEaXJlY3QoZW5lbXksIGRhbWFnZSwgdHJ1ZSwgOCk7XG4gICAgICAgIHNvdW5kTWFuYWdlci5wbGF5SGVhdnlJbXBhY3QoKTtcbiAgICAgICAgdGhpcy5zY3JlZW5TaGFrZSA9IDAuMzU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGFwcGx5RGFtYWdlVG9FbmVteShlbmVteTogRW5lbXlJbnN0YW5jZSwgY29tYm9TdGVwOiBudW1iZXIpIHtcbiAgICBsZXQgYmFzZURtZyA9IHRoaXMuY3VycmVudFdlYXBvbi5kYW1hZ2UgKiAoMC44NSArIGNvbWJvU3RlcCAqIDAuMjUpO1xuICAgIGNvbnN0IGlzQ3JpdCA9IE1hdGgucmFuZG9tKCkgPCB0aGlzLmN1cnJlbnRXZWFwb24uY3JpdENoYW5jZTtcbiAgICBpZiAoaXNDcml0KSB7XG4gICAgICBiYXNlRG1nICo9IDEuODtcbiAgICB9XG5cbiAgICBjb25zdCBrbm9ja2JhY2sgPSBjb21ib1N0ZXAgPT09IDMgPyA2IDogMi41O1xuICAgIHRoaXMuZGFtYWdlRW5lbXlEaXJlY3QoZW5lbXksIE1hdGgucm91bmQoYmFzZURtZyksIGlzQ3JpdCwga25vY2tiYWNrKTtcblxuICAgIC8vIEluY3JlYXNlIENoaSBlbmVyZ3kgb24gaGl0XG4gICAgdGhpcy5zdGF0cy5jdXJyZW50RW5lcmd5ID0gTWF0aC5taW4oXG4gICAgICB0aGlzLnN0YXRzLm1heEVuZXJneSxcbiAgICAgIHRoaXMuc3RhdHMuY3VycmVudEVuZXJneSArICh0aGlzLmN1cnJlbnRXZWFwb24uaWQgPT09ICdrYXRhbmFfc2FrdXJhJyA/IDMwIDogMjApXG4gICAgKTtcblxuICAgIC8vIEluY3JlbWVudCBjb21ib1xuICAgIHRoaXMuc3RhdHMuY29tYm9Db3VudCsrO1xuICAgIHRoaXMuc3RhdHMuY29tYm9UaW1lciA9IDIuNTtcbiAgICB0aGlzLm5vdGlmeVN0YXRzKCk7XG4gIH1cblxuICBwdWJsaWMgZGFtYWdlRW5lbXlEaXJlY3QoXG4gICAgZW5lbXk6IEVuZW15SW5zdGFuY2UsXG4gICAgZGFtYWdlOiBudW1iZXIsXG4gICAgaXNDcml0OiBib29sZWFuLFxuICAgIGtub2NrYmFja1Bvd2VyOiBudW1iZXJcbiAgKSB7XG4gICAgZW5lbXkuaGVhbHRoID0gTWF0aC5tYXgoMCwgZW5lbXkuaGVhbHRoIC0gZGFtYWdlKTtcblxuICAgIC8vIFJlY29pbCAvIEZsaW5jaFxuICAgIGlmIChlbmVteS5oZWFsdGggPiAwKSB7XG4gICAgICBlbmVteS5yaWcuY3VycmVudEFuaW0gPSAnZmxpbmNoJztcbiAgICAgIGVuZW15LnJpZy5hbmltUHJvZ3Jlc3MgPSAwO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGlmIChlbmVteS5oZWFsdGggPiAwICYmIGVuZW15LnJpZy5jdXJyZW50QW5pbSA9PT0gJ2ZsaW5jaCcpIHtcbiAgICAgICAgICBlbmVteS5yaWcuY3VycmVudEFuaW0gPSAnaWRsZSc7XG4gICAgICAgIH1cbiAgICAgIH0sIDMwMCk7XG4gICAgfVxuXG4gICAgLy8gS25vY2tiYWNrXG4gICAgY29uc3Qga25vY2tEaXIgPSBlbmVteS5yaWcucm9vdC5wb3NpdGlvbi5jbG9uZSgpLnN1Yih0aGlzLnBsYXllclBvcykubm9ybWFsaXplKCk7XG4gICAga25vY2tEaXIueSA9IDA7XG4gICAgZW5lbXkucmlnLnJvb3QucG9zaXRpb24uYWRkU2NhbGVkVmVjdG9yKGtub2NrRGlyLCBrbm9ja2JhY2tQb3dlciAqIDAuMTUpO1xuXG4gICAgLy8gU3BhcmtzICYgQmxvb2QgVkZYXG4gICAgdGhpcy5wYXJ0aWNsZXMuc3Bhd25IaXRTcGFya3MoXG4gICAgICBlbmVteS5yaWcucm9vdC5wb3NpdGlvbixcbiAgICAgIGlzQ3JpdCA/IDB4ZmYwMDQ0IDogMHhmOTczMTYsXG4gICAgICBpc0NyaXQgPyAxNiA6IDhcbiAgICApO1xuXG4gICAgLy8gRW1pdCBGbG9hdGluZyBEYW1hZ2UgVGV4dFxuICAgIHRoaXMuZW1pdEZsb2F0aW5nRGFtYWdlKFxuICAgICAgZW5lbXkucmlnLnJvb3QucG9zaXRpb24sXG4gICAgICBgJHtpc0NyaXQgPyAnQ1JJVCEgJyA6ICcnfS0ke2RhbWFnZX1gLFxuICAgICAgaXNDcml0ID8gJyNlZjQ0NDQnIDogJyNmYmJmMjQnLFxuICAgICAgaXNDcml0XG4gICAgKTtcblxuICAgIC8vIFVwZGF0ZSBCb3NzIFVJIGlmIGJvc3NcbiAgICBpZiAoZW5lbXkuaXNCb3NzICYmIHRoaXMub25Cb3NzSGVhbHRoVXBkYXRlKSB7XG4gICAgICB0aGlzLm9uQm9zc0hlYWx0aFVwZGF0ZShlbmVteS5oZWFsdGgsIGVuZW15Lm1heEhlYWx0aCwgZW5lbXkubmFtZSk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgRGVhdGhcbiAgICBpZiAoZW5lbXkuaGVhbHRoIDw9IDAgJiYgZW5lbXkuc3RhdGUgIT09ICdkZWFkJykge1xuICAgICAgdGhpcy5oYW5kbGVFbmVteURlYXRoKGVuZW15KTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGhhbmRsZUVuZW15RGVhdGgoZW5lbXk6IEVuZW15SW5zdGFuY2UpIHtcbiAgICBlbmVteS5zdGF0ZSA9ICdkZWFkJztcbiAgICBlbmVteS5yaWcuY3VycmVudEFuaW0gPSAnZGVhZCc7XG4gICAgZW5lbXkuZGlzc29sdmVUaW1lciA9IDIuMDtcblxuICAgIHNvdW5kTWFuYWdlci5wbGF5Q29pbigpO1xuICAgIHRoaXMucGFydGljbGVzLnNwYXduU21va2VQdWZmKGVuZW15LnJpZy5yb290LnBvc2l0aW9uLCAweDFlMjkzYiwgMTIpO1xuXG4gICAgY29uc3QgY29pblJld2FyZCA9IGVuZW15LmlzQm9zcyA/IDIwMCA6IChlbmVteS50eXBlID09PSAnaGVhdnknID8gNDUgOiAyNSk7XG4gICAgdGhpcy5zdGF0cy5jb2lucyArPSBjb2luUmV3YXJkO1xuICAgIHRoaXMuc3RhdHMua2lsbHMrKztcbiAgICB0aGlzLm5vdGlmeVN0YXRzKCk7XG5cbiAgICAvLyBJZiB0aGlzIGVuZW15IHdhcyBtYXJrZWQgd2l0aCB0aGUgUG93ZXIgQmFkZ2UgKFwicG93ZXIga2EgbmlzaGFuXCIpLCBkcm9wIHRoZSBwb3dlciBjb2xsZWN0IGl0ZW0hXG4gICAgaWYgKGVuZW15Lmhhc1Bvd2VyQ2FycmllckJhZGdlKSB7XG4gICAgICBpZiAoZW5lbXkucG93ZXJCYWRnZU1lc2gpIHtcbiAgICAgICAgdGhpcy5zY2VuZS5yZW1vdmUoZW5lbXkucG93ZXJCYWRnZU1lc2gpO1xuICAgICAgICBlbmVteS5wb3dlckJhZGdlTWVzaCA9IHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICAgIHRoaXMuc3Bhd25IZWFsdGhQaWNrdXAoZW5lbXkucmlnLnJvb3QucG9zaXRpb24sIDEyMCk7XG4gICAgICB0aGlzLmVtaXRGbG9hdGluZ0RhbWFnZShcbiAgICAgICAgZW5lbXkucmlnLnJvb3QucG9zaXRpb24sXG4gICAgICAgICfimIUgUE9XRVIgT1JCIERST1BQRUQhIOKYhScsXG4gICAgICAgICcjMTBiOTgxJyxcbiAgICAgICAgdHJ1ZVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBDaGVjayBCb3NzIFNwYXduaW5nIGNvbmRpdGlvblxuICAgIGlmICghdGhpcy5ib3NzU3Bhd25lZCAmJiB0aGlzLnN0YXRzLmtpbGxzID49IHRoaXMuY3VycmVudExldmVsLnRhcmdldEtpbGxzKSB7XG4gICAgICB0aGlzLnNwYXduQm9zcygpO1xuICAgIH1cblxuICAgIC8vIENoZWNrIFZpY3RvcnkgY29uZGl0aW9uIChCb3NzIHNsYWluKVxuICAgIGlmIChlbmVteS5pc0Jvc3MpIHtcbiAgICAgIHRoaXMuaGFuZGxlVmljdG9yeSgpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgZmxvYXRpbmcgM0QgXCJQb3dlciBLYSBOaXNoYW5cIiAoUG93ZXIgSW5kaWNhdG9yIEJhZGdlKVxuICAgKiB0aGF0IGhvdmVycyBvdmVyIHRoZSAxIG9yIDIgZGVzaWduYXRlZCBwb3dlci1jYXJyaWVyIGVuZW1pZXMgaW4gZWFjaCBsZXZlbC5cbiAgICovXG4gIHB1YmxpYyBjcmVhdGVQb3dlckNhcnJpZXJCYWRnZSgpOiBUSFJFRS5Hcm91cCB7XG4gICAgY29uc3QgZ3JvdXAgPSBuZXcgVEhSRUUuR3JvdXAoKTtcblxuICAgIC8vIDEuIEdsb3dpbmcgM0QgRW1lcmFsZCBEaWFtb25kIC8gQ3J5c3RhbFxuICAgIGNvbnN0IGNyeXN0YWxHZW8gPSBuZXcgVEhSRUUuT2N0YWhlZHJvbkdlb21ldHJ5KDAuMzIsIDApO1xuICAgIGNvbnN0IGNyeXN0YWxNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgY29sb3I6IDB4MTBiOTgxLFxuICAgICAgZW1pc3NpdmU6IDB4MDU5NjY5LFxuICAgICAgZW1pc3NpdmVJbnRlbnNpdHk6IDEuNCxcbiAgICAgIG1ldGFsbmVzczogMC4xLFxuICAgICAgcm91Z2huZXNzOiAwLjIsXG4gICAgfSk7XG4gICAgY29uc3QgY3J5c3RhbCA9IG5ldyBUSFJFRS5NZXNoKGNyeXN0YWxHZW8sIGNyeXN0YWxNYXQpO1xuICAgIGNyeXN0YWwuc2NhbGUuc2V0KDAuOCwgMS40LCAwLjgpO1xuICAgIGNyeXN0YWwubmFtZSA9ICdiYWRnZV9jcnlzdGFsJztcbiAgICBncm91cC5hZGQoY3J5c3RhbCk7XG5cbiAgICAvLyAyLiBHbG93aW5nIFdoaXRlIENyb3NzIFN5bWJvbCAoTWVkaWNhbC9IZWFsdGgvUG93ZXIgU2lnbilcbiAgICBjb25zdCBjcm9zc0hHZW8gPSBuZXcgVEhSRUUuQm94R2VvbWV0cnkoMC40OCwgMC4xMywgMC4xMyk7XG4gICAgY29uc3QgY3Jvc3NWR2VvID0gbmV3IFRIUkVFLkJveEdlb21ldHJ5KDAuMTMsIDAuNDgsIDAuMTMpO1xuICAgIGNvbnN0IGNyb3NzTWF0ID0gbmV3IFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKHsgY29sb3I6IDB4ZmZmZmZmIH0pO1xuICAgIGNvbnN0IGNyb3NzSCA9IG5ldyBUSFJFRS5NZXNoKGNyb3NzSEdlbywgY3Jvc3NNYXQpO1xuICAgIGNvbnN0IGNyb3NzViA9IG5ldyBUSFJFRS5NZXNoKGNyb3NzVkdlbywgY3Jvc3NNYXQpO1xuICAgIGdyb3VwLmFkZChjcm9zc0gpO1xuICAgIGdyb3VwLmFkZChjcm9zc1YpO1xuXG4gICAgLy8gMy4gT3JiaXRpbmcgR29sZCBSaW5nXG4gICAgY29uc3QgcmluZ0dlbyA9IG5ldyBUSFJFRS5Ub3J1c0dlb21ldHJ5KDAuNSwgMC4wMzUsIDgsIDIwKTtcbiAgICBjb25zdCByaW5nTWF0ID0gbmV3IFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKHsgY29sb3I6IDB4ZmFjYzE1LCB3aXJlZnJhbWU6IHRydWUgfSk7XG4gICAgY29uc3QgcmluZyA9IG5ldyBUSFJFRS5NZXNoKHJpbmdHZW8sIHJpbmdNYXQpO1xuICAgIHJpbmcucm90YXRpb24ueCA9IE1hdGguUEkgLyAyLjU7XG4gICAgcmluZy5uYW1lID0gJ2JhZGdlX3JpbmcnO1xuICAgIGdyb3VwLmFkZChyaW5nKTtcblxuICAgIC8vIDQuIEZsb2F0aW5nIFNwcml0ZSBMYWJlbDogXCLinJogUE9XRVIg4pyaXCJcbiAgICBjb25zdCBjYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKTtcbiAgICBjYW52YXMud2lkdGggPSAyNTY7XG4gICAgY2FudmFzLmhlaWdodCA9IDY0O1xuICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgIGlmIChjdHgpIHtcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAncmdiYSg2LCA3OCwgNTksIDAuODUpJztcbiAgICAgIGN0eC5maWxsUmVjdCg4LCA4LCAyNDAsIDQ4KTtcbiAgICAgIGN0eC5saW5lV2lkdGggPSA0O1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyMxMGI5ODEnO1xuICAgICAgY3R4LnN0cm9rZVJlY3QoOCwgOCwgMjQwLCA0OCk7XG5cbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnIzZlZTdiNyc7XG4gICAgICBjdHguZm9udCA9ICdib2xkIDI0cHggc2Fucy1zZXJpZic7XG4gICAgICBjdHgudGV4dEFsaWduID0gJ2NlbnRlcic7XG4gICAgICBjdHgudGV4dEJhc2VsaW5lID0gJ21pZGRsZSc7XG4gICAgICBjdHguZmlsbFRleHQoJ+KcmiBQT1dFUiDinJonLCAxMjgsIDMyKTtcbiAgICB9XG4gICAgY29uc3QgdGV4dHVyZSA9IG5ldyBUSFJFRS5DYW52YXNUZXh0dXJlKGNhbnZhcyk7XG4gICAgY29uc3Qgc3ByaXRlTWF0ID0gbmV3IFRIUkVFLlNwcml0ZU1hdGVyaWFsKHtcbiAgICAgIG1hcDogdGV4dHVyZSxcbiAgICAgIHRyYW5zcGFyZW50OiB0cnVlLFxuICAgICAgZGVwdGhUZXN0OiBmYWxzZSxcbiAgICB9KTtcbiAgICBjb25zdCBzcHJpdGUgPSBuZXcgVEhSRUUuU3ByaXRlKHNwcml0ZU1hdCk7XG4gICAgc3ByaXRlLnNjYWxlLnNldCgxLjQsIDAuMzUsIDEpO1xuICAgIHNwcml0ZS5wb3NpdGlvbi55ID0gMC41NTtcbiAgICBzcHJpdGUubmFtZSA9ICdiYWRnZV9zcHJpdGUnO1xuICAgIGdyb3VwLmFkZChzcHJpdGUpO1xuXG4gICAgLy8gNS4gU29mdCBlbWVyYWxkIHBvaW50IGxpZ2h0IHNvIHRoZSBlbmVteSBpcyBoaWdobGlnaHRlZCBhY3Jvc3MgdGhlIGxldmVsXG4gICAgY29uc3QgbGlnaHQgPSBuZXcgVEhSRUUuUG9pbnRMaWdodCgweDEwYjk4MSwgMS44LCA2KTtcbiAgICBsaWdodC5wb3NpdGlvbi5zZXQoMCwgMCwgMCk7XG4gICAgZ3JvdXAuYWRkKGxpZ2h0KTtcblxuICAgIHJldHVybiBncm91cDtcbiAgfVxuXG4gIC8qKlxuICAgKiBTcGF3bnMgYSBmbG9hdGluZyBjb2xsZWN0aWJsZSBIZWFsdGgvUG93ZXIgT3JiIGF0IGdpdmVuIHBvc2l0aW9uXG4gICAqL1xuICBwdWJsaWMgc3Bhd25IZWFsdGhQaWNrdXAocG9zOiBUSFJFRS5WZWN0b3IzLCBoZWFsQW1vdW50OiBudW1iZXIpIHtcbiAgICBjb25zdCBncm91cCA9IG5ldyBUSFJFRS5Hcm91cCgpO1xuXG4gICAgLy8gR2xvd2luZyBFbWVyYWxkIEphZGUgSGVhbHRoIENvcmVcbiAgICBjb25zdCBjb3JlR2VvID0gbmV3IFRIUkVFLkRvZGVjYWhlZHJvbkdlb21ldHJ5KDAuMzUsIDEpO1xuICAgIGNvbnN0IGNvcmVNYXQgPSBuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe1xuICAgICAgY29sb3I6IDB4MTBiOTgxLFxuICAgICAgZW1pc3NpdmU6IDB4MDU5NjY5LFxuICAgICAgZW1pc3NpdmVJbnRlbnNpdHk6IDAuOSxcbiAgICAgIG1ldGFsbmVzczogMC4yLFxuICAgICAgcm91Z2huZXNzOiAwLjIsXG4gICAgfSk7XG4gICAgY29uc3QgY29yZU1lc2ggPSBuZXcgVEhSRUUuTWVzaChjb3JlR2VvLCBjb3JlTWF0KTtcbiAgICBncm91cC5hZGQoY29yZU1lc2gpO1xuXG4gICAgLy8gT3JiaXRpbmcgR29sZGVuIC8gQ2VsZXN0aWFsIFJpbmdcbiAgICBjb25zdCByaW5nR2VvID0gbmV3IFRIUkVFLlRvcnVzR2VvbWV0cnkoMC41MiwgMC4wNCwgOCwgMjApO1xuICAgIGNvbnN0IHJpbmdNYXQgPSBuZXcgVEhSRUUuTWVzaEJhc2ljTWF0ZXJpYWwoe1xuICAgICAgY29sb3I6IDB4ZmFjYzE1LFxuICAgICAgd2lyZWZyYW1lOiB0cnVlLFxuICAgIH0pO1xuICAgIGNvbnN0IHJpbmdNZXNoID0gbmV3IFRIUkVFLk1lc2gocmluZ0dlbywgcmluZ01hdCk7XG4gICAgcmluZ01lc2gucm90YXRpb24ueCA9IE1hdGguUEkgLyAzO1xuICAgIGdyb3VwLmFkZChyaW5nTWVzaCk7XG5cbiAgICAvLyBTb2Z0IGVtZXJhbGQgcG9pbnQgbGlnaHQgYXVyYVxuICAgIGNvbnN0IGxpZ2h0ID0gbmV3IFRIUkVFLlBvaW50TGlnaHQoMHgxMGI5ODEsIDIuMCwgNyk7XG4gICAgbGlnaHQucG9zaXRpb24uc2V0KDAsIDAsIDApO1xuICAgIGdyb3VwLmFkZChsaWdodCk7XG5cbiAgICAvLyBGbG9hdCAwLjg1bSBhYm92ZSBncm91bmRcbiAgICBjb25zdCBzcGF3blBvcyA9IHBvcy5jbG9uZSgpO1xuICAgIHNwYXduUG9zLnkgPSAwLjg1O1xuICAgIGdyb3VwLnBvc2l0aW9uLmNvcHkoc3Bhd25Qb3MpO1xuICAgIHRoaXMuc2NlbmUuYWRkKGdyb3VwKTtcblxuICAgIHRoaXMuY29sbGVjdGlibGVzLnB1c2goe1xuICAgICAgaWQ6IHRoaXMubmV4dENvbGxlY3RpYmxlSWQrKyxcbiAgICAgIG1lc2g6IGdyb3VwLFxuICAgICAgaGVhbEFtb3VudCxcbiAgICAgIHBvc2l0aW9uOiBzcGF3blBvcyxcbiAgICAgIGJhc2VZOiAwLjg1LFxuICAgICAgYm9iVGltZTogTWF0aC5yYW5kb20oKSAqIE1hdGguUEksXG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIHNwYXduQm9zcygpIHtcbiAgICB0aGlzLmJvc3NTcGF3bmVkID0gdHJ1ZTtcbiAgICBzb3VuZE1hbmFnZXIucGxheUJvc3NSb2FyPy4oKTtcbiAgICBjb25zdCBib3NzUG9zID0gbmV3IFRIUkVFLlZlY3RvcjMoMCwgMCwgLTI4KTtcbiAgICB0aGlzLnNwYXduRW5lbXkoJ2Jvc3MnLCBib3NzUG9zLCB0cnVlKTtcbiAgICB0aGlzLnNjcmVlblNoYWtlID0gMC42O1xuICB9XG5cbiAgcHJpdmF0ZSBoYW5kbGVWaWN0b3J5KCkge1xuICAgIHNvdW5kTWFuYWdlci5wbGF5VmljdG9yeUdvbmcoKTtcbiAgICB0aGlzLnBsYXllclJpZy5jdXJyZW50QW5pbSA9ICd2aWN0b3J5JztcblxuICAgIC8vIENhbGN1bGF0ZSBzdGFyc1xuICAgIGxldCBzdGFycyA9IDE7XG4gICAgaWYgKHRoaXMuc3RhdHMuY3VycmVudEhlYWx0aCA+IDUwKSBzdGFycyA9IDI7XG4gICAgaWYgKHRoaXMuc3RhdHMuY3VycmVudEhlYWx0aCA+IDc1ICYmIHRoaXMuc3RhdHMuY29tYm9Db3VudCA+PSA4KSBzdGFycyA9IDM7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGlmICh0aGlzLm9uVmljdG9yeSkge1xuICAgICAgICB0aGlzLm9uVmljdG9yeSh0aGlzLmN1cnJlbnRMZXZlbC5yZXdhcmRDb2lucywgc3RhcnMpO1xuICAgICAgfVxuICAgIH0sIDE1MDApO1xuICB9XG5cbiAgcHVibGljIGRhbWFnZVBsYXllcihkYW1hZ2U6IG51bWJlciwgYXR0YWNrZXJQb3M6IFRIUkVFLlZlY3RvcjMpIHtcbiAgICBpZiAodGhpcy5pc0ludnVsbmVyYWJsZSB8fCB0aGlzLnN0YXRzLmN1cnJlbnRIZWFsdGggPD0gMCkgcmV0dXJuO1xuXG4gICAgLy8gUG9zdC1oaXQgaW52dWxuZXJhYmlsaXR5IHdpbmRvdyAoMC41NXMpXG4gICAgdGhpcy5pc0ludnVsbmVyYWJsZSA9IHRydWU7XG4gICAgdGhpcy5pbnZ1bG5lcmFiaWxpdHlUaW1lciA9IDAuNTU7XG5cbiAgICAvLyBCYWxhbmNlZCBpbmNvbWluZyBkYW1hZ2UgZm9yIDUwMCBIUDogcG93ZXIgZGVwbGV0ZXMgYXQgYW4gYWN0aXZlIGNvbWJhdCBwYWNlXG4gICAgY29uc3QgZmluYWxEYW1hZ2UgPSBNYXRoLm1heCgxNiwgTWF0aC5yb3VuZChkYW1hZ2UgKiAxLjY1ICogKDEgLSB0aGlzLmN1cnJlbnRTa2luLmRlZmVuc2VCb251cykpKTtcbiAgICB0aGlzLnN0YXRzLmN1cnJlbnRIZWFsdGggPSBNYXRoLm1heCgwLCB0aGlzLnN0YXRzLmN1cnJlbnRIZWFsdGggLSBmaW5hbERhbWFnZSk7XG5cbiAgICAvLyBIaXQgZmxpbmNoXG4gICAgdGhpcy5wbGF5ZXJSaWcuY3VycmVudEFuaW0gPSAnZmxpbmNoJztcbiAgICB0aGlzLnBsYXllclJpZy5hbmltUHJvZ3Jlc3MgPSAwO1xuICAgIHNvdW5kTWFuYWdlci5wbGF5SGVhdnlJbXBhY3QoKTtcbiAgICB0aGlzLnNjcmVlblNoYWtlID0gMC40O1xuXG4gICAgdGhpcy5wYXJ0aWNsZXMuc3Bhd25IaXRTcGFya3ModGhpcy5wbGF5ZXJQb3MsIDB4ZGMyNjI2LCAxMik7XG5cbiAgICB0aGlzLmVtaXRGbG9hdGluZ0RhbWFnZShcbiAgICAgIHRoaXMucGxheWVyUG9zLFxuICAgICAgYC0ke2ZpbmFsRGFtYWdlfWAsXG4gICAgICAnI2VmNDQ0NCcsXG4gICAgICBmYWxzZVxuICAgICk7XG5cbiAgICAvLyBLbm9ja2JhY2tcbiAgICBjb25zdCBrbm9ja0RpciA9IHRoaXMucGxheWVyUG9zLmNsb25lKCkuc3ViKGF0dGFja2VyUG9zKS5ub3JtYWxpemUoKTtcbiAgICBrbm9ja0Rpci55ID0gMDtcbiAgICB0aGlzLnBsYXllclZlbG9jaXR5LmFkZFNjYWxlZFZlY3Rvcihrbm9ja0RpciwgNik7XG5cbiAgICB0aGlzLm5vdGlmeVN0YXRzKCk7XG5cbiAgICBpZiAodGhpcy5zdGF0cy5jdXJyZW50SGVhbHRoIDw9IDApIHtcbiAgICAgIHRoaXMuaGFuZGxlUGxheWVyRGVhdGgoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLnBsYXllclJpZy5jdXJyZW50QW5pbSA9PT0gJ2ZsaW5jaCcpIHtcbiAgICAgICAgICB0aGlzLnBsYXllclJpZy5jdXJyZW50QW5pbSA9ICdpZGxlJztcbiAgICAgICAgfVxuICAgICAgfSwgMzUwKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGhhbmRsZVBsYXllckRlYXRoKCkge1xuICAgIHRoaXMucGxheWVyUmlnLmN1cnJlbnRBbmltID0gJ2RlYWQnO1xuICAgIHNvdW5kTWFuYWdlci5wbGF5R2FtZU92ZXIoKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGlmICh0aGlzLm9uR2FtZU92ZXIpIHtcbiAgICAgICAgdGhpcy5vbkdhbWVPdmVyKCk7XG4gICAgICB9XG4gICAgfSwgMTUwMCk7XG4gIH1cblxuICBwcml2YXRlIGVtaXRGbG9hdGluZ0RhbWFnZShwb3M6IFRIUkVFLlZlY3RvcjMsIHRleHQ6IHN0cmluZywgY29sb3I6IHN0cmluZywgaXNDcml0OiBib29sZWFuKSB7XG4gICAgLy8gUHJvamVjdCAzRCBjb29yZGluYXRlIHRvIHNjcmVlbiBjb29yZGluYXRlc1xuICAgIGNvbnN0IHYgPSBwb3MuY2xvbmUoKTtcbiAgICB2LnkgKz0gMS44O1xuICAgIHYucHJvamVjdCh0aGlzLmNhbWVyYSk7XG5cbiAgICBjb25zdCB4ID0gKHYueCAqIDAuNSArIDAuNSkgKiB0aGlzLmNvbnRhaW5lci5jbGllbnRXaWR0aDtcbiAgICBjb25zdCB5ID0gKC12LnkgKiAwLjUgKyAwLjUpICogdGhpcy5jb250YWluZXIuY2xpZW50SGVpZ2h0O1xuXG4gICAgaWYgKHRoaXMub25GbG9hdGluZ0RhbWFnZSkge1xuICAgICAgdGhpcy5vbkZsb2F0aW5nRGFtYWdlKHtcbiAgICAgICAgaWQ6IE1hdGgucmFuZG9tKCksXG4gICAgICAgIHRleHQsXG4gICAgICAgIGNvbG9yLFxuICAgICAgICBpc0NyaXQsXG4gICAgICAgIHNjcmVlblg6IHgsXG4gICAgICAgIHNjcmVlblk6IHksXG4gICAgICAgIG9wYWNpdHk6IDEsXG4gICAgICAgIHNjYWxlOiBpc0NyaXQgPyAxLjQgOiAxLjAsXG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgbm90aWZ5U3RhdHMoKSB7XG4gICAgaWYgKHRoaXMub25TdGF0c0NoYW5nZSkge1xuICAgICAgdGhpcy5vblN0YXRzQ2hhbmdlKHsgLi4udGhpcy5zdGF0cyB9KTtcbiAgICB9XG4gIH1cblxuICAvLyAtLS0gTWFpbiBFbmdpbmUgVGljayBMb29wIC0tLVxuXG4gIHB1YmxpYyB0aWNrID0gKCkgPT4ge1xuICAgIGlmICghdGhpcy5pc1J1bm5pbmcpIHJldHVybjtcblxuICAgIGNvbnN0IGRlbHRhID0gTWF0aC5taW4odGhpcy5jbG9jay5nZXREZWx0YSgpLCAwLjA1KTtcblxuICAgIGlmICghdGhpcy5pc1BhdXNlZCkge1xuICAgICAgdGhpcy51cGRhdGVQbGF5ZXIoZGVsdGEpO1xuICAgICAgdGhpcy51cGRhdGVFbmVtaWVzKGRlbHRhKTtcbiAgICAgIHRoaXMudXBkYXRlUHJvamVjdGlsZXMoZGVsdGEpO1xuICAgICAgdGhpcy51cGRhdGVDb2xsZWN0aWJsZXMoZGVsdGEpO1xuICAgICAgdGhpcy51cGRhdGVDYW1lcmEoZGVsdGEpO1xuICAgICAgdGhpcy5wYXJ0aWNsZXMudXBkYXRlKGRlbHRhLCB0aGlzLnBsYXllclBvcywgdGhpcy5jYW1lcmEpO1xuICAgIH1cblxuICAgIHRoaXMucmVuZGVyZXIucmVuZGVyKHRoaXMuc2NlbmUsIHRoaXMuY2FtZXJhKTtcblxuICAgIGlmICh0aGlzLmlzU29mdHdhcmVHbCkge1xuICAgICAgdGhpcy5hZnRlckRyYXcodGhpcy50aWNrKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5hbmltRnJhbWVJZCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh0aGlzLnRpY2spO1xuICAgIH1cbiAgfTtcblxuICBwcml2YXRlIGFmdGVyRHJhdyhjYjogKCkgPT4gdm9pZCkge1xuICAgIGNvbnN0IGdsID0gdGhpcy5yZW5kZXJlci5nZXRDb250ZXh0KCkgYXMgV2ViR0wyUmVuZGVyaW5nQ29udGV4dDtcbiAgICBjb25zdCBzeW5jID0gZ2wuZmVuY2VTeW5jKGdsLlNZTkNfR1BVX0NPTU1BTkRTX0NPTVBMRVRFLCAwKTtcbiAgICBnbC5mbHVzaCgpO1xuICAgIGNvbnN0IHBvbGwgPSAoKSA9PiB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHN5bmMgJiYgZ2wuZ2V0U3luY1BhcmFtZXRlcihzeW5jLCBnbC5TWU5DX1NUQVRVUyk7XG4gICAgICBpZiAoc3RhdGUgPT09IGdsLlVOU0lHTkFMRUQpIHtcbiAgICAgICAgdGhpcy5hbmltRnJhbWVJZCA9IHdpbmRvdy5zZXRUaW1lb3V0KHBvbGwsIDUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHN5bmMpIGdsLmRlbGV0ZVN5bmMoc3luYyk7XG4gICAgICAgIHRoaXMuYW5pbUZyYW1lSWQgPSB3aW5kb3cuc2V0VGltZW91dChjYiwgNjApO1xuICAgICAgfVxuICAgIH07XG4gICAgdGhpcy5hbmltRnJhbWVJZCA9IHdpbmRvdy5zZXRUaW1lb3V0KHBvbGwsIDUpO1xuICB9XG5cbiAgcHJpdmF0ZSB1cGRhdGVDb2xsZWN0aWJsZXMoZGVsdGE6IG51bWJlcikge1xuICAgIGZvciAobGV0IGkgPSB0aGlzLmNvbGxlY3RpYmxlcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgY29uc3QgaXRlbSA9IHRoaXMuY29sbGVjdGlibGVzW2ldO1xuICAgICAgaXRlbS5ib2JUaW1lICs9IGRlbHRhO1xuXG4gICAgICAvLyBCb2JiaW5nICYgUm90YXRpbmcgYW5pbWF0aW9uXG4gICAgICBpdGVtLm1lc2gucm90YXRpb24ueSArPSBkZWx0YSAqIDIuNTtcbiAgICAgIGlmIChpdGVtLm1lc2guY2hpbGRyZW4ubGVuZ3RoID4gMSkge1xuICAgICAgICBpdGVtLm1lc2guY2hpbGRyZW5bMV0ucm90YXRpb24ueiArPSBkZWx0YSAqIDMuMDsgLy8gc3BpbiByaW5nXG4gICAgICB9XG4gICAgICBpdGVtLm1lc2gucG9zaXRpb24ueSA9IGl0ZW0uYmFzZVkgKyBNYXRoLnNpbihpdGVtLmJvYlRpbWUgKiAzLjUpICogMC4xNTtcblxuICAgICAgLy8gRGlzdGFuY2UgdG8gcGxheWVyXG4gICAgICBjb25zdCBkaXN0ID0gdGhpcy5wbGF5ZXJQb3MuZGlzdGFuY2VUbyhpdGVtLm1lc2gucG9zaXRpb24pO1xuXG4gICAgICAvLyBNYWduZXRpemUgdG93YXJkIHBsYXllciBpZiB3aXRoaW4gMy41IG1ldGVyc1xuICAgICAgaWYgKGRpc3QgPCAzLjUpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gdGhpcy5wbGF5ZXJQb3MuY2xvbmUoKTtcbiAgICAgICAgdGFyZ2V0LnkgKz0gMC44NTtcbiAgICAgICAgaXRlbS5tZXNoLnBvc2l0aW9uLmxlcnAodGFyZ2V0LCBkZWx0YSAqIDcuMCk7XG4gICAgICB9XG5cbiAgICAgIC8vIENvbGxlY3Qgd2hlbiBpbiBjbG9zZSBjb250YWN0ICh3aXRoaW4gMS40bSlcbiAgICAgIGlmIChkaXN0IDwgMS40KSB7XG4gICAgICAgIC8vIENvbGxlY3QgUG93ZXIgLyBIZWFsdGghXG4gICAgICAgIHRoaXMuc3RhdHMuY3VycmVudEhlYWx0aCA9IE1hdGgubWluKHRoaXMuc3RhdHMubWF4SGVhbHRoLCB0aGlzLnN0YXRzLmN1cnJlbnRIZWFsdGggKyBpdGVtLmhlYWxBbW91bnQpO1xuXG4gICAgICAgIHNvdW5kTWFuYWdlci5wbGF5SGVhbHRoUGlja3VwKCk7XG4gICAgICAgIHRoaXMucGFydGljbGVzLnNwYXduSGl0U3BhcmtzKHRoaXMucGxheWVyUG9zLCAweDEwYjk4MSwgMTYpO1xuXG4gICAgICAgIHRoaXMuZW1pdEZsb2F0aW5nRGFtYWdlKFxuICAgICAgICAgIHRoaXMucGxheWVyUG9zLFxuICAgICAgICAgIGArJHtpdGVtLmhlYWxBbW91bnR9IFBPV0VSYCxcbiAgICAgICAgICAnIzEwYjk4MScsXG4gICAgICAgICAgdHJ1ZVxuICAgICAgICApO1xuXG4gICAgICAgIHRoaXMubm90aWZ5U3RhdHMoKTtcblxuICAgICAgICAvLyBSZW1vdmUgZnJvbSBzY2VuZSBhbmQgbGlzdFxuICAgICAgICB0aGlzLnNjZW5lLnJlbW92ZShpdGVtLm1lc2gpO1xuICAgICAgICB0aGlzLmNvbGxlY3RpYmxlcy5zcGxpY2UoaSwgMSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSB1cGRhdGVQbGF5ZXIoZGVsdGE6IG51bWJlcikge1xuICAgIGlmICh0aGlzLnN0YXRzLmN1cnJlbnRIZWFsdGggPD0gMCkgcmV0dXJuO1xuXG4gICAgLy8gSW52dWxuZXJhYmlsaXR5IHRpbWVyXG4gICAgaWYgKHRoaXMuaXNJbnZ1bG5lcmFibGUpIHtcbiAgICAgIHRoaXMuaW52dWxuZXJhYmlsaXR5VGltZXIgLT0gZGVsdGE7XG4gICAgICBpZiAodGhpcy5pbnZ1bG5lcmFiaWxpdHlUaW1lciA8PSAwKSB7XG4gICAgICAgIHRoaXMuaXNJbnZ1bG5lcmFibGUgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBTdGVhZHkgQ2hpIGVuZXJneSBnZW5lcmF0aW9uICgrNCBDaGkvc2VjKSBzbyBzcGVjaWFsIHBvd2VyIGlzIGF2YWlsYWJsZVxuICAgIGlmICh0aGlzLnN0YXRzLmN1cnJlbnRFbmVyZ3kgPCB0aGlzLnN0YXRzLm1heEVuZXJneSkge1xuICAgICAgdGhpcy5zdGF0cy5jdXJyZW50RW5lcmd5ID0gTWF0aC5taW4odGhpcy5zdGF0cy5tYXhFbmVyZ3ksIHRoaXMuc3RhdHMuY3VycmVudEVuZXJneSArIGRlbHRhICogNC41KTtcbiAgICB9XG5cbiAgICAvLyBTcGVjaWFsIERyYWdvbiBCbGFzdCAxLW1pbnV0ZSAoNjAgc2Vjb25kcykgY29vbGRvd24gY291bnRkb3duXG4gICAgaWYgKHRoaXMuc3RhdHMuc3BlY2lhbENvb2xkb3duID4gMCkge1xuICAgICAgY29uc3QgcHJldlNlYyA9IE1hdGguY2VpbCh0aGlzLnN0YXRzLnNwZWNpYWxDb29sZG93bik7XG4gICAgICB0aGlzLnN0YXRzLnNwZWNpYWxDb29sZG93biA9IE1hdGgubWF4KDAsIHRoaXMuc3RhdHMuc3BlY2lhbENvb2xkb3duIC0gZGVsdGEpO1xuICAgICAgY29uc3QgbmV3U2VjID0gTWF0aC5jZWlsKHRoaXMuc3RhdHMuc3BlY2lhbENvb2xkb3duKTtcbiAgICAgIGlmIChwcmV2U2VjICE9PSBuZXdTZWMgfHwgdGhpcy5zdGF0cy5zcGVjaWFsQ29vbGRvd24gPT09IDApIHtcbiAgICAgICAgdGhpcy5ub3RpZnlTdGF0cygpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIENvbWJvIHRpbWVyXG4gICAgaWYgKHRoaXMuY29tYm9XaW5kb3dUaW1lciA+IDApIHtcbiAgICAgIHRoaXMuY29tYm9XaW5kb3dUaW1lciAtPSBkZWx0YTtcbiAgICAgIGlmICh0aGlzLmNvbWJvV2luZG93VGltZXIgPD0gMCkge1xuICAgICAgICB0aGlzLmN1cnJlbnRDb21ib1N0ZXAgPSAwO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh0aGlzLnN0YXRzLmNvbWJvVGltZXIgPiAwKSB7XG4gICAgICB0aGlzLnN0YXRzLmNvbWJvVGltZXIgLT0gZGVsdGE7XG4gICAgICBpZiAodGhpcy5zdGF0cy5jb21ib1RpbWVyIDw9IDApIHtcbiAgICAgICAgdGhpcy5zdGF0cy5jb21ib0NvdW50ID0gMDtcbiAgICAgICAgdGhpcy5ub3RpZnlTdGF0cygpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIE1vdmVtZW50IGNhbGN1bGF0aW9uIHJlbGF0aXZlIHRvIGNhbWVyYSBhbmdsZVxuICAgIGNvbnN0IG14ID0gdGhpcy5pbnB1dC5tb3ZlWDtcbiAgICBjb25zdCBteiA9IHRoaXMuaW5wdXQubW92ZVo7XG4gICAgY29uc3QgaXNNb3ZpbmcgPSBNYXRoLmFicyhteCkgPiAwLjA1IHx8IE1hdGguYWJzKG16KSA+IDAuMDU7XG5cbiAgICBpZiAoaXNNb3ZpbmcgJiYgIXRoaXMuaXNBdHRhY2tpbmcgJiYgdGhpcy5wbGF5ZXJSaWcuY3VycmVudEFuaW0gIT09ICdkb2RnZScpIHtcbiAgICAgIGNvbnN0IGJhc2VTcGVlZCA9ICg2LjAgKyB0aGlzLmN1cnJlbnRTa2luLnNwZWVkQm9udXMgKiA2LjApO1xuICAgICAgXG4gICAgICAvLyBDYW1lcmEgdmlzdWFsIGZvcndhcmQgb24gZ3JvdW5kIHBsYW5lXG4gICAgICBjb25zdCBjYW1Gb3J3YXJkID0gbmV3IFRIUkVFLlZlY3RvcjMoKTtcbiAgICAgIHRoaXMuY2FtZXJhLmdldFdvcmxkRGlyZWN0aW9uKGNhbUZvcndhcmQpO1xuICAgICAgY2FtRm9yd2FyZC55ID0gMDtcbiAgICAgIGNhbUZvcndhcmQubm9ybWFsaXplKCk7XG5cbiAgICAgIC8vIENhbWVyYSB2aXN1YWwgc2NyZWVuLXJpZ2h0IGluIHdvcmxkIGNvb3JkaW5hdGVzXG4gICAgICBjb25zdCBjYW1SaWdodCA9IG5ldyBUSFJFRS5WZWN0b3IzKDEsIDAsIDApLmFwcGx5UXVhdGVybmlvbih0aGlzLmNhbWVyYS5xdWF0ZXJuaW9uKTtcbiAgICAgIGNhbVJpZ2h0LnkgPSAwO1xuICAgICAgY2FtUmlnaHQubm9ybWFsaXplKCk7XG5cbiAgICAgIC8vIENvbXBvc2UgbW92ZW1lbnQ6IG14ICgrMSA9IFJpZ2h0LCAtMSA9IExlZnQpLCBteiAoKzEgPSBGb3J3YXJkLCAtMSA9IEJhY2t3YXJkKVxuICAgICAgY29uc3QgbW92ZURpciA9IG5ldyBUSFJFRS5WZWN0b3IzKClcbiAgICAgICAgLmFkZFNjYWxlZFZlY3RvcihjYW1SaWdodCwgbXgpXG4gICAgICAgIC5hZGRTY2FsZWRWZWN0b3IoY2FtRm9yd2FyZCwgbXopO1xuXG4gICAgICBpZiAobW92ZURpci5sZW5ndGhTcSgpID4gMC4wMDEpIHtcbiAgICAgICAgbW92ZURpci5ub3JtYWxpemUoKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgdGFyZ2V0VmVsWCA9IG1vdmVEaXIueCAqIGJhc2VTcGVlZDtcbiAgICAgIGNvbnN0IHRhcmdldFZlbFogPSBtb3ZlRGlyLnogKiBiYXNlU3BlZWQ7XG5cbiAgICAgIHRoaXMucGxheWVyVmVsb2NpdHkueCA9IFRIUkVFLk1hdGhVdGlscy5kYW1wKHRoaXMucGxheWVyVmVsb2NpdHkueCwgdGFyZ2V0VmVsWCwgMTAsIGRlbHRhKTtcbiAgICAgIHRoaXMucGxheWVyVmVsb2NpdHkueiA9IFRIUkVFLk1hdGhVdGlscy5kYW1wKHRoaXMucGxheWVyVmVsb2NpdHkueiwgdGFyZ2V0VmVsWiwgMTAsIGRlbHRhKTtcblxuICAgICAgLy8gU21vb3RobHkgcm90YXRlIHBsYXllciB0b3dhcmQgbW92ZW1lbnQgZGlyZWN0aW9uXG4gICAgICB0aGlzLnBsYXllclJvdGF0aW9uID0gTWF0aC5hdGFuMihtb3ZlRGlyLngsIG1vdmVEaXIueik7XG4gICAgICB0aGlzLnBsYXllclJpZy5yb290LnJvdGF0aW9uLnkgPSB0aGlzLnBsYXllclJvdGF0aW9uO1xuXG4gICAgICBpZiAodGhpcy5pc0dyb3VuZGVkICYmIHRoaXMucGxheWVyUmlnLmN1cnJlbnRBbmltICE9PSAncnVuJykge1xuICAgICAgICB0aGlzLnBsYXllclJpZy5jdXJyZW50QW5pbSA9ICdydW4nO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAodGhpcy5pc0dyb3VuZGVkICYmICF0aGlzLmlzQXR0YWNraW5nICYmIHRoaXMucGxheWVyUmlnLmN1cnJlbnRBbmltICE9PSAnZG9kZ2UnKSB7XG4gICAgICB0aGlzLnBsYXllclZlbG9jaXR5LnggPSBUSFJFRS5NYXRoVXRpbHMuZGFtcCh0aGlzLnBsYXllclZlbG9jaXR5LngsIDAsIDEyLCBkZWx0YSk7XG4gICAgICB0aGlzLnBsYXllclZlbG9jaXR5LnogPSBUSFJFRS5NYXRoVXRpbHMuZGFtcCh0aGlzLnBsYXllclZlbG9jaXR5LnosIDAsIDEyLCBkZWx0YSk7XG5cbiAgICAgIGlmICh0aGlzLnBsYXllclJpZy5jdXJyZW50QW5pbSA9PT0gJ3J1bicpIHtcbiAgICAgICAgdGhpcy5wbGF5ZXJSaWcuY3VycmVudEFuaW0gPSAnaWRsZSc7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gR3Jhdml0eSAmIFZlcnRpY2FsIFBoeXNpY3NcbiAgICBpZiAoIXRoaXMuaXNHcm91bmRlZCkge1xuICAgICAgdGhpcy5wbGF5ZXJWZWxvY2l0eS55IC09IDIyLjAgKiBkZWx0YTtcbiAgICAgIHRoaXMucGxheWVyUG9zLnkgKz0gdGhpcy5wbGF5ZXJWZWxvY2l0eS55ICogZGVsdGE7XG5cbiAgICAgIGlmICh0aGlzLnBsYXllclBvcy55IDw9IDApIHtcbiAgICAgICAgdGhpcy5wbGF5ZXJQb3MueSA9IDA7XG4gICAgICAgIHRoaXMucGxheWVyVmVsb2NpdHkueSA9IDA7XG4gICAgICAgIHRoaXMuaXNHcm91bmRlZCA9IHRydWU7XG4gICAgICAgIHRoaXMucGxheWVyUmlnLmN1cnJlbnRBbmltID0gaXNNb3ZpbmcgPyAncnVuJyA6ICdpZGxlJztcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBBcHBseSBob3Jpem9udGFsIHZlbG9jaXR5XG4gICAgdGhpcy5wbGF5ZXJQb3MueCArPSB0aGlzLnBsYXllclZlbG9jaXR5LnggKiBkZWx0YTtcbiAgICB0aGlzLnBsYXllclBvcy56ICs9IHRoaXMucGxheWVyVmVsb2NpdHkueiAqIGRlbHRhO1xuXG4gICAgLy8gQ2xhbXAgd2l0aGluIGFyZW5hIHBlcmltZXRlclxuICAgIGNvbnN0IG1heEJvdW5kID0gNDg7XG4gICAgdGhpcy5wbGF5ZXJQb3MueCA9IFRIUkVFLk1hdGhVdGlscy5jbGFtcCh0aGlzLnBsYXllclBvcy54LCAtbWF4Qm91bmQsIG1heEJvdW5kKTtcbiAgICB0aGlzLnBsYXllclBvcy56ID0gVEhSRUUuTWF0aFV0aWxzLmNsYW1wKHRoaXMucGxheWVyUG9zLnosIC1tYXhCb3VuZCwgbWF4Qm91bmQpO1xuXG4gICAgdGhpcy5wbGF5ZXJSaWcucm9vdC5wb3NpdGlvbi5jb3B5KHRoaXMucGxheWVyUG9zKTtcblxuICAgIC8vIFVwZGF0ZSBhbmltYXRpb24gZnJhbWVzXG4gICAgaWYgKHRoaXMuaXNBdHRhY2tpbmcgfHwgdGhpcy5wbGF5ZXJSaWcuY3VycmVudEFuaW0gPT09ICdkb2RnZScgfHwgdGhpcy5wbGF5ZXJSaWcuY3VycmVudEFuaW0gPT09ICdraWNrJyB8fCB0aGlzLnBsYXllclJpZy5jdXJyZW50QW5pbSA9PT0gJ2ZsaW5jaCcpIHtcbiAgICAgIHRoaXMucGxheWVyUmlnLmFuaW1Qcm9ncmVzcyA9IE1hdGgubWluKDEuMCwgdGhpcy5wbGF5ZXJSaWcuYW5pbVByb2dyZXNzICsgZGVsdGEgKiAzLjUpO1xuICAgIH1cbiAgICBDaGFyYWN0ZXJGYWN0b3J5LnVwZGF0ZUFuaW1hdGlvbih0aGlzLnBsYXllclJpZywgZGVsdGEpO1xuICB9XG5cbiAgcHJpdmF0ZSB1cGRhdGVFbmVtaWVzKGRlbHRhOiBudW1iZXIpIHtcbiAgICBmb3IgKGxldCBpID0gdGhpcy5lbmVtaWVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICBjb25zdCBlbmVteSA9IHRoaXMuZW5lbWllc1tpXTtcblxuICAgICAgaWYgKGVuZW15LnN0YXRlID09PSAnZGVhZCcpIHtcbiAgICAgICAgaWYgKGVuZW15LnBvd2VyQmFkZ2VNZXNoKSB7XG4gICAgICAgICAgdGhpcy5zY2VuZS5yZW1vdmUoZW5lbXkucG93ZXJCYWRnZU1lc2gpO1xuICAgICAgICAgIGVuZW15LnBvd2VyQmFkZ2VNZXNoID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIGVuZW15LmRpc3NvbHZlVGltZXIgLT0gZGVsdGE7XG4gICAgICAgIENoYXJhY3RlckZhY3RvcnkudXBkYXRlQW5pbWF0aW9uKGVuZW15LnJpZywgZGVsdGEpO1xuXG4gICAgICAgIGlmIChlbmVteS5kaXNzb2x2ZVRpbWVyIDw9IDApIHtcbiAgICAgICAgICB0aGlzLnNjZW5lLnJlbW92ZShlbmVteS5yaWcucm9vdCk7XG4gICAgICAgICAgdGhpcy5lbmVtaWVzLnNwbGljZShpLCAxKTtcbiAgICAgICAgfVxuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgZW5lbXkuYXR0YWNrQ29vbGRvd24gLT0gZGVsdGE7XG4gICAgICBjb25zdCB0b1BsYXllciA9IHRoaXMucGxheWVyUG9zLmNsb25lKCkuc3ViKGVuZW15LnJpZy5yb290LnBvc2l0aW9uKTtcbiAgICAgIGNvbnN0IGRpc3RUb1BsYXllciA9IHRvUGxheWVyLmxlbmd0aCgpO1xuXG4gICAgICAvLyBFbmVteSBBSSBTdGF0ZSBNYWNoaW5lXG4gICAgICBpZiAoZGlzdFRvUGxheWVyIDwgMjQpIHtcbiAgICAgICAgLy8gUGxheWVyIGRldGVjdGVkXG4gICAgICAgIGVuZW15LnN0YXRlID0gJ2NoYXNlJztcbiAgICAgICAgZW5lbXkucmlnLnJvb3QubG9va0F0KHRoaXMucGxheWVyUG9zLngsIGVuZW15LnJpZy5yb290LnBvc2l0aW9uLnksIHRoaXMucGxheWVyUG9zLnopO1xuXG4gICAgICAgIGlmIChkaXN0VG9QbGF5ZXIgPiBlbmVteS5yYW5nZSkge1xuICAgICAgICAgIC8vIE1vdmUgdG93YXJkcyBwbGF5ZXJcbiAgICAgICAgICBjb25zdCBtb3ZlRGlyID0gdG9QbGF5ZXIuY2xvbmUoKS5ub3JtYWxpemUoKTtcbiAgICAgICAgICBlbmVteS5yaWcucm9vdC5wb3NpdGlvbi5hZGRTY2FsZWRWZWN0b3IobW92ZURpciwgZW5lbXkuc3BlZWQgKiBkZWx0YSk7XG4gICAgICAgICAgaWYgKGVuZW15LnJpZy5jdXJyZW50QW5pbSAhPT0gJ3J1bicpIHtcbiAgICAgICAgICAgIGVuZW15LnJpZy5jdXJyZW50QW5pbSA9ICdydW4nO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBJbiBhdHRhY2sgcmFuZ2VcbiAgICAgICAgICBpZiAoZW5lbXkuYXR0YWNrQ29vbGRvd24gPD0gMCkge1xuICAgICAgICAgICAgdGhpcy5leGVjdXRlRW5lbXlBdHRhY2soZW5lbXkpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBlbmVteS5yaWcuY3VycmVudEFuaW0gPSAnaWRsZSc7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBQYXRyb2wgb3IgaWRsZVxuICAgICAgICBlbmVteS5zdGF0ZSA9ICdpZGxlJztcbiAgICAgICAgZW5lbXkucmlnLmN1cnJlbnRBbmltID0gJ2lkbGUnO1xuICAgICAgfVxuXG4gICAgICBDaGFyYWN0ZXJGYWN0b3J5LnVwZGF0ZUFuaW1hdGlvbihlbmVteS5yaWcsIGRlbHRhKTtcblxuICAgICAgLy8gVXBkYXRlIGZsb2F0aW5nIFBvd2VyIEJhZGdlIHBvc2l0aW9uIGlmIG1hcmtlZFxuICAgICAgaWYgKGVuZW15Lmhhc1Bvd2VyQ2FycmllckJhZGdlICYmIGVuZW15LnBvd2VyQmFkZ2VNZXNoKSB7XG4gICAgICAgIGNvbnN0IHRpbWUgPSBwZXJmb3JtYW5jZS5ub3coKSAqIDAuMDAzO1xuICAgICAgICBlbmVteS5wb3dlckJhZGdlTWVzaC5wb3NpdGlvbi5zZXQoXG4gICAgICAgICAgZW5lbXkucmlnLnJvb3QucG9zaXRpb24ueCxcbiAgICAgICAgICBlbmVteS5yaWcucm9vdC5wb3NpdGlvbi55ICsgMi4zICsgTWF0aC5zaW4odGltZSAqIDMpICogMC4xLFxuICAgICAgICAgIGVuZW15LnJpZy5yb290LnBvc2l0aW9uLnpcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgY3J5c3RhbCA9IGVuZW15LnBvd2VyQmFkZ2VNZXNoLmdldE9iamVjdEJ5TmFtZSgnYmFkZ2VfY3J5c3RhbCcpO1xuICAgICAgICBpZiAoY3J5c3RhbCkgY3J5c3RhbC5yb3RhdGlvbi55ICs9IGRlbHRhICogMi4wO1xuICAgICAgICBjb25zdCByaW5nID0gZW5lbXkucG93ZXJCYWRnZU1lc2guZ2V0T2JqZWN0QnlOYW1lKCdiYWRnZV9yaW5nJyk7XG4gICAgICAgIGlmIChyaW5nKSByaW5nLnJvdGF0aW9uLnogKz0gZGVsdGEgKiAyLjU7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBleGVjdXRlRW5lbXlBdHRhY2soZW5lbXk6IEVuZW15SW5zdGFuY2UpIHtcbiAgICBlbmVteS5hdHRhY2tDb29sZG93biA9IGVuZW15LmlzQm9zcyA/IDIuNSA6IChlbmVteS50eXBlID09PSAnZmFzdCcgPyAxLjggOiAzLjApO1xuICAgIGVuZW15LnJpZy5jdXJyZW50QW5pbSA9ICdhdHRhY2sxJztcbiAgICBlbmVteS5yaWcuYW5pbVByb2dyZXNzID0gMDtcblxuICAgIGlmIChlbmVteS50eXBlID09PSAnYXJjaGVyJykge1xuICAgICAgc291bmRNYW5hZ2VyLnBsYXlBcnJvd1Nob290KCk7XG4gICAgICBjb25zdCBkaXIgPSB0aGlzLnBsYXllclBvcy5jbG9uZSgpLnN1YihlbmVteS5yaWcucm9vdC5wb3NpdGlvbikubm9ybWFsaXplKCk7XG4gICAgICB0aGlzLnBhcnRpY2xlcy5zcGF3bkFycm93KGVuZW15LnJpZy5yb290LnBvc2l0aW9uLCBkaXIsIGVuZW15LmF0dGFja1Bvd2VyKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc291bmRNYW5hZ2VyLnBsYXlTd29yZFNsYXNoKCk7XG5cbiAgICAgIC8vIERhbWFnZSBwbGF5ZXIgaWYgc3RpbGwgaW4gcmFuZ2Ugd2hlbiBzd2luZyBjb25uZWN0c1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGlmIChlbmVteS5oZWFsdGggPiAwKSB7XG4gICAgICAgICAgY29uc3QgZGlzdCA9IHRoaXMucGxheWVyUG9zLmRpc3RhbmNlVG8oZW5lbXkucmlnLnJvb3QucG9zaXRpb24pO1xuICAgICAgICAgIGlmIChkaXN0IDw9IGVuZW15LnJhbmdlICsgMC42KSB7XG4gICAgICAgICAgICB0aGlzLmRhbWFnZVBsYXllcihlbmVteS5hdHRhY2tQb3dlciwgZW5lbXkucmlnLnJvb3QucG9zaXRpb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSwgMjAwKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHVwZGF0ZVByb2plY3RpbGVzKGRlbHRhOiBudW1iZXIpIHtcbiAgICB0aGlzLnBhcnRpY2xlcy5wcm9qZWN0aWxlcy5mb3JFYWNoKChwcm9qLCBpZHgpID0+IHtcbiAgICAgIC8vIENoZWNrIGNvbGxpc2lvbiB3aXRoIHBsYXllciBpZiBob3N0aWxlIHByb2plY3RpbGVcbiAgICAgIGlmICghcHJvai5mcm9tUGxheWVyKSB7XG4gICAgICAgIGNvbnN0IGRpc3QgPSBwcm9qLm1lc2gucG9zaXRpb24uZGlzdGFuY2VUbyh0aGlzLnBsYXllclBvcyk7XG4gICAgICAgIGlmIChkaXN0IDwgMS40KSB7XG4gICAgICAgICAgdGhpcy5kYW1hZ2VQbGF5ZXIocHJvai5kYW1hZ2UsIHByb2oubWVzaC5wb3NpdGlvbik7XG4gICAgICAgICAgdGhpcy5zY2VuZS5yZW1vdmUocHJvai5tZXNoKTtcbiAgICAgICAgICB0aGlzLnBhcnRpY2xlcy5wcm9qZWN0aWxlcy5zcGxpY2UoaWR4LCAxKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gUGxheWVyIGVuZXJneSB3YXZlIGhpdHMgZW5lbWllc1xuICAgICAgICB0aGlzLmVuZW1pZXMuZm9yRWFjaChlbmVteSA9PiB7XG4gICAgICAgICAgaWYgKGVuZW15LmhlYWx0aCA8PSAwKSByZXR1cm47XG4gICAgICAgICAgY29uc3QgZGlzdCA9IHByb2oubWVzaC5wb3NpdGlvbi5kaXN0YW5jZVRvKGVuZW15LnJpZy5yb290LnBvc2l0aW9uKTtcbiAgICAgICAgICBpZiAoZGlzdCA8IDIuNSkge1xuICAgICAgICAgICAgdGhpcy5kYW1hZ2VFbmVteURpcmVjdChlbmVteSwgcHJvai5kYW1hZ2UsIHRydWUsIDgpO1xuICAgICAgICAgICAgc291bmRNYW5hZ2VyLnBsYXlTd29yZENsYXNoKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgdXBkYXRlQ2FtZXJhKGRlbHRhOiBudW1iZXIpIHtcbiAgICAvLyBDYW1lcmEgcm90YXRpb24gaW5wdXRzXG4gICAgaWYgKHRoaXMuaW5wdXQuY2FtZXJhUm90YXRlWCAhPT0gMCkge1xuICAgICAgdGhpcy5jYW1lcmFBbmdsZVggKz0gdGhpcy5pbnB1dC5jYW1lcmFSb3RhdGVYICogZGVsdGEgKiAyLjI7XG4gICAgfVxuICAgIGlmICh0aGlzLmlucHV0LmNhbWVyYVJvdGF0ZVkgIT09IDApIHtcbiAgICAgIHRoaXMuY2FtZXJhQW5nbGVZID0gVEhSRUUuTWF0aFV0aWxzLmNsYW1wKFxuICAgICAgICB0aGlzLmNhbWVyYUFuZ2xlWSArIHRoaXMuaW5wdXQuY2FtZXJhUm90YXRlWSAqIGRlbHRhICogMS41LFxuICAgICAgICAwLjEsXG4gICAgICAgIDAuOVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBDYWxjdWxhdGUgaWRlYWwgY2FtZXJhIHBvc2l0aW9uIGJlaGluZCBwbGF5ZXJcbiAgICBjb25zdCBvZmZzZXRaID0gTWF0aC5jb3ModGhpcy5jYW1lcmFBbmdsZVgpICogTWF0aC5jb3ModGhpcy5jYW1lcmFBbmdsZVkpICogdGhpcy5jYW1lcmFEaXN0YW5jZTtcbiAgICBjb25zdCBvZmZzZXRYID0gTWF0aC5zaW4odGhpcy5jYW1lcmFBbmdsZVgpICogTWF0aC5jb3ModGhpcy5jYW1lcmFBbmdsZVkpICogdGhpcy5jYW1lcmFEaXN0YW5jZTtcbiAgICBjb25zdCBvZmZzZXRZID0gTWF0aC5zaW4odGhpcy5jYW1lcmFBbmdsZVkpICogdGhpcy5jYW1lcmFEaXN0YW5jZSArIDEuNjtcblxuICAgIGNvbnN0IHRhcmdldENhbVBvcyA9IG5ldyBUSFJFRS5WZWN0b3IzKFxuICAgICAgdGhpcy5wbGF5ZXJQb3MueCAtIG9mZnNldFgsXG4gICAgICB0aGlzLnBsYXllclBvcy55ICsgb2Zmc2V0WSxcbiAgICAgIHRoaXMucGxheWVyUG9zLnogLSBvZmZzZXRaXG4gICAgKTtcblxuICAgIC8vIFNjcmVlbiBTaGFrZSBlZmZlY3RcbiAgICBpZiAodGhpcy5zY3JlZW5TaGFrZSA+IDApIHtcbiAgICAgIHRhcmdldENhbVBvcy54ICs9IChNYXRoLnJhbmRvbSgpIC0gMC41KSAqIHRoaXMuc2NyZWVuU2hha2U7XG4gICAgICB0YXJnZXRDYW1Qb3MueSArPSAoTWF0aC5yYW5kb20oKSAtIDAuNSkgKiB0aGlzLnNjcmVlblNoYWtlO1xuICAgICAgdGhpcy5zY3JlZW5TaGFrZSA9IE1hdGgubWF4KDAsIHRoaXMuc2NyZWVuU2hha2UgLSBkZWx0YSAqIDIuNSk7XG4gICAgfVxuXG4gICAgLy8gU2lsa3kgc21vb3RoIGNhbWVyYSBkYW1waW5nXG4gICAgdGhpcy5jYW1lcmEucG9zaXRpb24ueCA9IFRIUkVFLk1hdGhVdGlscy5kYW1wKHRoaXMuY2FtZXJhLnBvc2l0aW9uLngsIHRhcmdldENhbVBvcy54LCAxMCwgZGVsdGEpO1xuICAgIHRoaXMuY2FtZXJhLnBvc2l0aW9uLnkgPSBUSFJFRS5NYXRoVXRpbHMuZGFtcCh0aGlzLmNhbWVyYS5wb3NpdGlvbi55LCB0YXJnZXRDYW1Qb3MueSwgMTAsIGRlbHRhKTtcbiAgICB0aGlzLmNhbWVyYS5wb3NpdGlvbi56ID0gVEhSRUUuTWF0aFV0aWxzLmRhbXAodGhpcy5jYW1lcmEucG9zaXRpb24ueiwgdGFyZ2V0Q2FtUG9zLnosIDEwLCBkZWx0YSk7XG5cbiAgICAvLyBMb29rIGF0IHBsYXllciBjaGVzdFxuICAgIGNvbnN0IGxvb2tUYXJnZXQgPSBuZXcgVEhSRUUuVmVjdG9yMyh0aGlzLnBsYXllclBvcy54LCB0aGlzLnBsYXllclBvcy55ICsgMS40LCB0aGlzLnBsYXllclBvcy56KTtcbiAgICB0aGlzLmNhbWVyYS5sb29rQXQobG9va1RhcmdldCk7XG4gIH1cblxuICBwdWJsaWMgaGFuZGxlUmVzaXplID0gKCkgPT4ge1xuICAgIGlmICghdGhpcy5jb250YWluZXIpIHJldHVybjtcbiAgICBjb25zdCB3aWR0aCA9IHRoaXMuY29udGFpbmVyLmNsaWVudFdpZHRoO1xuICAgIGNvbnN0IGhlaWdodCA9IHRoaXMuY29udGFpbmVyLmNsaWVudEhlaWdodDtcblxuICAgIHRoaXMuY2FtZXJhLmFzcGVjdCA9IHdpZHRoIC8gaGVpZ2h0O1xuICAgIHRoaXMuY2FtZXJhLnVwZGF0ZVByb2plY3Rpb25NYXRyaXgoKTtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFNpemUod2lkdGgsIGhlaWdodCk7XG4gIH07XG5cbiAgcHVibGljIHBhdXNlKCkge1xuICAgIHRoaXMuaXNQYXVzZWQgPSB0cnVlO1xuICB9XG5cbiAgcHVibGljIHJlc3VtZSgpIHtcbiAgICB0aGlzLmlzUGF1c2VkID0gZmFsc2U7XG4gIH1cblxuICBwdWJsaWMgZGlzcG9zZSgpIHtcbiAgICB0aGlzLmlzUnVubmluZyA9IGZhbHNlO1xuICAgIHNvdW5kTWFuYWdlci5zdG9wQmdtKCk7XG4gICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHRoaXMuaGFuZGxlUmVzaXplKTtcbiAgICBjYW5jZWxBbmltYXRpb25GcmFtZSh0aGlzLmFuaW1GcmFtZUlkKTtcbiAgICBjbGVhclRpbWVvdXQodGhpcy5hbmltRnJhbWVJZCk7XG5cbiAgICB0aGlzLmNvbGxlY3RpYmxlcy5mb3JFYWNoKGMgPT4ge1xuICAgICAgdGhpcy5zY2VuZS5yZW1vdmUoYy5tZXNoKTtcbiAgICB9KTtcbiAgICB0aGlzLmNvbGxlY3RpYmxlcyA9IFtdO1xuXG4gICAgdGhpcy5lbmVtaWVzLmZvckVhY2goZSA9PiB7XG4gICAgICBpZiAoZS5wb3dlckJhZGdlTWVzaCkge1xuICAgICAgICB0aGlzLnNjZW5lLnJlbW92ZShlLnBvd2VyQmFkZ2VNZXNoKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHRoaXMucGFydGljbGVzLmRpc3Bvc2UoKTtcbiAgICB0aGlzLnJlbmRlcmVyLmRpc3Bvc2UoKTtcbiAgICBpZiAodGhpcy5jb250YWluZXIgJiYgdGhpcy5yZW5kZXJlci5kb21FbGVtZW50KSB7XG4gICAgICB0aGlzLmNvbnRhaW5lci5yZW1vdmVDaGlsZCh0aGlzLnJlbmRlcmVyLmRvbUVsZW1lbnQpO1xuICAgIH1cbiAgfVxufVxuIl19