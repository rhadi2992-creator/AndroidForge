const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"];/**
* @license
* SPDX-License-Identifier: Apache-2.0
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=677b64f2";
import { GameEngine } from "/src/engine/GameEngine.ts";
import { INITIAL_WEAPONS, INITIAL_SKINS, INITIAL_LEVELS } from "/src/data/gameData.ts";
import { HUD } from "/src/components/HUD.tsx";
import { MainMenu } from "/src/components/MainMenu.tsx";
import { ArmoryModal } from "/src/components/ArmoryModal.tsx";
import { LevelSelectModal } from "/src/components/LevelSelectModal.tsx";
import { VictoryModal } from "/src/components/VictoryModal.tsx";
import { GameOverModal } from "/src/components/GameOverModal.tsx";
import { PauseModal } from "/src/components/PauseModal.tsx";
import { SettingsModal } from "/src/components/SettingsModal.tsx";
import { HowToPlayModal } from "/src/components/HowToPlayModal.tsx";
import { ProjectDownloadModal } from "/src/components/ProjectDownloadModal.tsx";
import { soundManager } from "/src/audio/SoundEffects.ts";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=677b64f2";
export default function App() {
	const canvasMountRef = useRef(null);
	const engineRef = useRef(null);
	// Game UI State
	const [screen, setScreen] = useState("menu");
	const [activeModal, setActiveModal] = useState(null);
	// Persistent Player Progression
	const [coins, setCoins] = useState(() => {
		const saved = localStorage.getItem("sw_coins");
		return saved ? parseInt(saved, 10) : 100;
	});
	const [weapons, setWeapons] = useState(() => {
		const saved = localStorage.getItem("sw_weapons");
		if (saved) {
			try {
				const parsed = JSON.parse(saved);
				return INITIAL_WEAPONS.map((w) => {
					const match = parsed.find((p) => p.id === w.id);
					return match ? {
						...w,
						unlocked: match.unlocked
					} : w;
				});
			} catch {}
		}
		return INITIAL_WEAPONS;
	});
	const [skins, setSkins] = useState(() => {
		const saved = localStorage.getItem("sw_skins");
		if (saved) {
			try {
				const parsed = JSON.parse(saved);
				return INITIAL_SKINS.map((s) => {
					const match = parsed.find((p) => p.id === s.id);
					return match ? {
						...s,
						unlocked: match.unlocked
					} : s;
				});
			} catch {}
		}
		return INITIAL_SKINS;
	});
	const [levels, setLevels] = useState(() => {
		const saved = localStorage.getItem("sw_levels");
		if (saved) {
			try {
				const parsed = JSON.parse(saved);
				return INITIAL_LEVELS.map((l) => {
					const match = parsed.find((p) => p.id === l.id);
					return match ? {
						...l,
						unlocked: match.unlocked,
						stars: match.stars
					} : l;
				});
			} catch {}
		}
		return INITIAL_LEVELS;
	});
	const [selectedWeaponId, setSelectedWeaponId] = useState(() => {
		return localStorage.getItem("sw_weapon_id") || "katana_shadow";
	});
	const [selectedSkinId, setSelectedSkinId] = useState(() => {
		return localStorage.getItem("sw_skin_id") || "skin_shadow";
	});
	const [currentLevelId, setCurrentLevelId] = useState(1);
	// Sound settings
	const [soundSettings, setSoundSettings] = useState({
		masterVolume: .8,
		sfxVolume: .9,
		musicVolume: .5,
		soundEnabled: true,
		musicEnabled: true
	});
	// Dynamic In-Game Stats & HUD state
	const [stats, setStats] = useState({
		maxHealth: 500,
		currentHealth: 500,
		maxEnergy: 100,
		currentEnergy: 50,
		coins: 100,
		selectedWeaponId: "katana_shadow",
		selectedSkinId: "skin_shadow",
		comboCount: 0,
		comboTimer: 0,
		kills: 0,
		specialCooldown: 0,
		specialMaxCooldown: 60
	});
	const [bossHealth, setBossHealth] = useState(null);
	const [floatingDamages, setFloatingDamages] = useState([]);
	const [victoryRewards, setVictoryRewards] = useState({
		coins: 0,
		stars: 0
	});
	// Save changes to localStorage
	useEffect(() => {
		localStorage.setItem("sw_coins", coins.toString());
	}, [coins]);
	useEffect(() => {
		localStorage.setItem("sw_weapons", JSON.stringify(weapons));
	}, [weapons]);
	useEffect(() => {
		localStorage.setItem("sw_skins", JSON.stringify(skins));
	}, [skins]);
	useEffect(() => {
		localStorage.setItem("sw_levels", JSON.stringify(levels));
	}, [levels]);
	useEffect(() => {
		localStorage.setItem("sw_weapon_id", selectedWeaponId);
	}, [selectedWeaponId]);
	useEffect(() => {
		localStorage.setItem("sw_skin_id", selectedSkinId);
	}, [selectedSkinId]);
	const activeLevel = levels.find((l) => l.id === currentLevelId) || levels[0];
	const activeWeapon = weapons.find((w) => w.id === selectedWeaponId) || weapons[0];
	const activeSkin = skins.find((s) => s.id === selectedSkinId) || skins[0];
	// Initialize or Rebuild 3D Engine for Level
	const initEngineForLevel = useCallback((level, weapon, skin) => {
		if (!canvasMountRef.current) return;
		if (engineRef.current) {
			engineRef.current.dispose();
			engineRef.current = null;
		}
		setBossHealth(null);
		setFloatingDamages([]);
		const engine = new GameEngine(canvasMountRef.current, level, weapon, skin, coins);
		engine.onStatsChange = (newStats) => {
			setStats(newStats);
			setCoins(newStats.coins);
		};
		engine.onFloatingDamage = (dmg) => {
			setFloatingDamages((prev) => [...prev.slice(-12), dmg]);
			setTimeout(() => {
				setFloatingDamages((prev) => prev.filter((d) => d.id !== dmg.id));
			}, 700);
		};
		engine.onBossHealthUpdate = (current, max, name) => {
			setBossHealth({
				current,
				max,
				name
			});
		};
		engine.onGameOver = () => {
			window.AndroidBridge?.onGameOver?.();
			setScreen("game_over");
		};
		engine.onVictory = (rewardCoins, starsEarned) => {
			window.AndroidBridge?.onVictory?.();
			setCoins((c) => c + rewardCoins);
			setVictoryRewards({
				coins: rewardCoins,
				stars: starsEarned
			});
			// Unlock next level and save stars
			setLevels((prev) => {
				return prev.map((lvl) => {
					if (lvl.id === level.id) {
						return {
							...lvl,
							stars: Math.max(lvl.stars, starsEarned)
						};
					}
					if (lvl.id === level.id + 1) {
						return {
							...lvl,
							unlocked: true
						};
					}
					return lvl;
				});
			});
			setScreen("victory");
		};
		engineRef.current = engine;
	}, [coins]);
	// Handle Rewarded Ad watching and rewards
	const handleWatchRewardedAd = (type = "general") => {
		soundManager.playClick();
		if (window.AndroidBridge?.showRewardedAd) {
			window.AndroidBridge.showRewardedAd(type);
		} else {
			// Browser preview simulated ad
			const rewardToast = document.createElement("div");
			rewardToast.className = "fixed top-12 left-1/2 -translate-x-1/2 z-[100] bg-amber-500 text-black font-bold px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-2 animate-bounce text-sm";
			rewardToast.innerText = "Watching Sponsored Video Ad... (2s)";
			document.body.appendChild(rewardToast);
			setTimeout(() => {
				if (rewardToast.parentNode) rewardToast.parentNode.removeChild(rewardToast);
				if (window.onRewardedAdReward) {
					window.onRewardedAdReward(200, type);
				}
			}, 2e3);
		}
	};
	// Android Bridge Listeners
	useEffect(() => {
		window.onRewardedAdReward = (amount, type) => {
			const grant = amount || 200;
			setCoins((c) => c + grant);
			soundManager.playCoin();
			if (type === "revive" && engineRef.current) {
				// Revive warrior with full health
				engineRef.current.stats.currentHealth = engineRef.current.stats.maxHealth;
				engineRef.current.playerRig.currentAnim = "idle";
				engineRef.current.notifyStats();
				setScreen("playing");
			}
		};
		window.onAndroidBack = () => {
			if (screen === "playing") {
				handlePause();
			} else if (screen === "paused") {
				handleResume();
			} else if (screen !== "menu") {
				handleHome();
			}
		};
		return () => {
			delete window.onRewardedAdReward;
			delete window.onAndroidBack;
		};
	}, [screen]);
	// Initial engine load for background scenery on main menu
	useEffect(() => {
		initEngineForLevel(activeLevel, activeWeapon, activeSkin);
		return () => {
			if (engineRef.current) {
				engineRef.current.dispose();
				engineRef.current = null;
			}
		};
	}, []);
	// Keyboard desktop controls listener
	useEffect(() => {
		const keysDown = new Set();
		const handleKeyDown = (e) => {
			if (e.repeat) return;
			keysDown.add(e.code);
			if (e.code === "Escape") {
				if (screen === "playing") {
					handlePause();
				} else if (screen === "paused") {
					handleResume();
				}
				return;
			}
			if (screen !== "playing" || !engineRef.current) return;
			if (e.code === "Space") {
				engineRef.current.triggerJump();
			} else if (e.code === "KeyJ" || e.code === "Enter") {
				engineRef.current.triggerAttack();
			} else if (e.code === "KeyK") {
				engineRef.current.triggerHeavyKick();
			} else if (e.code === "ShiftLeft" || e.code === "ShiftRight" || e.code === "KeyL") {
				engineRef.current.triggerDodge();
			} else if (e.code === "KeyE") {
				engineRef.current.triggerSpecialPower();
			}
			updateKeyboardMovement();
		};
		const handleKeyUp = (e) => {
			keysDown.delete(e.code);
			if (screen === "playing" && engineRef.current) {
				updateKeyboardMovement();
			}
		};
		const updateKeyboardMovement = () => {
			if (!engineRef.current) return;
			let mx = 0;
			let mz = 0;
			let rotX = 0;
			if (keysDown.has("KeyW") || keysDown.has("ArrowUp")) mz += 1;
			if (keysDown.has("KeyS") || keysDown.has("ArrowDown")) mz -= 1;
			if (keysDown.has("KeyA") || keysDown.has("ArrowLeft")) mx -= 1;
			if (keysDown.has("KeyD") || keysDown.has("ArrowRight")) mx += 1;
			if (keysDown.has("KeyQ")) rotX -= 1;
			if (keysDown.has("KeyR")) rotX += 1;
			// Normalize diagonal movement
			const len = Math.sqrt(mx * mx + mz * mz);
			if (len > 0) {
				mx /= len;
				mz /= len;
			}
			engineRef.current.updateInput({
				moveX: mx,
				moveZ: mz,
				cameraRotateX: rotX
			});
		};
		window.addEventListener("keydown", handleKeyDown);
		window.addEventListener("keyup", handleKeyUp);
		return () => {
			window.removeEventListener("keydown", handleKeyDown);
			window.removeEventListener("keyup", handleKeyUp);
		};
	}, [screen]);
	// Handle Game Screen Transitions
	const handleStartGame = () => {
		window.AndroidBridge?.onGameStarted?.();
		setScreen("playing");
		initEngineForLevel(activeLevel, activeWeapon, activeSkin);
	};
	const handlePause = () => {
		if (engineRef.current) {
			engineRef.current.pause();
		}
		setScreen("paused");
	};
	const handleResume = () => {
		if (engineRef.current) {
			engineRef.current.resume();
		}
		setScreen("playing");
	};
	const handleRestart = () => {
		window.AndroidBridge?.onGameStarted?.();
		setScreen("playing");
		initEngineForLevel(activeLevel, activeWeapon, activeSkin);
	};
	const handleHome = () => {
		window.AndroidBridge?.onGameEnded?.();
		window.AndroidBridge?.showBannerAd?.();
		setScreen("menu");
		initEngineForLevel(activeLevel, activeWeapon, activeSkin);
	};
	const handleNextLevel = () => {
		const nextId = currentLevelId + 1;
		const nextLvl = levels.find((l) => l.id === nextId);
		if (nextLvl && nextLvl.unlocked) {
			setCurrentLevelId(nextId);
			setScreen("playing");
			initEngineForLevel(nextLvl, activeWeapon, activeSkin);
		} else {
			handleHome();
		}
	};
	const handleUnlockWeapon = (weaponId, price) => {
		if (coins >= price) {
			setCoins((c) => c - price);
			setWeapons((prev) => prev.map((w) => w.id === weaponId ? {
				...w,
				unlocked: true
			} : w));
			setSelectedWeaponId(weaponId);
		}
	};
	const handleUnlockSkin = (skinId, price) => {
		if (coins >= price) {
			setCoins((c) => c - price);
			setSkins((prev) => prev.map((s) => s.id === skinId ? {
				...s,
				unlocked: true
			} : s));
			setSelectedSkinId(skinId);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative w-screen h-screen overflow-hidden bg-black select-none",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				ref: canvasMountRef,
				className: "absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 435,
				columnNumber: 7
			}, this),
			screen === "playing" && /* @__PURE__ */ _jsxDEV(HUD, {
				stats,
				level: activeLevel,
				floatingDamages,
				bossHealth,
				onInputUpdate: (input) => {
					if (engineRef.current) {
						engineRef.current.updateInput(input);
					}
				},
				onPause: handlePause
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 442,
				columnNumber: 9
			}, this),
			screen === "menu" && !activeModal && /* @__PURE__ */ _jsxDEV(MainMenu, {
				onStartGame: handleStartGame,
				onOpenLevelSelect: () => setActiveModal("level_select"),
				onOpenArmory: () => setActiveModal("armory"),
				onOpenSettings: () => setActiveModal("settings"),
				onOpenHowToPlay: () => setActiveModal("how_to_play"),
				onDownloadProject: () => setActiveModal("download_zip"),
				onWatchAd: () => handleWatchRewardedAd("menu_bonus"),
				coins,
				currentLevelName: activeLevel.name
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 458,
				columnNumber: 9
			}, this),
			screen === "paused" && /* @__PURE__ */ _jsxDEV(PauseModal, {
				levelName: activeLevel.name,
				onResume: handleResume,
				onRestart: handleRestart,
				onOpenSettings: () => setActiveModal("settings"),
				onHome: handleHome
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 473,
				columnNumber: 9
			}, this),
			screen === "victory" && /* @__PURE__ */ _jsxDEV(VictoryModal, {
				levelName: activeLevel.name,
				earnedCoins: victoryRewards.coins,
				stars: victoryRewards.stars,
				hasNextLevel: currentLevelId < levels.length && levels[currentLevelId]?.unlocked,
				onNextLevel: handleNextLevel,
				onRestart: handleRestart,
				onHome: handleHome,
				onWatchRewardedAd: () => handleWatchRewardedAd("victory_double")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 484,
				columnNumber: 9
			}, this),
			screen === "game_over" && /* @__PURE__ */ _jsxDEV(GameOverModal, {
				levelName: activeLevel.name,
				onRestart: handleRestart,
				onHome: handleHome,
				onOpenArmory: () => {
					setScreen("menu");
					setActiveModal("armory");
				},
				onWatchRewardedAd: () => handleWatchRewardedAd("revive")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 498,
				columnNumber: 9
			}, this),
			activeModal === "armory" && /* @__PURE__ */ _jsxDEV(ArmoryModal, {
				weapons,
				skins,
				selectedWeaponId,
				selectedSkinId,
				coins,
				onSelectWeapon: (id) => {
					setSelectedWeaponId(id);
					const w = weapons.find((item) => item.id === id);
					if (w) initEngineForLevel(activeLevel, w, activeSkin);
				},
				onSelectSkin: (id) => {
					setSelectedSkinId(id);
					const s = skins.find((item) => item.id === id);
					if (s) initEngineForLevel(activeLevel, activeWeapon, s);
				},
				onUnlockWeapon: handleUnlockWeapon,
				onUnlockSkin: handleUnlockSkin,
				onWatchRewardedAd: () => handleWatchRewardedAd("armory"),
				onClose: () => setActiveModal(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 512,
				columnNumber: 9
			}, this),
			activeModal === "level_select" && /* @__PURE__ */ _jsxDEV(LevelSelectModal, {
				levels,
				currentLevelId,
				onSelectLevel: (id) => {
					setCurrentLevelId(id);
					const lvl = levels.find((l) => l.id === id);
					if (lvl) initEngineForLevel(lvl, activeWeapon, activeSkin);
				},
				onClose: () => setActiveModal(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 537,
				columnNumber: 9
			}, this),
			activeModal === "settings" && /* @__PURE__ */ _jsxDEV(SettingsModal, {
				soundSettings,
				onUpdateSound: (newSettings) => setSoundSettings((prev) => ({
					...prev,
					...newSettings
				})),
				onClose: () => setActiveModal(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 551,
				columnNumber: 9
			}, this),
			activeModal === "how_to_play" && /* @__PURE__ */ _jsxDEV(HowToPlayModal, { onClose: () => setActiveModal(null) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 560,
				columnNumber: 9
			}, this),
			activeModal === "download_zip" && /* @__PURE__ */ _jsxDEV(ProjectDownloadModal, { onClose: () => setActiveModal(null) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 565,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 433,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sU0FBUyxXQUFXLFFBQVEsVUFBVSxtQkFBbUI7QUFDaEUsU0FBUyxrQkFBa0I7QUFDM0IsU0FDRSxpQkFDQSxlQUNBLHNCQUNLO0FBVVAsU0FBUyxXQUFXO0FBQ3BCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMsb0JBQW9COzs7QUFFN0IsZUFBZSxTQUFTLE1BQU07Q0FDNUIsTUFBTSxpQkFBaUIsT0FBdUIsSUFBSTtDQUNsRCxNQUFNLFlBQVksT0FBMEIsSUFBSTs7Q0FHaEQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFrRSxNQUFNO0NBQ3BHLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUF5RixJQUFJOztDQUduSSxNQUFNLENBQUMsT0FBTyxZQUFZLGVBQXVCO0VBQy9DLE1BQU0sUUFBUSxhQUFhLFFBQVEsVUFBVTtFQUM3QyxPQUFPLFFBQVEsU0FBUyxPQUFPLEVBQUUsSUFBSTtDQUN2QyxDQUFDO0NBRUQsTUFBTSxDQUFDLFNBQVMsY0FBYyxlQUF5QjtFQUNyRCxNQUFNLFFBQVEsYUFBYSxRQUFRLFlBQVk7RUFDL0MsSUFBSSxPQUFPO0dBQ1QsSUFBSTtJQUNGLE1BQU0sU0FBUyxLQUFLLE1BQU0sS0FBSztJQUMvQixPQUFPLGdCQUFnQixLQUFJLE1BQUs7S0FDOUIsTUFBTSxRQUFRLE9BQU8sTUFBTSxNQUFjLEVBQUUsT0FBTyxFQUFFLEVBQUU7S0FDdEQsT0FBTyxRQUFRO01BQUUsR0FBRztNQUFHLFVBQVUsTUFBTTtLQUFTLElBQUk7SUFDdEQsQ0FBQztHQUNILFFBQVEsQ0FBQztFQUNYO0VBQ0EsT0FBTztDQUNULENBQUM7Q0FFRCxNQUFNLENBQUMsT0FBTyxZQUFZLGVBQTZCO0VBQ3JELE1BQU0sUUFBUSxhQUFhLFFBQVEsVUFBVTtFQUM3QyxJQUFJLE9BQU87R0FDVCxJQUFJO0lBQ0YsTUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLO0lBQy9CLE9BQU8sY0FBYyxLQUFJLE1BQUs7S0FDNUIsTUFBTSxRQUFRLE9BQU8sTUFBTSxNQUFrQixFQUFFLE9BQU8sRUFBRSxFQUFFO0tBQzFELE9BQU8sUUFBUTtNQUFFLEdBQUc7TUFBRyxVQUFVLE1BQU07S0FBUyxJQUFJO0lBQ3RELENBQUM7R0FDSCxRQUFRLENBQUM7RUFDWDtFQUNBLE9BQU87Q0FDVCxDQUFDO0NBRUQsTUFBTSxDQUFDLFFBQVEsYUFBYSxlQUE4QjtFQUN4RCxNQUFNLFFBQVEsYUFBYSxRQUFRLFdBQVc7RUFDOUMsSUFBSSxPQUFPO0dBQ1QsSUFBSTtJQUNGLE1BQU0sU0FBUyxLQUFLLE1BQU0sS0FBSztJQUMvQixPQUFPLGVBQWUsS0FBSSxNQUFLO0tBQzdCLE1BQU0sUUFBUSxPQUFPLE1BQU0sTUFBbUIsRUFBRSxPQUFPLEVBQUUsRUFBRTtLQUMzRCxPQUFPLFFBQVE7TUFBRSxHQUFHO01BQUcsVUFBVSxNQUFNO01BQVUsT0FBTyxNQUFNO0tBQU0sSUFBSTtJQUMxRSxDQUFDO0dBQ0gsUUFBUSxDQUFDO0VBQ1g7RUFDQSxPQUFPO0NBQ1QsQ0FBQztDQUVELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLGVBQXVCO0VBQ3JFLE9BQU8sYUFBYSxRQUFRLGNBQWMsS0FBSztDQUNqRCxDQUFDO0NBRUQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsZUFBdUI7RUFDakUsT0FBTyxhQUFhLFFBQVEsWUFBWSxLQUFLO0NBQy9DLENBQUM7Q0FFRCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFpQixDQUFDOztDQUc5RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBd0I7RUFDaEUsY0FBYztFQUNkLFdBQVc7RUFDWCxhQUFhO0VBQ2IsY0FBYztFQUNkLGNBQWM7Q0FDaEIsQ0FBQzs7Q0FHRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQXNCO0VBQzlDLFdBQVc7RUFDWCxlQUFlO0VBQ2YsV0FBVztFQUNYLGVBQWU7RUFDZixPQUFPO0VBQ1Asa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixZQUFZO0VBQ1osWUFBWTtFQUNaLE9BQU87RUFDUCxpQkFBaUI7RUFDakIsb0JBQW9CO0NBQ3RCLENBQUM7Q0FFRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBZ0UsSUFBSTtDQUN4RyxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUEyQixDQUFDLENBQUM7Q0FDM0UsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBMkM7RUFBRSxPQUFPO0VBQUcsT0FBTztDQUFFLENBQUM7O0NBRzdHLGdCQUFnQjtFQUNkLGFBQWEsUUFBUSxZQUFZLE1BQU0sU0FBUyxDQUFDO0NBQ25ELEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FFVixnQkFBZ0I7RUFDZCxhQUFhLFFBQVEsY0FBYyxLQUFLLFVBQVUsT0FBTyxDQUFDO0NBQzVELEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FFWixnQkFBZ0I7RUFDZCxhQUFhLFFBQVEsWUFBWSxLQUFLLFVBQVUsS0FBSyxDQUFDO0NBQ3hELEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FFVixnQkFBZ0I7RUFDZCxhQUFhLFFBQVEsYUFBYSxLQUFLLFVBQVUsTUFBTSxDQUFDO0NBQzFELEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FFWCxnQkFBZ0I7RUFDZCxhQUFhLFFBQVEsZ0JBQWdCLGdCQUFnQjtDQUN2RCxHQUFHLENBQUMsZ0JBQWdCLENBQUM7Q0FFckIsZ0JBQWdCO0VBQ2QsYUFBYSxRQUFRLGNBQWMsY0FBYztDQUNuRCxHQUFHLENBQUMsY0FBYyxDQUFDO0NBRW5CLE1BQU0sY0FBYyxPQUFPLE1BQUssTUFBSyxFQUFFLE9BQU8sY0FBYyxLQUFLLE9BQU87Q0FDeEUsTUFBTSxlQUFlLFFBQVEsTUFBSyxNQUFLLEVBQUUsT0FBTyxnQkFBZ0IsS0FBSyxRQUFRO0NBQzdFLE1BQU0sYUFBYSxNQUFNLE1BQUssTUFBSyxFQUFFLE9BQU8sY0FBYyxLQUFLLE1BQU07O0NBR3JFLE1BQU0scUJBQXFCLGFBQWEsT0FBb0IsUUFBZ0IsU0FBcUI7RUFDL0YsSUFBSSxDQUFDLGVBQWUsU0FBUztFQUU3QixJQUFJLFVBQVUsU0FBUztHQUNyQixVQUFVLFFBQVEsUUFBUTtHQUMxQixVQUFVLFVBQVU7RUFDdEI7RUFFQSxjQUFjLElBQUk7RUFDbEIsbUJBQW1CLENBQUMsQ0FBQztFQUVyQixNQUFNLFNBQVMsSUFBSSxXQUNqQixlQUFlLFNBQ2YsT0FDQSxRQUNBLE1BQ0EsS0FDRjtFQUVBLE9BQU8saUJBQWlCLGFBQWE7R0FDbkMsU0FBUyxRQUFRO0dBQ2pCLFNBQVMsU0FBUyxLQUFLO0VBQ3pCO0VBRUEsT0FBTyxvQkFBb0IsUUFBUTtHQUNqQyxvQkFBbUIsU0FBUSxDQUFDLEdBQUcsS0FBSyxNQUFNLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQztHQUNwRCxpQkFBaUI7SUFDZixvQkFBbUIsU0FBUSxLQUFLLFFBQU8sTUFBSyxFQUFFLE9BQU8sSUFBSSxFQUFFLENBQUM7R0FDOUQsR0FBRyxHQUFHO0VBQ1I7RUFFQSxPQUFPLHNCQUFzQixTQUFTLEtBQUssU0FBUztHQUNsRCxjQUFjO0lBQUU7SUFBUztJQUFLO0dBQUssQ0FBQztFQUN0QztFQUVBLE9BQU8sbUJBQW1CO0dBQ3hCLE9BQU8sZUFBZSxhQUFhO0dBQ25DLFVBQVUsV0FBVztFQUN2QjtFQUVBLE9BQU8sYUFBYSxhQUFhLGdCQUFnQjtHQUMvQyxPQUFPLGVBQWUsWUFBWTtHQUNsQyxVQUFTLE1BQUssSUFBSSxXQUFXO0dBQzdCLGtCQUFrQjtJQUFFLE9BQU87SUFBYSxPQUFPO0dBQVksQ0FBQzs7R0FHNUQsV0FBVSxTQUFRO0lBQ2hCLE9BQU8sS0FBSyxLQUFJLFFBQU87S0FDckIsSUFBSSxJQUFJLE9BQU8sTUFBTSxJQUFJO01BQ3ZCLE9BQU87T0FDTCxHQUFHO09BQ0gsT0FBTyxLQUFLLElBQUksSUFBSSxPQUFPLFdBQVc7TUFDeEM7S0FDRjtLQUNBLElBQUksSUFBSSxPQUFPLE1BQU0sS0FBSyxHQUFHO01BQzNCLE9BQU87T0FBRSxHQUFHO09BQUssVUFBVTtNQUFLO0tBQ2xDO0tBQ0EsT0FBTztJQUNULENBQUM7R0FDSCxDQUFDO0dBRUQsVUFBVSxTQUFTO0VBQ3JCO0VBRUEsVUFBVSxVQUFVO0NBQ3RCLEdBQUcsQ0FBQyxLQUFLLENBQUM7O0NBR1YsTUFBTSx5QkFBeUIsT0FBZSxjQUFjO0VBQzFELGFBQWEsVUFBVTtFQUN2QixJQUFJLE9BQU8sZUFBZSxnQkFBZ0I7R0FDeEMsT0FBTyxjQUFjLGVBQWUsSUFBSTtFQUMxQyxPQUFPOztHQUVMLE1BQU0sY0FBYyxTQUFTLGNBQWMsS0FBSztHQUNoRCxZQUFZLFlBQVk7R0FDeEIsWUFBWSxZQUFZO0dBQ3hCLFNBQVMsS0FBSyxZQUFZLFdBQVc7R0FFckMsaUJBQWlCO0lBQ2YsSUFBSSxZQUFZLFlBQVksWUFBWSxXQUFXLFlBQVksV0FBVztJQUMxRSxJQUFJLE9BQU8sb0JBQW9CO0tBQzdCLE9BQU8sbUJBQW1CLEtBQUssSUFBSTtJQUNyQztHQUNGLEdBQUcsR0FBSTtFQUNUO0NBQ0Y7O0NBR0EsZ0JBQWdCO0VBQ2QsT0FBTyxzQkFBc0IsUUFBZ0IsU0FBaUI7R0FDNUQsTUFBTSxRQUFRLFVBQVU7R0FDeEIsVUFBUyxNQUFLLElBQUksS0FBSztHQUN2QixhQUFhLFNBQVM7R0FFdEIsSUFBSSxTQUFTLFlBQVksVUFBVSxTQUFTOztJQUUxQyxVQUFVLFFBQVEsTUFBTSxnQkFBZ0IsVUFBVSxRQUFRLE1BQU07SUFDaEUsVUFBVSxRQUFRLFVBQVUsY0FBYztJQUMxQyxVQUFVLFFBQVEsWUFBWTtJQUM5QixVQUFVLFNBQVM7R0FDckI7RUFDRjtFQUVBLE9BQU8sc0JBQXNCO0dBQzNCLElBQUksV0FBVyxXQUFXO0lBQ3hCLFlBQVk7R0FDZCxPQUFPLElBQUksV0FBVyxVQUFVO0lBQzlCLGFBQWE7R0FDZixPQUFPLElBQUksV0FBVyxRQUFRO0lBQzVCLFdBQVc7R0FDYjtFQUNGO0VBRUEsYUFBYTtHQUNYLE9BQU8sT0FBTztHQUNkLE9BQU8sT0FBTztFQUNoQjtDQUNGLEdBQUcsQ0FBQyxNQUFNLENBQUM7O0NBR1gsZ0JBQWdCO0VBQ2QsbUJBQW1CLGFBQWEsY0FBYyxVQUFVO0VBRXhELGFBQWE7R0FDWCxJQUFJLFVBQVUsU0FBUztJQUNyQixVQUFVLFFBQVEsUUFBUTtJQUMxQixVQUFVLFVBQVU7R0FDdEI7RUFDRjtDQUNGLEdBQUcsQ0FBQyxDQUFDOztDQUdMLGdCQUFnQjtFQUNkLE1BQU0sV0FBVyxJQUFJLElBQVk7RUFFakMsTUFBTSxpQkFBaUIsTUFBcUI7R0FDMUMsSUFBSSxFQUFFLFFBQVE7R0FDZCxTQUFTLElBQUksRUFBRSxJQUFJO0dBRW5CLElBQUksRUFBRSxTQUFTLFVBQVU7SUFDdkIsSUFBSSxXQUFXLFdBQVc7S0FDeEIsWUFBWTtJQUNkLE9BQU8sSUFBSSxXQUFXLFVBQVU7S0FDOUIsYUFBYTtJQUNmO0lBQ0E7R0FDRjtHQUVBLElBQUksV0FBVyxhQUFhLENBQUMsVUFBVSxTQUFTO0dBRWhELElBQUksRUFBRSxTQUFTLFNBQVM7SUFDdEIsVUFBVSxRQUFRLFlBQVk7R0FDaEMsT0FBTyxJQUFJLEVBQUUsU0FBUyxVQUFVLEVBQUUsU0FBUyxTQUFTO0lBQ2xELFVBQVUsUUFBUSxjQUFjO0dBQ2xDLE9BQU8sSUFBSSxFQUFFLFNBQVMsUUFBUTtJQUM1QixVQUFVLFFBQVEsaUJBQWlCO0dBQ3JDLE9BQU8sSUFBSSxFQUFFLFNBQVMsZUFBZSxFQUFFLFNBQVMsZ0JBQWdCLEVBQUUsU0FBUyxRQUFRO0lBQ2pGLFVBQVUsUUFBUSxhQUFhO0dBQ2pDLE9BQU8sSUFBSSxFQUFFLFNBQVMsUUFBUTtJQUM1QixVQUFVLFFBQVEsb0JBQW9CO0dBQ3hDO0dBRUEsdUJBQXVCO0VBQ3pCO0VBRUEsTUFBTSxlQUFlLE1BQXFCO0dBQ3hDLFNBQVMsT0FBTyxFQUFFLElBQUk7R0FDdEIsSUFBSSxXQUFXLGFBQWEsVUFBVSxTQUFTO0lBQzdDLHVCQUF1QjtHQUN6QjtFQUNGO0VBRUEsTUFBTSwrQkFBK0I7R0FDbkMsSUFBSSxDQUFDLFVBQVUsU0FBUztHQUV4QixJQUFJLEtBQUs7R0FDVCxJQUFJLEtBQUs7R0FDVCxJQUFJLE9BQU87R0FFWCxJQUFJLFNBQVMsSUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLFNBQVMsR0FBRyxNQUFNO0dBQzNELElBQUksU0FBUyxJQUFJLE1BQU0sS0FBSyxTQUFTLElBQUksV0FBVyxHQUFHLE1BQU07R0FDN0QsSUFBSSxTQUFTLElBQUksTUFBTSxLQUFLLFNBQVMsSUFBSSxXQUFXLEdBQUcsTUFBTTtHQUM3RCxJQUFJLFNBQVMsSUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLFlBQVksR0FBRyxNQUFNO0dBRTlELElBQUksU0FBUyxJQUFJLE1BQU0sR0FBRyxRQUFRO0dBQ2xDLElBQUksU0FBUyxJQUFJLE1BQU0sR0FBRyxRQUFROztHQUdsQyxNQUFNLE1BQU0sS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEVBQUU7R0FDdkMsSUFBSSxNQUFNLEdBQUc7SUFDWCxNQUFNO0lBQ04sTUFBTTtHQUNSO0dBRUEsVUFBVSxRQUFRLFlBQVk7SUFDNUIsT0FBTztJQUNQLE9BQU87SUFDUCxlQUFlO0dBQ2pCLENBQUM7RUFDSDtFQUVBLE9BQU8saUJBQWlCLFdBQVcsYUFBYTtFQUNoRCxPQUFPLGlCQUFpQixTQUFTLFdBQVc7RUFFNUMsYUFBYTtHQUNYLE9BQU8sb0JBQW9CLFdBQVcsYUFBYTtHQUNuRCxPQUFPLG9CQUFvQixTQUFTLFdBQVc7RUFDakQ7Q0FDRixHQUFHLENBQUMsTUFBTSxDQUFDOztDQUdYLE1BQU0sd0JBQXdCO0VBQzVCLE9BQU8sZUFBZSxnQkFBZ0I7RUFDdEMsVUFBVSxTQUFTO0VBQ25CLG1CQUFtQixhQUFhLGNBQWMsVUFBVTtDQUMxRDtDQUVBLE1BQU0sb0JBQW9CO0VBQ3hCLElBQUksVUFBVSxTQUFTO0dBQ3JCLFVBQVUsUUFBUSxNQUFNO0VBQzFCO0VBQ0EsVUFBVSxRQUFRO0NBQ3BCO0NBRUEsTUFBTSxxQkFBcUI7RUFDekIsSUFBSSxVQUFVLFNBQVM7R0FDckIsVUFBVSxRQUFRLE9BQU87RUFDM0I7RUFDQSxVQUFVLFNBQVM7Q0FDckI7Q0FFQSxNQUFNLHNCQUFzQjtFQUMxQixPQUFPLGVBQWUsZ0JBQWdCO0VBQ3RDLFVBQVUsU0FBUztFQUNuQixtQkFBbUIsYUFBYSxjQUFjLFVBQVU7Q0FDMUQ7Q0FFQSxNQUFNLG1CQUFtQjtFQUN2QixPQUFPLGVBQWUsY0FBYztFQUNwQyxPQUFPLGVBQWUsZUFBZTtFQUNyQyxVQUFVLE1BQU07RUFDaEIsbUJBQW1CLGFBQWEsY0FBYyxVQUFVO0NBQzFEO0NBRUEsTUFBTSx3QkFBd0I7RUFDNUIsTUFBTSxTQUFTLGlCQUFpQjtFQUNoQyxNQUFNLFVBQVUsT0FBTyxNQUFLLE1BQUssRUFBRSxPQUFPLE1BQU07RUFDaEQsSUFBSSxXQUFXLFFBQVEsVUFBVTtHQUMvQixrQkFBa0IsTUFBTTtHQUN4QixVQUFVLFNBQVM7R0FDbkIsbUJBQW1CLFNBQVMsY0FBYyxVQUFVO0VBQ3RELE9BQU87R0FDTCxXQUFXO0VBQ2I7Q0FDRjtDQUVBLE1BQU0sc0JBQXNCLFVBQWtCLFVBQWtCO0VBQzlELElBQUksU0FBUyxPQUFPO0dBQ2xCLFVBQVMsTUFBSyxJQUFJLEtBQUs7R0FDdkIsWUFBVyxTQUFRLEtBQUssS0FBSSxNQUFLLEVBQUUsT0FBTyxXQUFXO0lBQUUsR0FBRztJQUFHLFVBQVU7R0FBSyxJQUFJLENBQUMsQ0FBQztHQUNsRixvQkFBb0IsUUFBUTtFQUM5QjtDQUNGO0NBRUEsTUFBTSxvQkFBb0IsUUFBZ0IsVUFBa0I7RUFDMUQsSUFBSSxTQUFTLE9BQU87R0FDbEIsVUFBUyxNQUFLLElBQUksS0FBSztHQUN2QixVQUFTLFNBQVEsS0FBSyxLQUFJLE1BQUssRUFBRSxPQUFPLFNBQVM7SUFBRSxHQUFHO0lBQUcsVUFBVTtHQUFLLElBQUksQ0FBQyxDQUFDO0dBQzlFLGtCQUFrQixNQUFNO0VBQzFCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQ0UsS0FBSztJQUNMLFdBQVU7R0FDWDs7Ozs7R0FHQSxXQUFXLGFBQ1Ysd0JBQUMsS0FBRDtJQUNTO0lBQ1AsT0FBTztJQUNVO0lBQ0w7SUFDWixnQkFBZSxVQUFTO0tBQ3RCLElBQUksVUFBVSxTQUFTO01BQ3JCLFVBQVUsUUFBUSxZQUFZLEtBQUs7S0FDckM7SUFDRjtJQUNBLFNBQVM7R0FDVjs7Ozs7R0FJRixXQUFXLFVBQVUsQ0FBQyxlQUNyQix3QkFBQyxVQUFEO0lBQ0UsYUFBYTtJQUNiLHlCQUF5QixlQUFlLGNBQWM7SUFDdEQsb0JBQW9CLGVBQWUsUUFBUTtJQUMzQyxzQkFBc0IsZUFBZSxVQUFVO0lBQy9DLHVCQUF1QixlQUFlLGFBQWE7SUFDbkQseUJBQXlCLGVBQWUsY0FBYztJQUN0RCxpQkFBaUIsc0JBQXNCLFlBQVk7SUFDNUM7SUFDUCxrQkFBa0IsWUFBWTtHQUMvQjs7Ozs7R0FJRixXQUFXLFlBQ1Ysd0JBQUMsWUFBRDtJQUNFLFdBQVcsWUFBWTtJQUN2QixVQUFVO0lBQ1YsV0FBVztJQUNYLHNCQUFzQixlQUFlLFVBQVU7SUFDL0MsUUFBUTtHQUNUOzs7OztHQUlGLFdBQVcsYUFDVix3QkFBQyxjQUFEO0lBQ0UsV0FBVyxZQUFZO0lBQ3ZCLGFBQWEsZUFBZTtJQUM1QixPQUFPLGVBQWU7SUFDdEIsY0FBYyxpQkFBaUIsT0FBTyxVQUFVLE9BQU8sZUFBZSxFQUFFO0lBQ3hFLGFBQWE7SUFDYixXQUFXO0lBQ1gsUUFBUTtJQUNSLHlCQUF5QixzQkFBc0IsZ0JBQWdCO0dBQ2hFOzs7OztHQUlGLFdBQVcsZUFDVix3QkFBQyxlQUFEO0lBQ0UsV0FBVyxZQUFZO0lBQ3ZCLFdBQVc7SUFDWCxRQUFRO0lBQ1Isb0JBQW9CO0tBQ2xCLFVBQVUsTUFBTTtLQUNoQixlQUFlLFFBQVE7SUFDekI7SUFDQSx5QkFBeUIsc0JBQXNCLFFBQVE7R0FDeEQ7Ozs7O0dBSUYsZ0JBQWdCLFlBQ2Ysd0JBQUMsYUFBRDtJQUNXO0lBQ0Y7SUFDVztJQUNGO0lBQ1Q7SUFDUCxpQkFBaUIsT0FBTztLQUN0QixvQkFBb0IsRUFBRTtLQUN0QixNQUFNLElBQUksUUFBUSxNQUFLLFNBQVEsS0FBSyxPQUFPLEVBQUU7S0FDN0MsSUFBSSxHQUFHLG1CQUFtQixhQUFhLEdBQUcsVUFBVTtJQUN0RDtJQUNBLGVBQWUsT0FBTztLQUNwQixrQkFBa0IsRUFBRTtLQUNwQixNQUFNLElBQUksTUFBTSxNQUFLLFNBQVEsS0FBSyxPQUFPLEVBQUU7S0FDM0MsSUFBSSxHQUFHLG1CQUFtQixhQUFhLGNBQWMsQ0FBQztJQUN4RDtJQUNBLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QseUJBQXlCLHNCQUFzQixRQUFRO0lBQ3ZELGVBQWUsZUFBZSxJQUFJO0dBQ25DOzs7OztHQUlGLGdCQUFnQixrQkFDZix3QkFBQyxrQkFBRDtJQUNVO0lBQ1E7SUFDaEIsZ0JBQWdCLE9BQU87S0FDckIsa0JBQWtCLEVBQUU7S0FDcEIsTUFBTSxNQUFNLE9BQU8sTUFBSyxNQUFLLEVBQUUsT0FBTyxFQUFFO0tBQ3hDLElBQUksS0FBSyxtQkFBbUIsS0FBSyxjQUFjLFVBQVU7SUFDM0Q7SUFDQSxlQUFlLGVBQWUsSUFBSTtHQUNuQzs7Ozs7R0FJRixnQkFBZ0IsY0FDZix3QkFBQyxlQUFEO0lBQ2lCO0lBQ2YsZ0JBQWUsZ0JBQWUsa0JBQWlCLFVBQVM7S0FBRSxHQUFHO0tBQU0sR0FBRztJQUFZLEVBQUU7SUFDcEYsZUFBZSxlQUFlLElBQUk7R0FDbkM7Ozs7O0dBSUYsZ0JBQWdCLGlCQUNmLHdCQUFDLGdCQUFELEVBQWdCLGVBQWUsZUFBZSxJQUFJLEVBQUk7Ozs7O0dBSXZELGdCQUFnQixrQkFDZix3QkFBQyxzQkFBRCxFQUFzQixlQUFlLGVBQWUsSUFBSSxFQUFJOzs7OztFQUUzRDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgR2FtZUVuZ2luZSB9IGZyb20gJy4vZW5naW5lL0dhbWVFbmdpbmUnO1xuaW1wb3J0IHtcbiAgSU5JVElBTF9XRUFQT05TLFxuICBJTklUSUFMX1NLSU5TLFxuICBJTklUSUFMX0xFVkVMUyxcbn0gZnJvbSAnLi9kYXRhL2dhbWVEYXRhJztcbmltcG9ydCB7XG4gIFdlYXBvbixcbiAgUGxheWVyU2tpbixcbiAgTGV2ZWxDb25maWcsXG4gIFBsYXllclN0YXRzLFxuICBVc2VySW5wdXQsXG4gIEZsb2F0aW5nRGFtYWdlLFxuICBTb3VuZFNldHRpbmdzLFxufSBmcm9tICcuL3R5cGVzL2dhbWUnO1xuaW1wb3J0IHsgSFVEIH0gZnJvbSAnLi9jb21wb25lbnRzL0hVRCc7XG5pbXBvcnQgeyBNYWluTWVudSB9IGZyb20gJy4vY29tcG9uZW50cy9NYWluTWVudSc7XG5pbXBvcnQgeyBBcm1vcnlNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9Bcm1vcnlNb2RhbCc7XG5pbXBvcnQgeyBMZXZlbFNlbGVjdE1vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL0xldmVsU2VsZWN0TW9kYWwnO1xuaW1wb3J0IHsgVmljdG9yeU1vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL1ZpY3RvcnlNb2RhbCc7XG5pbXBvcnQgeyBHYW1lT3Zlck1vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL0dhbWVPdmVyTW9kYWwnO1xuaW1wb3J0IHsgUGF1c2VNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9QYXVzZU1vZGFsJztcbmltcG9ydCB7IFNldHRpbmdzTW9kYWwgfSBmcm9tICcuL2NvbXBvbmVudHMvU2V0dGluZ3NNb2RhbCc7XG5pbXBvcnQgeyBIb3dUb1BsYXlNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9Ib3dUb1BsYXlNb2RhbCc7XG5pbXBvcnQgeyBQcm9qZWN0RG93bmxvYWRNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9Qcm9qZWN0RG93bmxvYWRNb2RhbCc7XG5pbXBvcnQgeyBzb3VuZE1hbmFnZXIgfSBmcm9tICcuL2F1ZGlvL1NvdW5kRWZmZWN0cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgY2FudmFzTW91bnRSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBlbmdpbmVSZWYgPSB1c2VSZWY8R2FtZUVuZ2luZSB8IG51bGw+KG51bGwpO1xuXG4gIC8vIEdhbWUgVUkgU3RhdGVcbiAgY29uc3QgW3NjcmVlbiwgc2V0U2NyZWVuXSA9IHVzZVN0YXRlPCdtZW51JyB8ICdwbGF5aW5nJyB8ICdwYXVzZWQnIHwgJ3ZpY3RvcnknIHwgJ2dhbWVfb3Zlcic+KCdtZW51Jyk7XG4gIGNvbnN0IFthY3RpdmVNb2RhbCwgc2V0QWN0aXZlTW9kYWxdID0gdXNlU3RhdGU8J2FybW9yeScgfCAnbGV2ZWxfc2VsZWN0JyB8ICdzZXR0aW5ncycgfCAnaG93X3RvX3BsYXknIHwgJ2Rvd25sb2FkX3ppcCcgfCBudWxsPihudWxsKTtcblxuICAvLyBQZXJzaXN0ZW50IFBsYXllciBQcm9ncmVzc2lvblxuICBjb25zdCBbY29pbnMsIHNldENvaW5zXSA9IHVzZVN0YXRlPG51bWJlcj4oKCkgPT4ge1xuICAgIGNvbnN0IHNhdmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3N3X2NvaW5zJyk7XG4gICAgcmV0dXJuIHNhdmVkID8gcGFyc2VJbnQoc2F2ZWQsIDEwKSA6IDEwMDtcbiAgfSk7XG5cbiAgY29uc3QgW3dlYXBvbnMsIHNldFdlYXBvbnNdID0gdXNlU3RhdGU8V2VhcG9uW10+KCgpID0+IHtcbiAgICBjb25zdCBzYXZlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdzd193ZWFwb25zJyk7XG4gICAgaWYgKHNhdmVkKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKHNhdmVkKTtcbiAgICAgICAgcmV0dXJuIElOSVRJQUxfV0VBUE9OUy5tYXAodyA9PiB7XG4gICAgICAgICAgY29uc3QgbWF0Y2ggPSBwYXJzZWQuZmluZCgocDogV2VhcG9uKSA9PiBwLmlkID09PSB3LmlkKTtcbiAgICAgICAgICByZXR1cm4gbWF0Y2ggPyB7IC4uLncsIHVubG9ja2VkOiBtYXRjaC51bmxvY2tlZCB9IDogdztcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIHt9XG4gICAgfVxuICAgIHJldHVybiBJTklUSUFMX1dFQVBPTlM7XG4gIH0pO1xuXG4gIGNvbnN0IFtza2lucywgc2V0U2tpbnNdID0gdXNlU3RhdGU8UGxheWVyU2tpbltdPigoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnc3dfc2tpbnMnKTtcbiAgICBpZiAoc2F2ZWQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2Uoc2F2ZWQpO1xuICAgICAgICByZXR1cm4gSU5JVElBTF9TS0lOUy5tYXAocyA9PiB7XG4gICAgICAgICAgY29uc3QgbWF0Y2ggPSBwYXJzZWQuZmluZCgocDogUGxheWVyU2tpbikgPT4gcC5pZCA9PT0gcy5pZCk7XG4gICAgICAgICAgcmV0dXJuIG1hdGNoID8geyAuLi5zLCB1bmxvY2tlZDogbWF0Y2gudW5sb2NrZWQgfSA6IHM7XG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCB7fVxuICAgIH1cbiAgICByZXR1cm4gSU5JVElBTF9TS0lOUztcbiAgfSk7XG5cbiAgY29uc3QgW2xldmVscywgc2V0TGV2ZWxzXSA9IHVzZVN0YXRlPExldmVsQ29uZmlnW10+KCgpID0+IHtcbiAgICBjb25zdCBzYXZlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdzd19sZXZlbHMnKTtcbiAgICBpZiAoc2F2ZWQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2Uoc2F2ZWQpO1xuICAgICAgICByZXR1cm4gSU5JVElBTF9MRVZFTFMubWFwKGwgPT4ge1xuICAgICAgICAgIGNvbnN0IG1hdGNoID0gcGFyc2VkLmZpbmQoKHA6IExldmVsQ29uZmlnKSA9PiBwLmlkID09PSBsLmlkKTtcbiAgICAgICAgICByZXR1cm4gbWF0Y2ggPyB7IC4uLmwsIHVubG9ja2VkOiBtYXRjaC51bmxvY2tlZCwgc3RhcnM6IG1hdGNoLnN0YXJzIH0gOiBsO1xuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2gge31cbiAgICB9XG4gICAgcmV0dXJuIElOSVRJQUxfTEVWRUxTO1xuICB9KTtcblxuICBjb25zdCBbc2VsZWN0ZWRXZWFwb25JZCwgc2V0U2VsZWN0ZWRXZWFwb25JZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCgpID0+IHtcbiAgICByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3N3X3dlYXBvbl9pZCcpIHx8ICdrYXRhbmFfc2hhZG93JztcbiAgfSk7XG5cbiAgY29uc3QgW3NlbGVjdGVkU2tpbklkLCBzZXRTZWxlY3RlZFNraW5JZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCgpID0+IHtcbiAgICByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3N3X3NraW5faWQnKSB8fCAnc2tpbl9zaGFkb3cnO1xuICB9KTtcblxuICBjb25zdCBbY3VycmVudExldmVsSWQsIHNldEN1cnJlbnRMZXZlbElkXSA9IHVzZVN0YXRlPG51bWJlcj4oMSk7XG5cbiAgLy8gU291bmQgc2V0dGluZ3NcbiAgY29uc3QgW3NvdW5kU2V0dGluZ3MsIHNldFNvdW5kU2V0dGluZ3NdID0gdXNlU3RhdGU8U291bmRTZXR0aW5ncz4oe1xuICAgIG1hc3RlclZvbHVtZTogMC44LFxuICAgIHNmeFZvbHVtZTogMC45LFxuICAgIG11c2ljVm9sdW1lOiAwLjUsXG4gICAgc291bmRFbmFibGVkOiB0cnVlLFxuICAgIG11c2ljRW5hYmxlZDogdHJ1ZSxcbiAgfSk7XG5cbiAgLy8gRHluYW1pYyBJbi1HYW1lIFN0YXRzICYgSFVEIHN0YXRlXG4gIGNvbnN0IFtzdGF0cywgc2V0U3RhdHNdID0gdXNlU3RhdGU8UGxheWVyU3RhdHM+KHtcbiAgICBtYXhIZWFsdGg6IDUwMCxcbiAgICBjdXJyZW50SGVhbHRoOiA1MDAsXG4gICAgbWF4RW5lcmd5OiAxMDAsXG4gICAgY3VycmVudEVuZXJneTogNTAsXG4gICAgY29pbnM6IDEwMCxcbiAgICBzZWxlY3RlZFdlYXBvbklkOiAna2F0YW5hX3NoYWRvdycsXG4gICAgc2VsZWN0ZWRTa2luSWQ6ICdza2luX3NoYWRvdycsXG4gICAgY29tYm9Db3VudDogMCxcbiAgICBjb21ib1RpbWVyOiAwLFxuICAgIGtpbGxzOiAwLFxuICAgIHNwZWNpYWxDb29sZG93bjogMCxcbiAgICBzcGVjaWFsTWF4Q29vbGRvd246IDYwLFxuICB9KTtcblxuICBjb25zdCBbYm9zc0hlYWx0aCwgc2V0Qm9zc0hlYWx0aF0gPSB1c2VTdGF0ZTx7IGN1cnJlbnQ6IG51bWJlcjsgbWF4OiBudW1iZXI7IG5hbWU6IHN0cmluZyB9IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtmbG9hdGluZ0RhbWFnZXMsIHNldEZsb2F0aW5nRGFtYWdlc10gPSB1c2VTdGF0ZTxGbG9hdGluZ0RhbWFnZVtdPihbXSk7XG4gIGNvbnN0IFt2aWN0b3J5UmV3YXJkcywgc2V0VmljdG9yeVJld2FyZHNdID0gdXNlU3RhdGU8eyBjb2luczogbnVtYmVyOyBzdGFyczogbnVtYmVyIH0+KHsgY29pbnM6IDAsIHN0YXJzOiAwIH0pO1xuXG4gIC8vIFNhdmUgY2hhbmdlcyB0byBsb2NhbFN0b3JhZ2VcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnc3dfY29pbnMnLCBjb2lucy50b1N0cmluZygpKTtcbiAgfSwgW2NvaW5zXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnc3dfd2VhcG9ucycsIEpTT04uc3RyaW5naWZ5KHdlYXBvbnMpKTtcbiAgfSwgW3dlYXBvbnNdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdzd19za2lucycsIEpTT04uc3RyaW5naWZ5KHNraW5zKSk7XG4gIH0sIFtza2luc10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3N3X2xldmVscycsIEpTT04uc3RyaW5naWZ5KGxldmVscykpO1xuICB9LCBbbGV2ZWxzXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnc3dfd2VhcG9uX2lkJywgc2VsZWN0ZWRXZWFwb25JZCk7XG4gIH0sIFtzZWxlY3RlZFdlYXBvbklkXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnc3dfc2tpbl9pZCcsIHNlbGVjdGVkU2tpbklkKTtcbiAgfSwgW3NlbGVjdGVkU2tpbklkXSk7XG5cbiAgY29uc3QgYWN0aXZlTGV2ZWwgPSBsZXZlbHMuZmluZChsID0+IGwuaWQgPT09IGN1cnJlbnRMZXZlbElkKSB8fCBsZXZlbHNbMF07XG4gIGNvbnN0IGFjdGl2ZVdlYXBvbiA9IHdlYXBvbnMuZmluZCh3ID0+IHcuaWQgPT09IHNlbGVjdGVkV2VhcG9uSWQpIHx8IHdlYXBvbnNbMF07XG4gIGNvbnN0IGFjdGl2ZVNraW4gPSBza2lucy5maW5kKHMgPT4gcy5pZCA9PT0gc2VsZWN0ZWRTa2luSWQpIHx8IHNraW5zWzBdO1xuXG4gIC8vIEluaXRpYWxpemUgb3IgUmVidWlsZCAzRCBFbmdpbmUgZm9yIExldmVsXG4gIGNvbnN0IGluaXRFbmdpbmVGb3JMZXZlbCA9IHVzZUNhbGxiYWNrKChsZXZlbDogTGV2ZWxDb25maWcsIHdlYXBvbjogV2VhcG9uLCBza2luOiBQbGF5ZXJTa2luKSA9PiB7XG4gICAgaWYgKCFjYW52YXNNb3VudFJlZi5jdXJyZW50KSByZXR1cm47XG5cbiAgICBpZiAoZW5naW5lUmVmLmN1cnJlbnQpIHtcbiAgICAgIGVuZ2luZVJlZi5jdXJyZW50LmRpc3Bvc2UoKTtcbiAgICAgIGVuZ2luZVJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG5cbiAgICBzZXRCb3NzSGVhbHRoKG51bGwpO1xuICAgIHNldEZsb2F0aW5nRGFtYWdlcyhbXSk7XG5cbiAgICBjb25zdCBlbmdpbmUgPSBuZXcgR2FtZUVuZ2luZShcbiAgICAgIGNhbnZhc01vdW50UmVmLmN1cnJlbnQsXG4gICAgICBsZXZlbCxcbiAgICAgIHdlYXBvbixcbiAgICAgIHNraW4sXG4gICAgICBjb2luc1xuICAgICk7XG5cbiAgICBlbmdpbmUub25TdGF0c0NoYW5nZSA9IChuZXdTdGF0cykgPT4ge1xuICAgICAgc2V0U3RhdHMobmV3U3RhdHMpO1xuICAgICAgc2V0Q29pbnMobmV3U3RhdHMuY29pbnMpO1xuICAgIH07XG5cbiAgICBlbmdpbmUub25GbG9hdGluZ0RhbWFnZSA9IChkbWcpID0+IHtcbiAgICAgIHNldEZsb2F0aW5nRGFtYWdlcyhwcmV2ID0+IFsuLi5wcmV2LnNsaWNlKC0xMiksIGRtZ10pO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldEZsb2F0aW5nRGFtYWdlcyhwcmV2ID0+IHByZXYuZmlsdGVyKGQgPT4gZC5pZCAhPT0gZG1nLmlkKSk7XG4gICAgICB9LCA3MDApO1xuICAgIH07XG5cbiAgICBlbmdpbmUub25Cb3NzSGVhbHRoVXBkYXRlID0gKGN1cnJlbnQsIG1heCwgbmFtZSkgPT4ge1xuICAgICAgc2V0Qm9zc0hlYWx0aCh7IGN1cnJlbnQsIG1heCwgbmFtZSB9KTtcbiAgICB9O1xuXG4gICAgZW5naW5lLm9uR2FtZU92ZXIgPSAoKSA9PiB7XG4gICAgICB3aW5kb3cuQW5kcm9pZEJyaWRnZT8ub25HYW1lT3Zlcj8uKCk7XG4gICAgICBzZXRTY3JlZW4oJ2dhbWVfb3ZlcicpO1xuICAgIH07XG5cbiAgICBlbmdpbmUub25WaWN0b3J5ID0gKHJld2FyZENvaW5zLCBzdGFyc0Vhcm5lZCkgPT4ge1xuICAgICAgd2luZG93LkFuZHJvaWRCcmlkZ2U/Lm9uVmljdG9yeT8uKCk7XG4gICAgICBzZXRDb2lucyhjID0+IGMgKyByZXdhcmRDb2lucyk7XG4gICAgICBzZXRWaWN0b3J5UmV3YXJkcyh7IGNvaW5zOiByZXdhcmRDb2lucywgc3RhcnM6IHN0YXJzRWFybmVkIH0pO1xuXG4gICAgICAvLyBVbmxvY2sgbmV4dCBsZXZlbCBhbmQgc2F2ZSBzdGFyc1xuICAgICAgc2V0TGV2ZWxzKHByZXYgPT4ge1xuICAgICAgICByZXR1cm4gcHJldi5tYXAobHZsID0+IHtcbiAgICAgICAgICBpZiAobHZsLmlkID09PSBsZXZlbC5pZCkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgLi4ubHZsLFxuICAgICAgICAgICAgICBzdGFyczogTWF0aC5tYXgobHZsLnN0YXJzLCBzdGFyc0Vhcm5lZCksXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAobHZsLmlkID09PSBsZXZlbC5pZCArIDEpIHtcbiAgICAgICAgICAgIHJldHVybiB7IC4uLmx2bCwgdW5sb2NrZWQ6IHRydWUgfTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGx2bDtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcblxuICAgICAgc2V0U2NyZWVuKCd2aWN0b3J5Jyk7XG4gICAgfTtcblxuICAgIGVuZ2luZVJlZi5jdXJyZW50ID0gZW5naW5lO1xuICB9LCBbY29pbnNdKTtcblxuICAvLyBIYW5kbGUgUmV3YXJkZWQgQWQgd2F0Y2hpbmcgYW5kIHJld2FyZHNcbiAgY29uc3QgaGFuZGxlV2F0Y2hSZXdhcmRlZEFkID0gKHR5cGU6IHN0cmluZyA9ICdnZW5lcmFsJykgPT4ge1xuICAgIHNvdW5kTWFuYWdlci5wbGF5Q2xpY2soKTtcbiAgICBpZiAod2luZG93LkFuZHJvaWRCcmlkZ2U/LnNob3dSZXdhcmRlZEFkKSB7XG4gICAgICB3aW5kb3cuQW5kcm9pZEJyaWRnZS5zaG93UmV3YXJkZWRBZCh0eXBlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gQnJvd3NlciBwcmV2aWV3IHNpbXVsYXRlZCBhZFxuICAgICAgY29uc3QgcmV3YXJkVG9hc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIHJld2FyZFRvYXN0LmNsYXNzTmFtZSA9ICdmaXhlZCB0b3AtMTIgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiB6LVsxMDBdIGJnLWFtYmVyLTUwMCB0ZXh0LWJsYWNrIGZvbnQtYm9sZCBweC02IHB5LTMgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBhbmltYXRlLWJvdW5jZSB0ZXh0LXNtJztcbiAgICAgIHJld2FyZFRvYXN0LmlubmVyVGV4dCA9ICdXYXRjaGluZyBTcG9uc29yZWQgVmlkZW8gQWQuLi4gKDJzKSc7XG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHJld2FyZFRvYXN0KTtcblxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGlmIChyZXdhcmRUb2FzdC5wYXJlbnROb2RlKSByZXdhcmRUb2FzdC5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHJld2FyZFRvYXN0KTtcbiAgICAgICAgaWYgKHdpbmRvdy5vblJld2FyZGVkQWRSZXdhcmQpIHtcbiAgICAgICAgICB3aW5kb3cub25SZXdhcmRlZEFkUmV3YXJkKDIwMCwgdHlwZSk7XG4gICAgICAgIH1cbiAgICAgIH0sIDIwMDApO1xuICAgIH1cbiAgfTtcblxuICAvLyBBbmRyb2lkIEJyaWRnZSBMaXN0ZW5lcnNcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB3aW5kb3cub25SZXdhcmRlZEFkUmV3YXJkID0gKGFtb3VudDogbnVtYmVyLCB0eXBlOiBzdHJpbmcpID0+IHtcbiAgICAgIGNvbnN0IGdyYW50ID0gYW1vdW50IHx8IDIwMDtcbiAgICAgIHNldENvaW5zKGMgPT4gYyArIGdyYW50KTtcbiAgICAgIHNvdW5kTWFuYWdlci5wbGF5Q29pbigpO1xuXG4gICAgICBpZiAodHlwZSA9PT0gJ3Jldml2ZScgJiYgZW5naW5lUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgLy8gUmV2aXZlIHdhcnJpb3Igd2l0aCBmdWxsIGhlYWx0aFxuICAgICAgICBlbmdpbmVSZWYuY3VycmVudC5zdGF0cy5jdXJyZW50SGVhbHRoID0gZW5naW5lUmVmLmN1cnJlbnQuc3RhdHMubWF4SGVhbHRoO1xuICAgICAgICBlbmdpbmVSZWYuY3VycmVudC5wbGF5ZXJSaWcuY3VycmVudEFuaW0gPSAnaWRsZSc7XG4gICAgICAgIGVuZ2luZVJlZi5jdXJyZW50Lm5vdGlmeVN0YXRzKCk7XG4gICAgICAgIHNldFNjcmVlbigncGxheWluZycpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICB3aW5kb3cub25BbmRyb2lkQmFjayA9ICgpID0+IHtcbiAgICAgIGlmIChzY3JlZW4gPT09ICdwbGF5aW5nJykge1xuICAgICAgICBoYW5kbGVQYXVzZSgpO1xuICAgICAgfSBlbHNlIGlmIChzY3JlZW4gPT09ICdwYXVzZWQnKSB7XG4gICAgICAgIGhhbmRsZVJlc3VtZSgpO1xuICAgICAgfSBlbHNlIGlmIChzY3JlZW4gIT09ICdtZW51Jykge1xuICAgICAgICBoYW5kbGVIb21lKCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBkZWxldGUgd2luZG93Lm9uUmV3YXJkZWRBZFJld2FyZDtcbiAgICAgIGRlbGV0ZSB3aW5kb3cub25BbmRyb2lkQmFjaztcbiAgICB9O1xuICB9LCBbc2NyZWVuXSk7XG5cbiAgLy8gSW5pdGlhbCBlbmdpbmUgbG9hZCBmb3IgYmFja2dyb3VuZCBzY2VuZXJ5IG9uIG1haW4gbWVudVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGluaXRFbmdpbmVGb3JMZXZlbChhY3RpdmVMZXZlbCwgYWN0aXZlV2VhcG9uLCBhY3RpdmVTa2luKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpZiAoZW5naW5lUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgZW5naW5lUmVmLmN1cnJlbnQuZGlzcG9zZSgpO1xuICAgICAgICBlbmdpbmVSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIC8vIEtleWJvYXJkIGRlc2t0b3AgY29udHJvbHMgbGlzdGVuZXJcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBrZXlzRG93biA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuXG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoZS5yZXBlYXQpIHJldHVybjtcbiAgICAgIGtleXNEb3duLmFkZChlLmNvZGUpO1xuXG4gICAgICBpZiAoZS5jb2RlID09PSAnRXNjYXBlJykge1xuICAgICAgICBpZiAoc2NyZWVuID09PSAncGxheWluZycpIHtcbiAgICAgICAgICBoYW5kbGVQYXVzZSgpO1xuICAgICAgICB9IGVsc2UgaWYgKHNjcmVlbiA9PT0gJ3BhdXNlZCcpIHtcbiAgICAgICAgICBoYW5kbGVSZXN1bWUoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGlmIChzY3JlZW4gIT09ICdwbGF5aW5nJyB8fCAhZW5naW5lUmVmLmN1cnJlbnQpIHJldHVybjtcblxuICAgICAgaWYgKGUuY29kZSA9PT0gJ1NwYWNlJykge1xuICAgICAgICBlbmdpbmVSZWYuY3VycmVudC50cmlnZ2VySnVtcCgpO1xuICAgICAgfSBlbHNlIGlmIChlLmNvZGUgPT09ICdLZXlKJyB8fCBlLmNvZGUgPT09ICdFbnRlcicpIHtcbiAgICAgICAgZW5naW5lUmVmLmN1cnJlbnQudHJpZ2dlckF0dGFjaygpO1xuICAgICAgfSBlbHNlIGlmIChlLmNvZGUgPT09ICdLZXlLJykge1xuICAgICAgICBlbmdpbmVSZWYuY3VycmVudC50cmlnZ2VySGVhdnlLaWNrKCk7XG4gICAgICB9IGVsc2UgaWYgKGUuY29kZSA9PT0gJ1NoaWZ0TGVmdCcgfHwgZS5jb2RlID09PSAnU2hpZnRSaWdodCcgfHwgZS5jb2RlID09PSAnS2V5TCcpIHtcbiAgICAgICAgZW5naW5lUmVmLmN1cnJlbnQudHJpZ2dlckRvZGdlKCk7XG4gICAgICB9IGVsc2UgaWYgKGUuY29kZSA9PT0gJ0tleUUnKSB7XG4gICAgICAgIGVuZ2luZVJlZi5jdXJyZW50LnRyaWdnZXJTcGVjaWFsUG93ZXIoKTtcbiAgICAgIH1cblxuICAgICAgdXBkYXRlS2V5Ym9hcmRNb3ZlbWVudCgpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVLZXlVcCA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBrZXlzRG93bi5kZWxldGUoZS5jb2RlKTtcbiAgICAgIGlmIChzY3JlZW4gPT09ICdwbGF5aW5nJyAmJiBlbmdpbmVSZWYuY3VycmVudCkge1xuICAgICAgICB1cGRhdGVLZXlib2FyZE1vdmVtZW50KCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHVwZGF0ZUtleWJvYXJkTW92ZW1lbnQgPSAoKSA9PiB7XG4gICAgICBpZiAoIWVuZ2luZVJlZi5jdXJyZW50KSByZXR1cm47XG5cbiAgICAgIGxldCBteCA9IDA7XG4gICAgICBsZXQgbXogPSAwO1xuICAgICAgbGV0IHJvdFggPSAwO1xuXG4gICAgICBpZiAoa2V5c0Rvd24uaGFzKCdLZXlXJykgfHwga2V5c0Rvd24uaGFzKCdBcnJvd1VwJykpIG16ICs9IDE7XG4gICAgICBpZiAoa2V5c0Rvd24uaGFzKCdLZXlTJykgfHwga2V5c0Rvd24uaGFzKCdBcnJvd0Rvd24nKSkgbXogLT0gMTtcbiAgICAgIGlmIChrZXlzRG93bi5oYXMoJ0tleUEnKSB8fCBrZXlzRG93bi5oYXMoJ0Fycm93TGVmdCcpKSBteCAtPSAxO1xuICAgICAgaWYgKGtleXNEb3duLmhhcygnS2V5RCcpIHx8IGtleXNEb3duLmhhcygnQXJyb3dSaWdodCcpKSBteCArPSAxO1xuXG4gICAgICBpZiAoa2V5c0Rvd24uaGFzKCdLZXlRJykpIHJvdFggLT0gMTtcbiAgICAgIGlmIChrZXlzRG93bi5oYXMoJ0tleVInKSkgcm90WCArPSAxO1xuXG4gICAgICAvLyBOb3JtYWxpemUgZGlhZ29uYWwgbW92ZW1lbnRcbiAgICAgIGNvbnN0IGxlbiA9IE1hdGguc3FydChteCAqIG14ICsgbXogKiBteik7XG4gICAgICBpZiAobGVuID4gMCkge1xuICAgICAgICBteCAvPSBsZW47XG4gICAgICAgIG16IC89IGxlbjtcbiAgICAgIH1cblxuICAgICAgZW5naW5lUmVmLmN1cnJlbnQudXBkYXRlSW5wdXQoe1xuICAgICAgICBtb3ZlWDogbXgsXG4gICAgICAgIG1vdmVaOiBteixcbiAgICAgICAgY2FtZXJhUm90YXRlWDogcm90WCxcbiAgICAgIH0pO1xuICAgIH07XG5cbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXl1cCcsIGhhbmRsZUtleVVwKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleXVwJywgaGFuZGxlS2V5VXApO1xuICAgIH07XG4gIH0sIFtzY3JlZW5dKTtcblxuICAvLyBIYW5kbGUgR2FtZSBTY3JlZW4gVHJhbnNpdGlvbnNcbiAgY29uc3QgaGFuZGxlU3RhcnRHYW1lID0gKCkgPT4ge1xuICAgIHdpbmRvdy5BbmRyb2lkQnJpZGdlPy5vbkdhbWVTdGFydGVkPy4oKTtcbiAgICBzZXRTY3JlZW4oJ3BsYXlpbmcnKTtcbiAgICBpbml0RW5naW5lRm9yTGV2ZWwoYWN0aXZlTGV2ZWwsIGFjdGl2ZVdlYXBvbiwgYWN0aXZlU2tpbik7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUGF1c2UgPSAoKSA9PiB7XG4gICAgaWYgKGVuZ2luZVJlZi5jdXJyZW50KSB7XG4gICAgICBlbmdpbmVSZWYuY3VycmVudC5wYXVzZSgpO1xuICAgIH1cbiAgICBzZXRTY3JlZW4oJ3BhdXNlZCcpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVJlc3VtZSA9ICgpID0+IHtcbiAgICBpZiAoZW5naW5lUmVmLmN1cnJlbnQpIHtcbiAgICAgIGVuZ2luZVJlZi5jdXJyZW50LnJlc3VtZSgpO1xuICAgIH1cbiAgICBzZXRTY3JlZW4oJ3BsYXlpbmcnKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVSZXN0YXJ0ID0gKCkgPT4ge1xuICAgIHdpbmRvdy5BbmRyb2lkQnJpZGdlPy5vbkdhbWVTdGFydGVkPy4oKTtcbiAgICBzZXRTY3JlZW4oJ3BsYXlpbmcnKTtcbiAgICBpbml0RW5naW5lRm9yTGV2ZWwoYWN0aXZlTGV2ZWwsIGFjdGl2ZVdlYXBvbiwgYWN0aXZlU2tpbik7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlSG9tZSA9ICgpID0+IHtcbiAgICB3aW5kb3cuQW5kcm9pZEJyaWRnZT8ub25HYW1lRW5kZWQ/LigpO1xuICAgIHdpbmRvdy5BbmRyb2lkQnJpZGdlPy5zaG93QmFubmVyQWQ/LigpO1xuICAgIHNldFNjcmVlbignbWVudScpO1xuICAgIGluaXRFbmdpbmVGb3JMZXZlbChhY3RpdmVMZXZlbCwgYWN0aXZlV2VhcG9uLCBhY3RpdmVTa2luKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVOZXh0TGV2ZWwgPSAoKSA9PiB7XG4gICAgY29uc3QgbmV4dElkID0gY3VycmVudExldmVsSWQgKyAxO1xuICAgIGNvbnN0IG5leHRMdmwgPSBsZXZlbHMuZmluZChsID0+IGwuaWQgPT09IG5leHRJZCk7XG4gICAgaWYgKG5leHRMdmwgJiYgbmV4dEx2bC51bmxvY2tlZCkge1xuICAgICAgc2V0Q3VycmVudExldmVsSWQobmV4dElkKTtcbiAgICAgIHNldFNjcmVlbigncGxheWluZycpO1xuICAgICAgaW5pdEVuZ2luZUZvckxldmVsKG5leHRMdmwsIGFjdGl2ZVdlYXBvbiwgYWN0aXZlU2tpbik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGhhbmRsZUhvbWUoKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlVW5sb2NrV2VhcG9uID0gKHdlYXBvbklkOiBzdHJpbmcsIHByaWNlOiBudW1iZXIpID0+IHtcbiAgICBpZiAoY29pbnMgPj0gcHJpY2UpIHtcbiAgICAgIHNldENvaW5zKGMgPT4gYyAtIHByaWNlKTtcbiAgICAgIHNldFdlYXBvbnMocHJldiA9PiBwcmV2Lm1hcCh3ID0+IHcuaWQgPT09IHdlYXBvbklkID8geyAuLi53LCB1bmxvY2tlZDogdHJ1ZSB9IDogdykpO1xuICAgICAgc2V0U2VsZWN0ZWRXZWFwb25JZCh3ZWFwb25JZCk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVVubG9ja1NraW4gPSAoc2tpbklkOiBzdHJpbmcsIHByaWNlOiBudW1iZXIpID0+IHtcbiAgICBpZiAoY29pbnMgPj0gcHJpY2UpIHtcbiAgICAgIHNldENvaW5zKGMgPT4gYyAtIHByaWNlKTtcbiAgICAgIHNldFNraW5zKHByZXYgPT4gcHJldi5tYXAocyA9PiBzLmlkID09PSBza2luSWQgPyB7IC4uLnMsIHVubG9ja2VkOiB0cnVlIH0gOiBzKSk7XG4gICAgICBzZXRTZWxlY3RlZFNraW5JZChza2luSWQpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1zY3JlZW4gaC1zY3JlZW4gb3ZlcmZsb3ctaGlkZGVuIGJnLWJsYWNrIHNlbGVjdC1ub25lXCI+XG4gICAgICB7LyogRGVkaWNhdGVkIDNEIENhbnZhcyBNb3VudCAoUmVuZGVyZWQgb25jZSwgbmV2ZXIgcmVzZXRzIG9uIFVJIHN0YXRlIHVwZGF0ZSkgKi99XG4gICAgICA8ZGl2XG4gICAgICAgIHJlZj17Y2FudmFzTW91bnRSZWZ9XG4gICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgdy1mdWxsIGgtZnVsbCBjdXJzb3ItZ3JhYiBhY3RpdmU6Y3Vyc29yLWdyYWJiaW5nXCJcbiAgICAgIC8+XG5cbiAgICAgIHsvKiBJbi1HYW1lIEhVRCBvdmVybGF5ICovfVxuICAgICAge3NjcmVlbiA9PT0gJ3BsYXlpbmcnICYmIChcbiAgICAgICAgPEhVRFxuICAgICAgICAgIHN0YXRzPXtzdGF0c31cbiAgICAgICAgICBsZXZlbD17YWN0aXZlTGV2ZWx9XG4gICAgICAgICAgZmxvYXRpbmdEYW1hZ2VzPXtmbG9hdGluZ0RhbWFnZXN9XG4gICAgICAgICAgYm9zc0hlYWx0aD17Ym9zc0hlYWx0aH1cbiAgICAgICAgICBvbklucHV0VXBkYXRlPXtpbnB1dCA9PiB7XG4gICAgICAgICAgICBpZiAoZW5naW5lUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgICAgZW5naW5lUmVmLmN1cnJlbnQudXBkYXRlSW5wdXQoaW5wdXQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH19XG4gICAgICAgICAgb25QYXVzZT17aGFuZGxlUGF1c2V9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7LyogTWFpbiBNZW51IFNjcmVlbiAqL31cbiAgICAgIHtzY3JlZW4gPT09ICdtZW51JyAmJiAhYWN0aXZlTW9kYWwgJiYgKFxuICAgICAgICA8TWFpbk1lbnVcbiAgICAgICAgICBvblN0YXJ0R2FtZT17aGFuZGxlU3RhcnRHYW1lfVxuICAgICAgICAgIG9uT3BlbkxldmVsU2VsZWN0PXsoKSA9PiBzZXRBY3RpdmVNb2RhbCgnbGV2ZWxfc2VsZWN0Jyl9XG4gICAgICAgICAgb25PcGVuQXJtb3J5PXsoKSA9PiBzZXRBY3RpdmVNb2RhbCgnYXJtb3J5Jyl9XG4gICAgICAgICAgb25PcGVuU2V0dGluZ3M9eygpID0+IHNldEFjdGl2ZU1vZGFsKCdzZXR0aW5ncycpfVxuICAgICAgICAgIG9uT3Blbkhvd1RvUGxheT17KCkgPT4gc2V0QWN0aXZlTW9kYWwoJ2hvd190b19wbGF5Jyl9XG4gICAgICAgICAgb25Eb3dubG9hZFByb2plY3Q9eygpID0+IHNldEFjdGl2ZU1vZGFsKCdkb3dubG9hZF96aXAnKX1cbiAgICAgICAgICBvbldhdGNoQWQ9eygpID0+IGhhbmRsZVdhdGNoUmV3YXJkZWRBZCgnbWVudV9ib251cycpfVxuICAgICAgICAgIGNvaW5zPXtjb2luc31cbiAgICAgICAgICBjdXJyZW50TGV2ZWxOYW1lPXthY3RpdmVMZXZlbC5uYW1lfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qIFBhdXNlIE1vZGFsICovfVxuICAgICAge3NjcmVlbiA9PT0gJ3BhdXNlZCcgJiYgKFxuICAgICAgICA8UGF1c2VNb2RhbFxuICAgICAgICAgIGxldmVsTmFtZT17YWN0aXZlTGV2ZWwubmFtZX1cbiAgICAgICAgICBvblJlc3VtZT17aGFuZGxlUmVzdW1lfVxuICAgICAgICAgIG9uUmVzdGFydD17aGFuZGxlUmVzdGFydH1cbiAgICAgICAgICBvbk9wZW5TZXR0aW5ncz17KCkgPT4gc2V0QWN0aXZlTW9kYWwoJ3NldHRpbmdzJyl9XG4gICAgICAgICAgb25Ib21lPXtoYW5kbGVIb21lfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qIFZpY3RvcnkgTW9kYWwgKi99XG4gICAgICB7c2NyZWVuID09PSAndmljdG9yeScgJiYgKFxuICAgICAgICA8VmljdG9yeU1vZGFsXG4gICAgICAgICAgbGV2ZWxOYW1lPXthY3RpdmVMZXZlbC5uYW1lfVxuICAgICAgICAgIGVhcm5lZENvaW5zPXt2aWN0b3J5UmV3YXJkcy5jb2luc31cbiAgICAgICAgICBzdGFycz17dmljdG9yeVJld2FyZHMuc3RhcnN9XG4gICAgICAgICAgaGFzTmV4dExldmVsPXtjdXJyZW50TGV2ZWxJZCA8IGxldmVscy5sZW5ndGggJiYgbGV2ZWxzW2N1cnJlbnRMZXZlbElkXT8udW5sb2NrZWR9XG4gICAgICAgICAgb25OZXh0TGV2ZWw9e2hhbmRsZU5leHRMZXZlbH1cbiAgICAgICAgICBvblJlc3RhcnQ9e2hhbmRsZVJlc3RhcnR9XG4gICAgICAgICAgb25Ib21lPXtoYW5kbGVIb21lfVxuICAgICAgICAgIG9uV2F0Y2hSZXdhcmRlZEFkPXsoKSA9PiBoYW5kbGVXYXRjaFJld2FyZGVkQWQoJ3ZpY3RvcnlfZG91YmxlJyl9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7LyogR2FtZSBPdmVyIE1vZGFsICovfVxuICAgICAge3NjcmVlbiA9PT0gJ2dhbWVfb3ZlcicgJiYgKFxuICAgICAgICA8R2FtZU92ZXJNb2RhbFxuICAgICAgICAgIGxldmVsTmFtZT17YWN0aXZlTGV2ZWwubmFtZX1cbiAgICAgICAgICBvblJlc3RhcnQ9e2hhbmRsZVJlc3RhcnR9XG4gICAgICAgICAgb25Ib21lPXtoYW5kbGVIb21lfVxuICAgICAgICAgIG9uT3BlbkFybW9yeT17KCkgPT4ge1xuICAgICAgICAgICAgc2V0U2NyZWVuKCdtZW51Jyk7XG4gICAgICAgICAgICBzZXRBY3RpdmVNb2RhbCgnYXJtb3J5Jyk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvbldhdGNoUmV3YXJkZWRBZD17KCkgPT4gaGFuZGxlV2F0Y2hSZXdhcmRlZEFkKCdyZXZpdmUnKX1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBBcm1vcnkgTW9kYWwgKi99XG4gICAgICB7YWN0aXZlTW9kYWwgPT09ICdhcm1vcnknICYmIChcbiAgICAgICAgPEFybW9yeU1vZGFsXG4gICAgICAgICAgd2VhcG9ucz17d2VhcG9uc31cbiAgICAgICAgICBza2lucz17c2tpbnN9XG4gICAgICAgICAgc2VsZWN0ZWRXZWFwb25JZD17c2VsZWN0ZWRXZWFwb25JZH1cbiAgICAgICAgICBzZWxlY3RlZFNraW5JZD17c2VsZWN0ZWRTa2luSWR9XG4gICAgICAgICAgY29pbnM9e2NvaW5zfVxuICAgICAgICAgIG9uU2VsZWN0V2VhcG9uPXsoaWQpID0+IHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkV2VhcG9uSWQoaWQpO1xuICAgICAgICAgICAgY29uc3QgdyA9IHdlYXBvbnMuZmluZChpdGVtID0+IGl0ZW0uaWQgPT09IGlkKTtcbiAgICAgICAgICAgIGlmICh3KSBpbml0RW5naW5lRm9yTGV2ZWwoYWN0aXZlTGV2ZWwsIHcsIGFjdGl2ZVNraW4pO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25TZWxlY3RTa2luPXsoaWQpID0+IHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkU2tpbklkKGlkKTtcbiAgICAgICAgICAgIGNvbnN0IHMgPSBza2lucy5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PT0gaWQpO1xuICAgICAgICAgICAgaWYgKHMpIGluaXRFbmdpbmVGb3JMZXZlbChhY3RpdmVMZXZlbCwgYWN0aXZlV2VhcG9uLCBzKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIG9uVW5sb2NrV2VhcG9uPXtoYW5kbGVVbmxvY2tXZWFwb259XG4gICAgICAgICAgb25VbmxvY2tTa2luPXtoYW5kbGVVbmxvY2tTa2lufVxuICAgICAgICAgIG9uV2F0Y2hSZXdhcmRlZEFkPXsoKSA9PiBoYW5kbGVXYXRjaFJld2FyZGVkQWQoJ2FybW9yeScpfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFjdGl2ZU1vZGFsKG51bGwpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qIExldmVsIFNlbGVjdCBNb2RhbCAqL31cbiAgICAgIHthY3RpdmVNb2RhbCA9PT0gJ2xldmVsX3NlbGVjdCcgJiYgKFxuICAgICAgICA8TGV2ZWxTZWxlY3RNb2RhbFxuICAgICAgICAgIGxldmVscz17bGV2ZWxzfVxuICAgICAgICAgIGN1cnJlbnRMZXZlbElkPXtjdXJyZW50TGV2ZWxJZH1cbiAgICAgICAgICBvblNlbGVjdExldmVsPXsoaWQpID0+IHtcbiAgICAgICAgICAgIHNldEN1cnJlbnRMZXZlbElkKGlkKTtcbiAgICAgICAgICAgIGNvbnN0IGx2bCA9IGxldmVscy5maW5kKGwgPT4gbC5pZCA9PT0gaWQpO1xuICAgICAgICAgICAgaWYgKGx2bCkgaW5pdEVuZ2luZUZvckxldmVsKGx2bCwgYWN0aXZlV2VhcG9uLCBhY3RpdmVTa2luKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFjdGl2ZU1vZGFsKG51bGwpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qIFNldHRpbmdzIE1vZGFsICovfVxuICAgICAge2FjdGl2ZU1vZGFsID09PSAnc2V0dGluZ3MnICYmIChcbiAgICAgICAgPFNldHRpbmdzTW9kYWxcbiAgICAgICAgICBzb3VuZFNldHRpbmdzPXtzb3VuZFNldHRpbmdzfVxuICAgICAgICAgIG9uVXBkYXRlU291bmQ9e25ld1NldHRpbmdzID0+IHNldFNvdW5kU2V0dGluZ3MocHJldiA9PiAoeyAuLi5wcmV2LCAuLi5uZXdTZXR0aW5ncyB9KSl9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWN0aXZlTW9kYWwobnVsbCl9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7LyogSG93IFRvIFBsYXkgTW9kYWwgKi99XG4gICAgICB7YWN0aXZlTW9kYWwgPT09ICdob3dfdG9fcGxheScgJiYgKFxuICAgICAgICA8SG93VG9QbGF5TW9kYWwgb25DbG9zZT17KCkgPT4gc2V0QWN0aXZlTW9kYWwobnVsbCl9IC8+XG4gICAgICApfVxuXG4gICAgICB7LyogRG93bmxvYWQgUHJvamVjdCBaSVAgTW9kYWwgKi99XG4gICAgICB7YWN0aXZlTW9kYWwgPT09ICdkb3dubG9hZF96aXAnICYmIChcbiAgICAgICAgPFByb2plY3REb3dubG9hZE1vZGFsIG9uQ2xvc2U9eygpID0+IHNldEFjdGl2ZU1vZGFsKG51bGwpfSAvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==