package com.shadowwarrior.game

/**
 * AdMob Configuration & Ad Unit IDs for Shadow Warrior Android Game
 * Configured with the exact production AdMob credentials provided by the user.
 */
object AdConfig {

    /**
     * Set this to true during development to use Google's official test ad units
     * and avoid policy violations. Set to false for production release.
     */
    var USE_TEST_ADS = false

    // Real Production AdMob IDs (Provided by user)
    const val REAL_APP_ID = "ca-app-pub-3133971041724338~5461456996"
    const val REAL_BANNER_ID = "ca-app-pub-3133971041724338/8121465266"
    const val REAL_APP_OPEN_ID = "ca-app-pub-3133971041724338/3363962603"
    const val REAL_REWARDED_ID = "ca-app-pub-3133971041724338/2300107036"
    const val REAL_NATIVE_ID = "ca-app-pub-3133971041724338/2076745751"
    const val REAL_INTERSTITIAL_ID = "ca-app-pub-3133971041724338/3613188701"

    // Official Google AdMob Test Ad Units
    const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257390708"
    const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"
    const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"

    val BANNER_AD_UNIT_ID: String
        get() = if (USE_TEST_ADS) TEST_BANNER_ID else REAL_BANNER_ID

    val APP_OPEN_AD_UNIT_ID: String
        get() = if (USE_TEST_ADS) TEST_APP_OPEN_ID else REAL_APP_OPEN_ID

    val REWARDED_AD_UNIT_ID: String
        get() = if (USE_TEST_ADS) TEST_REWARDED_ID else REAL_REWARDED_ID

    val NATIVE_AD_UNIT_ID: String
        get() = if (USE_TEST_ADS) TEST_NATIVE_ID else REAL_NATIVE_ID

    val INTERSTITIAL_AD_UNIT_ID: String
        get() = if (USE_TEST_ADS) TEST_INTERSTITIAL_ID else REAL_INTERSTITIAL_ID

    // Interstitial frequency cap: 3 minutes (180,000 ms)
    const val INTERSTITIAL_COOLDOWN_MS = 180_000L

    // App Open Ad timeout validity: 4 hours
    const val APP_OPEN_EXPIRY_MS = 14_400_000L
}
