package com.shadowwarrior.game

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.*
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class AdManager private constructor() {

    companion object {
        private const val TAG = "ShadowWarriorAdManager"

        @Volatile
        private var instance: AdManager? = null

        fun getInstance(): AdManager =
            instance ?: synchronized(this) {
                instance ?: AdManager().also { instance = it }
            }
    }

    private var bannerAdView: AdView? = null
    private var isBannerLoaded = false

    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false
    private var lastInterstitialShowTime = 0L

    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    private var currentNativeAd: NativeAd? = null

    // 1. BANNER ADS
    fun loadBanner(activity: Activity, container: ViewGroup) {
        activity.runOnUiThread {
            try {
                if (bannerAdView != null) {
                    bannerAdView?.destroy()
                    container.removeAllViews()
                }

                val adView = AdView(activity).apply {
                    setAdSize(AdSize.BANNER)
                    adUnitId = AdConfig.BANNER_AD_UNIT_ID
                }

                adView.adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        Log.d(TAG, "Banner ad loaded successfully")
                        isBannerLoaded = true
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        Log.w(TAG, "Banner ad failed to load: ${error.message}")
                        isBannerLoaded = false
                    }
                }

                bannerAdView = adView
                container.addView(adView)
                adView.loadAd(AdRequest.Builder().build())
            } catch (e: Exception) {
                Log.e(TAG, "Exception initializing banner ad: ${e.message}", e)
            }
        }
    }

    fun showBanner(container: ViewGroup) {
        container.post {
            container.visibility = View.VISIBLE
            bannerAdView?.resume()
        }
    }

    fun hideBanner(container: ViewGroup) {
        container.post {
            container.visibility = View.GONE
            bannerAdView?.pause()
        }
    }

    // 2. INTERSTITIAL ADS
    fun preloadInterstitial(context: Context) {
        if (interstitialAd != null || isInterstitialLoading) return
        isInterstitialLoading = true

        val request = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            AdConfig.INTERSTITIAL_AD_UNIT_ID,
            request,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    Log.d(TAG, "Interstitial ad loaded successfully")
                    interstitialAd = ad
                    isInterstitialLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Interstitial ad failed to load: ${error.message}")
                    interstitialAd = null
                    isInterstitialLoading = false
                }
            }
        )
    }

    fun showInterstitial(activity: Activity, onClosed: (() -> Unit)? = null) {
        activity.runOnUiThread {
            val now = System.currentTimeMillis()
            val timeSinceLast = now - lastInterstitialShowTime

            if (timeSinceLast < AdConfig.INTERSTITIAL_COOLDOWN_MS) {
                Log.d(TAG, "Interstitial skipped due to cooldown (${timeSinceLast / 1000}s / 180s)")
                onClosed?.invoke()
                return@runOnUiThread
            }

            val ad = interstitialAd
            if (ad != null) {
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        interstitialAd = null
                        lastInterstitialShowTime = System.currentTimeMillis()
                        preloadInterstitial(activity)
                        onClosed?.invoke()
                    }

                    override fun onAdFailedToShowFullScreenContent(error: AdError) {
                        interstitialAd = null
                        preloadInterstitial(activity)
                        onClosed?.invoke()
                    }
                }
                ad.show(activity)
            } else {
                preloadInterstitial(activity)
                onClosed?.invoke()
            }
        }
    }

    // 3. REWARDED ADS
    fun preloadRewarded(context: Context) {
        if (rewardedAd != null || isRewardedLoading) return
        isRewardedLoading = true

        val request = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            AdConfig.REWARDED_AD_UNIT_ID,
            request,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "Rewarded ad loaded successfully")
                    rewardedAd = ad
                    isRewardedLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Rewarded ad failed to load: ${error.message}")
                    rewardedAd = null
                    isRewardedLoading = false
                }
            }
        )
    }

    fun isRewardedAdReady(): Boolean = rewardedAd != null

    fun showRewarded(
        activity: Activity,
        onRewardEarned: (amount: Int, type: String) -> Unit,
        onAdClosed: () -> Unit,
        onAdFailed: (errorMsg: String) -> Unit
    ) {
        activity.runOnUiThread {
            val ad = rewardedAd
            if (ad == null) {
                preloadRewarded(activity)
                onAdFailed("Ad is not ready yet. Please try again.")
                return@runOnUiThread
            }

            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    preloadRewarded(activity)
                    onAdClosed()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    preloadRewarded(activity)
                    onAdFailed(error.message)
                }
            }

            ad.show(activity) { rewardItem ->
                Log.d(TAG, "Reward confirmed: ${rewardItem.amount} ${rewardItem.type}")
                onRewardEarned(rewardItem.amount, rewardItem.type)
            }
        }
    }

    // 4. NATIVE ADVANCED ADS
    fun loadNativeAd(activity: Activity, container: ViewGroup) {
        activity.runOnUiThread {
            try {
                val adLoader = AdLoader.Builder(activity, AdConfig.NATIVE_AD_UNIT_ID)
                    .forNativeAd { nativeAd ->
                        currentNativeAd?.destroy()
                        currentNativeAd = nativeAd

                        val inflater = LayoutInflater.from(activity)
                        val adView = inflater.inflate(R.layout.ad_unified_native, null) as NativeAdView
                        populateNativeAdView(nativeAd, adView)

                        container.removeAllViews()
                        container.addView(adView)
                        container.visibility = View.VISIBLE
                    }
                    .withAdListener(object : AdListener() {
                        override fun onAdFailedToLoad(error: LoadAdError) {
                            container.visibility = View.GONE
                        }
                    })
                    .build()

                adLoader.loadAd(AdRequest.Builder().build())
            } catch (e: Exception) {
                Log.e(TAG, "Error loading native ad: ${e.message}", e)
            }
        }
    }

    private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
        adView.headlineView = adView.findViewById(R.id.ad_headline)
        (adView.headlineView as? TextView)?.text = nativeAd.headline

        adView.bodyView = adView.findViewById(R.id.ad_body)
        if (nativeAd.body != null) {
            (adView.bodyView as? TextView)?.apply {
                visibility = View.VISIBLE
                text = nativeAd.body
            }
        } else {
            adView.bodyView?.visibility = View.GONE
        }

        adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
        if (nativeAd.callToAction != null) {
            (adView.callToActionView as? Button)?.apply {
                visibility = View.VISIBLE
                text = nativeAd.callToAction
            }
        } else {
            adView.callToActionView?.visibility = View.GONE
        }

        adView.iconView = adView.findViewById(R.id.ad_app_icon)
        if (nativeAd.icon != null) {
            (adView.iconView as? ImageView)?.apply {
                visibility = View.VISIBLE
                setImageDrawable(nativeAd.icon?.drawable)
            }
        } else {
            adView.iconView?.visibility = View.GONE
        }

        adView.advertiserView = adView.findViewById(R.id.ad_advertiser)
        if (nativeAd.advertiser != null) {
            (adView.advertiserView as? TextView)?.apply {
                visibility = View.VISIBLE
                text = nativeAd.advertiser
            }
        } else {
            adView.advertiserView?.visibility = View.GONE
        }

        adView.setNativeAd(nativeAd)
    }

    fun hideNativeAd(container: ViewGroup) {
        container.post {
            container.visibility = View.GONE
        }
    }

    fun onDestroy() {
        bannerAdView?.destroy()
        currentNativeAd?.destroy()
    }
}
