package com.shadowwarrior.game

import android.app.Activity
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.Toast

class WebAppInterface(
    private val activity: Activity,
    private val webView: WebView,
    private val bannerContainer: FrameLayout,
    private val nativeContainer: FrameLayout
) {
    private val adManager = AdManager.getInstance()
    private val app = activity.application as? ShadowWarriorApp

    @JavascriptInterface
    fun showBannerAd() {
        activity.runOnUiThread { adManager.showBanner(bannerContainer) }
    }

    @JavascriptInterface
    fun hideBannerAd() {
        activity.runOnUiThread { adManager.hideBanner(bannerContainer) }
    }

    @JavascriptInterface
    fun showInterstitialAd() {
        activity.runOnUiThread { adManager.showInterstitial(activity) }
    }

    @JavascriptInterface
    fun showRewardedAd(rewardType: String) {
        activity.runOnUiThread {
            adManager.showRewarded(
                activity = activity,
                onRewardEarned = { amount, type ->
                    val granted = if (amount > 0) amount else 200
                    val js = "if (window.onRewardedAdReward) { window.onRewardedAdReward($granted, '$rewardType'); }"
                    webView.evaluateJavascript(js, null)
                    Toast.makeText(activity, "Reward Earned! +$granted Gold", Toast.LENGTH_SHORT).show()
                },
                onAdClosed = {},
                onAdFailed = {
                    Toast.makeText(activity, "Ad not ready yet. Please try again shortly.", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    @JavascriptInterface
    fun isRewardedAdReady(): Boolean = adManager.isRewardedAdReady()

    @JavascriptInterface
    fun showNativeAd() {
        activity.runOnUiThread { adManager.loadNativeAd(activity, nativeContainer) }
    }

    @JavascriptInterface
    fun hideNativeAd() {
        activity.runOnUiThread { adManager.hideNativeAd(nativeContainer) }
    }

    @JavascriptInterface
    fun onGameStarted() {
        app?.appOpenManager?.isGameActive = true
        activity.runOnUiThread {
            adManager.hideBanner(bannerContainer)
            adManager.hideNativeAd(nativeContainer)
        }
    }

    @JavascriptInterface
    fun onGameEnded() {
        app?.appOpenManager?.isGameActive = false
    }

    @JavascriptInterface
    fun onGameOver() {
        app?.appOpenManager?.isGameActive = false
        activity.runOnUiThread {
            adManager.showBanner(bannerContainer)
            adManager.showInterstitial(activity)
        }
    }

    @JavascriptInterface
    fun onVictory() {
        app?.appOpenManager?.isGameActive = false
        activity.runOnUiThread {
            adManager.showBanner(bannerContainer)
            adManager.showInterstitial(activity)
        }
    }
}
