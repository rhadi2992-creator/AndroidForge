package com.shadowwarrior.game

import android.app.Application
import android.util.Log
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

class ShadowWarriorApp : Application() {

    lateinit var appOpenManager: AppOpenManager
        private set

    override fun onCreate() {
        super.onCreate()

        MobileAds.initialize(this) { status ->
            Log.d("ShadowWarriorApp", "AdMob initialized")
        }

        appOpenManager = AppOpenManager(this)
        appOpenManager.fetchAd()

        AdManager.getInstance().preloadInterstitial(this)
        AdManager.getInstance().preloadRewarded(this)
    }

    fun requestConsent(activity: android.app.Activity, onComplete: () -> Unit) {
        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()

        val consentInformation = UserMessagingPlatform.getConsentInformation(this)
        consentInformation.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    onComplete()
                }
            },
            { requestConsentError ->
                onComplete()
            }
        )
    }
}
