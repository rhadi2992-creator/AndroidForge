# Preserve Google Mobile Ads SDK classes
-keep public class com.google.android.gms.ads.** {
   public *;
}

-keep public class com.google.ads.** {
   public *;
}

# Preserve User Messaging Platform (UMP)
-keep public class com.google.android.ump.** {
   public *;
}

# Preserve JavaScript Interface methods
-keepclassmembers class com.shadowwarrior.game.WebAppInterface {
   @android.webkit.JavascriptInterface <methods>;
}

# WebKit rules
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
