package com.educationwithhassan.colorsortmaster.game

import java.util.ArrayDeque

object ColorSortSolver {

    data class State(val tubes: List<List<Int>>, val firstMove: Pair<Int, Int>?)

    fun findBestMove(puzzle: ColorSortPuzzle): Pair<Int, Int>? {
        val currentTubes = puzzle.tubes.map { it.toList() }
        val queue = ArrayDeque<State>()
        val visited = HashSet<String>()

        val initialState = State(currentTubes, null)
        queue.add(initialState)
        visited.add(encode(currentTubes))

        var maxExplored = 800

        while (queue.isNotEmpty() && maxExplored > 0) {
            maxExplored--
            val state = queue.poll() ?: break

            if (isSolved(state.tubes)) {
                return state.firstMove
            }

            for (from in state.tubes.indices) {
                val src = state.tubes[from]
                if (src.isEmpty()) continue

                if (src.size == 4 && src.distinct().size == 1) continue

                val topColor = src.last()

                for (to in state.tubes.indices) {
                    if (from == to) continue
                    val dst = state.tubes[to]
                    if (dst.size >= 4) continue
                    if (dst.isNotEmpty() && dst.last() != topColor) continue

                    if (dst.isEmpty() && src.distinct().size == 1) continue

                    val newTubes = state.tubes.map { it.toMutableList() }
                    var matchCount = 0
                    for (k in src.indices.reversed()) {
                        if (src[k] == topColor) matchCount++ else break
                    }
                    val pourUnits = minOf(matchCount, 4 - dst.size)
                    repeat(pourUnits) {
                        newTubes[from].removeAt(newTubes[from].size - 1)
                        newTubes[to].add(topColor)
                    }

                    val key = encode(newTubes)
                    if (visited.add(key)) {
                        val nextMove = state.firstMove ?: Pair(from, to)
                        queue.add(State(newTubes, nextMove))
                    }
                }
            }
        }

        for (from in currentTubes.indices) {
            val src = currentTubes[from]
            if (src.isEmpty()) continue
            val topColor = src.last()
            for (to in currentTubes.indices) {
                if (from == to) continue
                val dst = currentTubes[to]
                if (dst.size < 4 && dst.isNotEmpty() && dst.last() == topColor) {
                    return Pair(from, to)
                }
            }
        }
        return null
    }

    private fun isSolved(tubes: List<List<Int>>): Boolean {
        for (t in tubes) {
            if (t.isEmpty()) continue
            if (t.size != 4) return false
            if (t.distinct().size != 1) return false
        }
        return true
    }

    private fun encode(tubes: List<List<Int>>): String {
        return tubes.map { it.joinToString(",") }.sorted().joinToString("|")
    }
}
