package com.educationwithhassan.colorsortmaster.admob

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.ViewGroup
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.UserMessagingPlatform
import java.util.Date

class AdMobManager(private val activity: Activity) {

    private var bannerView: AdView? = null
    private var bannerContainer: ViewGroup? = null
    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var appOpenAd: AppOpenAd? = null
    private var appOpenLoadTime: Long = 0
    private var lastInterstitialTime: Long = 0
    private var completedLevelsSinceLastAd: Int = 0
    private var isInitialized: Boolean = false

    fun initialize(onConsentReady: () -> Unit) {
        if (isInitialized) {
            onConsentReady()
            return
        }

        try {
            val params = com.google.android.ump.ConsentRequestParameters.Builder().build()
            val consentInfo = UserMessagingPlatform.getConsentInformation(activity)
            consentInfo.requestConsentInfoUpdate(
                activity,
                params,
                {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                        initMobileAds(onConsentReady)
                    }
                },
                { _ ->
                    initMobileAds(onConsentReady)
                }
            )
        } catch (e: Exception) {
            e.printStackTrace()
            initMobileAds(onConsentReady)
        }
    }

    private fun initMobileAds(onReady: () -> Unit) {
        try {
            MobileAds.initialize(activity) {
                isInitialized = true
                onReady()
            }
        } catch (e: Throwable) {
            isInitialized = false
            onReady()
        }
    }

    fun loadAnchoredAdaptiveBanner(container: ViewGroup) {
        try {
            bannerContainer = container
            destroyBanner()

            val adView = AdView(activity)
            adView.adUnitId = AdMobConfig.getBannerId()
            val adSize = getAnchoredAdaptiveBannerSize()
            adView.setAdSize(adSize)

            adView.adListener = object : AdListener() {
                override fun onAdLoaded() {}
                override fun onAdFailedToLoad(loadAdError: LoadAdError) {}
            }

            bannerView = adView
            container.addView(adView)
            adView.loadAd(AdRequest.Builder().build())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getAnchoredAdaptiveBannerSize(): AdSize {
        val display = activity.windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)

        val density = outMetrics.density
        val adWidthPixels = outMetrics.widthPixels.toFloat()
        val adWidth = (adWidthPixels / density).toInt()

        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth)
    }

    fun onConfigurationChanged(newConfig: Configuration) {
        bannerContainer?.let { container ->
            loadAnchoredAdaptiveBanner(container)
        }
    }

    fun setBannerVisibility(visible: Boolean) {
        bannerView?.visibility = if (visible) android.view.View.VISIBLE else android.view.View.GONE
    }

    fun destroyBanner() {
        bannerView?.let {
            bannerContainer?.removeView(it)
            it.destroy()
            bannerView = null
        }
    }

    fun preloadInterstitial() {
        try {
            InterstitialAd.load(
                activity,
                AdMobConfig.getInterstitialId(),
                AdRequest.Builder().build(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        interstitialAd = ad
                    }
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        interstitialAd = null
                    }
                }
            )
        } catch (e: Exception) {
            interstitialAd = null
        }
    }

    fun showInterstitialOnLevelComplete(onNext: () -> Unit) {
        completedLevelsSinceLastAd++
        val now = SystemClock.elapsedRealtime()
        val hasCooledDown = (now - lastInterstitialTime) >= AdMobConfig.INTERSTITIAL_COOLDOWN_MS

        if (completedLevelsSinceLastAd >= AdMobConfig.INTERSTITIAL_LEVEL_INTERVAL &&
            hasCooledDown &&
            interstitialAd != null
        ) {
            interstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    lastInterstitialTime = SystemClock.elapsedRealtime()
                    completedLevelsSinceLastAd = 0
                    preloadInterstitial()
                    onNext()
                }
                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    preloadInterstitial()
                    onNext()
                }
            }
            interstitialAd?.show(activity)
        } else {
            onNext()
        }
    }

    fun preloadRewarded() {
        try {
            RewardedAd.load(
                activity,
                AdMobConfig.getRewardedId(),
                AdRequest.Builder().build(),
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        rewardedAd = ad
                    }
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        rewardedAd = null
                    }
                }
            )
        } catch (e: Exception) {
            rewardedAd = null
        }
    }

    fun showRewardedAd(
        onUserEarnedReward: (amount: Int, type: String) -> Unit,
        onDismissed: () -> Unit = {},
        onUnavailable: () -> Unit = {}
    ) {
        val ad = rewardedAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    preloadRewarded()
                    onDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    rewardedAd = null
                    preloadRewarded()
                    onUnavailable()
                }
            }

            ad.show(activity) { rewardItem ->
                onUserEarnedReward(rewardItem.amount, rewardItem.type)
            }
        } else {
            preloadRewarded()
            onUnavailable()
        }
    }

    fun showRewarded(
        onRewardEarned: () -> Unit,
        onDismissed: () -> Unit = {},
        onUnavailable: () -> Unit = {}
    ) {
        showRewardedAd(
            onUserEarnedReward = { _, _ -> onRewardEarned() },
            onDismissed = onDismissed,
            onUnavailable = onUnavailable
        )
    }

    fun preloadAppOpen() {
        try {
            AppOpenAd.load(
                activity,
                AdMobConfig.getAppOpenId(),
                AdRequest.Builder().build(),
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        appOpenAd = ad
                        appOpenLoadTime = Date().time
                    }
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        appOpenAd = null
                    }
                }
            )
        } catch (e: Exception) {
            appOpenAd = null
        }
    }

    fun showAppOpenIfAvailable(onFinished: () -> Unit) {
        val isFresh = (Date().time - appOpenLoadTime) < (AdMobConfig.APP_OPEN_EXPIRY_HOURS * 3600_000)
        if (appOpenAd != null && isFresh) {
            appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    appOpenAd = null
                    preloadAppOpen()
                    onFinished()
                }
                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    appOpenAd = null
                    preloadAppOpen()
                    onFinished()
                }
            }
            appOpenAd?.show(activity)
        } else {
            preloadAppOpen()
            onFinished()
        }
    }

    fun loadNativeAd(onLoaded: (NativeAd) -> Unit) {
        try {
            val adLoader = AdLoader.Builder(activity, AdMobConfig.getNativeId())
                .forNativeAd { nativeAd ->
                    onLoaded(nativeAd)
                }
                .withNativeAdOptions(
                    NativeAdOptions.Builder()
                        .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
                        .build()
                )
                .build()

            adLoader.loadAd(AdRequest.Builder().build())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun onDestroy() {
        destroyBanner()
    }
}
