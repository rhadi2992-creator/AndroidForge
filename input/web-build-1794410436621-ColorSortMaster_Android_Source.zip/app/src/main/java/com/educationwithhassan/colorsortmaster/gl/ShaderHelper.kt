package com.educationwithhassan.colorsortmaster.gl

import android.opengl.GLES20
import android.util.Log

object ShaderHelper {
    private const val TAG = "ColorSortMaster"

    fun compileShader(type: Int, shaderCode: String): Int {
        val shaderId = GLES20.glCreateShader(type)
        if (shaderId == 0) {
            Log.e(TAG, "GLES20: Could not create new shader (type=" + type + ")")
            return 0
        }
        GLES20.glShaderSource(shaderId, shaderCode)
        GLES20.glCompileShader(shaderId)

        val compileStatus = IntArray(1)
        GLES20.glGetShaderiv(shaderId, GLES20.GL_COMPILE_STATUS, compileStatus, 0)
        if (compileStatus[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shaderId)
            Log.e(TAG, "GLES20: Compilation failed for shader (type=" + type + "):\n" + log)
            GLES20.glDeleteShader(shaderId)
            return 0
        }
        Log.d(TAG, "GLES20: Shader compiled successfully (type=" + type + ", id=" + shaderId + ")")
        return shaderId
    }

    fun createAndLinkProgram(vertexShaderCode: String, fragmentShaderCode: String): Int {
        val vertexShaderId = compileShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode)
        val fragmentShaderId = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode)

        if (vertexShaderId == 0 || fragmentShaderId == 0) {
            Log.e(TAG, "GLES20: Shader compilation failed during program creation")
            return 0
        }

        val programId = GLES20.glCreateProgram()
        if (programId == 0) {
            Log.e(TAG, "GLES20: Could not create new GL program")
            return 0
        }

        GLES20.glAttachShader(programId, vertexShaderId)
        GLES20.glAttachShader(programId, fragmentShaderId)
        GLES20.glLinkProgram(programId)

        val linkStatus = IntArray(1)
        GLES20.glGetProgramiv(programId, GLES20.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(programId)
            Log.e(TAG, "GLES20: Program linking failed:\n" + log)
            GLES20.glDeleteProgram(programId)
            return 0
        }

        Log.i(TAG, "GLES20: Program linked successfully (id=" + programId + ")")
        return programId
    }
}
