package com.educationwithhassan.colorsortmaster.data

import android.content.Context
import android.content.SharedPreferences

class SaveSystem(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("csm_save_data", Context.MODE_PRIVATE)

    fun getCurrentLevel(): Int = prefs.getInt("key_current_level", 1)

    fun markLevelComplete(level: Int) {
        val next = maxOf(getCurrentLevel(), level + 1)
        prefs.edit().putInt("key_current_level", next).apply()
        addCoins(100)
    }

    fun getCoins(): Int = prefs.getInt("key_coins", 250)

    fun addCoins(amount: Int) {
        val cur = getCoins()
        prefs.edit().putInt("key_coins", cur + amount).apply()
    }

    fun getSoundEnabled(): Boolean = prefs.getBoolean("key_sound", true)
    fun setSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("key_sound", enabled).apply()
    }

    fun getMusicEnabled(): Boolean = prefs.getBoolean("key_music", true)
    fun setMusicEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("key_music", enabled).apply()
    }

    fun getUseFallback2D(): Boolean = prefs.getBoolean("key_use_fallback_2d", false)
    fun setUseFallback2D(use2D: Boolean) {
        prefs.edit().putBoolean("key_use_fallback_2d", use2D).apply()
    }

    fun getLevelStars(level: Int): Int = prefs.getInt("key_stars_" + level, if (level < getCurrentLevel()) 3 else 0)
    fun setLevelStars(level: Int, stars: Int) {
        prefs.edit().putInt("key_stars_" + level, stars).apply()
    }

    fun getFreeUndos(): Int = prefs.getInt("key_free_undos", 5)
    fun useUndo(): Boolean {
        val count = getFreeUndos()
        if (count > 0) {
            prefs.edit().putInt("key_free_undos", count - 1).apply()
            return true
        }
        return false
    }
    fun addUndos(amount: Int) {
        prefs.edit().putInt("key_free_undos", getFreeUndos() + amount).apply()
    }

    fun getFreeHints(): Int = prefs.getInt("key_free_hints", 3)
    fun useHint(): Boolean {
        val count = getFreeHints()
        if (count > 0) {
            prefs.edit().putInt("key_free_hints", count - 1).apply()
            return true
        }
        return false
    }
    fun addHints(amount: Int) {
        prefs.edit().putInt("key_free_hints", getFreeHints() + amount).apply()
    }
}
