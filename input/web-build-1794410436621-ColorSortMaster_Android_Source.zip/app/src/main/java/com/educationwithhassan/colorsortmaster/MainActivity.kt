package com.educationwithhassan.colorsortmaster

import android.app.AlertDialog
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.educationwithhassan.colorsortmaster.admob.AdMobManager
import com.educationwithhassan.colorsortmaster.data.SaveSystem
import com.educationwithhassan.colorsortmaster.game.ColorSortPuzzle
import com.educationwithhassan.colorsortmaster.game.ColorSortSolver
import com.educationwithhassan.colorsortmaster.game.Game2DView
import com.educationwithhassan.colorsortmaster.gl.GameGLSurfaceView

class MainActivity : AppCompatActivity() {

    companion object {
        const val TAG = "ColorSortMaster"
    }

    private lateinit var saveSystem: SaveSystem
    private lateinit var puzzle: ColorSortPuzzle
    private lateinit var adMobManager: AdMobManager

    // UI View Containers
    private lateinit var rootLayout: FrameLayout
    private lateinit var loadingView: FrameLayout
    private lateinit var mainMenuView: FrameLayout
    private lateinit var gameplayView: FrameLayout
    private lateinit var bannerContainer: FrameLayout

    // Rendering Containers
    private var glSurfaceView: GameGLSurfaceView? = null
    private var game2DView: Game2DView? = null
    private lateinit var gameContainer: FrameLayout

    // HUD & Menu Texts
    private lateinit var levelText: TextView
    private lateinit var movesText: TextView
    private lateinit var timerText: TextView
    private lateinit var coinsText: TextView
    private lateinit var menuCoinsText: TextView
    private lateinit var menuLevelBadge: TextView
    private lateinit var soundToggleBtn: TextView

    // State
    private var moveCount = 0
    private var startTimeMs = 0L
    private var isGameRunning = false
    private val handler = Handler(Looper.getMainLooper())
    private var toneGenerator: ToneGenerator? = null

    private val timerRunnable = object : Runnable {
        override fun run() {
            if (isGameRunning) {
                val elapsedSec = (SystemClock.uptimeMillis() - startTimeMs) / 1000
                val m = elapsedSec / 60
                val s = elapsedSec % 60
                val timeFormatted = String.format("%02d:%02d", m, s)
                timerText.text = "⏱ " + timeFormatted
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "MainActivity onCreate started")

        saveSystem = SaveSystem(this)
        puzzle = ColorSortPuzzle(saveSystem.getCurrentLevel())
        Log.i(TAG, "SaveSystem loaded: Level=" + saveSystem.getCurrentLevel() + ", Coins=" + saveSystem.getCoins())

        rootLayout = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#0F172A"))
        }

        buildLoadingScreen()
        buildMainMenu()
        buildGameplayScreen()

        bannerContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        }
        rootLayout.addView(bannerContainer)

        setContentView(rootLayout)

        showLoadingScreen()

        adMobManager = AdMobManager(this)
        adMobManager.initialize(
            onConsentReady = {
                Log.i(TAG, "AdMob Consent Ready. Preloading banner and interstitials.")
                adMobManager.loadAnchoredAdaptiveBanner(bannerContainer)
                adMobManager.preloadInterstitial()
                adMobManager.preloadRewarded()
                adMobManager.preloadAppOpen()
            }
        )

        handler.postDelayed({
            showMainMenu()
        }, 1400)
    }

    private fun showLoadingScreen() {
        Log.i(TAG, "Displaying Loading Screen")
        loadingView.visibility = View.VISIBLE
        mainMenuView.visibility = View.GONE
        gameplayView.visibility = View.GONE
    }

    private fun showMainMenu() {
        Log.i(TAG, "Displaying Main Menu")
        isGameRunning = false
        loadingView.visibility = View.GONE
        mainMenuView.visibility = View.VISIBLE
        gameplayView.visibility = View.GONE

        menuCoinsText.text = "🪙 " + saveSystem.getCoins() + " Coins"
        menuLevelBadge.text = "Current: Level " + saveSystem.getCurrentLevel()
        soundToggleBtn.text = if (saveSystem.getSoundEnabled()) "🔊" else "🔇"
    }

    private fun showGameplayScreen() {
        Log.i(TAG, "Displaying Gameplay Screen for Level " + puzzle.currentLevel)
        loadingView.visibility = View.GONE
        mainMenuView.visibility = View.GONE
        gameplayView.visibility = View.VISIBLE

        moveCount = 0
        startTimeMs = SystemClock.uptimeMillis()
        isGameRunning = true

        updateHUD()
        handler.removeCallbacks(timerRunnable)
        handler.post(timerRunnable)

        initGameViews()
    }

    private fun buildLoadingScreen() {
        loadingView = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0F172A"), Color.parseColor("#1E1B4B"))
            )
        }

        val centerCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        }

        val logoIcon = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(88), dpToPx(88)).apply {
                bottomMargin = dpToPx(16)
            }
            setImageResource(R.mipmap.ic_launcher)
        }
        centerCol.addView(logoIcon)

        val title = TextView(this).apply {
            text = "Color Sort Master"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        centerCol.addView(title)

        val subtitle = TextView(this).apply {
            text = "3D Cartoon Puzzle"
            textSize = 15f
            setTextColor(Color.parseColor("#38BDF8"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dpToPx(4), 0, dpToPx(24))
        }
        centerCol.addView(subtitle)

        val progressBar = ProgressBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(44), dpToPx(44)).apply {
                bottomMargin = dpToPx(12)
            }
        }
        centerCol.addView(progressBar)

        val loadingText = TextView(this).apply {
            text = "Loading 3D assets & puzzle levels..."
            textSize = 13f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER
        }
        centerCol.addView(loadingText)

        loadingView.addView(centerCol)
        rootLayout.addView(loadingView)
    }

    private fun buildMainMenu() {
        mainMenuView = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0F172A"), Color.parseColor("#1E1B4B"))
            )
        }

        val header = RelativeLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                dpToPx(60)
            )
            setPadding(dpToPx(16), dpToPx(10), dpToPx(16), 0)
        }

        menuCoinsText = TextView(this).apply {
            text = "🪙 " + saveSystem.getCoins() + " Coins"
            textSize = 15f
            setTextColor(Color.parseColor("#FBBF24"))
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dpToPx(20).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#334155"))
            }
            setPadding(dpToPx(14), dpToPx(6), dpToPx(14), dpToPx(6))
            val lp = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                addRule(RelativeLayout.ALIGN_PARENT_LEFT)
                addRule(RelativeLayout.CENTER_VERTICAL)
            }
            layoutParams = lp
        }
        header.addView(menuCoinsText)

        soundToggleBtn = TextView(this).apply {
            text = "🔊"
            textSize = 20f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dpToPx(20).toFloat()
            }
            setPadding(dpToPx(10), dpToPx(6), dpToPx(10), dpToPx(6))
            val lp = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                addRule(RelativeLayout.ALIGN_PARENT_RIGHT)
                addRule(RelativeLayout.CENTER_VERTICAL)
            }
            layoutParams = lp
            setOnClickListener {
                val next = !saveSystem.getSoundEnabled()
                saveSystem.setSoundEnabled(next)
                text = if (next) "🔊" else "🔇"
                playSound(ToneGenerator.TONE_PROP_BEEP)
            }
        }
        header.addView(soundToggleBtn)
        mainMenuView.addView(header)

        val scroll = ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ).apply {
                topMargin = dpToPx(60)
                bottomMargin = dpToPx(60)
            }
        }

        val centerCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
            setPadding(dpToPx(24), dpToPx(16), dpToPx(24), dpToPx(24))
        }

        val logoIcon = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(96), dpToPx(96)).apply {
                bottomMargin = dpToPx(10)
            }
            setImageResource(R.mipmap.ic_launcher)
        }
        centerCol.addView(logoIcon)

        val title = TextView(this).apply {
            text = "Color Sort Master"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        centerCol.addView(title)

        menuLevelBadge = TextView(this).apply {
            text = "Current: Level " + saveSystem.getCurrentLevel()
            textSize = 14f
            setTextColor(Color.parseColor("#38BDF8"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dpToPx(4), 0, dpToPx(24))
        }
        centerCol.addView(menuLevelBadge)

        val playBtn = Button(this).apply {
            text = "▶  PLAY"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#10B981"))
                cornerRadius = dpToPx(26).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(60)
            ).apply {
                bottomMargin = dpToPx(14)
            }
            setOnClickListener {
                playSound(ToneGenerator.TONE_PROP_ACK)
                puzzle.loadLevel(saveSystem.getCurrentLevel())
                showGameplayScreen()
            }
        }
        centerCol.addView(playBtn)

        val levelsBtn = Button(this).apply {
            text = "🗺  LEVEL SELECT"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#334155"))
                cornerRadius = dpToPx(22).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(52)
            ).apply {
                bottomMargin = dpToPx(12)
            }
            setOnClickListener {
                playSound(ToneGenerator.TONE_PROP_BEEP)
                showLevelSelectDialog()
            }
        }
        centerCol.addView(levelsBtn)

        val dailyBtn = Button(this).apply {
            text = "⭐  DAILY CHALLENGE"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#D97706"))
                cornerRadius = dpToPx(22).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(52)
            ).apply {
                bottomMargin = dpToPx(12)
            }
            setOnClickListener {
                playSound(ToneGenerator.TONE_PROP_BEEP)
                puzzle.loadLevel(37)
                showGameplayScreen()
            }
        }
        centerCol.addView(dailyBtn)

        val settingsBtn = Button(this).apply {
            text = "⚙  SETTINGS"
            textSize = 16f
            setTextColor(Color.parseColor("#CBD5E1"))
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dpToPx(22).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#475569"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(52)
            ).apply {
                bottomMargin = dpToPx(12)
            }
            setOnClickListener {
                playSound(ToneGenerator.TONE_PROP_BEEP)
                showSettingsDialog()
            }
        }
        centerCol.addView(settingsBtn)

        scroll.addView(centerCol)
        mainMenuView.addView(scroll)
        rootLayout.addView(mainMenuView)
    }

    private fun buildGameplayScreen() {
        gameplayView = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0F172A"), Color.parseColor("#1E1B4B"))
            )
        }

        val mainCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ).apply {
                bottomMargin = dpToPx(50)
            }
        }

        val hud = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(56)
            )
            setPadding(dpToPx(12), 0, dpToPx(12), 0)
            setBackgroundColor(Color.parseColor("#0B1120"))
        }

        val backBtn = TextView(this).apply {
            text = "← Menu"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpToPx(8), dpToPx(6), dpToPx(8), dpToPx(6))
            setOnClickListener {
                playSound(ToneGenerator.TONE_PROP_BEEP)
                showMainMenu()
            }
        }
        hud.addView(backBtn)

        levelText = TextView(this).apply {
            text = "Level 1"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hud.addView(levelText)

        movesText = TextView(this).apply {
            text = "Moves: 0"
            textSize = 13f
            setTextColor(Color.parseColor("#38BDF8"))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpToPx(6), 0, dpToPx(6), 0)
        }
        hud.addView(movesText)

        timerText = TextView(this).apply {
            text = "⏱ 00:00"
            textSize = 13f
            setTextColor(Color.parseColor("#FBBF24"))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpToPx(6), 0, dpToPx(6), 0)
        }
        hud.addView(timerText)

        mainCol.addView(hud)

        gameContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        mainCol.addView(gameContainer)

        val boosterBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(64)
            )
            setBackgroundColor(Color.parseColor("#0B1120"))
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
        }

        val undoBtn = createBoosterButton("↩ Undo") {
            onUndoClicked()
        }
        boosterBar.addView(undoBtn)

        val hintBtn = createBoosterButton("💡 Hint") {
            onHintClicked()
        }
        boosterBar.addView(hintBtn)

        val extraTubeBtn = createBoosterButton("+1 Tube") {
            onExtraTubeClicked()
        }
        boosterBar.addView(extraTubeBtn)

        val restartBtn = createBoosterButton("↺ Restart") {
            onRestartClicked()
        }
        boosterBar.addView(restartBtn)

        mainCol.addView(boosterBar)
        gameplayView.addView(mainCol)
        rootLayout.addView(gameplayView)
    }

    private fun createBoosterButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dpToPx(14).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#334155"))
            }
            layoutParams = LinearLayout.LayoutParams(0, dpToPx(46), 1f).apply {
                leftMargin = dpToPx(4)
                rightMargin = dpToPx(4)
            }
            setOnClickListener {
                playSound(ToneGenerator.TONE_PROP_BEEP)
                onClick()
            }
        }
    }

    private fun initGameViews() {
        gameContainer.removeAllViews()
        val use2D = saveSystem.getUseFallback2D()

        if (use2D) {
            Log.i(TAG, "Initializing 2D Canvas Fallback view (User preference)")
            setup2DView()
        } else {
            Log.i(TAG, "Initializing 3D OpenGL ES 2.0 View")
            try {
                glSurfaceView = GameGLSurfaceView(
                    this,
                    puzzle,
                    onTubePairSelected = { from, to -> onMoveAttempt(from, to) },
                    onError = { errorMsg ->
                        Log.e(TAG, "GameGLSurfaceView error: " + errorMsg)
                        runOnUiThread {
                            switchToFallback2D("OpenGL ES Failure: " + errorMsg)
                        }
                    }
                )
                gameContainer.addView(glSurfaceView)
            } catch (t: Throwable) {
                Log.e(TAG, "Exception creating GameGLSurfaceView: " + t.message, t)
                switchToFallback2D("GL View Exception: " + t.message)
            }
        }
    }

    private fun setup2DView() {
        gameContainer.removeAllViews()
        game2DView = Game2DView(this).apply {
            puzzle = this@MainActivity.puzzle
            onTubePairSelected = { from, to -> onMoveAttempt(from, to) }
        }
        gameContainer.addView(game2DView)
    }

    private fun switchToFallback2D(reason: String) {
        Log.w(TAG, "Switching to 2D Fallback view: " + reason)
        saveSystem.setUseFallback2D(true)
        setup2DView()
        Toast.makeText(this, "Switched to 2D Cartoon Engine", Toast.LENGTH_SHORT).show()
    }

    private fun onMoveAttempt(fromIdx: Int, toIdx: Int) {
        Log.d(TAG, "Move attempt: from=" + fromIdx + " to=" + toIdx)
        val move = puzzle.pour(fromIdx, toIdx)
        if (move != null) {
            moveCount++
            updateHUD()
            playSound(ToneGenerator.TONE_PROP_ACK)
            glSurfaceView?.triggerPourAnimation(move)
            game2DView?.invalidate()

            if (puzzle.isSolved()) {
                Log.i(TAG, "Level " + puzzle.currentLevel + " Solved in " + moveCount + " moves!")
                playSound(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD)
                saveSystem.markLevelComplete(puzzle.currentLevel)
                showVictoryDialog()
            }
        } else {
            playSound(ToneGenerator.TONE_PROP_NACK)
            glSurfaceView?.triggerInvalidShake(fromIdx)
            game2DView?.triggerShake(fromIdx)
        }
    }

    private fun onUndoClicked() {
        if (puzzle.canUndo()) {
            puzzle.undo()
            moveCount++
            updateHUD()
            glSurfaceView?.requestRender()
            game2DView?.invalidate()
            playSound(ToneGenerator.TONE_PROP_BEEP)
        } else {
            Toast.makeText(this, "No moves to undo!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onHintClicked() {
        val hintMove = ColorSortSolver.findBestMove(puzzle)
        if (hintMove != null) {
            val from = hintMove.first + 1
            val to = hintMove.second + 1
            Toast.makeText(this, "💡 Hint: Pour tube " + from + " into tube " + to, Toast.LENGTH_LONG).show()
            playSound(ToneGenerator.TONE_PROP_ACK)
        } else {
            Toast.makeText(this, "No obvious move found. Try adding a tube or undoing!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onExtraTubeClicked() {
        if (puzzle.tubes.size < 12) {
            puzzle.addExtraTube()
            glSurfaceView?.requestRender()
            game2DView?.invalidate()
            Toast.makeText(this, "+1 Extra Tube Added!", Toast.LENGTH_SHORT).show()
            playSound(ToneGenerator.TONE_PROP_ACK)
        } else {
            Toast.makeText(this, "Max tube limit reached!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onRestartClicked() {
        puzzle.resetCurrentLevel()
        moveCount = 0
        startTimeMs = SystemClock.uptimeMillis()
        updateHUD()
        glSurfaceView?.requestRender()
        game2DView?.invalidate()
        playSound(ToneGenerator.TONE_PROP_BEEP)
    }

    private fun updateHUD() {
        levelText.text = "Level " + puzzle.currentLevel
        movesText.text = "Moves: " + moveCount
    }

    private fun showVictoryDialog() {
        isGameRunning = false
        val dialogView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dpToPx(24), dpToPx(20), dpToPx(24), dpToPx(20))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dpToPx(20).toFloat()
            }
        }

        val stars = TextView(this).apply {
            text = "⭐⭐⭐"
            textSize = 28f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dpToPx(8))
        }
        dialogView.addView(stars)

        val title = TextView(this).apply {
            text = "LEVEL COMPLETE!"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        dialogView.addView(title)

        val rewardText = TextView(this).apply {
            text = "+100 Coins Earned"
            textSize = 15f
            setTextColor(Color.parseColor("#FBBF24"))
            gravity = Gravity.CENTER
            setPadding(0, dpToPx(6), 0, dpToPx(16))
        }
        dialogView.addView(rewardText)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        val doubleRewardBtn = Button(this).apply {
            text = "📺 Double Coins (+200)"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#D97706"))
                cornerRadius = dpToPx(16).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(48)
            ).apply {
                bottomMargin = dpToPx(10)
            }
            setOnClickListener {
                adMobManager.showRewardedAd(
                    onUserEarnedReward = { amount, _ ->
                        val bonus = if (amount > 0) amount else 200
                        saveSystem.addCoins(bonus)
                        Toast.makeText(this@MainActivity, "Bonus " + bonus + " Coins Granted!", Toast.LENGTH_SHORT).show()
                    },
                    onDismissed = {
                        dialog.dismiss()
                        advanceToNextLevel()
                    },
                    onUnavailable = {
                        Toast.makeText(this@MainActivity, "Rewarded ad currently unavailable. Continuing!", Toast.LENGTH_SHORT).show()
                        dialog.dismiss()
                        advanceToNextLevel()
                    }
                )
            }
        }
        dialogView.addView(doubleRewardBtn)

        val nextLevelBtn = Button(this).apply {
            text = "Next Level ▶"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#10B981"))
                cornerRadius = dpToPx(16).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(50)
            )
            setOnClickListener {
                dialog.dismiss()
                adMobManager.showInterstitialOnLevelComplete {
                    advanceToNextLevel()
                }
            }
        }
        dialogView.addView(nextLevelBtn)

        dialog.show()
    }

    private fun advanceToNextLevel() {
        val nextLvl = puzzle.currentLevel + 1
        puzzle.loadLevel(nextLvl)
        showGameplayScreen()
    }

    private fun showLevelSelectDialog() {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16))
        }

        val builder = AlertDialog.Builder(this)
            .setTitle("Select Level (1 - 500)")
            .setView(scroll)
            .setNegativeButton("Close", null)

        val dialog = builder.create()

        val curLevel = saveSystem.getCurrentLevel()
        val totalLevels = 500
        val rowSize = 5

        for (r in 0 until (totalLevels + rowSize - 1) / rowSize) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dpToPx(48)
                ).apply {
                    bottomMargin = dpToPx(6)
                }
            }
            for (c in 0 until rowSize) {
                val lvl = r * rowSize + c + 1
                if (lvl <= totalLevels) {
                    val isUnlocked = lvl <= curLevel
                    val btn = Button(this).apply {
                        text = "" + lvl
                        textSize = 12f
                        setTextColor(if (isUnlocked) Color.WHITE else Color.parseColor("#64748B"))
                        background = GradientDrawable().apply {
                            setColor(if (isUnlocked) Color.parseColor("#1E293B") else Color.parseColor("#0F172A"))
                            cornerRadius = dpToPx(10).toFloat()
                            setStroke(dpToPx(1), if (isUnlocked) Color.parseColor("#38BDF8") else Color.parseColor("#334155"))
                        }
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                            leftMargin = dpToPx(2)
                            rightMargin = dpToPx(2)
                        }
                        isEnabled = isUnlocked
                        setOnClickListener {
                            dialog.dismiss()
                            puzzle.loadLevel(lvl)
                            showGameplayScreen()
                        }
                    }
                    rowLayout.addView(btn)
                }
            }
            col.addView(rowLayout)
        }

        scroll.addView(col)
        dialog.show()
    }

    private fun showSettingsDialog() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(20), dpToPx(16), dpToPx(20), dpToPx(16))
        }

        val soundCb = CheckBox(this).apply {
            text = "Sound Effects"
            isChecked = saveSystem.getSoundEnabled()
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                saveSystem.setSoundEnabled(checked)
                soundToggleBtn.text = if (checked) "🔊" else "🔇"
            }
        }
        col.addView(soundCb)

        val musicCb = CheckBox(this).apply {
            text = "Background Music"
            isChecked = saveSystem.getMusicEnabled()
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                saveSystem.setMusicEnabled(checked)
            }
        }
        col.addView(musicCb)

        val engine2dCb = CheckBox(this).apply {
            text = "Force 2D Cartoon Engine (Fallback)"
            isChecked = saveSystem.getUseFallback2D()
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                saveSystem.setUseFallback2D(checked)
                initGameViews()
            }
        }
        col.addView(engine2dCb)

        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(col)
            .setPositiveButton("Done", null)
            .show()
    }

    private fun playSound(toneType: Int) {
        if (!saveSystem.getSoundEnabled()) return
        try {
            if (toneGenerator == null) {
                toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            }
            toneGenerator?.startTone(toneType, 120)
        } catch (e: Throwable) {
            Log.w(TAG, "Audio error: " + e.message)
        }
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        adMobManager.onConfigurationChanged(newConfig)
    }

    override fun onResume() {
        super.onResume()
        glSurfaceView?.onResume()
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView?.onPause()
        isGameRunning = false
        handler.removeCallbacks(timerRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        toneGenerator?.release()
        adMobManager.onDestroy()
    }
}
