package com.educationwithhassan.colorsortmaster.game

data class MoveRecord(val from: Int, val to: Int, val color: Int, val count: Int)

class ColorSortPuzzle(var currentLevel: Int) {
    val tubes = mutableListOf<MutableList<Int>>()
    val history = mutableListOf<MoveRecord>()
    val capacity = 4
    private var initialTubes = listOf<List<Int>>()

    init {
        loadLevel(currentLevel)
    }

    fun loadLevel(level: Int) {
        currentLevel = level
        tubes.clear()
        history.clear()
        val generated = LevelGenerator.generate(level)
        initialTubes = generated.map { it.toList() }
        for (tube in generated) {
            tubes.add(tube.toMutableList())
        }
    }

    fun resetCurrentLevel() {
        tubes.clear()
        history.clear()
        for (tube in initialTubes) {
            tubes.add(tube.toMutableList())
        }
    }

    fun addExtraTube() {
        tubes.add(mutableListOf())
    }

    fun canUndo(): Boolean = history.isNotEmpty()

    fun pour(from: Int, to: Int): MoveRecord? {
        if (from == to || from !in tubes.indices || to !in tubes.indices) return null
        val source = tubes[from]
        val target = tubes[to]
        if (source.isEmpty() || target.size >= capacity) return null

        val topColor = source.last()
        if (target.isNotEmpty() && target.last() != topColor) return null

        var matchCount = 0
        for (i in source.indices.reversed()) {
            if (source[i] == topColor) matchCount++ else break
        }

        val availableSpace = capacity - target.size
        val unitsToPour = minOf(matchCount, availableSpace)
        if (unitsToPour <= 0) return null

        repeat(unitsToPour) {
            source.removeAt(source.size - 1)
            target.add(topColor)
        }

        val record = MoveRecord(from, to, topColor, unitsToPour)
        history.add(record)
        return record
    }

    fun undo(): Boolean {
        if (history.isEmpty()) return false
        val last = history.removeAt(history.size - 1)
        val source = tubes[last.from]
        val target = tubes[last.to]
        repeat(last.count) {
            target.removeAt(target.size - 1)
            source.add(last.color)
        }
        return true
    }

    fun isSolved(): Boolean {
        for (t in tubes) {
            if (t.isEmpty()) continue
            if (t.size != capacity) return false
            val first = t[0]
            if (t.any { it != first }) return false
        }
        return true
    }
}
