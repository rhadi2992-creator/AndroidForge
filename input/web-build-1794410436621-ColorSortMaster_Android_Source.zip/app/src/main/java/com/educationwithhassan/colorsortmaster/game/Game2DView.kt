package com.educationwithhassan.colorsortmaster.game

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator

class Game2DView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var puzzle: ColorSortPuzzle? = null
    var onTubePairSelected: ((Int, Int) -> Unit)? = null

    private var selectedIndex: Int? = null
    private var liftProgress = 0f
    private var liftAnimator: ValueAnimator? = null
    private var shakingIndex: Int? = null
    private var shakeOffset = 0f

    private val tubePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.parseColor("#70FFFFFF")
    }
    private val tubeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#18FFFFFF")
    }
    private val liquidPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#50FFFFFF")
    }
    private val selectionGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 8f
        color = Color.parseColor("#FFD700")
    }

    companion object {
        val PALETTE_HEX = arrayOf(
            "#EF4444", // Ruby Red
            "#3B82F6", // Ocean Blue
            "#EAB308", // Sunshine Yellow
            "#10B981", // Emerald Green
            "#8B5CF6", // Purple
            "#F97316", // Orange
            "#EC4899", // Pink
            "#06B6D4", // Cyan
            "#84CC16", // Lime
            "#14B8A6", // Teal
            "#F59E0B", // Amber
            "#6366F1"  // Indigo
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val p = puzzle ?: return
        val count = p.tubes.size
        if (count == 0) return

        val rows = if (count <= 5) 1 else 2
        val cols = (count + rows - 1) / rows

        val totalW = width.toFloat()
        val totalH = height.toFloat()

        val tubeW = minOf(totalW / (cols + 0.6f) * 0.7f, 130f)
        val tubeH = minOf(tubeW * 3.4f, totalH / (rows + 1f) * 0.75f)

        val rowH = totalH / rows

        for (i in 0 until count) {
            val r = if (rows == 1) 0 else (i / cols)
            val c = if (rows == 1) i else (i % cols)
            val rowCount = if (rows == 1) count else (if (r == 0) minOf(cols, count) else (count - cols))
            val rowStart = (totalW - (rowCount * tubeW + (rowCount - 1) * (tubeW * 0.45f))) / 2f
            var x = rowStart + c * (tubeW * 1.45f)
            var y = (r + 0.5f) * rowH - tubeH / 2f

            if (i == selectedIndex) {
                y -= 45f * liftProgress
            }
            if (i == shakingIndex) {
                x += shakeOffset
            }

            drawTube(canvas, x, y, tubeW, tubeH, p.tubes[i], i == selectedIndex)
        }
    }

    private fun drawTube(
        canvas: Canvas,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        liquid: List<Int>,
        isSelected: Boolean
    ) {
        val corner = w / 2f
        val rect = RectF(x, y, x + w, y + h)

        canvas.drawRoundRect(rect, corner, corner, tubeBgPaint)

        val segH = (h - corner * 0.5f) / 4f
        val liquidBottom = y + h - 4f

        for (segIdx in liquid.indices) {
            val colorIdx = (liquid[segIdx] - 1).coerceIn(0, PALETTE_HEX.size - 1)
            liquidPaint.color = Color.parseColor(PALETTE_HEX[colorIdx])

            val segTop = liquidBottom - (segIdx + 1) * segH
            val segRect = RectF(x + 4f, segTop, x + w - 4f, liquidBottom - segIdx * segH)

            if (segIdx == 0) {
                val path = Path()
                path.addRoundRect(segRect, floatArrayOf(
                    0f, 0f, 0f, 0f,
                    corner, corner, corner, corner
                ), Path.Direction.CW)
                canvas.drawPath(path, liquidPaint)
            } else {
                canvas.drawRect(segRect, liquidPaint)
            }

            val meniscusRect = RectF(x + 8f, segTop + 2f, x + w - 8f, segTop + 6f)
            canvas.drawRoundRect(meniscusRect, 3f, 3f, highlightPaint)
        }

        canvas.drawRoundRect(rect, corner, corner, tubePaint)

        val streak = Path()
        streak.moveTo(x + 8f, y + 15f)
        streak.lineTo(x + 14f, y + 15f)
        streak.lineTo(x + 14f, y + h - corner)
        streak.lineTo(x + 8f, y + h - corner)
        streak.close()
        canvas.drawPath(streak, highlightPaint)

        val collarRect = RectF(x - 4f, y - 2f, x + w + 4f, y + 8f)
        canvas.drawRoundRect(collarRect, 4f, 4f, tubePaint)

        if (isSelected) {
            canvas.drawRoundRect(RectF(x - 6f, y - 6f, x + w + 6f, y + h + 6f), corner + 6f, corner + 6f, selectionGlowPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            val touched = pickTube(event.x, event.y)
            if (touched != null) {
                handleTubeTouch(touched)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun handleTubeTouch(tubeIndex: Int) {
        val currSelected = selectedIndex
        if (currSelected == null) {
            selectedIndex = tubeIndex
            animateLift(true)
        } else if (currSelected == tubeIndex) {
            animateLift(false) {
                selectedIndex = null
                invalidate()
            }
        } else {
            val from = currSelected
            val to = tubeIndex
            selectedIndex = null
            liftProgress = 0f
            invalidate()
            onTubePairSelected?.invoke(from, to)
        }
    }

    private fun animateLift(up: Boolean, onEnd: (() -> Unit)? = null) {
        liftAnimator?.cancel()
        liftAnimator = ValueAnimator.ofFloat(liftProgress, if (up) 1f else 0f).apply {
            duration = 180
            interpolator = OvershootInterpolator(1.2f)
            addUpdateListener {
                liftProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun triggerShake(tubeIndex: Int) {
        shakingIndex = tubeIndex
        ValueAnimator.ofFloat(0f, 20f, -20f, 15f, -15f, 0f).apply {
            duration = 320
            addUpdateListener {
                shakeOffset = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun pickTube(touchX: Float, touchY: Float): Int? {
        val p = puzzle ?: return null
        val count = p.tubes.size
        if (count == 0) return null

        val rows = if (count <= 5) 1 else 2
        val cols = (count + rows - 1) / rows
        val totalW = width.toFloat()
        val totalH = height.toFloat()
        val tubeW = minOf(totalW / (cols + 0.6f) * 0.7f, 130f)
        val tubeH = minOf(tubeW * 3.4f, totalH / (rows + 1f) * 0.75f)
        val rowH = totalH / rows

        for (i in 0 until count) {
            val r = if (rows == 1) 0 else (i / cols)
            val c = if (rows == 1) i else (i % cols)
            val rowCount = if (rows == 1) count else (if (r == 0) minOf(cols, count) else (count - cols))
            val rowStart = (totalW - (rowCount * tubeW + (rowCount - 1) * (tubeW * 0.45f))) / 2f
            val x = rowStart + c * (tubeW * 1.45f)
            val y = (r + 0.5f) * rowH - tubeH / 2f

            val hitRect = RectF(x - 15f, y - 30f, x + tubeW + 15f, y + tubeH + 20f)
            if (hitRect.contains(touchX, touchY)) {
                return i
            }
        }
        return null
    }
}
