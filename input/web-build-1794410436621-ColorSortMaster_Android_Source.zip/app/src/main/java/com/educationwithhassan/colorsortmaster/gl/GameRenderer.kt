package com.educationwithhassan.colorsortmaster.gl

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.SystemClock
import android.util.Log
import com.educationwithhassan.colorsortmaster.game.ColorSortPuzzle
import com.educationwithhassan.colorsortmaster.game.MoveRecord
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class GameRenderer(
    private val context: Context,
    val puzzle: ColorSortPuzzle,
    private val onError: (String) -> Unit
) : GLSurfaceView.Renderer {

    companion object {
        private const val TAG = "ColorSortMaster"

        val COLOR_PALETTE = arrayOf(
            floatArrayOf(0.94f, 0.27f, 0.27f, 1.0f), // 1: Ruby Red (#EF4444)
            floatArrayOf(0.23f, 0.51f, 0.96f, 1.0f), // 2: Ocean Blue (#3B82F6)
            floatArrayOf(0.92f, 0.70f, 0.03f, 1.0f), // 3: Sunshine Yellow (#EAB308)
            floatArrayOf(0.06f, 0.73f, 0.51f, 1.0f), // 4: Emerald Green (#10B981)
            floatArrayOf(0.55f, 0.36f, 0.96f, 1.0f), // 5: Purple (#8B5CF6)
            floatArrayOf(0.98f, 0.45f, 0.09f, 1.0f), // 6: Orange (#F97316)
            floatArrayOf(0.93f, 0.28f, 0.60f, 1.0f), // 7: Pink (#EC4899)
            floatArrayOf(0.02f, 0.71f, 0.83f, 1.0f), // 8: Cyan (#06B6D4)
            floatArrayOf(0.52f, 0.80f, 0.09f, 1.0f), // 9: Lime (#84CC16)
            floatArrayOf(0.08f, 0.72f, 0.65f, 1.0f), // 10: Teal (#14B8A6)
            floatArrayOf(0.96f, 0.62f, 0.04f, 1.0f), // 11: Amber (#F59E0B)
            floatArrayOf(0.39f, 0.40f, 0.95f, 1.0f)  // 12: Indigo (#6366F1)
        )
    }

    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)

    private var programId = 0
    private var uMVPMatrixHandle = -1
    private var uModelMatrixHandle = -1
    private var uColorHandle = -1
    private var uIsGlassHandle = -1
    private var aPositionHandle = -1
    private var aNormalHandle = -1

    private lateinit var tubeVertexBuffer: FloatBuffer
    private lateinit var tubeNormalBuffer: FloatBuffer
    private lateinit var tubeIndexBuffer: ShortBuffer
    private var tubeIndexCount = 0

    private lateinit var liquidVertexBuffer: FloatBuffer
    private lateinit var liquidNormalBuffer: FloatBuffer
    private lateinit var liquidIndexBuffer: ShortBuffer
    private var liquidIndexCount = 0

    var selectedTubeIndex: Int? = null
    private var pouringMove: MoveRecord? = null
    private var pourStartTime: Long = 0
    private var pourDurationMs: Long = 400
    private var shakingTubeIndex: Int? = null
    private var shakeStartTime: Long = 0

    var hasError = false
        private set

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        Log.i(TAG, "GameRenderer onSurfaceCreated started")
        GLES20.glClearColor(0.06f, 0.09f, 0.16f, 1.0f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        try {
            initShaders()
            initGeometry()
            Log.i(TAG, "GameRenderer initialized successfully with 3D shaders and tube geometry")
        } catch (t: Throwable) {
            Log.e(TAG, "GameRenderer initialization exception: " + t.message, t)
            hasError = true
            onError(t.message ?: "OpenGL ES 2.0 Initialization Failure")
        }
    }

    private fun initShaders() {
        val vertexShaderCode = "uniform mat4 u_MVPMatrix;\n" +
            "uniform mat4 u_ModelMatrix;\n" +
            "attribute vec4 a_Position;\n" +
            "attribute vec3 a_Normal;\n" +
            "varying vec3 v_Position;\n" +
            "varying vec3 v_Normal;\n" +
            "void main() {\n" +
            "    v_Position = vec3(u_ModelMatrix * a_Position);\n" +
            "    v_Normal = normalize(vec3(u_ModelMatrix * vec4(a_Normal, 0.0)));\n" +
            "    gl_Position = u_MVPMatrix * a_Position;\n" +
            "}\n"

        val fragmentShaderCode = "precision mediump float;\n" +
            "uniform vec4 u_Color;\n" +
            "uniform int u_IsGlass;\n" +
            "varying vec3 v_Position;\n" +
            "varying vec3 v_Normal;\n" +
            "void main() {\n" +
            "    vec3 lightDir = normalize(vec3(0.5, 1.0, 1.8));\n" +
            "    vec3 viewDir = normalize(vec3(0.0, 0.0, 1.0));\n" +
            "    float diff = max(dot(v_Normal, lightDir), 0.25);\n" +
            "    vec3 reflectDir = reflect(-lightDir, v_Normal);\n" +
            "    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 16.0);\n" +
            "    if (u_IsGlass == 1) {\n" +
            "        float rim = 1.0 - max(dot(v_Normal, viewDir), 0.0);\n" +
            "        float rimFactor = pow(rim, 2.2);\n" +
            "        vec4 glassTint = vec4(0.85, 0.95, 1.0, 0.22);\n" +
            "        vec4 rimGlow = vec4(0.9, 0.96, 1.0, 0.55) * rimFactor;\n" +
            "        vec4 specGlow = vec4(1.0, 1.0, 1.0, 0.65) * spec;\n" +
            "        gl_FragColor = glassTint + rimGlow + specGlow;\n" +
            "    } else {\n" +
            "        vec3 diffuseColor = u_Color.rgb * (diff * 0.75 + 0.25);\n" +
            "        vec3 specColor = vec3(1.0, 1.0, 1.0) * spec * 0.35;\n" +
            "        gl_FragColor = vec4(diffuseColor + specColor, u_Color.a);\n" +
            "    }\n" +
            "}\n"

        programId = ShaderHelper.createAndLinkProgram(vertexShaderCode, fragmentShaderCode)
        if (programId == 0) {
            throw RuntimeException("Failed to compile and link OpenGL ES 2.0 shaders")
        }

        uMVPMatrixHandle = GLES20.glGetUniformLocation(programId, "u_MVPMatrix")
        uModelMatrixHandle = GLES20.glGetUniformLocation(programId, "u_ModelMatrix")
        uColorHandle = GLES20.glGetUniformLocation(programId, "u_Color")
        uIsGlassHandle = GLES20.glGetUniformLocation(programId, "u_IsGlass")
        aPositionHandle = GLES20.glGetAttribLocation(programId, "a_Position")
        aNormalHandle = GLES20.glGetAttribLocation(programId, "a_Normal")
    }

    private fun initGeometry() {
        val segments = 24
        val radius = 0.42f
        val height = 2.4f

        val tubeVerts = mutableListOf<Float>()
        val tubeNorms = mutableListOf<Float>()
        val tubeIndices = mutableListOf<Short>()

        for (i in 0..segments) {
            val theta = (i.toFloat() / segments) * 2.0f * Math.PI.toFloat()
            val cosT = Math.cos(theta.toDouble()).toFloat()
            val sinT = Math.sin(theta.toDouble()).toFloat()

            tubeVerts.add(radius * cosT)
            tubeVerts.add(height / 2f)
            tubeVerts.add(radius * sinT)
            tubeNorms.add(cosT); tubeNorms.add(0f); tubeNorms.add(sinT)

            tubeVerts.add(radius * cosT)
            tubeVerts.add(-height / 2f)
            tubeVerts.add(radius * sinT)
            tubeNorms.add(cosT); tubeNorms.add(0f); tubeNorms.add(sinT)
        }

        for (i in 0 until segments) {
            val p0 = (i * 2).toShort()
            val p1 = (i * 2 + 1).toShort()
            val p2 = ((i + 1) * 2).toShort()
            val p3 = ((i + 1) * 2 + 1).toShort()

            tubeIndices.add(p0); tubeIndices.add(p1); tubeIndices.add(p2)
            tubeIndices.add(p2); tubeIndices.add(p1); tubeIndices.add(p3)
        }

        tubeIndexCount = tubeIndices.size
        tubeVertexBuffer = createFloatBuffer(tubeVerts.toFloatArray())
        tubeNormalBuffer = createFloatBuffer(tubeNorms.toFloatArray())
        tubeIndexBuffer = createShortBuffer(tubeIndices.toShortArray())

        val segHeight = height / 4.15f
        val liquidRadius = radius * 0.92f
        val liqVerts = mutableListOf<Float>()
        val liqNorms = mutableListOf<Float>()
        val liqIndices = mutableListOf<Short>()

        for (i in 0..segments) {
            val theta = (i.toFloat() / segments) * 2.0f * Math.PI.toFloat()
            val cosT = Math.cos(theta.toDouble()).toFloat()
            val sinT = Math.sin(theta.toDouble()).toFloat()

            liqVerts.add(liquidRadius * cosT)
            liqVerts.add(segHeight / 2f)
            liqVerts.add(liquidRadius * sinT)
            liqNorms.add(cosT); liqNorms.add(0.2f); liqNorms.add(sinT)

            liqVerts.add(liquidRadius * cosT)
            liqVerts.add(-segHeight / 2f)
            liqVerts.add(liquidRadius * sinT)
            liqNorms.add(cosT); liqNorms.add(-0.2f); liqNorms.add(sinT)
        }

        for (i in 0 until segments) {
            val p0 = (i * 2).toShort()
            val p1 = (i * 2 + 1).toShort()
            val p2 = ((i + 1) * 2).toShort()
            val p3 = ((i + 1) * 2 + 1).toShort()

            liqIndices.add(p0); liqIndices.add(p1); liqIndices.add(p2)
            liqIndices.add(p2); liqIndices.add(p1); liqIndices.add(p3)
        }

        liquidIndexCount = liqIndices.size
        liquidVertexBuffer = createFloatBuffer(liqVerts.toFloatArray())
        liquidNormalBuffer = createFloatBuffer(liqNorms.toFloatArray())
        liquidIndexBuffer = createShortBuffer(liqIndices.toShortArray())
    }

    private fun createFloatBuffer(array: FloatArray): FloatBuffer {
        return ByteBuffer.allocateDirect(array.size * 4).run {
            order(ByteOrder.nativeOrder())
            asFloatBuffer().apply {
                put(array)
                position(0)
            }
        }
    }

    private fun createShortBuffer(array: ShortArray): ShortBuffer {
        return ByteBuffer.allocateDirect(array.size * 2).run {
            order(ByteOrder.nativeOrder())
            asShortBuffer().apply {
                put(array)
                position(0)
            }
        }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        Log.i(TAG, "GameRenderer onSurfaceChanged: " + width + "x" + height)
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / maxOf(1, height).toFloat()
        val fov = 45.0f
        val near = 1.0f
        val far = 25.0f
        val top = near * Math.tan(fov * Math.PI / 360.0).toFloat()
        val bottom = -top
        val left = bottom * ratio
        val right = top * ratio
        Matrix.frustumM(projectionMatrix, 0, left, right, bottom, top, near, far)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (hasError) return

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(programId)

        Matrix.setLookAtM(viewMatrix, 0, 0f, 0.4f, 8.2f, 0f, 0.0f, 0f, 0f, 1f, 0f)

        val tubes = puzzle.tubes
        val count = tubes.size
        if (count == 0) return

        val rows = if (count <= 5) 1 else 2
        val cols = (count + rows - 1) / rows
        val spacingX = minOf(1.25f, 5.0f / maxOf(1, cols))
        val rowOffsetY = if (rows == 1) 0.0f else 1.55f

        val now = SystemClock.uptimeMillis()

        for (i in 0 until count) {
            val row = if (rows == 1) 0 else (i / cols)
            val col = if (rows == 1) i else (i % cols)
            val rowItems = if (rows == 1) count else (if (row == 0) minOf(cols, count) else (count - cols))
            val startX = -(rowItems - 1) * spacingX / 2.0f
            var posX = startX + col * spacingX
            var posY = if (rows == 1) 0.0f else (if (row == 0) rowOffsetY else -rowOffsetY)
            var rotZ = 0.0f

            if (i == selectedTubeIndex) {
                posY += 0.55f
            }

            pouringMove?.let { move ->
                if (move.from == i) {
                    val progress = (now - pourStartTime).toFloat() / pourDurationMs.coerceAtLeast(1)
                    if (progress < 1.0f) {
                        posY += 0.55f
                        rotZ = if (move.to > move.from) -25f * progress else 25f * progress
                    } else {
                        pouringMove = null
                    }
                }
            }

            if (i == shakingTubeIndex) {
                val shakeElapsed = (now - shakeStartTime).toFloat()
                if (shakeElapsed < 300) {
                    val shakeOffset = Math.sin(shakeElapsed.toDouble() * 0.05).toFloat() * 0.08f
                    posX += shakeOffset
                } else {
                    shakingTubeIndex = null
                }
            }

            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, posX, posY, 0f)
            if (rotZ != 0.0f) {
                Matrix.rotateM(modelMatrix, 0, rotZ, 0f, 0f, 1f)
            }

            val liquidLayers = tubes[i]
            val segHeight = 2.4f / 4.15f
            for (layerIdx in 0 until liquidLayers.size) {
                val colorVal = liquidLayers[layerIdx]
                val paletteIdx = (colorVal - 1).coerceIn(0, COLOR_PALETTE.size - 1)
                val colorRgba = COLOR_PALETTE[paletteIdx]

                val layerModelMatrix = FloatArray(16)
                System.arraycopy(modelMatrix, 0, layerModelMatrix, 0, 16)
                val layerY = -1.2f + (layerIdx + 0.5f) * segHeight
                Matrix.translateM(layerModelMatrix, 0, 0f, layerY, 0f)

                Matrix.multiplyMM(mvpMatrix, 0, viewMatrix, 0, layerModelMatrix, 0)
                Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvpMatrix, 0)

                GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mvpMatrix, 0)
                GLES20.glUniformMatrix4fv(uModelMatrixHandle, 1, false, layerModelMatrix, 0)
                GLES20.glUniform4fv(uColorHandle, 1, colorRgba, 0)
                GLES20.glUniform1i(uIsGlassHandle, 0)

                GLES20.glEnableVertexAttribArray(aPositionHandle)
                GLES20.glVertexAttribPointer(aPositionHandle, 3, GLES20.GL_FLOAT, false, 0, liquidVertexBuffer)

                GLES20.glEnableVertexAttribArray(aNormalHandle)
                GLES20.glVertexAttribPointer(aNormalHandle, 3, GLES20.GL_FLOAT, false, 0, liquidNormalBuffer)

                GLES20.glDrawElements(GLES20.GL_TRIANGLES, liquidIndexCount, GLES20.GL_UNSIGNED_SHORT, liquidIndexBuffer)
            }

            Matrix.multiplyMM(mvpMatrix, 0, viewMatrix, 0, modelMatrix, 0)
            Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvpMatrix, 0)

            GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mvpMatrix, 0)
            GLES20.glUniformMatrix4fv(uModelMatrixHandle, 1, false, modelMatrix, 0)
            GLES20.glUniform4f(uColorHandle, 0.9f, 0.95f, 1.0f, 0.25f)
            GLES20.glUniform1i(uIsGlassHandle, 1)

            GLES20.glEnableVertexAttribArray(aPositionHandle)
            GLES20.glVertexAttribPointer(aPositionHandle, 3, GLES20.GL_FLOAT, false, 0, tubeVertexBuffer)

            GLES20.glEnableVertexAttribArray(aNormalHandle)
            GLES20.glVertexAttribPointer(aNormalHandle, 3, GLES20.GL_FLOAT, false, 0, tubeNormalBuffer)

            GLES20.glDrawElements(GLES20.GL_TRIANGLES, tubeIndexCount, GLES20.GL_UNSIGNED_SHORT, tubeIndexBuffer)
        }
    }

    fun pickTube(screenX: Float, screenY: Float, width: Int, height: Int): Int? {
        val total = puzzle.tubes.size
        if (total == 0) return null

        val rows = if (total <= 5) 1 else 2
        val cols = (total + rows - 1) / rows

        val touchRow = if (rows == 1) 0 else {
            if (screenY < height * 0.5f) 0 else 1
        }
        val colWidth = width.toFloat() / cols
        val touchCol = (screenX / colWidth).toInt().coerceIn(0, cols - 1)
        val index = if (rows == 1) touchCol else (touchRow * cols + touchCol)
        return if (index in 0 until total) index else null
    }

    fun setSelectedTube(index: Int?) {
        selectedTubeIndex = index
    }

    fun startPourAnimation(move: MoveRecord) {
        pouringMove = move
        pourStartTime = SystemClock.uptimeMillis()
    }

    fun shakeTube(tubeIndex: Int) {
        shakingTubeIndex = tubeIndex
        shakeStartTime = SystemClock.uptimeMillis()
    }
}
