package com.educationwithhassan.colorsortmaster.game

import java.util.Random

object LevelGenerator {

    fun generate(level: Int): List<List<Int>> {
        val rand = Random(level * 7919L + 1337L)
        val colorCount = when {
            level <= 5 -> 2
            level <= 20 -> 3
            level <= 50 -> 4
            level <= 100 -> 5
            level <= 200 -> 6
            level <= 350 -> 7
            else -> 8
        }
        val emptyCount = 2
        val scrambleSteps = 14 + (level / 12)

        val tubes = mutableListOf<MutableList<Int>>()
        for (c in 1..colorCount) {
            tubes.add(mutableListOf(c, c, c, c))
        }
        repeat(emptyCount) {
            tubes.add(mutableListOf())
        }

        repeat(scrambleSteps) {
            val nonEmpties = tubes.filter { it.isNotEmpty() }
            val nonFulls = tubes.filter { it.size < 4 }
            if (nonEmpties.isNotEmpty() && nonFulls.size > 1) {
                val from = nonEmpties[rand.nextInt(nonEmpties.size)]
                val validTargets = nonFulls.filter { it !== from }
                if (validTargets.isNotEmpty()) {
                    val to = validTargets[rand.nextInt(validTargets.size)]
                    to.add(from.removeAt(from.size - 1))
                }
            }
        }
        return tubes
    }
}
