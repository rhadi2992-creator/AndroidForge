# Keep Google Mobile Ads SDK classes
-keep public class com.google.android.gms.ads.** {
   public *;
}
-keep public class com.google.ads.** {
   public *;
}

# Keep UMP SDK
-keep class com.google.android.ump.** { *; }

# Keep OpenGL ES models & Puzzle classes
-keep class com.educationwithhassan.colorsortmaster.gl.** { *; }
-keep class com.educationwithhassan.colorsortmaster.game.** { *; }
-keep class com.educationwithhassan.colorsortmaster.admob.** { *; }
