package com.educationwithhassan.colorsortmaster.game

import java.util.Random

object LevelGenerator {

    fun generate(level: Int): List<List<Int>> {
        val rand = Random(level * 7919L + 1337L)
        val colorCount = when {
            level <= 20 -> if (level <= 8) 2 else 3
            level <= 75 -> if (level <= 45) 3 else 4
            level <= 175 -> minOf(7, 5 + ((level - 76) / 50))
            level <= 300 -> minOf(10, 7 + ((level - 176) / 45))
            else -> minOf(12, 9 + ((level - 301) / 70))
        }
        val emptyCount = 2
        val scrambleSteps = 12 + (level / 10)

        val tubes = mutableListOf<MutableList<Int>>()
        for (c in 1..colorCount) {
            tubes.add(mutableListOf(c, c, c, c))
        }
        repeat(emptyCount) {
            tubes.add(mutableListOf())
        }

        // Reverse scramble to guarantee solvability
        repeat(scrambleSteps) {
            val nonEmpties = tubes.filter { it.isNotEmpty() }
            val nonFulls = tubes.filter { it.size < 4 }
            if (nonEmpties.isNotEmpty() && nonFulls.size > 1) {
                val from = nonEmpties[rand.nextInt(nonEmpties.size)]
                val validTargets = nonFulls.filter { it !== from }
                if (validTargets.isNotEmpty()) {
                    val to = validTargets[rand.nextInt(validTargets.size)]
                    to.add(from.removeAt(from.size - 1))
                }
            }
        }
        return tubes
    }
}
