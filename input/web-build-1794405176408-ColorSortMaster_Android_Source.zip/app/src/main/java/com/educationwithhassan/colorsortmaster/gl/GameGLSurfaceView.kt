package com.educationwithhassan.colorsortmaster.gl

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import com.educationwithhassan.colorsortmaster.game.ColorSortPuzzle
import com.educationwithhassan.colorsortmaster.game.MoveRecord

class GameGLSurfaceView(
    context: Context,
    val puzzle: ColorSortPuzzle,
    val onTubePairSelected: (Int, Int) -> Unit
) : GLSurfaceView(context) {

    private val renderer: GameRenderer
    private var selectedIndex: Int? = null

    init {
        setEGLContextClientVersion(2)
        renderer = GameRenderer(context, puzzle)
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            val touchedIndex = renderer.pickTube(event.x, event.y, width, height)
            if (touchedIndex != null) {
                if (selectedIndex == null) {
                    selectedIndex = touchedIndex
                    renderer.setSelectedTube(touchedIndex)
                } else {
                    val from = selectedIndex!!
                    val to = touchedIndex
                    selectedIndex = null
                    renderer.setSelectedTube(null)
                    onTubePairSelected(from, to)
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    fun triggerPourAnimation(move: MoveRecord) {
        renderer.startPourAnimation(move)
    }

    fun triggerInvalidShake(tubeIndex: Int) {
        renderer.shakeTube(tubeIndex)
    }
}
