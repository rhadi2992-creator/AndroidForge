package com.educationwithhassan.colorsortmaster.admob

/**
 * AdMob Configuration for Color Sort Master – 3D Cartoon Puzzle
 * Publisher: pub-3133971041724338
 *
 * NOTE: Rewarded Interstitial has NOT been supplied.
 * It is intentionally left null and disabled to strictly prevent reusing the Rewarded ID.
 */
object AdMobConfig {
    const val PUBLISHER_ID = "pub-3133971041724338"
    const val ADMOB_APP_ID = "ca-app-pub-3133971041724338~8129645068"

    // Exact Production Ad Unit IDs
    const val PROD_BANNER = "ca-app-pub-3133971041724338/4473791883"
    const val PROD_APP_OPEN = "ca-app-pub-3133971041724338/6624991702"
    const val PROD_INTERSTITIAL = "ca-app-pub-3133971041724338/2083111465"
    const val PROD_NATIVE_ADVANCED = "ca-app-pub-3133971041724338/1847628540"
    const val PROD_REWARDED = "ca-app-pub-3133971041724338/1955118953"

    // Rewarded Interstitial: NOT supplied. Strictly NOT reusing the Rewarded ID.
    val PROD_REWARDED_INTERSTITIAL: String? = null

    // Google's Official Test IDs (Used in debug builds)
    object TestIds {
        const val BANNER = "ca-app-pub-3940256099942544/6300978111"
        const val INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"
        const val REWARDED = "ca-app-pub-3940256099942544/5224354917"
        const val NATIVE = "ca-app-pub-3940256099942544/2247696110"
        const val APP_OPEN = "ca-app-pub-3940256099942544/9257895782"
    }

    // Dynamic resolution based on build type
    var useTestAds: Boolean = false

    fun getBannerId(): String = if (useTestAds) TestIds.BANNER else PROD_BANNER
    fun getAppOpenId(): String = if (useTestAds) TestIds.APP_OPEN else PROD_APP_OPEN
    fun getInterstitialId(): String = if (useTestAds) TestIds.INTERSTITIAL else PROD_INTERSTITIAL
    fun getNativeId(): String = if (useTestAds) TestIds.NATIVE else PROD_NATIVE_ADVANCED
    fun getRewardedId(): String = if (useTestAds) TestIds.REWARDED else PROD_REWARDED

    // Policy and frequency constants
    const val INTERSTITIAL_LEVEL_INTERVAL = 3
    const val INTERSTITIAL_COOLDOWN_MS = 60_000L
    const val APP_OPEN_EXPIRY_HOURS = 4L
}
