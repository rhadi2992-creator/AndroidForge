package com.educationwithhassan.colorsortmaster

import android.content.res.Configuration
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.educationwithhassan.colorsortmaster.admob.AdMobManager
import com.educationwithhassan.colorsortmaster.data.SaveSystem
import com.educationwithhassan.colorsortmaster.game.ColorSortPuzzle
import com.educationwithhassan.colorsortmaster.gl.GameGLSurfaceView

class MainActivity : AppCompatActivity() {

    private lateinit var glSurfaceView: GameGLSurfaceView
    private lateinit var puzzle: ColorSortPuzzle
    private lateinit var adMobManager: AdMobManager
    private lateinit var saveSystem: SaveSystem
    private lateinit var rootLayout: FrameLayout
    private lateinit var bannerContainer: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        saveSystem = SaveSystem(this)
        puzzle = ColorSortPuzzle(saveSystem.getCurrentLevel())
        
        rootLayout = FrameLayout(this)
        glSurfaceView = GameGLSurfaceView(this, puzzle) { fromIdx, toIdx ->
            onMoveAttempt(fromIdx, toIdx)
        }
        rootLayout.addView(glSurfaceView)

        // Anchored adaptive banner container anchored to the bottom
        bannerContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        }
        rootLayout.addView(bannerContainer)
        setContentView(rootLayout)

        // Initialize AdMob with official IDs & UMP
        adMobManager = AdMobManager(this)
        adMobManager.initialize(
            onConsentReady = {
                adMobManager.loadAnchoredAdaptiveBanner(bannerContainer)
                adMobManager.preloadInterstitial()
                adMobManager.preloadRewarded()
                adMobManager.preloadAppOpen()
            }
        )
    }

    private fun onMoveAttempt(fromIdx: Int, toIdx: Int) {
        val move = puzzle.pour(fromIdx, toIdx)
        if (move != null) {
            glSurfaceView.triggerPourAnimation(move)
            if (puzzle.isSolved()) {
                saveSystem.markLevelComplete(puzzle.currentLevel)
                Toast.makeText(this, "Level Completed! +100 Coins", Toast.LENGTH_SHORT).show()
                
                // Show natural transition interstitial with cooldown cap
                adMobManager.showInterstitialOnLevelComplete {
                    puzzle.loadLevel(puzzle.currentLevel + 1)
                }
            }
        } else {
            glSurfaceView.triggerInvalidShake(fromIdx)
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Dynamically recalculate adaptive banner dimensions
        adMobManager.onConfigurationChanged(newConfig)
    }

    override fun onResume() {
        super.onResume()
        glSurfaceView.onResume()
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        adMobManager.onDestroy()
    }
}
