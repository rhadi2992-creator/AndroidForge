package com.educationwithhassan.colorsortmaster.data

import android.content.Context
import android.content.SharedPreferences

class SaveSystem(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("csm_save_data", Context.MODE_PRIVATE)

    fun getCurrentLevel(): Int = prefs.getInt("key_current_level", 1)

    fun markLevelComplete(level: Int) {
        val next = maxOf(getCurrentLevel(), level + 1)
        prefs.edit().putInt("key_current_level", next).apply()
        addCoins(100)
    }

    fun getCoins(): Int = prefs.getInt("key_coins", 250)

    fun addCoins(amount: Int) {
        val cur = getCoins()
        prefs.edit().putInt("key_coins", cur + amount).apply()
    }
}
