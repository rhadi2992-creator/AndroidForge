<?php
/**
 * SpinReward Pro — PDO Database Connection Singleton
 * File: backend-api/database.php
 *
 * Compatible with PHP 8.2+ and MySQL 8.0+ / MariaDB 10.4+ (XAMPP).
 */

declare(strict_types=1);

final class Database
{
    private static ?PDO $instance = null;

    public static function getConnection(): PDO
    {
        if (self::$instance !== null) {
            return self::$instance;
        }

        $config = require __DIR__ . '/config.php';
        $tz = (string)($config['app']['timezone'] ?? 'UTC');
        if ($tz !== '') {
            date_default_timezone_set($tz);
        }

        $db = $config['db'];

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $db['host'],
            (int)$db['port'],
            $db['name'],
            $db['charset']
        );

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci, time_zone = '+00:00'",
        ];

        try {
            self::$instance = new PDO($dsn, (string)$db['user'], (string)$db['pass'], $options);
        } catch (PDOException $e) {
            // Throw sanitized exception so DB credentials never appear in uncaught stack traces
            throw new RuntimeException(
                sprintf(
                    'Database connection failed (%s:%d/%s). Ensure MySQL/MariaDB is running and check backend-api/config.php.',
                    $db['host'],
                    (int)$db['port'],
                    $db['name']
                ),
                (int)$e->getCode()
            );
        }

        return self::$instance;
    }
}
