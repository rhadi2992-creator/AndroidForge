<?php
/**
 * GET /api/v1/wallet/summary.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';

Security::requireMethod('GET');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

$wStmt = $pdo->prepare('SELECT * FROM cash_wallets WHERE user_id = ? LIMIT 1');
$wStmt->execute([$userId]);
$wallet = $wStmt->fetch() ?: [
    'available_balance_pkr'      => '0.00',
    'pending_withdrawal_pkr'     => '0.00',
    'approved_task_earnings_pkr' => '0.00',
    'referral_cash_earnings_pkr' => '0.00',
    'total_withdrawn_pkr'        => '0.00',
];

$wrStmt = $pdo->prepare(
    'SELECT id, reference_id, payment_method, account_holder_name, account_number, amount_pkr,
            status, payment_reference, admin_note, created_at, processed_at
     FROM withdrawal_requests WHERE user_id = ? ORDER BY id DESC LIMIT 20'
);
$wrStmt->execute([$userId]);

$txStmt = $pdo->prepare(
    'SELECT id, reference_id, tx_type, amount_pkr, balance_after_pkr, description, created_at
     FROM wallet_transactions WHERE user_id = ? ORDER BY id DESC LIMIT 25'
);
$txStmt->execute([$userId]);

$minWithdraw = (float)Security::getSetting($pdo, 'minimum_withdrawal_pkr', '100');
$methods = array_map('trim', explode(',', Security::getSetting($pdo, 'payment_methods', 'JazzCash,Easypaisa')));

Response::json(200, true, 'Wallet summary loaded.', [
    'available_balance_pkr'      => (float)$wallet['available_balance_pkr'],
    'pending_withdrawal_pkr'     => (float)$wallet['pending_withdrawal_pkr'],
    'approved_task_earnings_pkr' => (float)$wallet['approved_task_earnings_pkr'],
    'referral_cash_earnings_pkr' => (float)$wallet['referral_cash_earnings_pkr'],
    'total_withdrawn_pkr'        => (float)$wallet['total_withdrawn_pkr'],
    'minimum_withdrawal_pkr'     => $minWithdraw,
    'payment_methods'            => $methods,
    'withdrawals'                => $wrStmt->fetchAll(),
    'recent_transactions'        => $txStmt->fetchAll(),
]);
