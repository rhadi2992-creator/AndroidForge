<?php
/**
 * POST /api/v1/wallet/withdraw.php
 * Safe atomic withdrawal request:
 * - Supports JazzCash and Easypaisa
 * - Enforces admin-configured minimum (default Rs. 100)
 * - Verifies available cash balance >= amount
 * - Blocks duplicate withdrawal requests (pending check + idempotency_key)
 * - Moves funds from available_balance_pkr to pending_withdrawal_pkr atomically
 * - Cash eligibility depends strictly on approved tasks & referral program, never ads or spin points
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';
require_once __DIR__ . '/../../../helpers/RateLimiter.php';

Security::requireMethod('POST');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

RateLimiter::enforce('withdraw_' . $userId, 5, 600);

$body = Response::readJsonBody();
$method         = trim((string)($body['payment_method'] ?? ''));
$holderName     = trim((string)($body['account_holder_name'] ?? ''));
$accountNumber  = preg_replace('/\s+/', '', trim((string)($body['account_number'] ?? '')));
$amount         = round((float)($body['amount_pkr'] ?? 0), 2);
$idempotencyKey = trim((string)($body['idempotency_key'] ?? ''));

$allowedMethods = array_map('trim', explode(',', Security::getSetting($pdo, 'payment_methods', 'JazzCash,Easypaisa')));
if (!in_array($method, $allowedMethods, true)) {
    Response::json(422, false, 'Unsupported payment method. Choose JazzCash or Easypaisa.');
}
if (mb_strlen($holderName) < 3 || mb_strlen($holderName) > 120) {
    Response::json(422, false, 'Please enter a valid account holder name.');
}
if (!preg_match('/^03[0-9]{9}$/', $accountNumber)) {
    Response::json(422, false, 'Please enter a valid 11-digit mobile account number (03XXXXXXXXX).');
}
if (strlen($idempotencyKey) < 16 || strlen($idempotencyKey) > 80) {
    Response::json(422, false, 'Valid idempotency_key is required.');
}

$minWithdraw = (float)Security::getSetting($pdo, 'minimum_withdrawal_pkr', '100');
if ($amount < $minWithdraw) {
    Response::json(422, false, "Minimum withdrawal amount is Rs. " . number_format($minWithdraw, 2) . ".");
}

$pdo->beginTransaction();
try {
    // Prevent duplicate request via idempotency key
    $dup = $pdo->prepare('SELECT id, reference_id FROM withdrawal_requests WHERE idempotency_key = ? LIMIT 1');
    $dup->execute([$idempotencyKey]);
    if ($existing = $dup->fetch()) {
        $pdo->rollBack();
        Response::json(409, false, 'Duplicate withdrawal request blocked.', ['reference_id' => $existing['reference_id']]);
    }

    // Prevent concurrent pending withdrawal spam
    $pendingStmt = $pdo->prepare('SELECT COUNT(*) FROM withdrawal_requests WHERE user_id = ? AND status IN ("pending", "approved")');
    $pendingStmt->execute([$userId]);
    if ((int)$pendingStmt->fetchColumn() > 0) {
        $pdo->rollBack();
        Response::json(409, false, 'You already have an active withdrawal request under review.');
    }

    // Lock wallet row
    $wStmt = $pdo->prepare(
        'SELECT available_balance_pkr, approved_task_earnings_pkr, referral_cash_earnings_pkr
         FROM cash_wallets WHERE user_id = ? FOR UPDATE'
    );
    $wStmt->execute([$userId]);
    $wallet = $wStmt->fetch();

    if (!$wallet || (float)$wallet['available_balance_pkr'] < $amount) {
        $pdo->rollBack();
        Response::json(422, false, 'Insufficient available cash balance.');
    }

    // Integrity check: ensure cash balance originates from genuine approved tasks / referral program
    $legitSourceTotal = (float)$wallet['approved_task_earnings_pkr'] + (float)$wallet['referral_cash_earnings_pkr'];
    if ($legitSourceTotal < $amount) {
        $pdo->rollBack();
        Response::json(403, false, 'Withdrawal requires verified cash task or referral program earnings.');
    }

    // Fraud heuristic check: shared account number across multiple users
    $sharedAcctStmt = $pdo->prepare('SELECT COUNT(DISTINCT user_id) FROM withdrawal_requests WHERE account_number = ? AND user_id != ?');
    $sharedAcctStmt->execute([$accountNumber, $userId]);
    $fraudFlag = ((int)$sharedAcctStmt->fetchColumn() > 0) ? 1 : 0;

    $newAvailable = round((float)$wallet['available_balance_pkr'] - $amount, 2);
    $refId = Security::generateUniqueRefId('WDR');

    $pdo->prepare(
        'UPDATE cash_wallets
         SET available_balance_pkr = available_balance_pkr - ?,
             pending_withdrawal_pkr = pending_withdrawal_pkr + ?
         WHERE user_id = ?'
    )->execute([$amount, $amount, $userId]);

    $pdo->prepare(
        'INSERT INTO withdrawal_requests
         (user_id, reference_id, payment_method, account_holder_name, account_number, amount_pkr, status, fraud_flag, idempotency_key)
         VALUES (?, ?, ?, ?, ?, ?, "pending", ?, ?)'
    )->execute([$userId, $refId, $method, $holderName, $accountNumber, $amount, $fraudFlag, $idempotencyKey]);
    $wrId = (int)$pdo->lastInsertId();

    $txRef = Security::generateUniqueRefId('TXN');
    $pdo->prepare(
        'INSERT INTO wallet_transactions (user_id, reference_id, tx_type, amount_pkr, balance_after_pkr, description, related_entity_id)
         VALUES (?, ?, "withdrawal_hold", ?, ?, ?, ?)'
    )->execute([$userId, $txRef, -$amount, $newAvailable, "Withdrawal hold ({$method} {$accountNumber})", $wrId]);

    $pdo->prepare(
        'INSERT INTO notifications (user_id, title, message, category) VALUES (?, ?, ?, "wallet")'
    )->execute([
        $userId,
        'Withdrawal Request Submitted',
        "Your {$method} withdrawal for Rs. " . number_format($amount, 2) . " ({$refId}) is pending review.",
    ]);

    Security::writeAuditLog($pdo, 'user', $userId, 'withdrawal_requested', 'withdrawal_request', $wrId, [
        'reference_id' => $refId,
        'amount_pkr'   => $amount,
        'method'       => $method,
        'fraud_flag'   => $fraudFlag,
    ]);

    $pdo->commit();

    Response::json(201, true, 'Withdrawal request submitted safely.', [
        'reference_id'          => $refId,
        'available_balance_pkr' => $newAvailable,
        'status'                => 'pending',
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    Response::json(500, false, 'Failed to process withdrawal request.');
}
