<?php
/**
 * POST /api/v1/auth/register.php
 * Registers a new Android user, initializes cash_wallet + user_non_cash_points,
 * and handles anti-abuse referral linking.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';
require_once __DIR__ . '/../../../helpers/RateLimiter.php';

Security::requireMethod('POST');
RateLimiter::enforce('register_' . Security::clientIp(), 10, 3600);

$body = Response::readJsonBody();
$fullName     = trim((string)($body['full_name'] ?? ''));
$email        = strtolower(trim((string)($body['email'] ?? '')));
$phone        = trim((string)($body['phone'] ?? ''));
$password     = (string)($body['password'] ?? '');
$referralInput = strtoupper(trim((string)($body['referral_code'] ?? '')));
$deviceFp     = substr(trim((string)($body['device_fingerprint'] ?? '')), 0, 128);

if (mb_strlen($fullName) < 2 || mb_strlen($fullName) > 120) {
    Response::json(422, false, 'Full name must be between 2 and 120 characters.');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    Response::json(422, false, 'Please enter a valid email address.');
}
if (strlen($password) < 8) {
    Response::json(422, false, 'Password must be at least 8 characters long.');
}

$pdo = Database::getConnection();
$ip  = Security::clientIp();

$dup = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
$dup->execute([$email]);
if ($dup->fetchColumn()) {
    Response::json(409, false, 'An account with this email already exists.');
}

$referrerId = null;
$fraudReason = null;

if ($referralInput !== '') {
    $refStmt = $pdo->prepare('SELECT id, email, signup_ip, device_fingerprint, status FROM users WHERE referral_code = ? LIMIT 1');
    $refStmt->execute([$referralInput]);
    $referrer = $refStmt->fetch();

    if (!$referrer || $referrer['status'] !== 'active') {
        Response::json(422, false, 'Invalid or inactive referral code.');
    }

    // Prevent self-referral or duplicate device/IP referral abuse
    if ($referrer['email'] === $email) {
        Response::json(422, false, 'Self-referrals are not permitted.');
    }
    if ($deviceFp !== '' && $referrer['device_fingerprint'] === $deviceFp) {
        $fraudReason = 'Matching device fingerprint with referrer';
    } elseif ($referrer['signup_ip'] === $ip && $ip !== '127.0.0.1') {
        $fraudReason = 'Matching signup IP address with referrer';
    }
    $referrerId = (int)$referrer['id'];
}

$pdo->beginTransaction();
try {
    $myRefCode = Security::generateReferralCode($pdo);
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $ins = $pdo->prepare(
        'INSERT INTO users (full_name, email, phone, password_hash, referral_code, referred_by_user_id, device_fingerprint, signup_ip)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $ins->execute([$fullName, $email, $phone ?: null, $hash, $myRefCode, $referrerId, $deviceFp ?: null, $ip]);
    $userId = (int)$pdo->lastInsertId();

    $pdo->prepare('INSERT INTO cash_wallets (user_id) VALUES (?)')->execute([$userId]);
    $pdo->prepare('INSERT INTO user_non_cash_points (user_id) VALUES (?)')->execute([$userId]);

    if ($referrerId !== null) {
        $refStatus = $fraudReason ? 'rejected' : 'pending';
        $pdo->prepare(
            'INSERT INTO referrals (referrer_user_id, referred_user_id, status, fraud_reason) VALUES (?, ?, ?, ?)'
        )->execute([$referrerId, $userId, $refStatus, $fraudReason]);
    }

    $pdo->prepare(
        'INSERT INTO notifications (user_id, title, message, category) VALUES (?, ?, ?, ?)'
    )->execute([
        $userId,
        'Welcome to SpinReward Pro',
        'You receive 5 free daily spins for non-cash perks, plus verified cash tasks you can withdraw via JazzCash or Easypaisa.',
        'system',
    ]);

    // Issue session token immediately
    $rawToken = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $rawToken);
    $config = require __DIR__ . '/../../../config.php';
    $ttlDays = max(1, (int)$config['app']['token_ttl_days']);

    $pdo->prepare(
        sprintf(
            'INSERT INTO user_sessions (user_id, token_hash, device_id, ip_address, user_agent, expires_at)
             VALUES (?, ?, ?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL %d DAY))',
            $ttlDays
        )
    )->execute([
        $userId,
        $tokenHash,
        $deviceFp ?: null,
        $ip,
        substr($_SERVER['HTTP_USER_AGENT'] ?? 'Android', 0, 255),
    ]);

    Security::writeAuditLog($pdo, 'user', $userId, 'user_registered', 'user', $userId, ['referred_by' => $referrerId]);
    $pdo->commit();

    Response::json(201, true, 'Registration successful.', [
        'token' => $rawToken,
        'user'  => [
            'id'            => $userId,
            'full_name'     => $fullName,
            'email'         => $email,
            'referral_code' => $myRefCode,
        ],
    ]);
} catch (Throwable $e) {
    $pdo->rollBack();
    Response::json(500, false, 'Unable to complete registration.');
}
