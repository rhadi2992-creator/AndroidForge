<?php
/**
 * POST /api/v1/auth/logout.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';

Security::requireMethod('POST');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);

$pdo->prepare('UPDATE user_sessions SET revoked_at = UTC_TIMESTAMP() WHERE id = ?')
    ->execute([(int)$user['session_id']]);

Response::json(200, true, 'Logged out successfully.');
