<?php
/**
 * GET /api/v1/spin/wheel.php
 * Returns server-configured wheel slices (<500 pts), remaining spins (server UTC), and recent spins.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';

Security::requireMethod('GET');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

$todayUtc = gmdate('Y-m-d');
$dailyLimit = (int)Security::getSetting($pdo, 'daily_spin_limit', '5');
$spinsEnabled = Security::getSetting($pdo, 'spins_enabled', '1') === '1';

$usedStmt = $pdo->prepare('SELECT COUNT(*) FROM spin_history WHERE user_id = ? AND spin_date_utc = ?');
$usedStmt->execute([$userId, $todayUtc]);
$spinsUsed = (int)$usedStmt->fetchColumn();

$slices = $pdo->query(
    'SELECT id, slice_index, label, points_value, slice_color
     FROM spin_reward_settings
     WHERE is_active = 1 AND points_value < 500
     ORDER BY slice_index ASC'
)->fetchAll();

$recentStmt = $pdo->prepare(
    'SELECT sh.id, sh.points_awarded, sh.spin_date_utc, sh.created_at, srs.label
     FROM spin_history sh
     INNER JOIN spin_reward_settings srs ON srs.id = sh.slice_id
     WHERE sh.user_id = ?
     ORDER BY sh.id DESC
     LIMIT 10'
);
$recentStmt->execute([$userId]);

$pointsStmt = $pdo->prepare('SELECT points_balance FROM user_non_cash_points WHERE user_id = ?');
$pointsStmt->execute([$userId]);
$pointsBalance = (int)($pointsStmt->fetchColumn() ?: 0);

Response::json(200, true, 'Spin wheel data loaded.', [
    'spins_enabled'    => $spinsEnabled,
    'server_date_utc'  => $todayUtc,
    'daily_limit'      => $dailyLimit,
    'used_today'       => $spinsUsed,
    'remaining_today'  => max(0, $dailyLimit - $spinsUsed),
    'points_balance'   => $pointsBalance,
    'slices'           => array_map(static fn($s) => [
        'id'           => (int)$s['id'],
        'slice_index'  => (int)$s['slice_index'],
        'label'        => $s['label'],
        'points_value' => (int)$s['points_value'],
        'slice_color'  => $s['slice_color'],
    ], $slices),
    'recent_spins'     => $recentStmt->fetchAll(),
]);
