<?php
/**
 * SpinReward Pro — Sliding-Window File Rate Limiter
 * File: backend-api/helpers/RateLimiter.php
 */

declare(strict_types=1);

require_once __DIR__ . '/Response.php';

final class RateLimiter
{
    public static function enforce(string $bucketKey, int $maxRequests, int $windowSeconds): void
    {
        $config = require __DIR__ . '/../config.php';
        $dir = $config['security']['rate_limit_dir'];
        if (!is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }

        $file = $dir . '/' . hash('sha256', $bucketKey) . '.json';
        $now = time();

        $fp = @fopen($file, 'c+');
        if ($fp === false) {
            return; // Fail open only if filesystem lock unavailable
        }

        flock($fp, LOCK_EX);
        $raw = stream_get_contents($fp);
        $timestamps = $raw ? json_decode($raw, true) : [];
        if (!is_array($timestamps)) {
            $timestamps = [];
        }

        $cutoff = $now - $windowSeconds;
        $timestamps = array_values(array_filter($timestamps, static fn($t) => is_int($t) && $t > $cutoff));

        if (count($timestamps) >= $maxRequests) {
            flock($fp, LOCK_UN);
            fclose($fp);
            Response::json(429, false, 'Too many requests. Please wait before trying again.');
        }

        $timestamps[] = $now;
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($timestamps));
        flock($fp, LOCK_UN);
        fclose($fp);
    }
}
