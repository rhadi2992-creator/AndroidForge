<?php
/**
 * SpinReward Pro — Admin Login
 * File: admin-panel/login.php
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/csrf.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    $pdo = Database::getConnection();
    $stmt = $pdo->prepare('SELECT id, username, password_hash, status FROM admins WHERE username = ? OR email = ? LIMIT 1');
    $stmt->execute([$username, $username]);
    $admin = $stmt->fetch();

    if ($admin && $admin['status'] === 'active' && password_verify($password, $admin['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = (int)$admin['id'];

        $pdo->prepare('UPDATE admins SET last_login_at = UTC_TIMESTAMP(), last_login_ip = ? WHERE id = ?')
            ->execute([Security::clientIp(), (int)$admin['id']]);

        Security::writeAuditLog($pdo, 'admin', (int)$admin['id'], 'admin_login', 'admin', (int)$admin['id']);
        header('Location: index.php');
        exit;
    }
    $error = 'Invalid credentials or suspended admin account.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In — SpinReward Admin</title>
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body class="login-page">
  <form method="post" class="login-card">
    <?= csrf_field() ?>
    <h1 style="margin:0 0 6px;font-size:20px;">SpinReward Admin</h1>
    <p style="margin:0 0 20px;color:#64748b;font-size:13px;">Sign in with your administrator credentials.</p>
    <?php if ($error !== ''): ?>
      <div class="alert alert-error"><?= h($error) ?></div>
    <?php endif; ?>
    <div style="margin-bottom:14px;">
      <label for="username">Username or Email</label>
      <input id="username" name="username" type="text" required autocomplete="username">
    </div>
    <div style="margin-bottom:18px;">
      <label for="password">Password</label>
      <input id="password" name="password" type="password" required autocomplete="current-password">
    </div>
    <button type="submit" class="btn" style="width:100%;">Sign In</button>
  </form>
</body>
</html>
