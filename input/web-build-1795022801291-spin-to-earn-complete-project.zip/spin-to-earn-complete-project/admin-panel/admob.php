<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $ids = $_POST['id'] ?? [];
    $upd = $pdo->prepare(
        'UPDATE advertisements_settings
         SET is_enabled = ?, test_mode = ?, test_ad_unit_id = ?, prod_ad_unit_id = ?,
             placement_notes = ?, frequency_cap_per_hour = ?, cooldown_seconds = ?, rewarded_points = ?
         WHERE id = ?'
    );
    foreach ($ids as $id) {
        $idInt = (int)$id;
        $upd->execute([
            isset($_POST['is_enabled'][$idInt]) ? 1 : 0,
            isset($_POST['test_mode'][$idInt]) ? 1 : 0,
            trim((string)($_POST['test_ad_unit_id'][$idInt] ?? '')),
            trim((string)($_POST['prod_ad_unit_id'][$idInt] ?? '')),
            trim((string)($_POST['placement_notes'][$idInt] ?? '')),
            max(0, (int)($_POST['frequency_cap_per_hour'][$idInt] ?? 0)),
            max(0, (int)($_POST['cooldown_seconds'][$idInt] ?? 0)),
            max(0, (int)($_POST['rewarded_points'][$idInt] ?? 0)),
            $idInt,
        ]);
    }
    Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], 'admob_settings_updated');
    $_SESSION['flash_success'] = 'AdMob 6-format settings saved.';
    header('Location: admob.php');
    exit;
}

$ads = $pdo->query('SELECT * FROM advertisements_settings ORDER BY id ASC')->fetchAll();

$pageTitle = 'AdMob Settings (All 6 Formats)';
$activeNav = 'admob';
require __DIR__ . '/includes/layout_top.php';
?>
<form method="post">
  <?= csrf_field() ?>
  <?php foreach ($ads as $ad): $id = (int)$ad['id']; ?>
  <div class="card">
    <input type="hidden" name="id[]" value="<?= $id ?>">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
      <strong style="font-size:15px;text-transform:uppercase;"><?= h(str_replace('_', ' ', $ad['ad_format'])) ?></strong>
      <div style="display:flex;gap:16px;">
        <label style="margin:0;"><input type="checkbox" name="is_enabled[<?= $id ?>]" <?= (int)$ad['is_enabled'] === 1 ? 'checked' : '' ?> style="width:auto;"> Enabled</label>
        <label style="margin:0;"><input type="checkbox" name="test_mode[<?= $id ?>]" <?= (int)$ad['test_mode'] === 1 ? 'checked' : '' ?> style="width:auto;"> Test Mode</label>
      </div>
    </div>
    <div class="form-grid">
      <div><label>Test Ad Unit ID</label><input name="test_ad_unit_id[<?= $id ?>]" value="<?= h($ad['test_ad_unit_id']) ?>"></div>
      <div><label>Production Ad Unit ID</label><input name="prod_ad_unit_id[<?= $id ?>]" value="<?= h($ad['prod_ad_unit_id']) ?>" placeholder="ca-app-pub-XXXX/YYYY"></div>
      <div><label>Frequency Cap / Hour</label><input type="number" min="0" name="frequency_cap_per_hour[<?= $id ?>]" value="<?= (int)$ad['frequency_cap_per_hour'] ?>"></div>
      <div><label>Cooldown (Seconds)</label><input type="number" min="0" name="cooldown_seconds[<?= $id ?>]" value="<?= (int)$ad['cooldown_seconds'] ?>"></div>
      <div><label>Non-Cash Rewarded Pts</label><input type="number" min="0" name="rewarded_points[<?= $id ?>]" value="<?= (int)$ad['rewarded_points'] ?>"></div>
      <div><label>Placement Policy</label><input name="placement_notes[<?= $id ?>]" value="<?= h($ad['placement_notes']) ?>"></div>
    </div>
  </div>
  <?php endforeach; ?>
  <button type="submit" class="btn">Save All AdMob Configurations</button>
</form>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
