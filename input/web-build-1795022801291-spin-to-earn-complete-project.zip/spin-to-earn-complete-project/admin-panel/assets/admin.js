function toggleSidebar() {
  var el = document.getElementById('sidebar');
  if (el) el.classList.toggle('open');
}

function confirmAction(msg) {
  return window.confirm(msg || 'Are you sure you want to proceed?');
}
