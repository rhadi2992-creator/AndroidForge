<?php
/**
 * SpinReward Pro — Admin Authentication Guard
 * File: admin-panel/includes/auth_guard.php
 */

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/csrf.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$pdo = Database::getConnection();
$adminStmt = $pdo->prepare('SELECT id, username, full_name, role, status FROM admins WHERE id = ? LIMIT 1');
$adminStmt->execute([(int)$_SESSION['admin_id']]);
$currentAdmin = $adminStmt->fetch();

if (!$currentAdmin || $currentAdmin['status'] !== 'active') {
    $_SESSION = [];
    session_destroy();
    header('Location: login.php');
    exit;
}
