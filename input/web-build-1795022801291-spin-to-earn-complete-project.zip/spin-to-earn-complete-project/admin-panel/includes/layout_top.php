<?php
/**
 * SpinReward Pro — Admin Layout Top
 * File: admin-panel/includes/layout_top.php
 */
$pageTitle = $pageTitle ?? 'Dashboard';
$activeNav = $activeNav ?? 'dashboard';
$navItems = [
    ['id' => 'dashboard',   'href' => 'index.php',       'label' => 'Dashboard'],
    ['id' => 'users',       'href' => 'users.php',       'label' => 'Users'],
    ['id' => 'spins',       'href' => 'spins.php',       'label' => 'Spin Management'],
    ['id' => 'tasks',       'href' => 'tasks.php',       'label' => 'Task Management'],
    ['id' => 'withdrawals', 'href' => 'withdrawals.php', 'label' => 'Withdrawals'],
    ['id' => 'referrals',   'href' => 'referrals.php',   'label' => 'Referrals'],
    ['id' => 'admob',       'href' => 'admob.php',       'label' => 'AdMob Settings'],
    ['id' => 'settings',    'href' => 'settings.php',    'label' => 'App Settings'],
    ['id' => 'audit',       'href' => 'audit_logs.php',  'label' => 'Audit Logs'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h($pageTitle) ?> — SpinReward Admin</title>
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<div class="admin-shell">
  <aside class="sidebar" id="sidebar">
    <div class="brand">SpinReward Admin</div>
    <nav class="nav-list">
      <?php foreach ($navItems as $item): ?>
        <a href="<?= h($item['href']) ?>" class="nav-link <?= $activeNav === $item['id'] ? 'active' : '' ?>">
          <?= h($item['label']) ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-footer">
      <div class="admin-meta">Signed in as <strong><?= h($currentAdmin['username']) ?></strong></div>
      <a href="logout.php" class="btn-outline">Sign Out</a>
    </div>
  </aside>
  <main class="main-area">
    <header class="topbar">
      <button type="button" class="menu-toggle" onclick="toggleSidebar()">Menu</button>
      <h1><?= h($pageTitle) ?></h1>
      <div class="topbar-meta"><?= gmdate('Y-m-d H:i') ?> UTC</div>
    </header>
    <div class="content-wrap">
      <?php if (!empty($_SESSION['flash_success'])): ?>
        <div class="alert alert-success"><?= h($_SESSION['flash_success']) ?></div>
        <?php unset($_SESSION['flash_success']); ?>
      <?php endif; ?>
      <?php if (!empty($_SESSION['flash_error'])): ?>
        <div class="alert alert-error"><?= h($_SESSION['flash_error']) ?></div>
        <?php unset($_SESSION['flash_error']); ?>
      <?php endif; ?>
