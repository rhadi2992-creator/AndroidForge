<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $wrId = (int)($_POST['withdrawal_id'] ?? 0);
    $decision = (string)($_POST['decision'] ?? '');
    $paymentRef = trim((string)($_POST['payment_reference'] ?? ''));
    $adminNote = trim((string)($_POST['admin_note'] ?? ''));

    if ($wrId > 0 && in_array($decision, ['approved', 'paid', 'rejected'], true)) {
        $pdo->beginTransaction();
        try {
            $wrStmt = $pdo->prepare('SELECT * FROM withdrawal_requests WHERE id = ? FOR UPDATE');
            $wrStmt->execute([$wrId]);
            $wr = $wrStmt->fetch();

            if ($wr && in_array($wr['status'], ['pending', 'approved'], true)) {
                $uid = (int)$wr['user_id'];
                $amt = (float)$wr['amount_pkr'];
                $wStmt = $pdo->prepare('SELECT available_balance_pkr FROM cash_wallets WHERE user_id = ? FOR UPDATE');
                $wStmt->execute([$uid]);
                $avail = (float)$wStmt->fetchColumn();

                if ($decision === 'approved' && $wr['status'] === 'pending') {
                    $pdo->prepare('UPDATE withdrawal_requests SET status = "approved", admin_note = ?, processed_by_admin_id = ?, processed_at = UTC_TIMESTAMP() WHERE id = ?')
                        ->execute([$adminNote ?: null, (int)$currentAdmin['id'], $wrId]);
                } elseif ($decision === 'paid') {
                    $pdo->prepare('UPDATE withdrawal_requests SET status = "paid", payment_reference = ?, admin_note = ?, processed_by_admin_id = ?, processed_at = UTC_TIMESTAMP() WHERE id = ?')
                        ->execute([$paymentRef ?: $wr['reference_id'], $adminNote ?: null, (int)$currentAdmin['id'], $wrId]);
                    $pdo->prepare('UPDATE cash_wallets SET pending_withdrawal_pkr = pending_withdrawal_pkr - ?, total_withdrawn_pkr = total_withdrawn_pkr + ? WHERE user_id = ?')
                        ->execute([$amt, $amt, $uid]);
                    $txRef = Security::generateUniqueRefId('PAID');
                    $pdo->prepare('INSERT INTO wallet_transactions (user_id, reference_id, tx_type, amount_pkr, balance_after_pkr, description, related_entity_id) VALUES (?, ?, "withdrawal_paid", 0.00, ?, ?, ?)')
                        ->execute([$uid, $txRef, $avail, "Paid {$wr['payment_method']} ({$wr['reference_id']})", $wrId]);
                    $pdo->prepare('INSERT INTO notifications (user_id, title, message, category) VALUES (?, ?, ?, "wallet")')
                        ->execute([$uid, 'Withdrawal Paid', "Your {$wr['payment_method']} withdrawal ({$wr['reference_id']}) has been marked as paid."]);
                } elseif ($decision === 'rejected') {
                    $newAvail = round($avail + $amt, 2);
                    $pdo->prepare('UPDATE withdrawal_requests SET status = "rejected", admin_note = ?, processed_by_admin_id = ?, processed_at = UTC_TIMESTAMP() WHERE id = ?')
                        ->execute([$adminNote ?: 'Rejected by administrator', (int)$currentAdmin['id'], $wrId]);
                    $pdo->prepare('UPDATE cash_wallets SET available_balance_pkr = available_balance_pkr + ?, pending_withdrawal_pkr = pending_withdrawal_pkr - ? WHERE user_id = ?')
                        ->execute([$amt, $amt, $uid]);
                    $txRef = Security::generateUniqueRefId('RFND');
                    $pdo->prepare('INSERT INTO wallet_transactions (user_id, reference_id, tx_type, amount_pkr, balance_after_pkr, description, related_entity_id) VALUES (?, ?, "withdrawal_refund", ?, ?, ?, ?)')
                        ->execute([$uid, $txRef, $amt, $newAvail, "Refunded rejected withdrawal ({$wr['reference_id']})", $wrId]);
                    $pdo->prepare('INSERT INTO notifications (user_id, title, message, category) VALUES (?, ?, ?, "wallet")')
                        ->execute([$uid, 'Withdrawal Rejected & Refunded', "Rs. " . number_format($amt, 2) . " has been returned to your available cash balance."]);
                }
                Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], "withdrawal_{$decision}", 'withdrawal_request', $wrId);
                $_SESSION['flash_success'] = "Withdrawal {$wr['reference_id']} updated to {$decision}.";
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $_SESSION['flash_error'] = 'Error updating withdrawal request.';
        }
    }
    header('Location: withdrawals.php');
    exit;
}

$requests = $pdo->query(
    'SELECT wr.*, u.email FROM withdrawal_requests wr INNER JOIN users u ON u.id = wr.user_id ORDER BY wr.status = "pending" DESC, wr.id DESC LIMIT 60'
)->fetchAll();

$pageTitle = 'Withdrawal Management';
$activeNav = 'withdrawals';
require __DIR__ . '/includes/layout_top.php';
?>
<div class="card table-wrap">
  <table>
    <thead><tr><th>Reference</th><th>User</th><th>Method &amp; Account</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach ($requests as $wr): ?>
      <tr>
        <td><?= h($wr['reference_id']) ?><?= (int)$wr['fraud_flag'] === 1 ? '<br><span style="color:#b91c1c;font-size:11px;">Shared account flag</span>' : '' ?></td>
        <td><?= h($wr['email']) ?></td>
        <td><strong><?= h($wr['payment_method']) ?></strong><br><?= h($wr['account_holder_name']) ?> · <?= h($wr['account_number']) ?></td>
        <td>Rs. <?= number_format((float)$wr['amount_pkr'], 2) ?></td>
        <td><?= h($wr['status']) ?></td>
        <td>
          <?php if (in_array($wr['status'], ['pending', 'approved'], true)): ?>
          <form method="post" style="display:flex;gap:6px;flex-wrap:wrap;">
            <?= csrf_field() ?>
            <input type="hidden" name="withdrawal_id" value="<?= (int)$wr['id'] ?>">
            <input name="payment_reference" placeholder="Txn Ref" style="width:110px;">
            <input name="admin_note" placeholder="Note" style="width:110px;">
            <?php if ($wr['status'] === 'pending'): ?>
              <button type="submit" name="decision" value="approved" class="btn btn-sm">Approve</button>
            <?php endif; ?>
            <button type="submit" name="decision" value="paid" class="btn btn-sm btn-green">Mark Paid</button>
            <button type="submit" name="decision" value="rejected" class="btn btn-sm btn-red">Reject &amp; Refund</button>
          </form>
          <?php else: echo h($wr['payment_reference'] ?: $wr['admin_note']); endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
