<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create_task') {
        $title = trim((string)($_POST['title'] ?? ''));
        $cat = (string)($_POST['category'] ?? 'survey');
        $instr = trim((string)($_POST['instructions'] ?? ''));
        $reward = round((float)($_POST['reward_pkr'] ?? 0), 2);
        if ($title !== '' && $instr !== '' && $reward > 0) {
            $pdo->prepare(
                'INSERT INTO tasks (title, category, instructions, reward_pkr, status) VALUES (?, ?, ?, ?, "active")'
            )->execute([$title, $cat, $instr, $reward]);
            Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], 'task_created', 'task', (int)$pdo->lastInsertId());
            $_SESSION['flash_success'] = 'Cash task created.';
        }
    } elseif ($action === 'delete_task') {
        $tid = (int)($_POST['task_id'] ?? 0);
        $pdo->prepare('UPDATE tasks SET status = "archived" WHERE id = ?')->execute([$tid]);
        Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], 'task_archived', 'task', $tid);
        $_SESSION['flash_success'] = 'Task archived.';
    } elseif ($action === 'review_submission') {
        $subId = (int)($_POST['submission_id'] ?? 0);
        $decision = ($_POST['decision'] ?? '') === 'approve' ? 'approved' : 'rejected';
        $note = trim((string)($_POST['admin_note'] ?? ''));

        $pdo->beginTransaction();
        try {
            $sStmt = $pdo->prepare('SELECT * FROM task_submissions WHERE id = ? FOR UPDATE');
            $sStmt->execute([$subId]);
            $sub = $sStmt->fetch();

            if ($sub && $sub['status'] === 'pending') {
                $pdo->prepare(
                    'UPDATE task_submissions SET status = ?, admin_note = ?, reviewed_by_admin_id = ?, reviewed_at = UTC_TIMESTAMP() WHERE id = ?'
                )->execute([$decision, $note ?: null, (int)$currentAdmin['id'], $subId]);

                if ($decision === 'approved') {
                    $uid = (int)$sub['user_id'];
                    $amt = (float)$sub['reward_snapshot_pkr'];
                    $wStmt = $pdo->prepare('SELECT available_balance_pkr FROM cash_wallets WHERE user_id = ? FOR UPDATE');
                    $wStmt->execute([$uid]);
                    $newBal = round((float)$wStmt->fetchColumn() + $amt, 2);

                    $pdo->prepare(
                        'UPDATE cash_wallets SET available_balance_pkr = available_balance_pkr + ?, approved_task_earnings_pkr = approved_task_earnings_pkr + ? WHERE user_id = ?'
                    )->execute([$amt, $amt, $uid]);

                    $refId = Security::generateUniqueRefId('TASK');
                    $pdo->prepare(
                        'INSERT INTO wallet_transactions (user_id, reference_id, tx_type, amount_pkr, balance_after_pkr, description, related_entity_id)
                         VALUES (?, ?, "task_credit", ?, ?, ?, ?)'
                    )->execute([$uid, $refId, $amt, $newBal, "Approved task submission #{$subId}", $subId]);

                    $pdo->prepare('INSERT INTO notifications (user_id, title, message, category) VALUES (?, ?, ?, "task")')
                        ->execute([$uid, 'Task Approved', "Rs. " . number_format($amt, 2) . " has been credited to your cash wallet."]);

                    // Approve pending referral if referral requires 1st approved task
                    $refEnabled = Security::getSetting($pdo, 'referral_program_enabled', '1') === '1';
                    $refAmt = (float)Security::getSetting($pdo, 'referral_cash_reward_pkr', '25.00');
                    if ($refEnabled && $refAmt > 0) {
                        $rStmt = $pdo->prepare('SELECT * FROM referrals WHERE referred_user_id = ? AND status = "pending" FOR UPDATE');
                        $rStmt->execute([$uid]);
                        if ($refRow = $rStmt->fetch()) {
                            $referrerId = (int)$refRow['referrer_user_id'];
                            $pdo->prepare('UPDATE referrals SET status = "approved", approved_at = UTC_TIMESTAMP() WHERE id = ?')->execute([(int)$refRow['id']]);
                            $rwStmt = $pdo->prepare('SELECT available_balance_pkr FROM cash_wallets WHERE user_id = ? FOR UPDATE');
                            $rwStmt->execute([$referrerId]);
                            $refNewBal = round((float)$rwStmt->fetchColumn() + $refAmt, 2);

                            $pdo->prepare(
                                'UPDATE cash_wallets SET available_balance_pkr = available_balance_pkr + ?, referral_cash_earnings_pkr = referral_cash_earnings_pkr + ? WHERE user_id = ?'
                            )->execute([$refAmt, $refAmt, $referrerId]);

                            $refTx = Security::generateUniqueRefId('REFC');
                            $pdo->prepare(
                                'INSERT INTO referral_rewards (referral_id, referrer_user_id, reward_type, amount_pkr, reference_id) VALUES (?, ?, "cash_program", ?, ?)'
                            )->execute([(int)$refRow['id'], $referrerId, $refAmt, $refTx]);
                            $pdo->prepare(
                                'INSERT INTO wallet_transactions (user_id, reference_id, tx_type, amount_pkr, balance_after_pkr, description, related_entity_id)
                                 VALUES (?, ?, "referral_credit", ?, ?, ?, ?)'
                            )->execute([$referrerId, $refTx, $refAmt, $refNewBal, "Referral program reward for user #{$uid}", (int)$refRow['id']]);
                        }
                    }
                }
                Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], "task_submission_{$decision}", 'task_submission', $subId);
                $_SESSION['flash_success'] = "Submission #{$subId} marked {$decision}.";
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $_SESSION['flash_error'] = 'Failed to process submission review.';
        }
    }
    header('Location: tasks.php');
    exit;
}

$tasks = $pdo->query('SELECT * FROM tasks WHERE status != "archived" ORDER BY id DESC')->fetchAll();
$submissions = $pdo->query(
    'SELECT ts.*, t.title AS task_title, u.email AS user_email
     FROM task_submissions ts
     INNER JOIN tasks t ON t.id = ts.task_id
     INNER JOIN users u ON u.id = ts.user_id
     ORDER BY ts.status = "pending" DESC, ts.id DESC LIMIT 50'
)->fetchAll();

$pageTitle = 'Task Management';
$activeNav = 'tasks';
require __DIR__ . '/includes/layout_top.php';
?>
<div class="card">
  <h2 style="margin:0 0 12px;font-size:15px;">Create Genuine Cash Task</h2>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create_task">
    <div><label>Title</label><input name="title" required></div>
    <div><label>Category</label>
      <select name="category">
        <option value="survey">Approved Survey</option>
        <option value="data_entry">Data Entry</option>
        <option value="website_testing">Website Testing</option>
        <option value="sponsor_task">Sponsor Task</option>
        <option value="assignment">Admin Assignment</option>
      </select>
    </div>
    <div><label>Cash Reward (PKR)</label><input name="reward_pkr" type="number" step="0.01" min="5" required></div>
    <div style="grid-column:1 / -1;"><label>Instructions</label><textarea name="instructions" rows="2" required></textarea></div>
    <div><button type="submit" class="btn">Publish Task</button></div>
  </form>
</div>

<div class="card table-wrap">
  <h2 style="margin:0 0 12px;font-size:15px;">Task Proof Submissions</h2>
  <table>
    <thead><tr><th>ID</th><th>User</th><th>Task</th><th>Proof</th><th>Reward</th><th>Status</th><th>Review</th></tr></thead>
    <tbody>
      <?php foreach ($submissions as $sub): ?>
      <tr>
        <td>#<?= (int)$sub['id'] ?></td>
        <td><?= h($sub['user_email']) ?></td>
        <td><?= h($sub['task_title']) ?></td>
        <td><?= h($sub['proof_text']) ?></td>
        <td>Rs. <?= number_format((float)$sub['reward_snapshot_pkr'], 2) ?></td>
        <td><?= h($sub['status']) ?></td>
        <td>
          <?php if ($sub['status'] === 'pending'): ?>
          <form method="post" style="display:flex;gap:6px;align-items:center;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="review_submission">
            <input type="hidden" name="submission_id" value="<?= (int)$sub['id'] ?>">
            <input name="admin_note" placeholder="Optional note" style="width:130px;">
            <button type="submit" name="decision" value="approve" class="btn btn-sm btn-green">Approve</button>
            <button type="submit" name="decision" value="reject" class="btn btn-sm btn-red">Reject</button>
          </form>
          <?php else: echo h($sub['admin_note'] ?: 'Reviewed'); endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="card table-wrap">
  <h2 style="margin:0 0 12px;font-size:15px;">Active Tasks</h2>
  <table>
    <thead><tr><th>Title</th><th>Category</th><th>Reward</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach ($tasks as $t): ?>
      <tr>
        <td><?= h($t['title']) ?></td>
        <td><?= h($t['category']) ?></td>
        <td>Rs. <?= number_format((float)$t['reward_pkr'], 2) ?></td>
        <td>
          <form method="post" onsubmit="return confirmAction('Archive this task?')">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete_task">
            <input type="hidden" name="task_id" value="<?= (int)$t['id'] ?>">
            <button type="submit" class="btn btn-sm btn-red">Archive</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
