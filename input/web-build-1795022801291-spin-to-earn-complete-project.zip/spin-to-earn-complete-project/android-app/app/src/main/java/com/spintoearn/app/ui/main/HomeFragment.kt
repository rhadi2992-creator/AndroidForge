package com.spintoearn.app.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.ads.AdMobManager
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.databinding.FragmentHomeBinding
import com.spintoearn.app.ui.features.DailyActivity
import com.spintoearn.app.ui.features.RewardsActivity
import com.spintoearn.app.ui.features.TasksActivity
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        AdMobManager.loadBanner(requireContext(), binding.bannerAdContainer)
        AdMobManager.loadNative(requireContext(), binding.nativeAdContainer)

        binding.btnOpenTasks.setOnClickListener {
            // Natural transition: interstitial shown only if cooldown & policy eligible
            AdMobManager.showInterstitialIfEligible(requireActivity()) {
                startActivity(Intent(requireContext(), TasksActivity::class.java))
            }
        }
        binding.btnOpenRewards.setOnClickListener {
            startActivity(Intent(requireContext(), RewardsActivity::class.java))
        }
        binding.btnOpenDaily.setOnClickListener {
            startActivity(Intent(requireContext(), DailyActivity::class.java))
        }

        loadDashboard()
    }

    private fun loadDashboard() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val res = ApiClient.getService(requireContext()).getDashboard()
                if (res.success && res.data != null && _binding != null) {
                    val d = res.data
                    val name = d.user?.fullName?.takeIf { it.isNotBlank() } ?: "User"
                    binding.tvGreeting.text = "Hello, $name"
                    binding.tvAnnouncement.text = d.announcement.orEmpty()
                    binding.tvCashBalance.text = String.format("Rs. %.2f", d.cashWallet?.availableBalancePkr ?: 0.0)
                    binding.tvNonCashPoints.text = "${d.nonCashPoints?.balance ?: 0L} pts"
                } else if (_binding != null) {
                    binding.tvAnnouncement.text = res.message ?: "Unable to refresh dashboard right now."
                }
            } catch (e: Exception) {
                if (_binding != null) {
                    binding.tvAnnouncement.text = ApiClient.extractErrorMessage(e)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
