package com.spintoearn.app.data.model

import com.google.gson.annotations.SerializedName

data class ApiResponse<T>(
    val success: Boolean = false,
    val message: String? = null,
    @SerializedName("server_time") val serverTime: String? = null,
    val data: T? = null
)

data class ApiErrorResponse(
    val success: Boolean = false,
    val message: String? = null
)

data class AuthData(
    val token: String? = null,
    val user: UserSummary? = null
)

data class UserSummary(
    val id: Long = 0L,
    @SerializedName("full_name") val fullName: String? = null,
    val email: String? = null,
    val phone: String? = null,
    @SerializedName("referral_code") val referralCode: String? = null
)

data class AdFormatRule(
    val enabled: Boolean = false,
    @SerializedName("test_mode") val testMode: Boolean = false,
    @SerializedName("ad_unit_id") val adUnitId: String = "",
    @SerializedName("frequency_cap_per_hour") val frequencyCapPerHour: Int = 0,
    @SerializedName("cooldown_seconds") val cooldownSeconds: Int = 0,
    @SerializedName("rewarded_points") val rewardedPoints: Int = 0,
    @SerializedName("placement_notes") val placementNotes: String? = null
)

data class AppConfigData(
    @SerializedName("app_name") val appName: String? = null,
    @SerializedName("app_version") val appVersion: String? = null,
    @SerializedName("support_email") val supportEmail: String? = null,
    @SerializedName("minimum_withdrawal_pkr") val minimumWithdrawalPkr: Double = 100.0,
    @SerializedName("payment_methods") val paymentMethods: List<String>? = null,
    @SerializedName("maintenance_mode") val maintenanceMode: Boolean = false,
    @SerializedName("announcement_message") val announcementMessage: String? = null,
    @SerializedName("spins_enabled") val spinsEnabled: Boolean = true,
    @SerializedName("daily_spin_limit") val dailySpinLimit: Int = 5,
    val admob: Map<String, AdFormatRule>? = null
)

data class DashboardData(
    val user: UserSummary? = null,
    val spins: SpinQuota? = null,
    @SerializedName("non_cash_points") val nonCashPoints: NonCashPoints? = null,
    @SerializedName("cash_wallet") val cashWallet: CashWallet? = null,
    @SerializedName("active_tasks_count") val activeTasksCount: Int = 0,
    @SerializedName("unread_notifications") val unreadNotifications: Int = 0,
    val announcement: String? = null
)

data class SpinQuota(
    @SerializedName("server_date_utc") val serverDateUtc: String? = null,
    @SerializedName("daily_limit") val dailyLimit: Int = 5,
    @SerializedName("used_today") val usedToday: Int = 0,
    @SerializedName("remaining_today") val remainingToday: Int = 0,
    @SerializedName("spins_enabled") val spinsEnabled: Boolean = true
)

data class NonCashPoints(
    val balance: Long = 0L,
    @SerializedName("lifetime_earned") val lifetimeEarned: Long = 0L
)

data class CashWallet(
    @SerializedName("available_balance_pkr") val availableBalancePkr: Double = 0.0,
    @SerializedName("pending_withdrawal_pkr") val pendingWithdrawalPkr: Double = 0.0,
    @SerializedName("approved_task_earnings_pkr") val approvedTaskEarningsPkr: Double = 0.0,
    @SerializedName("total_withdrawn_pkr") val totalWithdrawnPkr: Double = 0.0
)

data class WheelSlice(
    val id: Int = 0,
    @SerializedName("slice_index") val sliceIndex: Int = 0,
    val label: String? = null,
    @SerializedName("points_value") val pointsValue: Int = 0,
    @SerializedName("slice_color") val sliceColor: String? = null
)

data class RecentSpinItem(
    val id: Long = 0L,
    @SerializedName("points_awarded") val pointsAwarded: Int = 0,
    @SerializedName("spin_date_utc") val spinDateUtc: String? = null,
    @SerializedName("created_at") val createdAt: String? = null,
    val label: String? = null
)

data class WheelData(
    @SerializedName("spins_enabled") val spinsEnabled: Boolean = true,
    @SerializedName("server_date_utc") val serverDateUtc: String? = null,
    @SerializedName("daily_limit") val dailyLimit: Int = 5,
    @SerializedName("used_today") val usedToday: Int = 0,
    @SerializedName("remaining_today") val remainingToday: Int = 0,
    @SerializedName("points_balance") val pointsBalance: Long = 0L,
    val slices: List<WheelSlice>? = null,
    @SerializedName("recent_spins") val recentSpins: List<RecentSpinItem>? = null
)

data class SpinHistoryData(
    val items: List<RecentSpinItem>? = null
)

data class SpinResultData(
    @SerializedName("slice_id") val sliceId: Int = 0,
    @SerializedName("slice_index") val sliceIndex: Int = 0,
    val label: String? = null,
    @SerializedName("points_awarded") val pointsAwarded: Int = 0,
    @SerializedName("points_balance") val pointsBalance: Long = 0L,
    @SerializedName("used_today") val usedToday: Int = 0,
    @SerializedName("remaining_today") val remainingToday: Int = 0,
    @SerializedName("reference_id") val referenceId: String? = null
)

data class RewardedVerifyData(
    @SerializedName("points_awarded") val pointsAwarded: Int = 0,
    @SerializedName("points_balance") val pointsBalance: Long = 0L,
    @SerializedName("reference_id") val referenceId: String? = null
)

data class TaskItem(
    val id: Long = 0L,
    val title: String? = null,
    val category: String? = null,
    val instructions: String? = null,
    @SerializedName("reward_pkr") val rewardPkr: Double = 0.0,
    @SerializedName("requires_proof") val requiresProof: Boolean = true,
    @SerializedName("proof_placeholder") val proofPlaceholder: String? = null,
    @SerializedName("can_submit") val canSubmit: Boolean = true
)

data class TasksData(val tasks: List<TaskItem>? = null)

data class WalletSummaryData(
    @SerializedName("available_balance_pkr") val availableBalancePkr: Double = 0.0,
    @SerializedName("pending_withdrawal_pkr") val pendingWithdrawalPkr: Double = 0.0,
    @SerializedName("approved_task_earnings_pkr") val approvedTaskEarningsPkr: Double = 0.0,
    @SerializedName("total_withdrawn_pkr") val totalWithdrawnPkr: Double = 0.0,
    @SerializedName("minimum_withdrawal_pkr") val minimumWithdrawalPkr: Double = 100.0,
    @SerializedName("recent_transactions") val recentTransactions: List<CashTransactionItem>? = null
)

data class CashTransactionItem(
    val id: Long = 0L,
    @SerializedName("reference_id") val referenceId: String? = null,
    @SerializedName("tx_type") val txType: String? = null,
    @SerializedName("amount_pkr") val amountPkr: Double = 0.0,
    @SerializedName("balance_after_pkr") val balanceAfterPkr: Double = 0.0,
    val description: String? = null,
    @SerializedName("created_at") val createdAt: String? = null
)

data class TransactionsData(
    @SerializedName("cash_transactions") val cashTransactions: List<CashTransactionItem>? = null
)

data class ReferralData(
    @SerializedName("referral_code") val referralCode: String? = null,
    @SerializedName("reward_per_referral_pkr") val rewardPerReferralPkr: Double = 0.0,
    @SerializedName("total_referrals") val totalReferrals: Int = 0,
    @SerializedName("pending_referrals") val pendingReferrals: Int = 0,
    @SerializedName("approved_referrals") val approvedReferrals: Int = 0,
    @SerializedName("total_cash_earned_pkr") val totalCashEarnedPkr: Double = 0.0
)

data class NotificationItem(
    val id: Long = 0L,
    val title: String? = null,
    val message: String? = null,
    val category: String? = null,
    @SerializedName("created_at") val createdAt: String? = null
)

data class NotificationsData(val items: List<NotificationItem>? = null)

data class DailyActivityData(
    @SerializedName("server_date_utc") val serverDateUtc: String? = null,
    @SerializedName("checked_in_today") val checkedInToday: Boolean = false,
    @SerializedName("checkin_streak") val checkinStreak: Int = 0,
    @SerializedName("checkin_points") val checkinPoints: Int = 40,
    @SerializedName("spins_used_today") val spinsUsedToday: Int = 0,
    @SerializedName("daily_spin_limit") val dailySpinLimit: Int = 5,
    @SerializedName("approved_tasks") val approvedTasks: Int = 0
)
