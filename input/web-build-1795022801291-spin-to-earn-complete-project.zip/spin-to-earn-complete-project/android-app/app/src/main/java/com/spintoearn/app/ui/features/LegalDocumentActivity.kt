package com.spintoearn.app.ui.features

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.spintoearn.app.databinding.ActivityLegalDocumentBinding

class LegalDocumentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLegalDocumentBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLegalDocumentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val docType = intent.getStringExtra("doc_type") ?: "privacy"
        if (docType == "terms") {
            binding.tvDocTitle.text = "Terms & Conditions"
            binding.tvDocBody.text =
                "1. Non-Cash Spin Points: Spin Wheel and Rewarded Ad points are non-transferable, non-cash in-app benefits only. They can never be converted to cash, gift cards, or cryptocurrency.\n\n" +
                "2. Genuine Cash Tasks: Cash balances accrue solely from admin-approved tasks and legitimate referral programs.\n\n" +
                "3. Withdrawals: Minimum withdrawal is configured by the administrator (default Rs. 100) via JazzCash or Easypaisa.\n\n" +
                "4. Anti-Fraud Policy: Duplicate accounts, device spoofing, and self-referrals result in immediate suspension."
        } else {
            binding.tvDocTitle.text = "Privacy Policy"
            binding.tvDocBody.text =
                "1. Data Collected: Name, email, optional phone number, device integrity token, and task/withdrawal records.\n\n" +
                "2. Advertising SDK: Google Mobile Ads SDK is used in compliance with Google Play AdMob policies. You may manage ad personalization in device settings.\n\n" +
                "3. Account Deletion: You may permanently delete your account and anonymize personal data at any time from Profile -> Delete Account."
        }
    }
}
