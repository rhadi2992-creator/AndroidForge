package com.spintoearn.app.ui.features

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.spintoearn.app.data.local.SessionManager
import com.spintoearn.app.databinding.ActivityHelpSupportBinding

class HelpSupportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHelpSupportBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHelpSupportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val email = SessionManager(this).getAppConfig()?.supportEmail?.ifBlank { "support@spin-earn.ct.ws" }
            ?: "support@spin-earn.ct.ws"
        binding.tvSupportEmail.text = "Support Email: $email"

        binding.btnEmailSupport.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")).apply {
                putExtra(Intent.EXTRA_SUBJECT, "SpinReward Pro Support Request")
            }
            startActivity(Intent.createChooser(intent, "Contact Support"))
        }
    }
}
