package com.spintoearn.app.data.api

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import com.google.gson.TypeAdapter
import com.google.gson.reflect.TypeToken
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonToken
import com.google.gson.stream.JsonWriter
import com.spintoearn.app.BuildConfig
import com.spintoearn.app.data.local.SessionManager
import com.spintoearn.app.data.model.AdFormatRule
import com.spintoearn.app.data.model.ApiErrorResponse
import com.spintoearn.app.ui.auth.LoginActivity
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import java.lang.reflect.Type
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

object ApiClient {
    @Volatile
    private var service: ApiService? = null

    @Volatile
    private var lastUnauthorizedRedirectMs = 0L

    private val errorGson = Gson()

    fun getService(context: Context): ApiService {
        return service ?: synchronized(this) {
            service ?: buildService(context.applicationContext).also { service = it }
        }
    }

    fun extractErrorMessage(error: Throwable): String {
        return when (error) {
            is HttpException -> {
                val rawBody = try {
                    error.response()?.errorBody()?.string()
                } catch (_: Exception) {
                    null
                }
                val parsedMessage = if (!rawBody.isNullOrBlank()) {
                    try {
                        errorGson.fromJson(rawBody, ApiErrorResponse::class.java)?.message
                    } catch (_: Exception) {
                        null
                    }
                } else {
                    null
                }
                if (!parsedMessage.isNullOrBlank()) {
                    parsedMessage
                } else if (error.code() == 401) {
                    "Session expired. Please log in again."
                } else {
                    "Server error (HTTP ${error.code()})."
                }
            }
            is SocketTimeoutException -> "Request timed out. Please try again."
            is IOException -> "Network error. Please check your internet connection."
            else -> error.localizedMessage?.takeIf { it.isNotBlank() } ?: "Unexpected error occurred."
        }
    }

    private fun handleUnauthorizedOnMainThread(appContext: Context) {
        val now = System.currentTimeMillis()
        val shouldRedirect = synchronized(this) {
            if (now - lastUnauthorizedRedirectMs >= 2500L) {
                lastUnauthorizedRedirectMs = now
                true
            } else {
                false
            }
        }
        if (!shouldRedirect) return

        SessionManager(appContext).clearSession()
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(appContext, "Session expired. Please log in again.", Toast.LENGTH_LONG).show()
            val intent = Intent(appContext, LoginActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
            appContext.startActivity(intent)
        }
    }

    private fun buildLenientGson(): Gson {
        val booleanAdapter = object : TypeAdapter<Boolean>() {
            override fun write(out: JsonWriter, value: Boolean?) {
                if (value == null) out.nullValue() else out.value(value)
            }

            override fun read(reader: JsonReader): Boolean {
                return when (reader.peek()) {
                    JsonToken.BOOLEAN -> reader.nextBoolean()
                    JsonToken.NUMBER -> reader.nextDouble() != 0.0
                    JsonToken.STRING -> when (reader.nextString().trim().lowercase()) {
                        "true", "1", "t", "yes", "on" -> true
                        else -> false
                    }
                    JsonToken.NULL -> {
                        reader.nextNull()
                        false
                    }
                    else -> {
                        reader.skipValue()
                        false
                    }
                }
            }
        }

        val intAdapter = object : TypeAdapter<Int>() {
            override fun write(out: JsonWriter, value: Int?) {
                if (value == null) out.nullValue() else out.value(value)
            }

            override fun read(reader: JsonReader): Int {
                return when (reader.peek()) {
                    JsonToken.NUMBER -> reader.nextDouble().toInt()
                    JsonToken.STRING -> reader.nextString().trim().toDoubleOrNull()?.toInt() ?: 0
                    JsonToken.BOOLEAN -> if (reader.nextBoolean()) 1 else 0
                    JsonToken.NULL -> {
                        reader.nextNull()
                        0
                    }
                    else -> {
                        reader.skipValue()
                        0
                    }
                }
            }
        }

        val longAdapter = object : TypeAdapter<Long>() {
            override fun write(out: JsonWriter, value: Long?) {
                if (value == null) out.nullValue() else out.value(value)
            }

            override fun read(reader: JsonReader): Long {
                return when (reader.peek()) {
                    JsonToken.NUMBER -> reader.nextDouble().toLong()
                    JsonToken.STRING -> reader.nextString().trim().toDoubleOrNull()?.toLong() ?: 0L
                    JsonToken.BOOLEAN -> if (reader.nextBoolean()) 1L else 0L
                    JsonToken.NULL -> {
                        reader.nextNull()
                        0L
                    }
                    else -> {
                        reader.skipValue()
                        0L
                    }
                }
            }
        }

        val doubleAdapter = object : TypeAdapter<Double>() {
            override fun write(out: JsonWriter, value: Double?) {
                if (value == null) out.nullValue() else out.value(value)
            }

            override fun read(reader: JsonReader): Double {
                return when (reader.peek()) {
                    JsonToken.NUMBER -> reader.nextDouble()
                    JsonToken.STRING -> reader.nextString().trim().toDoubleOrNull() ?: 0.0
                    JsonToken.BOOLEAN -> if (reader.nextBoolean()) 1.0 else 0.0
                    JsonToken.NULL -> {
                        reader.nextNull()
                        0.0
                    }
                    else -> {
                        reader.skipValue()
                        0.0
                    }
                }
            }
        }

        val adMapType: Type = object : TypeToken<Map<String, AdFormatRule>>() {}.type
        val adMapDeserializer = object : JsonDeserializer<Map<String, AdFormatRule>> {
            override fun deserialize(
                json: JsonElement?,
                typeOfT: Type?,
                context: JsonDeserializationContext
            ): Map<String, AdFormatRule> {
                if (json == null || !json.isJsonObject) {
                    return emptyMap()
                }
                val result = LinkedHashMap<String, AdFormatRule>()
                for ((key, value) in json.asJsonObject.entrySet()) {
                    if (value != null && value.isJsonObject) {
                        val obj = value.asJsonObject
                        val rule = context.deserialize<AdFormatRule>(obj, AdFormatRule::class.java)
                        val safeUnitId = obj.get("ad_unit_id")?.takeIf { !it.isJsonNull }?.asString ?: ""
                        result[key] = rule.copy(adUnitId = safeUnitId)
                    }
                }
                return result
            }
        }

        return GsonBuilder()
            .registerTypeAdapter(Boolean::class.javaPrimitiveType, booleanAdapter)
            .registerTypeAdapter(Boolean::class.javaObjectType, booleanAdapter)
            .registerTypeAdapter(Int::class.javaPrimitiveType, intAdapter)
            .registerTypeAdapter(Int::class.javaObjectType, intAdapter)
            .registerTypeAdapter(Long::class.javaPrimitiveType, longAdapter)
            .registerTypeAdapter(Long::class.javaObjectType, longAdapter)
            .registerTypeAdapter(Double::class.javaPrimitiveType, doubleAdapter)
            .registerTypeAdapter(Double::class.javaObjectType, doubleAdapter)
            .registerTypeAdapter(adMapType, adMapDeserializer)
            .create()
    }

    private fun buildService(appContext: Context): ApiService {
        val session = SessionManager(appContext)
        val logging = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY else HttpLoggingInterceptor.Level.NONE
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val original = chain.request()
                val reqBuilder = original.newBuilder()
                    .header("Accept", "application/json")
                val token = session.getToken()
                if (!token.isNullOrBlank()) {
                    reqBuilder.header("Authorization", "Bearer $token")
                }
                val response = chain.proceed(reqBuilder.build())
                val path = original.url.encodedPath
                val isCredentialCheckEndpoint = path.endsWith("/auth/login.php") ||
                    path.endsWith("/auth/register.php") ||
                    path.endsWith("/auth/delete_account.php")
                if (response.code == 401 && !token.isNullOrBlank() && !isCredentialCheckEndpoint) {
                    handleUnauthorizedOnMainThread(appContext)
                }
                response
            }
            .addInterceptor(logging)
            .build()

        return Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(buildLenientGson()))
            .build()
            .create(ApiService::class.java)
    }
}
