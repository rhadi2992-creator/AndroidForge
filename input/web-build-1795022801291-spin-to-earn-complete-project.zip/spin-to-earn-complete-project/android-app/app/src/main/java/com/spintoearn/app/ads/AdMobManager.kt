package com.spintoearn.app.ads

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.spintoearn.app.R
import com.spintoearn.app.data.local.SessionManager
import com.spintoearn.app.data.model.AdFormatRule
import java.util.UUID

object AdMobManager {
    // Configured Production AdMob Ad Unit IDs
    private const val PROD_BANNER = "ca-app-pub-3133971041724338/8119772283"
    private const val PROD_INTERSTITIAL = "ca-app-pub-3133971041724338/2404411178"
    private const val PROD_NATIVE = "ca-app-pub-3133971041724338/2686327254"
    private const val PROD_REWARDED = "ca-app-pub-3133971041724338/6186588562"
    private const val PROD_APP_OPEN = "ca-app-pub-3133971041724338/6162537838"

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var rewardedInterstitialAd: RewardedInterstitialAd? = null
    private var appOpenAd: AppOpenAd? = null

    private var lastInterstitialShownMs = 0L
    private var lastAppOpenShownMs = 0L
    private var isShowingAd = false

    private fun rule(context: Context, key: String, fallbackId: String, defaultEnabled: Boolean = true): AdFormatRule {
        val cfg = SessionManager(context).getAppConfig()?.admob?.get(key)
        return cfg ?: AdFormatRule(
            enabled = defaultEnabled,
            testMode = false,
            adUnitId = fallbackId,
            frequencyCapPerHour = 0,
            cooldownSeconds = 0,
            rewardedPoints = 75,
            placementNotes = null
        )
    }

    // 1. BANNER AD
    fun loadBanner(context: Context, container: FrameLayout) {
        val r = rule(context, "banner", PROD_BANNER)
        if (!r.enabled) {
            container.visibility = View.GONE
            return
        }
        container.removeAllViews()
        val adView = AdView(context).apply {
            adUnitId = r.adUnitId.ifBlank { PROD_BANNER }
            setAdSize(AdSize.BANNER)
        }
        adView.adListener = object : AdListener() {
            override fun onAdFailedToLoad(error: LoadAdError) {
                container.visibility = View.GONE
            }
            override fun onAdLoaded() {
                container.visibility = View.VISIBLE
            }
        }
        container.addView(adView)
        adView.loadAd(AdRequest.Builder().build())
    }

    // 2. NATIVE AD (Clearly labelled Sponsored Ad)
    fun loadNative(context: Context, container: FrameLayout) {
        val r = rule(context, "native", PROD_NATIVE)
        if (!r.enabled) {
            container.visibility = View.GONE
            return
        }
        val loader = AdLoader.Builder(context, r.adUnitId.ifBlank { PROD_NATIVE })
            .forNativeAd { nativeAd: NativeAd ->
                val adView = LayoutInflater.from(context).inflate(R.layout.layout_native_ad, container, false) as NativeAdView
                adView.headlineView = adView.findViewById(R.id.adHeadline)
                adView.bodyView = adView.findViewById(R.id.adBody)
                adView.callToActionView = adView.findViewById(R.id.adCallToAction)
                adView.iconView = adView.findViewById(R.id.adAppIcon)

                (adView.headlineView as TextView).text = nativeAd.headline
                (adView.bodyView as TextView).text = nativeAd.body ?: ""
                (adView.callToActionView as Button).text = nativeAd.callToAction ?: "Learn More"
                nativeAd.icon?.drawable?.let { (adView.iconView as ImageView).setImageDrawable(it) }

                adView.setNativeAd(nativeAd)
                container.removeAllViews()
                container.addView(adView)
                container.visibility = View.VISIBLE
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    container.visibility = View.GONE
                }
            })
            .withNativeAdOptions(NativeAdOptions.Builder().build())
            .build()
        loader.loadAd(AdRequest.Builder().build())
    }

    // 3. INTERSTITIAL AD (Preloaded + shown immediately after every spin and on eligible transitions)
    fun preloadInterstitial(context: Context) {
        val r = rule(context, "interstitial", PROD_INTERSTITIAL)
        if (!r.enabled || interstitialAd != null) return
        InterstitialAd.load(
            context,
            r.adUnitId.ifBlank { PROD_INTERSTITIAL },
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitialAd = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitialAd = null }
            }
        )
    }

    fun showInterstitialAfterSpin(activity: Activity, onDone: () -> Unit) {
        val r = rule(activity, "interstitial", PROD_INTERSTITIAL)
        if (!r.enabled || isShowingAd) {
            onDone()
            return
        }
        val loaded = interstitialAd
        if (loaded != null) {
            presentInterstitial(activity, loaded, onDone)
            return
        }
        InterstitialAd.load(
            activity,
            r.adUnitId.ifBlank { PROD_INTERSTITIAL },
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    if (activity.isFinishing || activity.isDestroyed) {
                        interstitialAd = ad
                        onDone()
                        return
                    }
                    presentInterstitial(activity, ad, onDone)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    onDone()
                }
            }
        )
    }

    fun showInterstitialIfEligible(activity: Activity, onDone: () -> Unit) {
        val r = rule(activity, "interstitial", PROD_INTERSTITIAL)
        val elapsedSec = (System.currentTimeMillis() - lastInterstitialShownMs) / 1000
        if (!r.enabled || elapsedSec < r.cooldownSeconds || interstitialAd == null || isShowingAd) {
            preloadInterstitial(activity)
            onDone()
            return
        }
        interstitialAd?.let { presentInterstitial(activity, it, onDone) } ?: onDone()
    }

    private fun presentInterstitial(activity: Activity, ad: InterstitialAd, onDone: () -> Unit) {
        isShowingAd = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                isShowingAd = false
                interstitialAd = null
                lastInterstitialShownMs = System.currentTimeMillis()
                preloadInterstitial(activity)
                onDone()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                isShowingAd = false
                interstitialAd = null
                preloadInterstitial(activity)
                onDone()
            }
        }
        ad.show(activity)
    }

    // 4. REWARDED AD (Non-cash in-app points only)
    fun loadAndShowRewarded(
        activity: Activity,
        onEarned: (nonce: String) -> Unit,
        onUnavailable: (reason: String) -> Unit
    ) {
        val r = rule(activity, "rewarded", PROD_REWARDED)
        if (!r.enabled) {
            onUnavailable("Rewarded ads are currently disabled by administrator.")
            return
        }
        RewardedAd.load(
            activity,
            r.adUnitId.ifBlank { PROD_REWARDED },
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    var rewardGranted = false
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            rewardedAd = null
                            if (!rewardGranted) {
                                onUnavailable("Ad closed before completion.")
                            }
                        }
                        override fun onAdFailedToShowFullScreenContent(error: AdError) {
                            rewardedAd = null
                            onUnavailable(error.message)
                        }
                    }
                    ad.show(activity) { _ ->
                        rewardGranted = true
                        onEarned("admob_rw_${UUID.randomUUID()}")
                    }
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    onUnavailable("No rewarded ad available right now (${error.message}).")
                }
            }
        )
    }

    // 5. REWARDED INTERSTITIAL AD (Disabled unless configured by Admin)
    fun showRewardedInterstitialWithIntro(
        activity: Activity,
        onEarned: (nonce: String) -> Unit,
        onSkippedOrUnavailable: (msg: String) -> Unit
    ) {
        val r = rule(activity, "rewarded_interstitial", "", defaultEnabled = false)
        if (!r.enabled || r.adUnitId.isBlank()) {
            onSkippedOrUnavailable("Bonus ad is currently disabled.")
            return
        }
        MaterialAlertDialogBuilder(activity)
            .setTitle("Optional Bonus Ad")
            .setMessage("View a short sponsored ad to receive ${r.rewardedPoints} non-cash in-app points. You can skip at any time.")
            .setPositiveButton("Continue") { _, _ ->
                RewardedInterstitialAd.load(
                    activity,
                    r.adUnitId,
                    AdRequest.Builder().build(),
                    object : RewardedInterstitialAdLoadCallback() {
                        override fun onAdLoaded(ad: RewardedInterstitialAd) {
                            rewardedInterstitialAd = ad
                            var earned = false
                            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                                override fun onAdDismissedFullScreenContent() {
                                    rewardedInterstitialAd = null
                                    if (!earned) onSkippedOrUnavailable("Skipped before completion.")
                                }
                            }
                            ad.show(activity) { _ ->
                                earned = true
                                onEarned("admob_ri_${UUID.randomUUID()}")
                            }
                        }
                        override fun onAdFailedToLoad(error: LoadAdError) {
                            onSkippedOrUnavailable("Ad unavailable right now (${error.message}).")
                        }
                    }
                )
            }
            .setNegativeButton("Skip") { dialog, _ ->
                dialog.dismiss()
                onSkippedOrUnavailable("Skipped.")
            }
            .show()
    }

    // 6. APP OPEN AD (Launch/foreground resume)
    fun preloadAppOpen(context: Context) {
        val r = rule(context, "app_open", PROD_APP_OPEN)
        if (!r.enabled || appOpenAd != null) return
        AppOpenAd.load(
            context,
            r.adUnitId.ifBlank { PROD_APP_OPEN },
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) { appOpenAd = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { appOpenAd = null }
            }
        )
    }

    fun showAppOpenIfEligible(activity: Activity) {
        val r = rule(activity, "app_open", PROD_APP_OPEN)
        val elapsedSec = (System.currentTimeMillis() - lastAppOpenShownMs) / 1000
        if (!r.enabled || elapsedSec < r.cooldownSeconds || isShowingAd) {
            preloadAppOpen(activity)
            return
        }
        val ad = appOpenAd ?: run {
            preloadAppOpen(activity)
            return
        }
        isShowingAd = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                isShowingAd = false
                appOpenAd = null
                lastAppOpenShownMs = System.currentTimeMillis()
                preloadAppOpen(activity)
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                isShowingAd = false
                appOpenAd = null
            }
        }
        ad.show(activity)
    }
}
