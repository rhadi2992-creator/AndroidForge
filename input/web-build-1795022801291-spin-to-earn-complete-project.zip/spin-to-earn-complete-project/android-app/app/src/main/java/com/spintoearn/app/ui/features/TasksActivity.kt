package com.spintoearn.app.ui.features

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.model.TaskItem
import com.spintoearn.app.databinding.ActivityTasksBinding
import com.spintoearn.app.databinding.ItemListRowBinding
import kotlinx.coroutines.launch

class TasksActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTasksBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTasksBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.rvTasks.layoutManager = LinearLayoutManager(this)
        loadTasks()
    }

    private fun loadTasks() {
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService(this@TasksActivity).getTasks()
                if (res.success && res.data != null) {
                    binding.rvTasks.adapter = TaskAdapter(res.data.tasks.orEmpty()) { task ->
                        openProofDialog(task)
                    }
                } else {
                    Toast.makeText(this@TasksActivity, res.message ?: "Unable to load tasks.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@TasksActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openProofDialog(task: TaskItem) {
        if (!task.canSubmit) {
            Toast.makeText(this, "Submission limit reached for this task.", Toast.LENGTH_SHORT).show()
            return
        }
        val input = EditText(this).apply { hint = task.proofPlaceholder ?: "Enter proof details" }
        MaterialAlertDialogBuilder(this)
            .setTitle(task.title ?: "Cash Task")
            .setMessage("${task.instructions.orEmpty()}\n\nReward: Rs. ${String.format("%.2f", task.rewardPkr)}")
            .setView(input)
            .setPositiveButton("Submit Proof") { _, _ ->
                val proof = input.text.toString().trim()
                lifecycleScope.launch {
                    try {
                        val res = ApiClient.getService(this@TasksActivity).submitTask(
                            mapOf("task_id" to task.id, "proof_text" to proof)
                        )
                        Toast.makeText(
                            this@TasksActivity,
                            res.message ?: if (res.success) "Task proof submitted." else "Submission failed.",
                            Toast.LENGTH_LONG
                        ).show()
                        loadTasks()
                    } catch (e: Exception) {
                        Toast.makeText(this@TasksActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private class TaskAdapter(
        private val items: List<TaskItem>,
        private val onClick: (TaskItem) -> Unit
    ) : RecyclerView.Adapter<TaskAdapter.VH>() {
        class VH(val b: ItemListRowBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemListRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.b.tvRowTitle.text = item.title.orEmpty()
            holder.b.tvRowSubtitle.text = item.instructions.orEmpty()
            holder.b.tvRowMeta.text = "Reward: Rs. ${String.format("%.2f", item.rewardPkr)} · ${item.category.orEmpty()}"
            holder.itemView.setOnClickListener { onClick(item) }
        }
    }
}
