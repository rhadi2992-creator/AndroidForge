package com.spintoearn.app.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.spintoearn.app.ads.AdMobManager
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.local.SessionManager
import com.spintoearn.app.databinding.FragmentSpinBinding
import kotlinx.coroutines.launch
import java.util.UUID

class SpinFragment : Fragment() {

    private var _binding: FragmentSpinBinding? = null
    private val binding get() = _binding!!
    private var isSpinning = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSpinBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        AdMobManager.loadBanner(requireContext(), binding.bannerAdContainer)
        AdMobManager.preloadInterstitial(requireContext())

        binding.btnSpinNow.isEnabled = false
        binding.btnSpinNow.setOnClickListener { executeSpin() }
        loadWheel()
    }

    private fun loadWheel() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val res = ApiClient.getService(requireContext()).getSpinWheel()
                if (res.success && res.data != null && _binding != null) {
                    val d = res.data
                    val slices = d.slices.orEmpty()
                    val recent = d.recentSpins.orEmpty()
                    binding.spinWheelView.setSlices(slices)
                    binding.tvRemainingSpins.text = "Remaining spins today: ${d.remainingToday} / ${d.dailyLimit} (${d.serverDateUtc.orEmpty()})"
                    binding.btnSpinNow.isEnabled = !isSpinning && d.spinsEnabled && d.remainingToday > 0 && slices.isNotEmpty()

                    binding.tvRecentSpins.text = if (recent.isEmpty()) {
                        "No spins recorded yet."
                    } else {
                        recent.joinToString("\n") {
                            "• ${it.label ?: "Spin"} (+${it.pointsAwarded} pts) — ${it.spinDateUtc.orEmpty()}"
                        }
                    }
                } else if (_binding != null) {
                    binding.btnSpinNow.isEnabled = false
                    binding.tvRemainingSpins.text = res.message ?: "Unable to load spin wheel."
                }
            } catch (e: Exception) {
                if (_binding != null) {
                    binding.btnSpinNow.isEnabled = false
                    val msg = ApiClient.extractErrorMessage(e)
                    binding.tvRemainingSpins.text = msg
                    Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun executeSpin() {
        if (isSpinning) return
        isSpinning = true
        binding.btnSpinNow.isEnabled = false
        val idempotencyKey = "spin_${UUID.randomUUID()}"
        val fp = SessionManager(requireContext()).getDeviceFingerprint()

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val res = ApiClient.getService(requireContext()).executeSpin(
                    mapOf("idempotency_key" to idempotencyKey, "device_fingerprint" to fp)
                )
                if (res.success && res.data != null && _binding != null) {
                    val result = res.data
                    binding.spinWheelView.spinToSliceIndex(result.sliceIndex) {
                        isSpinning = false
                        if (_binding != null && isAdded) {
                            AdMobManager.showInterstitialAfterSpin(requireActivity()) {
                                if (_binding != null && isAdded) {
                                    MaterialAlertDialogBuilder(requireContext())
                                        .setTitle("Spin Result")
                                        .setMessage("You received ${result.pointsAwarded} non-cash points!\nNew Non-Cash Balance: ${result.pointsBalance} pts")
                                        .setPositiveButton("OK", null)
                                        .show()
                                    loadWheel()
                                }
                            }
                        }
                    }
                } else {
                    isSpinning = false
                    if (_binding != null) {
                        binding.btnSpinNow.isEnabled = true
                        Toast.makeText(requireContext(), res.message ?: "Spin failed.", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                isSpinning = false
                if (_binding != null && isAdded) {
                    binding.btnSpinNow.isEnabled = true
                    Toast.makeText(requireContext(), ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
                    loadWheel()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
