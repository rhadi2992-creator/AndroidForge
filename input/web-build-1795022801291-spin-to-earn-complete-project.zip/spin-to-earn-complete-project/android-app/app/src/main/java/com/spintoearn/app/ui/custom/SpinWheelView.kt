package com.spintoearn.app.ui.custom

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.spintoearn.app.data.model.WheelSlice
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class SpinWheelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var slices: List<WheelSlice> = emptyList()
    private val slicePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 32f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val pointerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0F172A")
        style = Paint.Style.FILL
    }
    private val oval = RectF()
    private var currentRotation = 0f

    fun setSlices(items: List<WheelSlice>) {
        slices = items
        invalidate()
    }

    fun spinToSliceIndex(targetSliceIndex: Int, onComplete: () -> Unit) {
        if (slices.isEmpty()) {
            onComplete()
            return
        }
        val idx = slices.indexOfFirst { it.sliceIndex == targetSliceIndex }.coerceAtLeast(0)
        val sweep = 360f / slices.size
        // Pointer is at top (270 deg). Calculate angle so target slice center lands at 270 deg.
        val sliceCenter = idx * sweep + (sweep / 2f)
        val targetAngle = (360f * 6) + (270f - sliceCenter)
        val start = currentRotation % 360f
        val end = start + (targetAngle - (start % 360f)) + 1080f

        ObjectAnimator.ofFloat(this, "wheelRotation", start, end).apply {
            duration = 3600L
            interpolator = DecelerateInterpolator(2.2f)
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    currentRotation = end % 360f
                    onComplete()
                }
            })
            start()
        }
    }

    @Suppress("unused")
    fun setWheelRotation(deg: Float) {
        currentRotation = deg
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = min(width, height).toFloat()
        val pad = 24f
        val cx = width / 2f
        val cy = height / 2f
        val radius = (size / 2f) - pad
        oval.set(cx - radius, cy - radius, cx + radius, cy + radius)

        if (slices.isEmpty()) return

        val sweep = 360f / slices.size
        canvas.save()
        canvas.rotate(currentRotation, cx, cy)

        slices.forEachIndexed { index, slice ->
            val startAngle = index * sweep
            slicePaint.color = try {
                Color.parseColor(slice.sliceColor ?: "#1D4ED8")
            } catch (_: Exception) {
                Color.parseColor("#1D4ED8")
            }
            canvas.drawArc(oval, startAngle, sweep, true, slicePaint)
            canvas.drawArc(oval, startAngle, sweep, true, borderPaint)

            val midRad = Math.toRadians((startAngle + sweep / 2f).toDouble())
            val tx = (cx + cos(midRad) * radius * 0.65f).toFloat()
            val ty = (cy + sin(midRad) * radius * 0.65f).toFloat() + 10f
            canvas.drawText(slice.label ?: "${slice.pointsValue}", tx, ty, textPaint)
        }
        canvas.restore()

        // Top pointer triangle
        val pointer = Path().apply {
            moveTo(cx, pad + 26f)
            lineTo(cx - 18f, pad - 8f)
            lineTo(cx + 18f, pad - 8f)
            close()
        }
        canvas.drawPath(pointer, pointerPaint)
    }
}
