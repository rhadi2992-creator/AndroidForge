# Keep generic signatures and annotations for Retrofit & Gson
-keepattributes Exceptions, InnerClasses, Signature, *Annotation*

# Keep custom SpinWheelView animated property setter used by ObjectAnimator
-keepclassmembers class com.spintoearn.app.ui.custom.SpinWheelView {
    public void setWheelRotation(float);
}

# Keep API data models & Gson @SerializedName fields
-keep class com.spintoearn.app.data.model.** { *; }
-keep class com.google.gson.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Retrofit 2 & OkHttp 4 rules
-keep interface com.spintoearn.app.data.api.** { *; }
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
-keepattributes EnclosingMethod
-keepclassmembers class * extends com.google.gson.reflect.TypeToken
-keep,allowobfuscation,allowshrinking class retrofit2.Response
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation
-dontwarn retrofit2.**
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-dontwarn org.codehaus.mojo.animal_sniffer.**

# Keep Google Mobile Ads SDK classes
-keep class com.google.android.gms.ads.** { *; }
-keep class com.spintoearn.app.ads.AdMobManager { *; }
