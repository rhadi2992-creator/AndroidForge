# 03. Google AdMob Integration Guide

## Configured AdMob IDs (Production)
- App ID (`AndroidManifest.xml`): `ca-app-pub-3133971041724338~1937507315`
- Banner: `ca-app-pub-3133971041724338/8119772283`
- Interstitial: `ca-app-pub-3133971041724338/2404411178`
- Native: `ca-app-pub-3133971041724338/2686327254`
- Rewarded: `ca-app-pub-3133971041724338/6186588562`
- App Open: `ca-app-pub-3133971041724338/6162537838`

## Active Placements in `AdMobManager.kt`
1. **Banner Ads**: Reserved bottom layout container on Home, Spin, Wallet, Referral, and Profile—never overlapping Submit/Withdraw buttons.
2. **Interstitial Ads**: Preloaded on launch and inside `SpinFragment`; triggered immediately after every spin completes (5 spins = 5 interstitial ads) via `showInterstitialAfterSpin`, plus eligible transitions.
3. **Native Ads**: Inflated with `layout_native_ad.xml` showing an explicit `"Sponsored Ad"` label on Home and Referral screens.
4. **Rewarded Ads**: Optional non-cash bonus points trigger in `RewardsActivity`; awards non-cash points only via SDK callback + server nonce verification. (Standalone "Watch Video & Earn" UI/sections removed.)
5. **App Open Ads**: Lifecycle-managed via `ProcessLifecycleOwner` with configurable cooldown.

## Admin Panel & SSV Configuration
1. All active Ad Unit IDs above are pre-seeded in `advertisements_settings` with `test_mode = 0`.
2. You can toggle formats or adjust frequency caps anytime in **Admin Panel -> AdMob Settings**.
3. Enable `ADMOB_SSV_VERIFY=true` and configure your AdMob SSV callback URL in the AdMob console pointing to `backend-api/api/v1/ads/rewarded_verify.php`.
