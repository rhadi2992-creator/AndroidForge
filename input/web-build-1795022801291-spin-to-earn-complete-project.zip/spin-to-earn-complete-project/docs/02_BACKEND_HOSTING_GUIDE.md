# 02. PHP 8.2+ Backend & Admin Panel Hosting Guide

## Server Requirements
- PHP 8.2+ with extensions: `pdo_mysql`, `openssl`, `fileinfo`, `mbstring`, `json`
- Apache (with `mod_rewrite` enabled) or Nginx + PHP-FPM
- MySQL 8.0+ or MariaDB 10.4+
- Valid HTTPS/TLS certificate for production (Let's Encrypt or managed TLS — required because `usesCleartextTraffic="false"` is enforced in `AndroidManifest.xml`).

## Local Windows XAMPP URLs
When placed in `C:\xampp\htdocs\spin-to-earn-complete-project\`:
- Backend API root: `http://localhost/spin-to-earn-complete-project/backend-api/`
- Public App Config endpoint: `http://localhost/spin-to-earn-complete-project/backend-api/api/v1/config/app.php`
- Admin Panel Login: `http://localhost/spin-to-earn-complete-project/admin-panel/login.php`

## Live Production Deployment Steps
1. Upload `backend-api/` and `admin-panel/` to your HTTPS host.
2. Copy `backend-api/config.production.example.php` to `backend-api/config.production.php` (kept separate from local XAMPP defaults) and configure your live DB credentials + HTTPS `APP_BASE_URL`.
3. Run `php backend-api/setup.php` once via SSH/CLI to generate a unique 64-char hex `backend-api/.app_secret` and initial Super Admin credentials.
4. Ensure sensitive files (`config.php`, `config.production.php`, `.app_secret`, `database.php`, `setup.php`) are blocked from HTTP access (`.htaccess` is included for Apache).
5. For Nginx, add:
   ```nginx
   location ~* /(\.app_secret|\.env|config(\.production(\.example)?)?\.php|database\.php|setup\.php)$ {
       deny all;
   }
   location ^~ /backend-api/uploads/ {
       deny all;
   }
   ```
6. Set `API_BASE_URL` at Gradle build time via `-PAPI_BASE_URL="https://YOUR_DOMAIN/backend-api/api/v1/"`. Never hardcode `localhost` into remote release APKs.
