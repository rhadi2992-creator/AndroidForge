# 08. AndroidForge & GitHub Actions CI/CD Guide

## Why `gradle assembleRelease` Failed Previously
In `spin-to-earn-complete-project.zip`, the repository contains five top-level modules:
- `android-app/` (contains `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `gradlew`, `app/`)
- `backend-api/` (PHP 8+ REST API)
- `admin-panel/` (PHP Web Admin Dashboard)
- `database/` (MySQL schema)
- `docs/` (Guides)

Running `gradle assembleRelease` from the outer `spin-to-earn-complete-project/` folder fails with:
`Directory does not contain a Gradle build.`

## How to Upload & Configure in AndroidForge
1. **If uploading `spin-to-earn-complete-project.zip` directly to AndroidForge:**
   - Set **Project Root / Working Directory** in AndroidForge build settings to:
     `spin-to-earn-complete-project/android-app` (or `android-app` if AndroidForge unzips the top-level directory).
   - Set **Build Command** to:
     `./gradlew assembleRelease --no-daemon` (or `gradle assembleRelease`).
   - *(Optional)* If your AndroidForge uploader rejects nested directories and only accepts a ZIP whose root directly contains `settings.gradle.kts`, zip ONLY the contents of `android-app/` (or select `android-app/` when uploading) while keeping `backend-api/`, `admin-panel/`, and `database/` deployed on your PHP server.
2. **If building via GitHub Actions:**
   - Push the complete repository to GitHub (the included `.github/workflows/android-release.yml` automatically detects `android-app/settings.gradle.kts`, installs JDK 17 + Android SDK 34, runs `./gradlew assembleRelease` inside `android-app/`, and uploads the APK artifact).
3. **Production Backend URL (`API_BASE_URL`):**
   - Replace the placeholder `https://your-domain.example.com/backend-api/api/v1/` with your hosted HTTPS PHP backend URL via `-PAPI_BASE_URL="https://api.yourdomain.com/backend-api/api/v1/"` or repository variable `API_BASE_URL`.
   - Never use `localhost` or `127.0.0.1` in a remotely distributed APK.
4. **Signed vs. Unsigned Release APK:**
   - **Signed APK (`app-release.apk`)**: Produced when `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, and `ANDROID_KEY_PASSWORD` secrets (or `android-app/keystore.properties`) are provided. Required for Play Store / device installation.
   - **Unsigned APK (`app-release-unsigned.apk`)**: Produced when signing credentials are not provided. Cannot be installed on Android phones until signed with `apksigner` or a keystore.
