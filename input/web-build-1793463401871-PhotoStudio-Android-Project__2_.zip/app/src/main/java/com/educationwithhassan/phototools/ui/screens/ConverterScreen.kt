package com.educationwithhassan.phototools.ui.screens

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.phototools.core.ads.AdMobManager
import com.educationwithhassan.phototools.core.image.BitmapUtils
import com.educationwithhassan.phototools.core.image.ImageConverter
import com.educationwithhassan.phototools.core.storage.HistoryRepository
import com.educationwithhassan.phototools.core.storage.MediaStoreSaver
import com.educationwithhassan.phototools.data.model.SavedProject
import com.educationwithhassan.phototools.data.preferences.AppPreferences
import com.educationwithhassan.phototools.ui.PhotoStudioViewModel
import com.educationwithhassan.phototools.ui.components.EmptyPhotoPlaceholder
import com.educationwithhassan.phototools.ui.components.PrimaryActionButton
import com.educationwithhassan.phototools.ui.components.ToolTopBar
import com.educationwithhassan.phototools.ui.theme.PrimaryBlue
import com.educationwithhassan.phototools.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ConverterScreen(
    viewModel: PhotoStudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val preferences = remember { AppPreferences(context) }
    val historyRepo = remember { HistoryRepository(context) }

    val originalBitmap by viewModel.currentBitmap.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var selectedTargetFormat by remember { mutableStateOf(ImageConverter.TargetFormat.PNG) }
    var isProcessing by remember { mutableStateOf(false) }
    var conversionResult by remember { mutableStateOf<ImageConverter.ConversionResult?>(null) }
    var lastSavedResult by remember { mutableStateOf<MediaStoreSaver.SaveResult?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setPhotoUri(uri)
            lastSavedResult = null
        }
    }

    // Convert when format or bitmap changes
    LaunchedEffect(originalBitmap, selectedTargetFormat) {
        val bmp = originalBitmap ?: return@LaunchedEffect
        isProcessing = true
        withContext(Dispatchers.IO) {
            val result = ImageConverter.convert(bmp, selectedTargetFormat)
            withContext(Dispatchers.Main) {
                conversionResult = result
                isProcessing = false
            }
        }
    }

    Scaffold(
        topBar = {
            ToolTopBar(
                title = "Format Converter",
                onBack = onBack,
                actions = {
                    IconButton(onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Change Photo", tint = PrimaryBlue)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = PrimaryBlue)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Loading photo...", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else if (originalBitmap == null) {
                EmptyPhotoPlaceholder(
                    title = if (errorMessage != null) "Failed to Load Photo" else "No Photo Selected",
                    subtitle = errorMessage ?: "Select a photo from your gallery to convert",
                    onSelectPhoto = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                )
            } else {
                val orig = originalBitmap!!

                // Preview Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        conversionResult?.outputBitmap?.let { bmp ->
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Preview",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp)
                            )
                        } ?: CircularProgressIndicator(color = PrimaryBlue)

                        // Floating badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Output: ${selectedTargetFormat.extension.uppercase()} (${conversionResult?.fileSizeFormatted ?: ""})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Format Cards (JPG, PNG, WebP)
                Column {
                    Text(
                        text = "Choose Target Output Format",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    ImageConverter.TargetFormat.values().forEach { fmt ->
                        val isSelected = selectedTargetFormat == fmt
                        Card(
                            onClick = { selectedTargetFormat = fmt },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) PrimaryBlue.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                            ),
                            border = if (isSelected) CardDefaults.outlinedCardBorder().copy(
                                brush = androidx.compose.ui.graphics.SolidColor(PrimaryBlue)
                            ) else CardDefaults.outlinedCardBorder()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = fmt.displayName,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                        color = if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (fmt.supportsTransparency) "Supports Alpha & Transparency" else "Flattened Solid Background",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedTargetFormat = fmt },
                                    colors = RadioButtonDefaults.colors(selectedColor = PrimaryBlue)
                                )
                            }
                        }
                    }
                }

                // Transparency Info Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = PrimaryBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (selectedTargetFormat == ImageConverter.TargetFormat.JPG) {
                                "Converting transparent images to JPG automatically fills background with clean white."
                            } else {
                                "Full transparency and color depth are preserved in output."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Save Action
                PrimaryActionButton(
                    text = if (isProcessing) "Converting..." else "Save As ${selectedTargetFormat.extension.uppercase()}",
                    enabled = !isProcessing && conversionResult != null,
                    onClick = {
                        val result = conversionResult ?: return@PrimaryActionButton
                        isProcessing = true
                        coroutineScope.launch {
                            val saveRes = withContext(Dispatchers.IO) {
                                MediaStoreSaver.saveBitmap(
                                    context = context,
                                    bitmap = result.outputBitmap,
                                    format = selectedTargetFormat.extension,
                                    quality = 95,
                                    prefix = "Converted"
                                )
                            }
                            lastSavedResult = saveRes
                            isProcessing = false

                            if (saveRes.success && saveRes.uri != null) {
                                historyRepo.addProject(
                                    SavedProject(
                                        id = saveRes.fileName,
                                        title = "Converted to ${selectedTargetFormat.extension.uppercase()}",
                                        toolType = "Converter",
                                        uriString = saveRes.uri.toString(),
                                        timestamp = System.currentTimeMillis(),
                                        width = orig.width,
                                        height = orig.height,
                                        fileSizeFormatted = saveRes.fileSizeFormatted
                                    )
                                )
                                Toast.makeText(context, "Saved to Pictures/PhotoStudio", Toast.LENGTH_SHORT).show()

                                if (preferences.incrementActionAndShouldShowAd()) {
                                    (context as? Activity)?.let { act ->
                                        AdMobManager.showInterstitialIfReady(act) {}
                                    }
                                }
                            }
                        }
                    }
                )

                lastSavedResult?.let { res ->
                    if (res.success && res.uri != null) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = SuccessGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Converted and Saved!", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = SuccessGreen)
                                }
                                Button(
                                    onClick = { MediaStoreSaver.shareImage(context, res.uri) },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Share", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
