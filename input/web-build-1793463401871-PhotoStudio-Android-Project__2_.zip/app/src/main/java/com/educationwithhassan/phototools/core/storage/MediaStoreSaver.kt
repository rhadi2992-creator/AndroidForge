package com.educationwithhassan.phototools.core.storage

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.educationwithhassan.phototools.core.image.BitmapUtils
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MediaStoreSaver {

    data class SaveResult(
        val success: Boolean,
        val uri: Uri?,
        val filePath: String?,
        val fileName: String,
        val fileSizeFormatted: String,
        val errorMessage: String? = null
    )

    fun saveBitmap(
        context: Context,
        bitmap: Bitmap,
        format: String = "JPG",
        quality: Int = 90,
        prefix: String = "PhotoStudio"
    ): SaveResult {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val ext = when (format.uppercase()) {
            "PNG" -> "png"
            "WEBP" -> "webp"
            else -> "jpg"
        }
        val fileName = "${prefix}_${timeStamp}.${ext}"
        val mimeType = when (ext) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            else -> "image/jpeg"
        }

        val compressFormat = when (ext) {
            "png" -> Bitmap.CompressFormat.PNG
            "webp" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (quality >= 100) Bitmap.CompressFormat.WEBP_LOSSLESS else Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    @Suppress("DEPRECATION")
                    Bitmap.CompressFormat.WEBP
                }
            }
            else -> Bitmap.CompressFormat.JPEG
        }

        return try {
            var outputUri: Uri? = null
            var bytesWritten = 0L

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PhotoStudio")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                outputUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

                outputUri?.let { uri ->
                    resolver.openOutputStream(uri)?.use { stream ->
                        bitmap.compress(compressFormat, quality, stream)
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)

                    bytesWritten = BitmapUtils.getFileSizeFromUri(context, uri)
                }
            } else {
                // Legacy storage for Android 9 and lower
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val photoStudioDir = File(picturesDir, "PhotoStudio")
                if (!photoStudioDir.exists()) {
                    photoStudioDir.mkdirs()
                }

                val imageFile = File(photoStudioDir, fileName)
                FileOutputStream(imageFile).use { out ->
                    bitmap.compress(compressFormat, quality, out)
                    out.flush()
                }
                bytesWritten = imageFile.length()
                outputUri = Uri.fromFile(imageFile)

                // Notify media scanner
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DATA, imageFile.absolutePath)
                    put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                }
                context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            }

            if (outputUri != null) {
                SaveResult(
                    success = true,
                    uri = outputUri,
                    filePath = "Pictures/PhotoStudio/$fileName",
                    fileName = fileName,
                    fileSizeFormatted = BitmapUtils.formatFileSize(bytesWritten)
                )
            } else {
                SaveResult(
                    success = false,
                    uri = null,
                    filePath = null,
                    fileName = fileName,
                    fileSizeFormatted = "0 B",
                    errorMessage = "Failed to obtain MediaStore output stream"
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            SaveResult(
                success = false,
                uri = null,
                filePath = null,
                fileName = fileName,
                fileSizeFormatted = "0 B",
                errorMessage = e.localizedMessage ?: "Unknown save error"
            )
        }
    }

    /**
     * Launch the Android Share Sheet for a saved image URI.
     */
    fun shareImage(context: Context, uri: Uri, mimeType: String = "image/*") {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share image via").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
