package com.educationwithhassan.phototools.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.educationwithhassan.phototools.core.image.BitmapUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PhotoStudioViewModel(application: Application) : AndroidViewModel(application) {

    private val _currentPhotoUri = MutableStateFlow<Uri?>(null)
    val currentPhotoUri: StateFlow<Uri?> = _currentPhotoUri.asStateFlow()

    private val _currentBitmap = MutableStateFlow<Bitmap?>(null)
    val currentBitmap: StateFlow<Bitmap?> = _currentBitmap.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _fileSize = MutableStateFlow(0L)
    val fileSize: StateFlow<Long> = _fileSize.asStateFlow()

    fun setPhotoUri(uri: Uri?) {
        if (uri == null) return
        _currentPhotoUri.value = uri
        _isLoading.value = true
        _errorMessage.value = null

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val size = BitmapUtils.getFileSizeFromUri(context, uri)
                val bmp = BitmapUtils.decodeSampledBitmapFromUri(context, uri)

                withContext(Dispatchers.Main) {
                    if (bmp != null) {
                        _currentBitmap.value = bmp
                        _fileSize.value = if (size > 0) size else bmp.byteCount.toLong()
                        _isLoading.value = false
                        _errorMessage.value = null
                    } else {
                        _isLoading.value = false
                        _errorMessage.value = "Unable to decode the selected photo. Please try another image."
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _isLoading.value = false
                    _errorMessage.value = "Error loading photo: ${e.localizedMessage}"
                }
            }
        }
    }

    fun clearPhoto() {
        _currentPhotoUri.value = null
        _currentBitmap.value = null
        _fileSize.value = 0L
        _errorMessage.value = null
    }

    fun updateCurrentBitmap(newBitmap: Bitmap) {
        _currentBitmap.value = newBitmap
    }
}
