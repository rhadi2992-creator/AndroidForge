package com.educationwithhassan.phototools.ui.screens

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import android.view.MotionEvent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.phototools.core.ads.AdMobManager
import com.educationwithhassan.phototools.core.image.ImageAdjuster
import com.educationwithhassan.phototools.core.storage.HistoryRepository
import com.educationwithhassan.phototools.core.storage.MediaStoreSaver
import com.educationwithhassan.phototools.data.model.SavedProject
import com.educationwithhassan.phototools.data.preferences.AppPreferences
import com.educationwithhassan.phototools.ui.PhotoStudioViewModel
import com.educationwithhassan.phototools.ui.components.EmptyPhotoPlaceholder
import com.educationwithhassan.phototools.ui.components.PrimaryActionButton
import com.educationwithhassan.phototools.ui.components.SliderControl
import com.educationwithhassan.phototools.ui.components.ToolTopBar
import com.educationwithhassan.phototools.ui.theme.DangerRed
import com.educationwithhassan.phototools.ui.theme.PrimaryBlue
import com.educationwithhassan.phototools.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun EditorScreen(
    viewModel: PhotoStudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val preferences = remember { AppPreferences(context) }
    val historyRepo = remember { HistoryRepository(context) }

    val originalBitmap by viewModel.currentBitmap.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var adjustedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var editState by remember { mutableStateOf(ImageAdjuster.EditState()) }
    var undoStack by remember { mutableStateOf(listOf<ImageAdjuster.EditState>()) }
    var redoStack by remember { mutableStateOf(listOf<ImageAdjuster.EditState>()) }

    var showOriginalComparison by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Adjust, 1: Filters
    var isProcessing by remember { mutableStateOf(false) }
    var lastSavedResult by remember { mutableStateOf<MediaStoreSaver.SaveResult?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setPhotoUri(uri)
            lastSavedResult = null
        }
    }

    // Reset adjusted bitmap when base original bitmap changes
    LaunchedEffect(originalBitmap) {
        adjustedBitmap = originalBitmap
        editState = ImageAdjuster.EditState()
        undoStack = emptyList()
        redoStack = emptyList()
    }

    // Apply adjustments whenever editState changes
    LaunchedEffect(originalBitmap, editState) {
        val orig = originalBitmap ?: return@LaunchedEffect
        isProcessing = true
        withContext(Dispatchers.IO) {
            val result = ImageAdjuster.applyAdjustments(orig, editState)
            withContext(Dispatchers.Main) {
                adjustedBitmap = result
                isProcessing = false
            }
        }
    }

    fun updateStateWithUndo(newState: ImageAdjuster.EditState) {
        undoStack = undoStack + editState
        redoStack = emptyList()
        editState = newState
    }

    fun performUndo() {
        if (undoStack.isNotEmpty()) {
            val previous = undoStack.last()
            undoStack = undoStack.dropLast(1)
            redoStack = redoStack + editState
            editState = previous
        }
    }

    fun performRedo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.last()
            redoStack = redoStack.dropLast(1)
            undoStack = undoStack + editState
            editState = next
        }
    }

    fun resetToOriginal() {
        if (editState != ImageAdjuster.EditState()) {
            undoStack = undoStack + editState
            redoStack = emptyList()
            editState = ImageAdjuster.EditState()
        }
    }

    Scaffold(
        topBar = {
            ToolTopBar(
                title = "Photo Editor",
                onBack = onBack,
                actions = {
                    IconButton(onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Change Photo", tint = PrimaryBlue)
                    }
                    IconButton(onClick = { performUndo() }, enabled = undoStack.isNotEmpty()) {
                        Icon(
                            Icons.Default.Undo,
                            contentDescription = "Undo",
                            tint = if (undoStack.isNotEmpty()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                        )
                    }
                    IconButton(onClick = { performRedo() }, enabled = redoStack.isNotEmpty()) {
                        Icon(
                            Icons.Default.Redo,
                            contentDescription = "Redo",
                            tint = if (redoStack.isNotEmpty()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                        )
                    }
                    IconButton(onClick = { resetToOriginal() }, enabled = originalBitmap != null) {
                        Icon(Icons.Default.RestartAlt, contentDescription = "Reset", tint = MaterialTheme.colorScheme.onSurface)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = PrimaryBlue)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Loading your photo...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else if (originalBitmap == null) {
                EmptyPhotoPlaceholder(
                    title = if (errorMessage != null) "Failed to Load Photo" else "No Photo Selected",
                    subtitle = errorMessage ?: "Choose an image from your gallery to start editing",
                    onSelectPhoto = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                )
            } else {
                val orig = originalBitmap!!

                // Image Preview Card with Before/After touch support
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        val displayBmp = if (showOriginalComparison) orig else (adjustedBitmap ?: orig)
                        Image(
                            bitmap = displayBmp.asImageBitmap(),
                            contentDescription = "Preview",
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp)
                        )

                        // Top info badge: dimensions
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(10.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${orig.width} × ${orig.height} px",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Floating comparison button (touch and hold to see original)
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.95f))
                                .pointerInteropFilter { motionEvent ->
                                    when (motionEvent.action) {
                                        MotionEvent.ACTION_DOWN -> {
                                            showOriginalComparison = true
                                            true
                                        }
                                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                                            showOriginalComparison = false
                                            true
                                        }
                                        else -> false
                                    }
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = if (showOriginalComparison) "SHOWING ORIGINAL" else "HOLD FOR BEFORE",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (showOriginalComparison) PrimaryBlue else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Sub-tabs: Adjust vs Filters
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = PrimaryBlue
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Tone & Light", fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Creative Filters", fontWeight = FontWeight.SemiBold) }
                    )
                }

                if (selectedTab == 0) {
                    // Sliders
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            SliderControl(
                                title = "Brightness",
                                value = editState.brightness,
                                onValueChange = { updateStateWithUndo(editState.copy(brightness = it)) },
                                valueRange = -100f..100f,
                                valueDisplay = "${editState.brightness.toInt()}"
                            )

                            SliderControl(
                                title = "Contrast",
                                value = editState.contrast,
                                onValueChange = { updateStateWithUndo(editState.copy(contrast = it)) },
                                valueRange = -100f..100f,
                                valueDisplay = "${editState.contrast.toInt()}"
                            )

                            SliderControl(
                                title = "Saturation",
                                value = editState.saturation,
                                onValueChange = { updateStateWithUndo(editState.copy(saturation = it)) },
                                valueRange = -100f..100f,
                                valueDisplay = "${editState.saturation.toInt()}"
                            )

                            SliderControl(
                                title = "Exposure",
                                value = editState.exposure,
                                onValueChange = { updateStateWithUndo(editState.copy(exposure = it)) },
                                valueRange = -100f..100f,
                                valueDisplay = "${editState.exposure.toInt()}"
                            )

                            SliderControl(
                                title = "Warmth",
                                value = editState.warmth,
                                onValueChange = { updateStateWithUndo(editState.copy(warmth = it)) },
                                valueRange = -100f..100f,
                                valueDisplay = "${editState.warmth.toInt()}"
                            )
                        }
                    }
                } else {
                    // Filter Presets Carousel
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Select Preset Filter",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(ImageAdjuster.FilterPreset.values()) { preset ->
                                    val isSelected = editState.filter == preset
                                    OutlinedButton(
                                        onClick = { updateStateWithUndo(editState.copy(filter = preset)) },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (isSelected) PrimaryBlue.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface,
                                            contentColor = if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.onSurface
                                        ),
                                        border = ButtonDefaults.outlinedButtonBorder.copy(
                                            brush = androidx.compose.ui.graphics.SolidColor(
                                                if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.outline
                                            )
                                        )
                                    ) {
                                        Text(
                                            text = preset.displayName,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Save Action
                PrimaryActionButton(
                    text = if (isProcessing) "Applying..." else "Save Edited Photo",
                    enabled = !isProcessing && adjustedBitmap != null,
                    onClick = {
                        val output = adjustedBitmap ?: return@PrimaryActionButton
                        isProcessing = true
                        coroutineScope.launch {
                            val saveRes = withContext(Dispatchers.IO) {
                                MediaStoreSaver.saveBitmap(
                                    context = context,
                                    bitmap = output,
                                    format = "JPG",
                                    quality = 92,
                                    prefix = "Edited"
                                )
                            }
                            lastSavedResult = saveRes
                            isProcessing = false

                            if (saveRes.success && saveRes.uri != null) {
                                historyRepo.addProject(
                                    SavedProject(
                                        id = saveRes.fileName,
                                        title = "Enhanced Photo",
                                        toolType = "Photo Editor",
                                        uriString = saveRes.uri.toString(),
                                        timestamp = System.currentTimeMillis(),
                                        width = output.width,
                                        height = output.height,
                                        fileSizeFormatted = saveRes.fileSizeFormatted
                                    )
                                )
                                Toast.makeText(context, "Saved to Pictures/PhotoStudio", Toast.LENGTH_SHORT).show()

                                if (preferences.incrementActionAndShouldShowAd()) {
                                    (context as? Activity)?.let { act ->
                                        AdMobManager.showInterstitialIfReady(act) {}
                                    }
                                }
                            }
                        }
                    }
                )

                lastSavedResult?.let { res ->
                    if (res.success && res.uri != null) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = SuccessGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Saved Successfully!", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = SuccessGreen)
                                }
                                Button(
                                    onClick = { MediaStoreSaver.shareImage(context, res.uri) },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Share", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
