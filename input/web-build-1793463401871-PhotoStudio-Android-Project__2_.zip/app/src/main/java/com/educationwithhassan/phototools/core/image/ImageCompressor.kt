package com.educationwithhassan.phototools.core.image

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import java.io.ByteArrayOutputStream

object ImageCompressor {

    data class CompressionResult(
        val compressedBitmap: Bitmap,
        val compressedBytes: ByteArray,
        val originalSize: Long,
        val compressedSize: Long,
        val savingsPercentage: Int,
        val format: String
    )

    fun compress(
        bitmap: Bitmap,
        quality: Int = 80,
        format: String = "WEBP",
        originalSizeBytes: Long = 0L
    ): CompressionResult {
        val stream = ByteArrayOutputStream()
        val compressFormat = when (format.uppercase()) {
            "JPG", "JPEG" -> Bitmap.CompressFormat.JPEG
            "WEBP" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    @Suppress("DEPRECATION")
                    Bitmap.CompressFormat.WEBP
                }
            }
            "PNG" -> Bitmap.CompressFormat.PNG
            else -> Bitmap.CompressFormat.JPEG
        }

        // Clamp quality between 1 and 100
        val clampedQuality = quality.coerceIn(1, 100)
        bitmap.compress(compressFormat, clampedQuality, stream)
        val byteArray = stream.toByteArray()

        val compressedSize = byteArray.size.toLong()
        val baseline = if (originalSizeBytes > 0) originalSizeBytes else (bitmap.byteCount.toLong())
        val savings = if (baseline > compressedSize) {
            (((baseline - compressedSize).toDouble() / baseline) * 100).toInt()
        } else 0

        val compressedBmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size) ?: bitmap

        return CompressionResult(
            compressedBitmap = compressedBmp,
            compressedBytes = byteArray,
            originalSize = baseline,
            compressedSize = compressedSize,
            savingsPercentage = savings,
            format = format.uppercase()
        )
    }
}
