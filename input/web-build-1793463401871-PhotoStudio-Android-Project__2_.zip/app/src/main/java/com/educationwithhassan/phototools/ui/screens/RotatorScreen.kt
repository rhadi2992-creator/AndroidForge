package com.educationwithhassan.phototools.ui.screens

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.phototools.core.ads.AdMobManager
import com.educationwithhassan.phototools.core.image.BitmapUtils
import com.educationwithhassan.phototools.core.image.ImageRotator
import com.educationwithhassan.phototools.core.storage.HistoryRepository
import com.educationwithhassan.phototools.core.storage.MediaStoreSaver
import com.educationwithhassan.phototools.data.model.SavedProject
import com.educationwithhassan.phototools.data.preferences.AppPreferences
import com.educationwithhassan.phototools.ui.PhotoStudioViewModel
import com.educationwithhassan.phototools.ui.components.EmptyPhotoPlaceholder
import com.educationwithhassan.phototools.ui.components.PrimaryActionButton
import com.educationwithhassan.phototools.ui.components.ToolTopBar
import com.educationwithhassan.phototools.ui.theme.PrimaryBlue
import com.educationwithhassan.phototools.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun RotatorScreen(
    viewModel: PhotoStudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val preferences = remember { AppPreferences(context) }
    val historyRepo = remember { HistoryRepository(context) }

    val baseBitmap by viewModel.currentBitmap.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var currentBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var rotationAngle by remember { mutableFloatStateOf(0f) }

    var isProcessing by remember { mutableStateOf(false) }
    var lastSavedResult by remember { mutableStateOf<MediaStoreSaver.SaveResult?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setPhotoUri(uri)
            lastSavedResult = null
        }
    }

    LaunchedEffect(baseBitmap) {
        currentBitmap = baseBitmap
        rotationAngle = 0f
    }

    Scaffold(
        topBar = {
            ToolTopBar(
                title = "Rotate & Flip",
                onBack = onBack,
                actions = {
                    IconButton(onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Change Photo", tint = PrimaryBlue)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = PrimaryBlue)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Loading photo...", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else if (baseBitmap == null) {
                EmptyPhotoPlaceholder(
                    title = if (errorMessage != null) "Failed to Load Photo" else "No Photo Selected",
                    subtitle = errorMessage ?: "Select a photo from your gallery to rotate or flip",
                    onSelectPhoto = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                )
            } else {
                val bmp = currentBitmap ?: baseBitmap!!

                // Image Preview Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Rotated Preview",
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp)
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${bmp.width} × ${bmp.height} px (${rotationAngle.toInt()}°)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Rotation Controls
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Rotation Controls",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    currentBitmap = ImageRotator.rotate(bmp, 90f)
                                    rotationAngle = (rotationAngle + 90f) % 360f
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Icon(Icons.Default.Rotate90DegreesCw, contentDescription = null, tint = PrimaryBlue)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("90° CW", color = MaterialTheme.colorScheme.onSurface)
                            }

                            Button(
                                onClick = {
                                    currentBitmap = ImageRotator.rotate(bmp, 180f)
                                    rotationAngle = (rotationAngle + 180f) % 360f
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Icon(Icons.Default.RotateRight, contentDescription = null, tint = PrimaryBlue)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("180°", color = MaterialTheme.colorScheme.onSurface)
                            }

                            Button(
                                onClick = {
                                    currentBitmap = ImageRotator.rotate(bmp, 270f)
                                    rotationAngle = (rotationAngle + 270f) % 360f
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Icon(Icons.Default.Rotate90DegreesCcw, contentDescription = null, tint = PrimaryBlue)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("270°", color = MaterialTheme.colorScheme.onSurface)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Flip & Mirror Controls",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    currentBitmap = ImageRotator.flipHorizontal(bmp)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = PrimaryBlue)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Horizontal Flip", color = MaterialTheme.colorScheme.onSurface)
                            }

                            Button(
                                onClick = {
                                    currentBitmap = ImageRotator.flipVertical(bmp)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Icon(Icons.Default.SwapVert, contentDescription = null, tint = PrimaryBlue)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Vertical Flip", color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }

                // Save Action
                PrimaryActionButton(
                    text = if (isProcessing) "Saving..." else "Save Rotated Photo",
                    enabled = !isProcessing && (currentBitmap != null || baseBitmap != null),
                    onClick = {
                        val toSave = currentBitmap ?: baseBitmap ?: return@PrimaryActionButton
                        isProcessing = true
                        coroutineScope.launch {
                            val saveRes = withContext(Dispatchers.IO) {
                                MediaStoreSaver.saveBitmap(
                                    context = context,
                                    bitmap = toSave,
                                    format = "JPG",
                                    quality = 92,
                                    prefix = "Rotated"
                                )
                            }
                            lastSavedResult = saveRes
                            isProcessing = false

                            if (saveRes.success && saveRes.uri != null) {
                                historyRepo.addProject(
                                    SavedProject(
                                        id = saveRes.fileName,
                                        title = "Rotated Photo",
                                        toolType = "Rotator",
                                        uriString = saveRes.uri.toString(),
                                        timestamp = System.currentTimeMillis(),
                                        width = toSave.width,
                                        height = toSave.height,
                                        fileSizeFormatted = saveRes.fileSizeFormatted
                                    )
                                )
                                Toast.makeText(context, "Saved to Pictures/PhotoStudio", Toast.LENGTH_SHORT).show()

                                if (preferences.incrementActionAndShouldShowAd()) {
                                    (context as? Activity)?.let { act ->
                                        AdMobManager.showInterstitialIfReady(act) {}
                                    }
                                }
                            }
                        }
                    }
                )

                lastSavedResult?.let { res ->
                    if (res.success && res.uri != null) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = SuccessGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Saved Successfully!", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = SuccessGreen)
                                }
                                Button(
                                    onClick = { MediaStoreSaver.shareImage(context, res.uri) },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Share", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
