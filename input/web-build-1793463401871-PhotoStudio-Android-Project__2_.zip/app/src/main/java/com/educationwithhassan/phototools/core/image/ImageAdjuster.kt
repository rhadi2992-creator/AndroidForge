package com.educationwithhassan.phototools.core.image

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint

object ImageAdjuster {

    data class EditState(
        val brightness: Float = 0f,   // -100 to +100
        val contrast: Float = 0f,     // -100 to +100
        val saturation: Float = 0f,   // -100 to +100
        val exposure: Float = 0f,     // -100 to +100
        val warmth: Float = 0f,       // -100 to +100
        val filter: FilterPreset = FilterPreset.NONE
    )

    enum class FilterPreset(val displayName: String) {
        NONE("Normal"),
        GRAYSCALE("B&W"),
        SEPIA("Sepia"),
        VINTAGE("Vintage"),
        COOL("Cool Tone"),
        WARM("Golden Warm")
    }

    fun applyAdjustments(source: Bitmap, state: EditState): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val masterMatrix = ColorMatrix()

        // 1. Brightness & Exposure
        // Brightness shifts RGB values directly. Exposure scales RGB.
        val bShift = (state.brightness * 1.28f) + (state.exposure * 1.5f)
        val brightnessMatrix = ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, bShift,
                0f, 1f, 0f, 0f, bShift,
                0f, 0f, 1f, 0f, bShift,
                0f, 0f, 0f, 1f, 0f
            )
        )
        masterMatrix.postConcat(brightnessMatrix)

        // 2. Contrast
        // Scale around 128
        val cFactor = if (state.contrast >= 0) {
            1f + (state.contrast / 100f) * 1.5f
        } else {
            1f + (state.contrast / 100f) * 0.7f
        }
        val cShift = 128f * (1f - cFactor)
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                cFactor, 0f, 0f, 0f, cShift,
                0f, cFactor, 0f, 0f, cShift,
                0f, 0f, cFactor, 0f, cShift,
                0f, 0f, 0f, 1f, 0f
            )
        )
        masterMatrix.postConcat(contrastMatrix)

        // 3. Saturation
        val sFactor = 1f + (state.saturation / 100f)
        val satMatrix = ColorMatrix().apply { setSaturation(sFactor.coerceAtLeast(0f)) }
        masterMatrix.postConcat(satMatrix)

        // 4. Warmth (Red vs Blue tint balance)
        if (state.warmth != 0f) {
            val rShift = (state.warmth / 100f) * 35f
            val bShiftWarmth = -(state.warmth / 100f) * 35f
            val warmthMatrix = ColorMatrix(
                floatArrayOf(
                    1f, 0f, 0f, 0f, rShift,
                    0f, 1f, 0f, 0f, 0f,
                    0f, 0f, 1f, 0f, bShiftWarmth,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            masterMatrix.postConcat(warmthMatrix)
        }

        // 5. Presets
        when (state.filter) {
            FilterPreset.NONE -> {}
            FilterPreset.GRAYSCALE -> {
                val bw = ColorMatrix().apply { setSaturation(0f) }
                masterMatrix.postConcat(bw)
            }
            FilterPreset.SEPIA -> {
                val sepia = ColorMatrix().apply {
                    set(
                        floatArrayOf(
                            0.393f, 0.769f, 0.189f, 0f, 0f,
                            0.349f, 0.686f, 0.168f, 0f, 0f,
                            0.272f, 0.534f, 0.131f, 0f, 0f,
                            0f, 0f, 0f, 1f, 0f
                        )
                    )
                }
                masterMatrix.postConcat(sepia)
            }
            FilterPreset.VINTAGE -> {
                val vintage = ColorMatrix(
                    floatArrayOf(
                        0.9f, 0f, 0f, 0f, 20f,
                        0f, 0.8f, 0f, 0f, 10f,
                        0f, 0f, 0.7f, 0f, 40f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                masterMatrix.postConcat(vintage)
            }
            FilterPreset.COOL -> {
                val cool = ColorMatrix(
                    floatArrayOf(
                        0.9f, 0f, 0f, 0f, 0f,
                        0f, 0.95f, 0f, 0f, 10f,
                        0f, 0f, 1.15f, 0f, 25f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                masterMatrix.postConcat(cool)
            }
            FilterPreset.WARM -> {
                val warm = ColorMatrix(
                    floatArrayOf(
                        1.15f, 0f, 0f, 0f, 30f,
                        0f, 1.05f, 0f, 0f, 15f,
                        0f, 0f, 0.85f, 0f, -10f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                masterMatrix.postConcat(warm)
            }
        }

        paint.colorFilter = ColorMatrixColorFilter(masterMatrix)
        canvas.drawBitmap(source, 0f, 0f, paint)

        return result
    }
}
