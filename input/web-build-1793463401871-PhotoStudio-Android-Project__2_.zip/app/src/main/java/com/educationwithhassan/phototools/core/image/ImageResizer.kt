package com.educationwithhassan.phototools.core.image

import android.graphics.Bitmap
import kotlin.math.roundToInt

object ImageResizer {

    data class Preset(
        val name: String,
        val width: Int,
        val height: Int,
        val category: String
    )

    val standardPresets = listOf(
        Preset("Full HD (1080p)", 1920, 1080, "Video & Display"),
        Preset("HD Ready (720p)", 1280, 720, "Video & Display"),
        Preset("Instagram Square", 1080, 1080, "Social"),
        Preset("Instagram Story / Reel", 1080, 1920, "Social"),
        Preset("Instagram Portrait (4:5)", 1080, 1350, "Social"),
        Preset("YouTube Thumbnail", 1280, 720, "Social"),
        Preset("Website Banner", 1200, 630, "Web"),
        Preset("Thumbnail Small", 500, 500, "Web")
    )

    fun calculateHeightForWidth(originalWidth: Int, originalHeight: Int, targetWidth: Int): Int {
        if (originalWidth <= 0) return targetWidth
        val ratio = originalHeight.toDouble() / originalWidth.toDouble()
        return (targetWidth * ratio).roundToInt().coerceAtLeast(1)
    }

    fun calculateWidthForHeight(originalWidth: Int, originalHeight: Int, targetHeight: Int): Int {
        if (originalHeight <= 0) return targetHeight
        val ratio = originalWidth.toDouble() / originalHeight.toDouble()
        return (targetHeight * ratio).roundToInt().coerceAtLeast(1)
    }

    fun resize(
        bitmap: Bitmap,
        targetWidth: Int,
        targetHeight: Int,
        filter: Boolean = true
    ): Bitmap {
        val safeW = targetWidth.coerceIn(1, 8192)
        val safeH = targetHeight.coerceIn(1, 8192)

        return Bitmap.createScaledBitmap(bitmap, safeW, safeH, filter)
    }
}
