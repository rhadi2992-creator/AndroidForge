package com.educationwithhassan.phototools.core.ads

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.educationwithhassan.phototools.BuildConfig
import com.educationwithhassan.phototools.R
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MediaAspectRatio
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.util.Date

/**
 * Production-ready AdMob Manager handling all ad formats:
 * - Banner Ads
 * - Interstitial Ads
 * - App Open Ads
 * - Rewarded Ads
 * - Native Advanced Ads
 */
object AdMobManager {

    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false

    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    private var appOpenAd: AppOpenAd? = null
    private var isAppOpenLoading = false
    private var appOpenLoadTime: Long = 0

    // ==========================================
    // 1. INTERSTITIAL ADS
    // ==========================================
    fun loadInterstitial(context: Context) {
        if (interstitialAd != null || isInterstitialLoading) return
        isInterstitialLoading = true

        val adUnitId = context.getString(R.string.admob_interstitial_tool)
        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(
            context,
            adUnitId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                }
            }
        )
    }

    fun showInterstitialIfReady(activity: Activity, onAdDismissed: () -> Unit) {
        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onAdDismissed()
                }
            }
            ad.show(activity)
        } else {
            loadInterstitial(activity)
            onAdDismissed()
        }
    }

    // ==========================================
    // 2. REWARDED ADS
    // ==========================================
    fun loadRewarded(context: Context) {
        if (rewardedAd != null || isRewardedLoading) return
        isRewardedLoading = true

        val adUnitId = context.getString(R.string.admob_rewarded)
        val adRequest = AdRequest.Builder().build()

        RewardedAd.load(
            context,
            adUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                }
            }
        )
    }

    fun showRewardedIfReady(
        activity: Activity,
        onUserEarnedReward: (RewardItem) -> Unit,
        onAdDismissed: () -> Unit
    ) {
        val ad = rewardedAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewarded(activity)
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    loadRewarded(activity)
                    onAdDismissed()
                }
            }
            ad.show(activity) { rewardItem ->
                onUserEarnedReward(rewardItem)
            }
        } else {
            loadRewarded(activity)
            onAdDismissed()
        }
    }

    // ==========================================
    // 3. APP OPEN ADS
    // ==========================================
    fun loadAppOpenAd(context: Context) {
        if (isAppOpenLoading || isAppOpenAdAvailable()) return
        isAppOpenLoading = true

        val adUnitId = context.getString(R.string.admob_app_open)
        val request = AdRequest.Builder().build()

        AppOpenAd.load(
            context,
            adUnitId,
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    isAppOpenLoading = false
                    appOpenLoadTime = Date().time
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    isAppOpenLoading = false
                    appOpenAd = null
                }
            }
        )
    }

    private fun isAppOpenAdAvailable(): Boolean {
        val numHours = 4
        val dateDifference: Long = Date().time - appOpenLoadTime
        val numMilliSecondsPerHour: Long = 3600000
        return appOpenAd != null && (dateDifference < (numMilliSecondsPerHour * numHours))
    }

    fun showAppOpenAdIfAvailable(activity: Activity, onComplete: () -> Unit = {}) {
        if (!isAppOpenAdAvailable()) {
            loadAppOpenAd(activity)
            onComplete()
            return
        }

        appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                appOpenAd = null
                loadAppOpenAd(activity)
                onComplete()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                appOpenAd = null
                loadAppOpenAd(activity)
                onComplete()
            }
        }

        appOpenAd?.show(activity)
    }
}

/**
 * Clean AdBannerView composable for reserved non-intrusive banner placements.
 */
@Composable
fun AdBannerView(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier.fillMaxWidth(),
            factory = { context ->
                AdView(context).apply {
                    setAdSize(AdSize.BANNER)
                    adUnitId = context.getString(R.string.admob_banner_home)
                    loadAd(AdRequest.Builder().build())
                }
            }
        )
    }
}


/**
 * State representation for Native Ad loading lifecycle.
 */
sealed interface NativeAdState {
    object Idle : NativeAdState
    object Loading : NativeAdState
    data class Success(val nativeAd: NativeAd) : NativeAdState
    data class Error(val error: LoadAdError) : NativeAdState
}

/**
 * Native Ad Card that requests, loads, and displays real AdMob Native Advanced Ads.
 * Uses AdLoader, NativeAd, and NativeAdView according to Google's official Native Ads guidelines.
 *
 * Automatically manages:
 * - Real Ad Unit ID binding (Release: ca-app-pub-3133971041724338/1973374792, Debug: Google test ID)
 * - Registration of Headline, Body, Advertiser, Icon, MediaView, and CallToAction
 * - Ad attribution badge and AdChoices placement
 * - Memory leak prevention via proper NativeAd.destroy() on disposal
 * - Clean loading and graceful error/no-fill handling
 */
@Composable
fun NativeAdCard(
    modifier: Modifier = Modifier,
    customAdUnitId: String? = null
) {
    val context = LocalContext.current
    var adState by remember { mutableStateOf<NativeAdState>(NativeAdState.Loading) }

    // Use release production unit ID or Google test unit ID in debug to prevent policy strikes
    val adUnitId = customAdUnitId ?: if (BuildConfig.DEBUG) {
        "ca-app-pub-3940256099942544/2247696110"
    } else {
        context.getString(R.string.admob_native_advanced)
    }

    DisposableEffect(adUnitId) {
        var currentAd: NativeAd? = null
        adState = NativeAdState.Loading

        val adLoader = AdLoader.Builder(context, adUnitId)
            .forNativeAd { loadedAd: NativeAd ->
                currentAd?.destroy()
                currentAd = loadedAd
                adState = NativeAdState.Success(loadedAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(loadError: LoadAdError) {
                    adState = NativeAdState.Error(loadError)
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
                    .setMediaAspectRatio(MediaAspectRatio.LANDSCAPE)
                    .build()
            )
            .build()

        adLoader.loadAd(AdRequest.Builder().build())

        onDispose {
            currentAd?.destroy()
            currentAd = null
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        when (val state = adState) {
            is NativeAdState.Loading -> {
                // Polished skeleton loading state matching ad card dimensions
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Loading sponsored content…",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            is NativeAdState.Success -> {
                // Real Native Advanced Ad rendered via NativeAdView
                AndroidView(
                    modifier = Modifier.fillMaxWidth(),
                    factory = { ctx ->
                        val adView = LayoutInflater.from(ctx)
                            .inflate(R.layout.layout_native_ad, null, false) as NativeAdView
                        populateNativeAdView(state.nativeAd, adView)
                        adView
                    },
                    update = { adView ->
                        populateNativeAdView(state.nativeAd, adView)
                    }
                )
            }

            is NativeAdState.Error -> {
                // Graceful fallback: collapse without leaving an unsightly empty gap or error popup
                Spacer(modifier = Modifier.height(0.dp))
            }

            is NativeAdState.Idle -> {
                Spacer(modifier = Modifier.height(0.dp))
            }
        }
    }
}

/**
 * Registers all available ad assets with the NativeAdView and binds data.
 */
private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
    // 1. Register asset views with Google's NativeAdView
    adView.headlineView = adView.findViewById(R.id.ad_headline)
    adView.bodyView = adView.findViewById(R.id.ad_body)
    adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
    adView.iconView = adView.findViewById(R.id.ad_app_icon)
    adView.mediaView = adView.findViewById(R.id.ad_media)
    adView.advertiserView = adView.findViewById(R.id.ad_advertiser)
    adView.starRatingView = adView.findViewById(R.id.ad_stars)
    adView.priceView = adView.findViewById(R.id.ad_price)
    adView.storeView = adView.findViewById(R.id.ad_store)

    // 2. Headline (Mandatory asset)
    (adView.headlineView as? TextView)?.apply {
        text = nativeAd.headline
        visibility = if (nativeAd.headline.isNullOrEmpty()) View.INVISIBLE else View.VISIBLE
    }

    // 3. Body text
    (adView.bodyView as? TextView)?.apply {
        if (nativeAd.body.isNullOrEmpty()) {
            visibility = View.GONE
        } else {
            text = nativeAd.body
            visibility = View.VISIBLE
        }
    }

    // 4. Call To Action button
    (adView.callToActionView as? Button)?.apply {
        if (nativeAd.callToAction.isNullOrEmpty()) {
            visibility = View.GONE
        } else {
            text = nativeAd.callToAction
            visibility = View.VISIBLE
        }
    }

    // 5. App Icon
    (adView.iconView as? ImageView)?.apply {
        val icon = nativeAd.icon
        if (icon?.drawable != null) {
            setImageDrawable(icon.drawable)
            visibility = View.VISIBLE
        } else {
            visibility = View.GONE
        }
    }

    // 6. Media content (Image or Video)
    (adView.mediaView as? MediaView)?.apply {
        val mediaContent = nativeAd.mediaContent
        if (mediaContent != null) {
            setMediaContent(mediaContent)
            visibility = View.VISIBLE
        } else {
            visibility = View.GONE
        }
    }

    // 7. Advertiser
    (adView.advertiserView as? TextView)?.apply {
        if (nativeAd.advertiser.isNullOrEmpty()) {
            visibility = View.GONE
        } else {
            text = nativeAd.advertiser
            visibility = View.VISIBLE
        }
    }

    // 8. Star Rating
    (adView.starRatingView as? RatingBar)?.apply {
        val rating = nativeAd.starRating
        if (rating != null && rating > 0) {
            this.rating = rating.toFloat()
            visibility = View.VISIBLE
        } else {
            visibility = View.GONE
        }
    }

    // 9. Price
    (adView.priceView as? TextView)?.apply {
        if (nativeAd.price.isNullOrEmpty()) {
            visibility = View.GONE
        } else {
            text = nativeAd.price
            visibility = View.VISIBLE
        }
    }

    // 10. Store
    (adView.storeView as? TextView)?.apply {
        if (nativeAd.store.isNullOrEmpty()) {
            visibility = View.GONE
        } else {
            text = nativeAd.store
            visibility = View.VISIBLE
        }
    }

    // 11. Finally call setNativeAd to bind the NativeAd object to the NativeAdView container
    adView.setNativeAd(nativeAd)
}

