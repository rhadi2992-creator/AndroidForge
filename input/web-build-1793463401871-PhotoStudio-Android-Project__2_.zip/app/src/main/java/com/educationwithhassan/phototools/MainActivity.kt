package com.educationwithhassan.phototools

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Parcelable
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.educationwithhassan.phototools.core.ads.AdMobManager
import com.educationwithhassan.phototools.data.preferences.AppPreferences
import com.educationwithhassan.phototools.ui.PhotoStudioViewModel
import com.educationwithhassan.phototools.ui.navigation.Screen
import com.educationwithhassan.phototools.ui.screens.*
import com.educationwithhassan.phototools.ui.theme.PhotoStudioTheme

class MainActivity : ComponentActivity() {

    private lateinit var preferences: AppPreferences
    private var sharedImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = AppPreferences(this)

        // Handle incoming image from Android Share Intent
        handleSendImageIntent(intent)

        // Show App Open Ad if ready, preload others in background
        AdMobManager.showAppOpenAdIfAvailable(this)
        AdMobManager.loadInterstitial(this)
        AdMobManager.loadRewarded(this)

        setContent {
            val isSystemDark = isSystemInDarkTheme()
            val themeMode = remember { preferences.themeMode }
            val useDarkTheme = when (themeMode) {
                "light" -> false
                "dark" -> true
                else -> isSystemDark
            }

            PhotoStudioTheme(darkTheme = useDarkTheme) {
                val navController = rememberNavController()
                val photoViewModel: PhotoStudioViewModel = viewModel()

                // If launched with a shared URI from another app, set it in the ViewModel immediately
                LaunchedEffect(sharedImageUri) {
                    sharedImageUri?.let { uri ->
                        photoViewModel.setPhotoUri(uri)
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = Screen.Home.route
                ) {
                    composable(Screen.Home.route) {
                        HomeScreen(
                            viewModel = photoViewModel,
                            onNavigateToTool = { route, uri ->
                                if (uri != null) {
                                    photoViewModel.setPhotoUri(uri)
                                }
                                navController.navigate(route)
                            },
                            onNavigateToProjects = {
                                navController.navigate(Screen.History.route)
                            },
                            onNavigateToSettings = {
                                navController.navigate(Screen.Settings.route)
                            }
                        )
                    }

                    composable(Screen.Compressor.route) {
                        CompressorScreen(
                            viewModel = photoViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Resizer.route) {
                        ResizerScreen(
                            viewModel = photoViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Cropper.route) {
                        CropperScreen(
                            viewModel = photoViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Converter.route) {
                        ConverterScreen(
                            viewModel = photoViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Editor.route) {
                        EditorScreen(
                            viewModel = photoViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Rotator.route) {
                        RotatorScreen(
                            viewModel = photoViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Blur.route) {
                        BlurScreen(
                            viewModel = photoViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Passport.route) {
                        PassportScreen(
                            viewModel = photoViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.BgRemover.route) {
                        BgRemoverScreen(
                            viewModel = photoViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.History.route) {
                        HistoryScreen(
                            onBack = { navController.popBackStack() },
                            onOpenProject = { uri ->
                                photoViewModel.setPhotoUri(uri)
                                navController.navigate(Screen.Editor.route)
                            }
                        )
                    }

                    composable(Screen.Settings.route) {
                        SettingsScreen(
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }

    private fun handleSendImageIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("image/") == true) {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Parcelable>(Intent.EXTRA_STREAM) as? Uri
            }
            if (uri != null) {
                sharedImageUri = uri
            }
        }
    }
}
