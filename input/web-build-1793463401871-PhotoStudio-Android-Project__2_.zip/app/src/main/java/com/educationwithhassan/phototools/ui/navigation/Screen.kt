package com.educationwithhassan.phototools.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Compressor : Screen("compressor")
    object Resizer : Screen("resizer")
    object Cropper : Screen("cropper")
    object Converter : Screen("converter")
    object Editor : Screen("editor")
    object Rotator : Screen("rotator")
    object Blur : Screen("blur")
    object Passport : Screen("passport")
    object BgRemover : Screen("bg_remover")
    object History : Screen("history")
    object Settings : Screen("settings")

    companion object {
        fun fromRoute(route: String?): Screen {
            return when (route) {
                Home.route -> Home
                Compressor.route -> Compressor
                Resizer.route -> Resizer
                Cropper.route -> Cropper
                Converter.route -> Converter
                Editor.route -> Editor
                Rotator.route -> Rotator
                Blur.route -> Blur
                Passport.route -> Passport
                BgRemover.route -> BgRemover
                History.route -> History
                Settings.route -> Settings
                else -> Home
            }
        }
    }
}
