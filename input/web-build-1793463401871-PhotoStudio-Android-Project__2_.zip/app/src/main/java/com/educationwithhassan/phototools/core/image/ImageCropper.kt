package com.educationwithhassan.phototools.core.image

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.roundToInt

object ImageCropper {

    enum class AspectRatio(val label: String, val ratio: Float?) {
        FREE("Free", null),
        SQUARE("1:1", 1.0f),
        FOUR_THREE("4:3", 4f / 3f),
        SIXTEEN_NINE("16:9", 16f / 9f),
        THREE_FOUR("3:4", 3f / 4f)
    }

    /**
     * Calculate a default centered crop rect for a given aspect ratio
     */
    fun getCenteredCropRect(bitmapWidth: Int, bitmapHeight: Int, ratio: Float?): Rect {
        if (ratio == null) {
            return Rect(0, 0, bitmapWidth, bitmapHeight)
        }

        val imgRatio = bitmapWidth.toFloat() / bitmapHeight.toFloat()
        val cropW: Int
        val cropH: Int

        if (imgRatio > ratio) {
            // Image is wider than crop box
            cropH = bitmapHeight
            cropW = (cropH * ratio).roundToInt()
        } else {
            // Image is taller than crop box
            cropW = bitmapWidth
            cropH = (cropW / ratio).roundToInt()
        }

        val left = (bitmapWidth - cropW) / 2
        val top = (bitmapHeight - cropH) / 2

        return Rect(left, top, left + cropW, top + cropH)
    }

    /**
     * Crops a bitmap according to normalised rect coordinates (0f..1f)
     */
    fun cropNormalized(
        bitmap: Bitmap,
        leftNorm: Float,
        topNorm: Float,
        rightNorm: Float,
        bottomNorm: Float
    ): Bitmap {
        val l = (leftNorm.coerceIn(0f, 1f) * bitmap.width).roundToInt()
        val t = (topNorm.coerceIn(0f, 1f) * bitmap.height).roundToInt()
        val r = (rightNorm.coerceIn(0f, 1f) * bitmap.width).roundToInt()
        val b = (bottomNorm.coerceIn(0f, 1f) * bitmap.height).roundToInt()

        val width = (r - l).coerceAtLeast(1)
        val height = (b - t).coerceAtLeast(1)

        val safeX = l.coerceIn(0, bitmap.width - 1)
        val safeY = t.coerceIn(0, bitmap.height - 1)
        val safeW = width.coerceAtMost(bitmap.width - safeX)
        val safeH = height.coerceAtMost(bitmap.height - safeY)

        return Bitmap.createBitmap(bitmap, safeX, safeY, safeW, safeH)
    }

    fun crop(bitmap: Bitmap, rect: Rect): Bitmap {
        val safeX = rect.left.coerceIn(0, bitmap.width - 1)
        val safeY = rect.top.coerceIn(0, bitmap.height - 1)
        val safeW = rect.width().coerceIn(1, bitmap.width - safeX)
        val safeH = rect.height().coerceIn(1, bitmap.height - safeY)

        return Bitmap.createBitmap(bitmap, safeX, safeY, safeW, safeH)
    }
}
