package com.educationwithhassan.phototools.ui.screens

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.phototools.R
import com.educationwithhassan.phototools.core.ads.AdMobManager
import com.educationwithhassan.phototools.core.image.BitmapUtils
import com.educationwithhassan.phototools.core.image.PassportSheetGenerator
import com.educationwithhassan.phototools.core.storage.HistoryRepository
import com.educationwithhassan.phototools.core.storage.MediaStoreSaver
import com.educationwithhassan.phototools.data.model.PassportPreset
import com.educationwithhassan.phototools.data.model.SavedProject
import com.educationwithhassan.phototools.data.preferences.AppPreferences
import com.educationwithhassan.phototools.ui.PhotoStudioViewModel
import com.educationwithhassan.phototools.ui.components.EmptyPhotoPlaceholder
import com.educationwithhassan.phototools.ui.components.PrimaryActionButton
import com.educationwithhassan.phototools.ui.components.ToolTopBar
import com.educationwithhassan.phototools.ui.theme.PrimaryBlue
import com.educationwithhassan.phototools.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PassportScreen(
    viewModel: PhotoStudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val preferences = remember { AppPreferences(context) }
    val historyRepo = remember { HistoryRepository(context) }

    val originalBitmap by viewModel.currentBitmap.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var previewSheetBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var selectedPreset by remember { mutableStateOf(PassportSheetGenerator.standardPresets.first()) }
    var selectedLayout by remember { mutableStateOf(PassportSheetGenerator.PrintLayout.SIX_COPIES) }
    var forceWhiteBackground by remember { mutableStateOf(true) }

    var isProcessing by remember { mutableStateOf(false) }
    var lastSavedResult by remember { mutableStateOf<MediaStoreSaver.SaveResult?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setPhotoUri(uri)
            lastSavedResult = null
        }
    }

    // Generate passport layout preview
    LaunchedEffect(originalBitmap, selectedPreset, selectedLayout, forceWhiteBackground) {
        val orig = originalBitmap ?: return@LaunchedEffect
        isProcessing = true
        withContext(Dispatchers.IO) {
            val singleUnit = PassportSheetGenerator.prepareSinglePhoto(orig, selectedPreset, forceWhiteBackground)
            val sheet = PassportSheetGenerator.generatePrintSheet(singleUnit, selectedLayout, drawCutLines = true)
            withContext(Dispatchers.Main) {
                previewSheetBitmap = sheet
                isProcessing = false
            }
        }
    }

    Scaffold(
        topBar = {
            ToolTopBar(
                title = "Passport Photo Maker",
                onBack = onBack,
                actions = {
                    IconButton(onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Change Photo", tint = PrimaryBlue)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(290.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = PrimaryBlue)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Loading photo...", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else if (originalBitmap == null) {
                EmptyPhotoPlaceholder(
                    title = if (errorMessage != null) "Failed to Load Photo" else "No Photo Selected",
                    subtitle = errorMessage ?: "Select a portrait photo from your gallery to create passport sheets",
                    onSelectPhoto = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                )
            } else {
                // Official Requirements Disclaimer
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = PrimaryBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = context.getString(R.string.passport_disclaimer),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                }

                // Image Sheet Preview Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(290.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        previewSheetBitmap?.let { bmp ->
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Passport Sheet Preview",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp)
                            )
                        } ?: CircularProgressIndicator(color = PrimaryBlue)

                        // Floating info
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${selectedPreset.name} · ${selectedLayout.label}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Preset Selector
                Column {
                    Text(
                        text = "Standard Document Preset",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(PassportSheetGenerator.standardPresets) { preset ->
                            val isSelected = selectedPreset == preset
                            OutlinedButton(
                                onClick = { selectedPreset = preset },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) PrimaryBlue.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface,
                                    contentColor = if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.onSurface
                                ),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = androidx.compose.ui.graphics.SolidColor(
                                        if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.outline
                                    )
                                )
                            ) {
                                Text(
                                    text = preset.name,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                )
                            }
                        }
                    }
                }

                // Sheet Layout Selector
                Column {
                    Text(
                        text = "Print Sheet Layout",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(PassportSheetGenerator.PrintLayout.values()) { layout ->
                            val isSelected = selectedLayout == layout
                            OutlinedButton(
                                onClick = { selectedLayout = layout },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) PrimaryBlue.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface,
                                    contentColor = if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.onSurface
                                ),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = androidx.compose.ui.graphics.SolidColor(
                                        if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.outline
                                    )
                                )
                            ) {
                                Text(
                                    text = layout.label,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                )
                            }
                        }
                    }
                }

                // White Background Option
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Pure White Background",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Flattens photo onto clean white background",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = forceWhiteBackground,
                            onCheckedChange = { forceWhiteBackground = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = PrimaryBlue)
                        )
                    }
                }

                // Save Action
                PrimaryActionButton(
                    text = if (isProcessing) "Generating..." else "Export Printable Sheet (JPG)",
                    enabled = !isProcessing && previewSheetBitmap != null,
                    onClick = {
                        val sheet = previewSheetBitmap ?: return@PrimaryActionButton
                        isProcessing = true
                        coroutineScope.launch {
                            val saveRes = withContext(Dispatchers.IO) {
                                MediaStoreSaver.saveBitmap(
                                    context = context,
                                    bitmap = sheet,
                                    format = "JPG",
                                    quality = 95,
                                    prefix = "Passport_${selectedPreset.country}"
                                )
                            }
                            lastSavedResult = saveRes
                            isProcessing = false

                            if (saveRes.success && saveRes.uri != null) {
                                historyRepo.addProject(
                                    SavedProject(
                                        id = saveRes.fileName,
                                        title = "Passport Sheet (${selectedPreset.name})",
                                        toolType = "Passport Maker",
                                        uriString = saveRes.uri.toString(),
                                        timestamp = System.currentTimeMillis(),
                                        width = sheet.width,
                                        height = sheet.height,
                                        fileSizeFormatted = saveRes.fileSizeFormatted
                                    )
                                )
                                Toast.makeText(context, "Saved to Pictures/PhotoStudio", Toast.LENGTH_SHORT).show()

                                if (preferences.incrementActionAndShouldShowAd()) {
                                    (context as? Activity)?.let { act ->
                                        AdMobManager.showInterstitialIfReady(act) {}
                                    }
                                }
                            }
                        }
                    }
                )

                lastSavedResult?.let { res ->
                    if (res.success && res.uri != null) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = SuccessGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Passport Sheet Saved!", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = SuccessGreen)
                                }
                                Button(
                                    onClick = { MediaStoreSaver.shareImage(context, res.uri) },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Share", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
