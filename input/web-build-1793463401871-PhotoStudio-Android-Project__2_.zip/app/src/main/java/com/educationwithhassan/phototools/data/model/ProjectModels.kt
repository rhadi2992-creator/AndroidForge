package com.educationwithhassan.phototools.data.model

import androidx.compose.ui.graphics.vector.ImageVector

data class ToolItem(
    val id: String,
    val title: String,
    val description: String,
    val route: String,
    val iconName: String,
    val isPopular: Boolean = false,
    val badge: String? = null
)

data class SavedProject(
    val id: String,
    val title: String,
    val toolType: String,
    val uriString: String,
    val timestamp: Long,
    val width: Int,
    val height: Int,
    val fileSizeFormatted: String
)

data class PassportPreset(
    val id: String,
    val name: String,
    val country: String,
    val widthMm: Float,
    val heightMm: Float,
    val targetWidthPx: Int = 600,
    val targetHeightPx: Int = 600,
    val description: String
)

enum class OutputFormat(val extension: String, val mimeType: String) {
    JPG("jpg", "image/jpeg"),
    PNG("png", "image/png"),
    WEBP("webp", "image/webp")
}
