package com.educationwithhassan.phototools

import android.app.Application
import com.educationwithhassan.phototools.core.ads.AdMobManager
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Main Application class for Photo Studio – Photo Tools
 * Developed by Rana Hassan
 */
class PhotoStudioApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // Initialize Google Mobile Ads SDK on background thread to prevent UI freezing
        CoroutineScope(Dispatchers.IO).launch {
            MobileAds.initialize(this@PhotoStudioApp) {
                // Preload all ad units
                AdMobManager.loadAppOpenAd(this@PhotoStudioApp)
                AdMobManager.loadInterstitial(this@PhotoStudioApp)
                AdMobManager.loadRewarded(this@PhotoStudioApp)
            }
        }
    }
}
