package com.educationwithhassan.phototools.core.storage

import android.content.Context
import android.content.SharedPreferences
import com.educationwithhassan.phototools.data.model.SavedProject
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class HistoryRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("photo_studio_history", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val keyHistory = "saved_projects_list"

    fun getHistory(): List<SavedProject> {
        val json = prefs.getString(keyHistory, null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<SavedProject>>() {}.type
            gson.fromJson<List<SavedProject>>(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addProject(project: SavedProject) {
        val current = getHistory().toMutableList()
        // Remove existing item with same id if any
        current.removeAll { it.id == project.id }
        // Prepend new project at top
        current.add(0, project)
        // Keep max 50 recent projects
        val trimmed = if (current.size > 50) current.subList(0, 50) else current
        prefs.edit().putString(keyHistory, gson.toJson(trimmed)).apply()
    }

    fun deleteProject(projectId: String) {
        val current = getHistory().toMutableList()
        current.removeAll { it.id == projectId }
        prefs.edit().putString(keyHistory, gson.toJson(current)).apply()
    }

    fun clearAll() {
        prefs.edit().remove(keyHistory).apply()
    }
}
