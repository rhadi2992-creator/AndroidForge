# Photo Studio - Proguard Rules
-keepattributes *Annotation*
-keepclassmembers class * {
    @org.jetbrains.annotations.* <fields>;
    @org.jetbrains.annotations.* <methods>;
}

# Keep Gson data classes
-keepclassmembers class com.educationwithhassan.phototools.data.model.** { *; }

# Google Play Services Ads
-keep public class com.google.android.gms.ads.** {
   public *;
}
-keep public class com.google.ads.** {
   public *;
}
