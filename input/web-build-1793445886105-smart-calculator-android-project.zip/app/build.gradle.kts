import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.educationwithhassan.smartcalculator"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.educationwithhassan.smartcalculator"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        create("release") {
            // Optional local properties file (ignored by Git)
            val localProps = Properties()
            val localPropertiesFile = rootProject.file("local.properties")
            if (localPropertiesFile.exists() && localPropertiesFile.isFile) {
                localPropertiesFile.inputStream().use { localProps.load(it) }
            }
            val rootSigningFile = rootProject.file("release-signing.properties")
            if (rootSigningFile.exists() && rootSigningFile.isFile) {
                rootSigningFile.inputStream().use { localProps.load(it) }
            }
            val appSigningFile = file("release-signing.properties")
            if (appSigningFile.exists() && appSigningFile.isFile) {
                appSigningFile.inputStream().use { localProps.load(it) }
            }

            // Credentials from Environment Variables (CI / GitHub Actions / AndroidForge) or Gradle properties
            val keystorePath = System.getenv("KEYSTORE_FILE")
                ?: (findProperty("RELEASE_STORE_FILE") as? String)
                ?: (localProps.getProperty("RELEASE_STORE_FILE") as? String)
                ?: "release.keystore"

            val storePass = System.getenv("KEYSTORE_PASSWORD")
                ?: (findProperty("RELEASE_STORE_PASSWORD") as? String)
                ?: (localProps.getProperty("RELEASE_STORE_PASSWORD") as? String)

            val alias = System.getenv("KEY_ALIAS")
                ?: (findProperty("RELEASE_KEY_ALIAS") as? String)
                ?: (localProps.getProperty("RELEASE_KEY_ALIAS") as? String)

            val keyPass = System.getenv("KEY_PASSWORD")
                ?: (findProperty("RELEASE_KEY_PASSWORD") as? String)
                ?: (localProps.getProperty("RELEASE_KEY_PASSWORD") as? String)

            val isReleaseTask = gradle.startParameter.taskNames.any {
                it.contains("Release", ignoreCase = true)
            }

            if (!storePass.isNullOrBlank() && !alias.isNullOrBlank() && !keyPass.isNullOrBlank()) {
                val storeFileObj = file(keystorePath)
                if (storeFileObj.exists()) {
                    storeFile = storeFileObj
                    storePassword = storePass
                    keyAlias = alias
                    keyPassword = keyPass
                    enableV1Signing = true
                    enableV2Signing = true
                } else if (isReleaseTask) {
                    throw GradleException(
                        "Release build failed: Keystore file '${storeFileObj.absolutePath}' not found!\n" +
                        "Please provide your release keystore via KEYSTORE_FILE environment variable or place it at '$keystorePath'."
                    )
                }
            } else if (isReleaseTask) {
                throw GradleException(
                    "Release build failed: Missing release signing credentials!\n" +
                    "Amazon Appstore and Google Play reject APKs signed with the Android Debug certificate.\n" +
                    "To sign the release build, set the following environment variables (or Gradle properties):\n" +
                    "  - KEYSTORE_FILE (or RELEASE_STORE_FILE): path to your .jks / .keystore file\n" +
                    "  - KEYSTORE_PASSWORD (or RELEASE_STORE_PASSWORD): keystore password\n" +
                    "  - KEY_ALIAS (or RELEASE_KEY_ALIAS): key alias name\n" +
                    "  - KEY_PASSWORD (or RELEASE_KEY_PASSWORD): key password\n" +
                    "Never commit keystores or passwords directly to version control."
                )
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")

    // Jetpack Compose Material 3
    implementation(platform("androidx.compose:compose-bom:2024.08.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // ViewModel & Lifecycle Compose
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.4")

    // Navigation Compose
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // Google Mobile Ads (AdMob)
    implementation("com.google.android.gms:play-services-ads:23.3.0")

    // Unit Testing
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.08.00"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
