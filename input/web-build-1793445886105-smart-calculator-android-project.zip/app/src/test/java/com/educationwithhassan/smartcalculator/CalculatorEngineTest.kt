package com.educationwithhassan.smartcalculator

import com.educationwithhassan.smartcalculator.calculator.AngleMode
import com.educationwithhassan.smartcalculator.calculator.CalculatorEngine
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/**
 * Complete Unit Test Suite for Smart Calculator Engine
 * Developer: Education With Hassan
 * Validates arithmetic precedence, parentheses, decimals, negatives,
 * scientific math, trigonometry in DEG/RAD, domain validation, and error guards.
 */
class CalculatorEngineTest {

    private lateinit var engine: CalculatorEngine

    @Before
    fun setUp() {
        engine = CalculatorEngine()
    }

    @Test
    fun testBasicAddition() {
        val result = engine.evaluate("2 + 3")
        assertTrue(result.isSuccess)
        assertEquals("5", result.formattedResult)
    }

    @Test
    fun testBasicSubtraction() {
        val result = engine.evaluate("10 − 4")
        assertTrue(result.isSuccess)
        assertEquals("6", result.formattedResult)
    }

    @Test
    fun testBasicMultiplication() {
        val result = engine.evaluate("6 × 7")
        assertTrue(result.isSuccess)
        assertEquals("42", result.formattedResult)
    }

    @Test
    fun testBasicDivision() {
        val result = engine.evaluate("20 ÷ 4")
        assertTrue(result.isSuccess)
        assertEquals("5", result.formattedResult)
    }

    @Test
    fun testOperatorPrecedence() {
        val result = engine.evaluate("2 + 3 × 4")
        assertTrue(result.isSuccess)
        assertEquals("14", result.formattedResult)
    }

    @Test
    fun testParenthesesGrouping() {
        val result = engine.evaluate("(2 + 3) × 4")
        assertTrue(result.isSuccess)
        assertEquals("20", result.formattedResult)
    }

    @Test
    fun testDecimalArithmeticPrecision() {
        val result = engine.evaluate("0.1 + 0.2")
        assertTrue(result.isSuccess)
        assertEquals("0.3", result.formattedResult)
    }

    @Test
    fun testNegativeNumbers() {
        val result = engine.evaluate("-5 + 12")
        assertTrue(result.isSuccess)
        assertEquals("7", result.formattedResult)
    }

    @Test
    fun testPercentageCalculation() {
        val result = engine.evaluate("100 × 25%")
        assertTrue(result.isSuccess)
        assertEquals("25", result.formattedResult)
    }

    @Test
    fun testSquareRoot() {
        val result = engine.evaluate("sqrt(144)")
        assertTrue(result.isSuccess)
        assertEquals("12", result.formattedResult)
    }

    @Test
    fun testPowerCalculation() {
        val result = engine.evaluate("2 ^ 8")
        assertTrue(result.isSuccess)
        assertEquals("256", result.formattedResult)
    }

    @Test
    fun testLogarithms() {
        val log10Result = engine.evaluate("log(1000)")
        assertTrue(log10Result.isSuccess)
        assertEquals("3", log10Result.formattedResult)

        val lnResult = engine.evaluate("ln(e)")
        assertTrue(lnResult.isSuccess)
        assertEquals("1", lnResult.formattedResult)
    }

    @Test
    fun testTrigonometryDegreesAndRadians() {
        val sinDeg = engine.evaluate("sin(30)", angleMode = AngleMode.DEG)
        assertTrue(sinDeg.isSuccess)
        assertEquals("0.5", sinDeg.formattedResult)

        val cosRad = engine.evaluate("cos(π)", angleMode = AngleMode.RAD)
        assertTrue(cosRad.isSuccess)
        assertEquals("-1", cosRad.formattedResult)
    }

    @Test
    fun testFactorial() {
        val factResult = engine.evaluate("fact(5)")
        assertTrue(factResult.isSuccess)
        assertEquals("120", factResult.formattedResult)
    }

    @Test
    fun testAbsoluteValue() {
        val absResult = engine.evaluate("abs(-42.5)")
        assertTrue(absResult.isSuccess)
        assertEquals("42.5", absResult.formattedResult)
    }

    @Test
    fun testDivisionByZeroGuard() {
        val result = engine.evaluate("10 ÷ 0")
        assertFalse(result.isSuccess)
        assertNotNull(result.errorMessage)
        assertTrue(result.errorMessage!!.contains("divide by zero", ignoreCase = true))
    }

    @Test
    fun testNegativeSquareRootGuard() {
        val result = engine.evaluate("sqrt(-9)")
        assertFalse(result.isSuccess)
        assertNotNull(result.errorMessage)
        assertTrue(result.errorMessage!!.contains("negative", ignoreCase = true))
    }

    @Test
    fun testTrailingZeroElimination() {
        val result = engine.evaluate("4.50000 + 1.50000")
        assertTrue(result.isSuccess)
        assertEquals("6", result.formattedResult)
    }
}
