package com.educationwithhassan.smartcalculator.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.educationwithhassan.smartcalculator.viewmodel.CalculatorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    onNavigateToAbout: () -> Unit,
    onNavigateToHelp: () -> Unit,
    onNavigateToFAQ: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    viewModel: CalculatorViewModel
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            item {
                Text(
                    text = "Preferences",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Tactile Haptics") },
                    supportingContent = { Text("Gentle vibration when tapping keypad buttons") },
                    trailingContent = {
                        Switch(checked = true, onCheckedChange = { })
                    }
                )
                HorizontalDivider()
            }

            item {
                Text(
                    text = "Application Information & Guides",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Help & Instructions") },
                    supportingContent = { Text("Guide for basic arithmetic, scientific math & memory") },
                    leadingContent = { Icon(Icons.Default.HelpOutline, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { onNavigateToHelp() }
                )
                HorizontalDivider()
            }

            item {
                ListItem(
                    headlineContent = { Text("Frequently Asked Questions (FAQ)") },
                    supportingContent = { Text("Common questions, offline calculation & tips") },
                    leadingContent = { Icon(Icons.Default.QuestionAnswer, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { onNavigateToFAQ() }
                )
                HorizontalDivider()
            }

            item {
                ListItem(
                    headlineContent = { Text("About Smart Calculator") },
                    supportingContent = { Text("Version 1.0.0 by Education With Hassan") },
                    leadingContent = { Icon(Icons.Default.Info, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { onNavigateToAbout() }
                )
                HorizontalDivider()
            }

            item {
                ListItem(
                    headlineContent = { Text("Privacy Policy & AdMob Notice") },
                    supportingContent = { Text("Data protection, AdMob publisher ID & policy") },
                    leadingContent = { Icon(Icons.Default.Lock, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { onNavigateToPrivacy() }
                )
            }
        }
    }
}
