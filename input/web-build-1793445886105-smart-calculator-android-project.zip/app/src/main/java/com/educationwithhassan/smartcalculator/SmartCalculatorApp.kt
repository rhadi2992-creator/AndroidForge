package com.educationwithhassan.smartcalculator

import android.app.Application

import com.educationwithhassan.smartcalculator.admob.AdMobManager

/**
 * Application class for Smart Calculator.
 * Initializes AdMob SDK and offline calculation engines.
 */
class SmartCalculatorApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AdMobManager.getInstance().initialize(this)
    }
}
