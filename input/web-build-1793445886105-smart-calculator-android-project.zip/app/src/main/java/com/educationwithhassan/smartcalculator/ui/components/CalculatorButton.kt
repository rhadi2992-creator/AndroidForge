package com.educationwithhassan.smartcalculator.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class ButtonType {
    NUMBER, OPERATOR, FUNCTION, EQUALS, CLEAR, ACTION
}

@Composable
fun CalculatorButton(
    symbol: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    type: ButtonType = ButtonType.NUMBER,
    backgroundColor: Color? = null,
    textColor: Color? = null,
    fontSize: TextUnit = 24.sp,
    height: Dp = 64.dp
) {
    val interactionSource = remember { MutableInteractionSource() }

    val resolvedBg = backgroundColor ?: when (type) {
        ButtonType.NUMBER -> MaterialTheme.colorScheme.surfaceVariant
        ButtonType.OPERATOR -> MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
        ButtonType.FUNCTION -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
        ButtonType.EQUALS -> MaterialTheme.colorScheme.primary
        ButtonType.CLEAR -> MaterialTheme.colorScheme.error.copy(alpha = 0.2f)
        ButtonType.ACTION -> MaterialTheme.colorScheme.surface
    }

    val resolvedText = textColor ?: when (type) {
        ButtonType.EQUALS -> Color.White
        ButtonType.OPERATOR -> MaterialTheme.colorScheme.primary
        ButtonType.FUNCTION -> MaterialTheme.colorScheme.secondary
        ButtonType.CLEAR -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.onSurface
    }

    Box(
        modifier = modifier
            .height(height)
            .clip(RoundedCornerShape(20.dp))
            .background(resolvedBg)
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material.ripple.rememberRipple(bounded = true),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = symbol,
            color = resolvedText,
            fontSize = fontSize,
            fontWeight = if (type == ButtonType.EQUALS || type == ButtonType.OPERATOR) FontWeight.Bold else FontWeight.Medium
        )
    }
}
