package com.educationwithhassan.smartcalculator.calculator

import com.educationwithhassan.smartcalculator.data.HistoryItem

data class CalculatorState(
    val expression: String = "",
    val result: String = "0",
    val previewResult: String = "",
    val isScientific: Boolean = false,
    val angleMode: AngleMode = AngleMode.DEG,
    val memoryValue: Double = 0.0,
    val hasMemory: Boolean = false,
    val errorMessage: String? = null,
    val isEvaluated: Boolean = false,
    val history: List<HistoryItem> = emptyList(),
    val decimalPrecision: Int = 8,
    val isHapticEnabled: Boolean = true
)
