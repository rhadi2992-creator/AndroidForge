package com.educationwithhassan.smartcalculator.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.smartcalculator.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FAQScreen(onNavigateBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Frequently Asked Questions", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val faqs = listOf(
                "Can Smart Calculator calculate without an internet connection?" to
                        "Yes! The entire core mathematical engine, arithmetic, trigonometry, and calculation history work 100% offline. Internet access is only utilized by Google Mobile Ads (AdMob) to display non-intrusive advertisements.",
                "How does the percentage (%) button work?" to
                        "Smart Calculator supports both fractional percentages and compound operations. Entering 100 × 25% calculates 25, while 50% evaluates directly to 0.5.",
                "How do I switch between Degree (DEG) and Radian (RAD) modes?" to
                        "Toggle the Scientific mode icon in the top bar. You will see an active DEG or RAD badge in the top-left of the display card. Tap the badge at any time to instantly switch angle modes.",
                "How do Memory buttons (MC, MR, M+, M−, MS) work?" to
                        "• MC: Memory Clear (resets memory to 0)\n• MR: Memory Recall (inserts stored value)\n• M+: Adds current value to memory\n• M−: Subtracts current value from memory\n• MS: Memory Store (stores current value)\nA cyan [M] indicator appears on the display whenever memory contains a value.",
                "How does the app protect my privacy with AdMob?" to
                        "Your mathematical calculations and history never leave your device. Google AdMob may use pseudonymous device identifiers solely to serve relevant ads according to your Google Ad preferences and GDPR/CCPA regulations.",
                "Why is the app so fast and responsive?" to
                        "Smart Calculator is written in 100% native Kotlin 2.0 with Jetpack Compose Material 3 and an optimized Shunting-Yard AST mathematical parser. There are no webviews or heavy background daemons."
            )

            items(faqs.size) { i ->
                val (q, a) = faqs[i]
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = q,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = a,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        }
    }
}
