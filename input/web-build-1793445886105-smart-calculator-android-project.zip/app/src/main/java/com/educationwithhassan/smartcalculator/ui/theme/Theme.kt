package com.educationwithhassan.smartcalculator.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = BluePrimary,
    secondary = VioletSecondary,
    tertiary = CyanAccent,
    background = DeepNavy,
    surface = DarkNavySurface,
    surfaceVariant = DarkNavyElevated,
    onPrimary = WhiteSurface,
    onSecondary = WhiteSurface,
    onBackground = TextMainDark,
    onSurface = TextMainDark,
    error = ErrorColor
)

private val LightColorScheme = lightColorScheme(
    primary = BluePrimary,
    secondary = VioletSecondary,
    tertiary = CyanAccent,
    background = LightBackground,
    surface = WhiteSurface,
    surfaceVariant = OpKeyLight,
    onPrimary = WhiteSurface,
    onSecondary = WhiteSurface,
    onBackground = TextMainLight,
    onSurface = TextMainLight,
    error = ErrorColor
)

enum class ThemeSetting {
    SYSTEM, LIGHT, DARK
}

@Composable
fun SmartCalculatorTheme(
    themeSetting: ThemeSetting = ThemeSetting.SYSTEM,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeSetting) {
        ThemeSetting.SYSTEM -> isSystemInDarkTheme()
        ThemeSetting.LIGHT -> false
        ThemeSetting.DARK -> true
    }

    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
