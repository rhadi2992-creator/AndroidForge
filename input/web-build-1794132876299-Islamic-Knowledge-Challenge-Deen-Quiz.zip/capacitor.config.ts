export interface CapacitorConfig {
  appId: string;
  appName: string;
  webDir: string;
  bundledWebRuntime?: boolean;
  plugins?: Record<string, unknown>;
}

const config: CapacitorConfig = {
  appId: 'com.islamic.deenquiz',
  appName: 'Islamic Knowledge Challenge – Deen Quiz',
  webDir: 'dist',
  bundledWebRuntime: false,
  plugins: {
    AdMob: {
      appId: 'ca-app-pub-3133971041724338~1043785552',
      bannerAdUnitId: 'ca-app-pub-3133971041724338/3478377206',
      appOpenAdUnitId: 'ca-app-pub-3133971041724338/7226050527',
      interstitialAdUnitId: 'ca-app-pub-3133971041724338/2416576970',
      nativeAdUnitId: 'ca-app-pub-3133971041724338/8955879258',
      rewardedAdUnitId: 'ca-app-pub-3133971041724338/3018166024',
      initializeForTesting: false
    }
  }
};

export default config;
