package com.islamic.deenquiz;

import android.os.Bundle;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import java.util.Collections;
import java.util.Date;

/**
 * MainActivity for Islamic Knowledge Challenge - Deen Quiz
 * Handles Google Mobile Ads SDK initialization, lifecycle events, and all 5 ad formats:
 * 1. Banner Ad:       ca-app-pub-3133971041724338/3478377206
 * 2. App Open Ad:     ca-app-pub-3133971041724338/7226050527
 * 3. Interstitial Ad: ca-app-pub-3133971041724338/2416576970
 * 4. Native Ad:       ca-app-pub-3133971041724338/8955879258
 * 5. Rewarded Ad:     ca-app-pub-3133971041724338/3018166024
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "DeenQuizAdMob";

    // Production Ad Unit IDs
    public static final String ADMOB_APP_ID = "ca-app-pub-3133971041724338~1043785552";
    public static final String BANNER_AD_UNIT = "ca-app-pub-3133971041724338/3478377206";
    public static final String APP_OPEN_AD_UNIT = "ca-app-pub-3133971041724338/7226050527";
    public static final String INTERSTITIAL_AD_UNIT = "ca-app-pub-3133971041724338/2416576970";
    public static final String NATIVE_AD_UNIT = "ca-app-pub-3133971041724338/8955879258";
    public static final String REWARDED_AD_UNIT = "ca-app-pub-3133971041724338/3018166024";

    // Ad Instances
    private AdView bannerAdView;
    private InterstitialAd mInterstitialAd;
    private RewardedAd mRewardedAd;
    private AppOpenAd mAppOpenAd;
    private long appOpenLoadTime = 0;
    private boolean isShowingAppOpen = false;

    // Consent
    private ConsentInformation consentInformation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Initialize UMP (User Messaging Platform) for GDPR/Consent Compliance
        initConsentAndMobileAds();
    }

    private void initConsentAndMobileAds() {
        ConsentRequestParameters params = new ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false)
                .build();

        consentInformation = UserMessagingPlatform.getConsentInformation(this);
        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                () -> {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                            this,
                            formError -> {
                                if (formError != null) {
                                    Log.w(TAG, "Consent form error: " + formError.getMessage());
                                }
                                if (consentInformation.canRequestAds()) {
                                    initializeMobileAdsSdk();
                                }
                            }
                    );
                },
                requestConsentError -> {
                    Log.w(TAG, "Consent request error: " + requestConsentError.getMessage());
                    initializeMobileAdsSdk();
                }
        );

        if (consentInformation.canRequestAds()) {
            initializeMobileAdsSdk();
        }
    }

    private void initializeMobileAdsSdk() {
        // Configure general request settings
        RequestConfiguration configuration = new RequestConfiguration.Builder()
                .setTagForChildDirectedTreatment(RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE)
                .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_G)
                .build();
        MobileAds.setRequestConfiguration(configuration);

        // Initialize Google Mobile Ads SDK once
        MobileAds.initialize(this, initializationStatus -> {
            Log.d(TAG, "Google Mobile Ads SDK Initialized successfully.");
            // Preload ads for ready delivery
            loadAppOpenAd();
            preloadInterstitialAd();
            preloadRewardedAd();
        });
    }

    /* ---------------- APP OPEN AD IMPLEMENTATION ---------------- */
    public void loadAppOpenAd() {
        if (isAppOpenAdAvailable()) return;

        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(
                this,
                APP_OPEN_AD_UNIT,
                request,
                new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd appOpenAd) {
                        mAppOpenAd = appOpenAd;
                        appOpenLoadTime = (new Date()).getTime();
                        Log.d(TAG, "App Open Ad Loaded.");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        Log.w(TAG, "App Open Ad Failed: " + loadAdError.getMessage());
                        mAppOpenAd = null;
                    }
                }
        );
    }

    public boolean isAppOpenAdAvailable() {
        return mAppOpenAd != null && wasAppOpenLoadedLessThan4HoursAgo();
    }

    private boolean wasAppOpenLoadedLessThan4HoursAgo() {
        long dateDifference = (new Date()).getTime() - this.appOpenLoadTime;
        long numMilliSecondsPerHour = 3600000;
        return (dateDifference < (numMilliSecondsPerHour * 4));
    }

    public void showAppOpenAdIfAvailable() {
        if (!isShowingAppOpen && isAppOpenAdAvailable()) {
            mAppOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    mAppOpenAd = null;
                    isShowingAppOpen = false;
                    loadAppOpenAd(); // Preload next
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    mAppOpenAd = null;
                    isShowingAppOpen = false;
                    loadAppOpenAd();
                }

                @Override
                public void onAdShowedFullScreenContent() {
                    isShowingAppOpen = true;
                }
            });
            mAppOpenAd.show(this);
        } else {
            loadAppOpenAd();
        }
    }

    /* ---------------- INTERSTITIAL AD IMPLEMENTATION ---------------- */
    public void preloadInterstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(
                this,
                INTERSTITIAL_AD_UNIT,
                adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        Log.d(TAG, "Interstitial Ad Preloaded.");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        Log.w(TAG, "Interstitial Failed: " + loadAdError.getMessage());
                        mInterstitialAd = null;
                    }
                }
        );
    }

    public void showInterstitialAd(Runnable onDismissed) {
        if (mInterstitialAd != null) {
            mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    mInterstitialAd = null;
                    preloadInterstitialAd(); // Preload next
                    if (onDismissed != null) onDismissed.run();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    mInterstitialAd = null;
                    preloadInterstitialAd();
                    if (onDismissed != null) onDismissed.run();
                }
            });
            mInterstitialAd.show(this);
        } else {
            preloadInterstitialAd();
            if (onDismissed != null) onDismissed.run();
        }
    }

    /* ---------------- REWARDED AD IMPLEMENTATION ---------------- */
    public void preloadRewardedAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        RewardedAd.load(
                this,
                REWARDED_AD_UNIT,
                adRequest,
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                        mRewardedAd = rewardedAd;
                        Log.d(TAG, "Rewarded Ad Preloaded.");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        Log.w(TAG, "Rewarded Ad Failed: " + loadAdError.getMessage());
                        mRewardedAd = null;
                    }
                }
        );
    }

    public void showRewardedAd(Runnable onRewardGranted, Runnable onDismissed) {
        if (mRewardedAd != null) {
            mRewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    mRewardedAd = null;
                    preloadRewardedAd(); // Preload next
                    if (onDismissed != null) onDismissed.run();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    mRewardedAd = null;
                    preloadRewardedAd();
                    if (onDismissed != null) onDismissed.run();
                }
            });

            // Reward is ONLY granted if user watches successfully
            mRewardedAd.show(this, rewardItem -> {
                Log.d(TAG, "Verified User Reward: " + rewardItem.getAmount() + " " + rewardItem.getType());
                if (onRewardGranted != null) {
                    runOnUiThread(onRewardGranted);
                }
            });
        } else {
            preloadRewardedAd();
            if (onDismissed != null) onDismissed.run();
        }
    }

    /* ---------------- ANDROID LIFECYCLE MANAGEMENT ---------------- */
    @Override
    protected void onResume() {
        super.onResume();
        if (bannerAdView != null) {
            bannerAdView.resume();
        }
        showAppOpenAdIfAvailable();
    }

    @Override
    protected void onPause() {
        if (bannerAdView != null) {
            bannerAdView.pause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (bannerAdView != null) {
            bannerAdView.destroy();
        }
        super.onDestroy();
    }
}
