/**
 * Google AdMob Advanced Integration & Optimization Service
 * Islamic Knowledge Challenge – Deen Quiz
 *
 * OFFICIAL PRODUCTION ADMOB IDS (Configured exactly as requested):
 * - APP ID:            ca-app-pub-3133971041724338~1043785552
 * - BANNER AD UNIT:    ca-app-pub-3133971041724338/3478377206
 * - APP OPEN AD UNIT:  ca-app-pub-3133971041724338/7226050527
 * - INTERSTITIAL UNIT: ca-app-pub-3133971041724338/2416576970
 * - NATIVE AD UNIT:    ca-app-pub-3133971041724338/8955879258
 * - REWARDED AD UNIT:  ca-app-pub-3133971041724338/3018166024
 */

import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  BannerAdSize,
  BannerAdPosition,
  BannerAdPluginEvents,
  InterstitialAdPluginEvents,
  RewardAdPluginEvents,
  AppOpenAdPluginEvents,
  AppOpenAdOptions,
  AdOptions,
  BannerAdOptions,
  RewardAdOptions
} from '@capacitor-community/admob';

export interface AdMobConfig {
  appId: string;
  bannerAdUnitId: string;
  appOpenAdUnitId: string;
  interstitialAdUnitId: string;
  nativeAdUnitId: string;
  rewardedAdUnitId: string;
}

// Exact Google AdMob Production IDs
export const ADMOB_PRODUCTION_CONFIG: AdMobConfig = {
  appId: 'ca-app-pub-3133971041724338~1043785552',
  bannerAdUnitId: 'ca-app-pub-3133971041724338/3478377206',
  appOpenAdUnitId: 'ca-app-pub-3133971041724338/7226050527',
  interstitialAdUnitId: 'ca-app-pub-3133971041724338/2416576970',
  nativeAdUnitId: 'ca-app-pub-3133971041724338/8955879258',
  rewardedAdUnitId: 'ca-app-pub-3133971041724338/3018166024',
};

// Official Google AdMob Test IDs (prevents ad serving limits during dev/testing)
export const ADMOB_TEST_CONFIG: AdMobConfig = {
  appId: 'ca-app-pub-3940256099942544~3347511713',
  bannerAdUnitId: 'ca-app-pub-3940256099942544/6300978111',
  appOpenAdUnitId: 'ca-app-pub-3940256099942544/9257395921',
  interstitialAdUnitId: 'ca-app-pub-3940256099942544/1033173712',
  nativeAdUnitId: 'ca-app-pub-3940256099942544/2247696110',
  rewardedAdUnitId: 'ca-app-pub-3940256099942544/5224354917',
};

export interface AdMobDiagnostics {
  sdkInitialized: boolean;
  initializationStatus: 'INITIALIZED' | 'INITIALIZING' | 'FAILED' | 'NOT_INITIALIZED';
  platform: 'native_android' | 'web_simulator';
  adMode: 'production' | 'test';
  bannerStatus: 'READY' | 'LOADING' | 'FAILED' | 'IDLE';
  appOpenStatus: 'READY' | 'LOADING' | 'FAILED' | 'COOLDOWN';
  interstitialStatus: 'READY' | 'LOADING' | 'FAILED' | 'COOLDOWN';
  nativeStatus: 'READY' | 'RENDERED' | 'IDLE';
  rewardedStatus: 'READY' | 'LOADING' | 'FAILED';
  lastError: { timestamp: string; adType: string; message: string } | null;
  networkOnline: boolean;
  requestCounts: {
    banner: number;
    appOpen: number;
    interstitial: number;
    native: number;
    rewarded: number;
  };
  impressionCounts: {
    banner: number;
    appOpen: number;
    interstitial: number;
    native: number;
    rewarded: number;
  };
  rewardGrantedCount: number;
}

class AdMobService {
  private mode: 'production' | 'test' = 'production';
  private sdkInitialized: boolean = false;
  private isInitializing: boolean = false;

  // Statuses
  private bannerStatus: 'READY' | 'LOADING' | 'FAILED' | 'IDLE' = 'READY';
  private appOpenStatus: 'READY' | 'LOADING' | 'FAILED' | 'COOLDOWN' = 'READY';
  private interstitialStatus: 'READY' | 'LOADING' | 'FAILED' | 'COOLDOWN' = 'READY';
  private nativeStatus: 'READY' | 'RENDERED' | 'IDLE' = 'READY';
  private rewardedStatus: 'READY' | 'LOADING' | 'FAILED' = 'READY';

  private lastError: { timestamp: string; adType: string; message: string } | null = null;

  // Frequency Tracking
  private lastInterstitialShown: number = 0;
  private lastAppOpenShown: number = 0;
  private appOpenCooldownMs: number = 8 * 60 * 1000; // 8 minutes between App Open Ads
  private interstitialCooldownMs: number = 50 * 1000; // 50 seconds minimum between Interstitials

  // Diagnostics counters
  private requestCounts = { banner: 0, appOpen: 0, interstitial: 0, native: 0, rewarded: 0 };
  private impressionCounts = { banner: 0, appOpen: 0, interstitial: 0, native: 0, rewarded: 0 };
  private rewardGrantedCount: number = 0;

  constructor() {
    try {
      const savedMode = localStorage.getItem('deen_quiz_admob_mode');
      if (savedMode === 'production' || savedMode === 'test') {
        this.mode = savedMode;
      }
    } catch {
      this.mode = 'production';
    }

    this.initSdk();
  }

  /**
   * Initializes the Google Mobile Ads SDK once.
   * If on Android native platform, calls Capacitor AdMob plugin.
   * If on web browser, sets up high-fidelity simulator.
   */
  public async initSdk() {
    if (this.sdkInitialized || this.isInitializing) return;
    this.isInitializing = true;

    try {
      if (Capacitor.isNativePlatform()) {
        await AdMob.initialize({
          initializeForTesting: this.mode === 'test',
          tagForChildDirectedTreatment: false,
          tagForUnderAgeOfConsent: false,
        });

        this.setupNativeEventListeners();
      }

      this.sdkInitialized = true;
      this.isInitializing = false;
      this.preloadAllAds();
    } catch (err: unknown) {
      this.isInitializing = false;
      this.recordError('SDK', err instanceof Error ? err.message : String(err));
    }
  }

  private setupNativeEventListeners() {
    // Banner listeners
    AdMob.addListener(BannerAdPluginEvents.Loaded, () => {
      this.bannerStatus = 'READY';
    });
    AdMob.addListener(BannerAdPluginEvents.FailedToLoad, (err) => {
      this.bannerStatus = 'FAILED';
      this.recordError('Banner', err.message);
    });
    AdMob.addListener(BannerAdPluginEvents.Opened, () => {
      this.recordImpression('banner');
    });

    // Interstitial listeners
    AdMob.addListener(InterstitialAdPluginEvents.Loaded, () => {
      this.interstitialStatus = 'READY';
    });
    AdMob.addListener(InterstitialAdPluginEvents.FailedToLoad, (err) => {
      this.interstitialStatus = 'FAILED';
      this.recordError('Interstitial', err.message);
    });
    AdMob.addListener(InterstitialAdPluginEvents.Showed, () => {
      this.recordImpression('interstitial');
    });
    AdMob.addListener(InterstitialAdPluginEvents.Dismissed, () => {
      this.preloadInterstitial();
    });

    // Rewarded listeners
    AdMob.addListener(RewardAdPluginEvents.Loaded, () => {
      this.rewardedStatus = 'READY';
    });
    AdMob.addListener(RewardAdPluginEvents.FailedToLoad, (err) => {
      this.rewardedStatus = 'FAILED';
      this.recordError('Rewarded', err.message);
    });
    AdMob.addListener(RewardAdPluginEvents.Rewarded, (reward) => {
      this.rewardGrantedCount++;
      console.log('Native AdMob Reward granted:', reward);
    });

    // App Open listeners
    AdMob.addListener(AppOpenAdPluginEvents.Loaded, () => {
      this.appOpenStatus = 'READY';
    });
    AdMob.addListener(AppOpenAdPluginEvents.FailedToLoad, (err) => {
      this.appOpenStatus = 'FAILED';
      this.recordError('AppOpen', err.message);
    });
    AdMob.addListener(AppOpenAdPluginEvents.Closed, () => {
      this.preloadAppOpen();
    });
  }

  public preloadAllAds() {
    this.preloadBanner();
    this.preloadAppOpen();
    this.preloadInterstitial();
    this.preloadRewarded();
  }

  public async preloadBanner() {
    this.requestCounts.banner++;
    this.bannerStatus = 'LOADING';
    const config = this.getConfig();

    if (Capacitor.isNativePlatform()) {
      try {
        const options: BannerAdOptions = {
          adId: config.bannerAdUnitId,
          adSize: BannerAdSize.ADAPTIVE_BANNER,
          position: BannerAdPosition.BOTTOM_CENTER,
          margin: 0,
          isTesting: this.mode === 'test'
        };
        await AdMob.showBanner(options);
        this.bannerStatus = 'READY';
      } catch (err: unknown) {
        this.bannerStatus = 'FAILED';
        this.recordError('Banner', err instanceof Error ? err.message : String(err));
      }
    } else {
      setTimeout(() => {
        this.bannerStatus = 'READY';
      }, 300);
    }
  }

  public async hideBanner() {
    if (Capacitor.isNativePlatform()) {
      try {
        await AdMob.hideBanner();
      } catch {}
    }
  }

  public async resumeBanner() {
    if (Capacitor.isNativePlatform()) {
      try {
        await AdMob.resumeBanner();
      } catch {}
    }
  }

  public async preloadAppOpen() {
    this.requestCounts.appOpen++;
    this.appOpenStatus = 'LOADING';
    const config = this.getConfig();

    if (Capacitor.isNativePlatform()) {
      try {
        const options: AppOpenAdOptions = {
          adId: config.appOpenAdUnitId
        };
        await AdMob.loadAppOpen(options);
        this.appOpenStatus = 'READY';
      } catch (err: unknown) {
        this.appOpenStatus = 'FAILED';
        this.recordError('AppOpen', err instanceof Error ? err.message : String(err));
      }
    } else {
      setTimeout(() => {
        this.appOpenStatus = 'READY';
      }, 400);
    }
  }

  public async preloadInterstitial() {
    this.requestCounts.interstitial++;
    this.interstitialStatus = 'LOADING';
    const config = this.getConfig();

    if (Capacitor.isNativePlatform()) {
      try {
        const options: AdOptions = {
          adId: config.interstitialAdUnitId,
          isTesting: this.mode === 'test'
        };
        await AdMob.prepareInterstitial(options);
        this.interstitialStatus = 'READY';
      } catch (err: unknown) {
        this.interstitialStatus = 'FAILED';
        this.recordError('Interstitial', err instanceof Error ? err.message : String(err));
      }
    } else {
      setTimeout(() => {
        this.interstitialStatus = 'READY';
      }, 350);
    }
  }

  public async preloadRewarded() {
    this.requestCounts.rewarded++;
    this.rewardedStatus = 'LOADING';
    const config = this.getConfig();

    if (Capacitor.isNativePlatform()) {
      try {
        const options: RewardAdOptions = {
          adId: config.rewardedAdUnitId,
          isTesting: this.mode === 'test'
        };
        await AdMob.prepareRewardVideoAd(options);
        this.rewardedStatus = 'READY';
      } catch (err: unknown) {
        this.rewardedStatus = 'FAILED';
        this.recordError('Rewarded', err instanceof Error ? err.message : String(err));
      }
    } else {
      setTimeout(() => {
        this.rewardedStatus = 'READY';
      }, 350);
    }
  }

  public getMode(): 'production' | 'test' {
    return this.mode;
  }

  public setMode(mode: 'production' | 'test') {
    this.mode = mode;
    try {
      localStorage.setItem('deen_quiz_admob_mode', mode);
    } catch {}
    this.preloadAllAds();
  }

  public getConfig(): AdMobConfig {
    return this.mode === 'production' ? ADMOB_PRODUCTION_CONFIG : ADMOB_TEST_CONFIG;
  }

  public shouldShowAppOpen(): boolean {
    const now = Date.now();
    return (now - this.lastAppOpenShown > this.appOpenCooldownMs);
  }

  public recordAppOpenShown() {
    this.lastAppOpenShown = Date.now();
    this.recordImpression('appOpen');
    this.preloadAppOpen();
  }

  public shouldShowInterstitial(): boolean {
    const now = Date.now();
    return (now - this.lastInterstitialShown > this.interstitialCooldownMs);
  }

  public recordInterstitialShown() {
    this.lastInterstitialShown = Date.now();
    this.recordImpression('interstitial');
    this.preloadInterstitial();
  }

  public recordImpression(type: 'banner' | 'appOpen' | 'interstitial' | 'native' | 'rewarded') {
    this.impressionCounts[type]++;
  }

  public recordRewardGranted() {
    this.rewardGrantedCount++;
    this.recordImpression('rewarded');
    this.preloadRewarded();
  }

  public recordError(adType: string, message: string) {
    this.lastError = {
      timestamp: new Date().toLocaleTimeString(),
      adType,
      message
    };
    console.warn(`[AdMob Error - ${adType}]:`, message);
  }

  public getDiagnostics(): AdMobDiagnostics {
    return {
      sdkInitialized: this.sdkInitialized,
      initializationStatus: this.sdkInitialized ? 'INITIALIZED' : this.isInitializing ? 'INITIALIZING' : 'NOT_INITIALIZED',
      platform: Capacitor.isNativePlatform() ? 'native_android' : 'web_simulator',
      adMode: this.mode,
      bannerStatus: this.bannerStatus,
      appOpenStatus: this.appOpenStatus,
      interstitialStatus: this.interstitialStatus,
      nativeStatus: this.nativeStatus,
      rewardedStatus: this.rewardedStatus,
      lastError: this.lastError,
      networkOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
      requestCounts: { ...this.requestCounts },
      impressionCounts: { ...this.impressionCounts },
      rewardGrantedCount: this.rewardGrantedCount,
    };
  }

  public resetDiagnostics() {
    this.requestCounts = { banner: 0, appOpen: 0, interstitial: 0, native: 0, rewarded: 0 };
    this.impressionCounts = { banner: 0, appOpen: 0, interstitial: 0, native: 0, rewarded: 0 };
    this.rewardGrantedCount = 0;
    this.lastError = null;
  }
}

export const adMobService = new AdMobService();
