import { UserStats, UserPreferences, LevelProgress, QuizSummary } from '../types/quiz';

const STATS_KEY = 'deen_quiz_user_stats_v1';
const PREFS_KEY = 'deen_quiz_user_prefs_v1';

export function getDefaultStats(): UserStats {
  const initialLevels: Record<number, LevelProgress> = {};
  for (let i = 1; i <= 20; i++) {
    initialLevels[i] = {
      level: i,
      unlocked: i === 1, // Level 1 is unlocked initially
      completed: false,
      stars: 0,
      highScore: 0
    };
  }

  return {
    totalScore: 0,
    highScore: 0,
    totalQuizzesPlayed: 0,
    totalQuestionsAnswered: 0,
    totalCorrectAnswers: 0,
    coins: 50, // Starting gift for lifelines
    currentStreak: 1,
    bestStreak: 1,
    lastPlayedDate: '',
    categoryScores: {},
    levelProgress: initialLevels,
    dailyHistory: {},
    lifelines: {
      fiftyFifty: 3,
      hint: 3,
      extraTime: 3
    }
  };
}

export function getDefaultPreferences(): UserPreferences {
  return {
    language: 'en',
    theme: 'emerald',
    showAdPlaceholders: true,
    adMobMode: 'production'
  };
}

class StorageService {
  private stats: UserStats;
  private preferences: UserPreferences;

  constructor() {
    this.stats = this.loadStats();
    this.preferences = this.loadPreferences();
    this.verifyDailyStreak();
  }

  private loadStats(): UserStats {
    try {
      const data = localStorage.getItem(STATS_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        const defaults = getDefaultStats();
        return {
          ...defaults,
          ...parsed,
          levelProgress: { ...defaults.levelProgress, ...parsed.levelProgress },
          lifelines: { ...defaults.lifelines, ...parsed.lifelines }
        };
      }
    } catch {
      // fallback
    }
    return getDefaultStats();
  }

  private loadPreferences(): UserPreferences {
    try {
      const data = localStorage.getItem(PREFS_KEY);
      if (data) {
        return { ...getDefaultPreferences(), ...JSON.parse(data) };
      }
    } catch {
      // fallback
    }
    return getDefaultPreferences();
  }

  public getStats(): UserStats {
    return { ...this.stats };
  }

  public getPreferences(): UserPreferences {
    return { ...this.preferences };
  }

  public savePreferences(updates: Partial<UserPreferences>) {
    this.preferences = { ...this.preferences, ...updates };
    try {
      localStorage.setItem(PREFS_KEY, JSON.stringify(this.preferences));
    } catch {}
  }

  public saveStats(updates: Partial<UserStats>) {
    this.stats = { ...this.stats, ...updates };
    try {
      localStorage.setItem(STATS_KEY, JSON.stringify(this.stats));
    } catch {}
  }

  public verifyDailyStreak() {
    const today = new Date().toISOString().split('T')[0];
    if (!this.stats.lastPlayedDate) {
      this.stats.lastPlayedDate = today;
      this.stats.currentStreak = 1;
      this.saveStats(this.stats);
      return;
    }

    if (this.stats.lastPlayedDate === today) {
      return; // Already recorded today
    }

    const lastDate = new Date(this.stats.lastPlayedDate);
    const currDate = new Date(today);
    const diffDays = Math.round((currDate.getTime() - lastDate.getTime()) / (1000 * 3600 * 24));

    if (diffDays === 1) {
      // Consecutive day!
      this.stats.currentStreak += 1;
      if (this.stats.currentStreak > this.stats.bestStreak) {
        this.stats.bestStreak = this.stats.currentStreak;
      }
    } else if (diffDays > 1) {
      // Streak broken, restart at 1
      this.stats.currentStreak = 1;
    }

    this.stats.lastPlayedDate = today;
    this.saveStats(this.stats);
  }

  /**
   * Process quiz completion and update levels, scores, coins, categories
   */
  public recordQuizCompletion(summary: QuizSummary): { unlockedNextLevel: boolean; coinsAwarded: number } {
    let unlockedNext = false;
    const earnedCoins = Math.round(summary.totalScore / 5) + (summary.starsEarned * 10);

    const newTotalScore = this.stats.totalScore + summary.totalScore;
    const newHighScore = Math.max(this.stats.highScore, summary.totalScore);
    const newQuizzesPlayed = this.stats.totalQuizzesPlayed + 1;
    const newAnswered = this.stats.totalQuestionsAnswered + summary.totalQuestions;
    const newCorrect = this.stats.totalCorrectAnswers + summary.correctCount;
    const newCoins = this.stats.coins + earnedCoins;

    const levelProg = { ...this.stats.levelProgress };

    if (summary.mode === 'level' && summary.levelNumber) {
      const currentLevel = summary.levelNumber;
      const passed = summary.correctCount >= 7; // 70%+ passing mark

      const existing = levelProg[currentLevel] || {
        level: currentLevel,
        unlocked: true,
        completed: false,
        stars: 0,
        highScore: 0
      };

      levelProg[currentLevel] = {
        ...existing,
        completed: passed || existing.completed,
        stars: Math.max(existing.stars, summary.starsEarned),
        highScore: Math.max(existing.highScore, summary.totalScore)
      };

      // If passed and next level exists (up to 20), unlock level N+1
      if (passed && currentLevel < 20) {
        const nextLevel = currentLevel + 1;
        if (!levelProg[nextLevel] || !levelProg[nextLevel].unlocked) {
          levelProg[nextLevel] = {
            level: nextLevel,
            unlocked: true,
            completed: false,
            stars: 0,
            highScore: 0
          };
          unlockedNext = true;
        }
      }
    }

    if (summary.mode === 'daily') {
      const today = new Date().toISOString().split('T')[0];
      this.stats.dailyHistory[today] = {
        date: today,
        completed: true,
        score: summary.totalScore,
        accuracy: summary.accuracyPercentage
      };
    }

    this.saveStats({
      totalScore: newTotalScore,
      highScore: newHighScore,
      totalQuizzesPlayed: newQuizzesPlayed,
      totalQuestionsAnswered: newAnswered,
      totalCorrectAnswers: newCorrect,
      coins: newCoins,
      levelProgress: levelProg
    });

    return {
      unlockedNextLevel: unlockedNext,
      coinsAwarded: earnedCoins
    };
  }

  public useLifeline(type: 'fiftyFifty' | 'hint' | 'extraTime'): boolean {
    if (this.stats.lifelines[type] > 0) {
      this.stats.lifelines[type] -= 1;
      this.saveStats({ lifelines: { ...this.stats.lifelines } });
      return true;
    }
    return false;
  }

  public addLifelines(type: 'fiftyFifty' | 'hint' | 'extraTime', count: number = 1) {
    this.stats.lifelines[type] += count;
    this.saveStats({ lifelines: { ...this.stats.lifelines } });
  }

  public resetAllProgress() {
    this.stats = getDefaultStats();
    this.preferences = getDefaultPreferences();
    try {
      localStorage.removeItem(STATS_KEY);
      localStorage.removeItem(PREFS_KEY);
      localStorage.removeItem('deen_quiz_audio_settings');
    } catch {}
    this.saveStats(this.stats);
    this.savePreferences(this.preferences);
  }
}

export const storageService = new StorageService();
