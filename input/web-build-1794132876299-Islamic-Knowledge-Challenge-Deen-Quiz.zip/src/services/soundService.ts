import { AudioSettings } from '../types/quiz';

class SoundService {
  private ctx: AudioContext | null = null;
  private musicGainNode: GainNode | null = null;
  private sfxGainNode: GainNode | null = null;
  private isMusicPlaying: boolean = false;
  private ambientOscillators: OscillatorNode[] = [];
  private ambientGains: GainNode[] = [];
  private lfoOsc: OscillatorNode | null = null;
  private naatAudio: HTMLAudioElement | null = null;
  private customAudio: HTMLAudioElement | null = null;
  private duckMultiplier: number = 1.0;
  private autoplayUnlockAttached: boolean = false;

  private settings: AudioSettings = {
    musicEnabled: true,
    musicVolume: 0.35,
    sfxEnabled: true,
    sfxVolume: 0.65,
    musicTrack: 'naat_mp3'
  };

  constructor() {
    this.loadSavedSettings();
    this.setupAutoplayUnlock();
  }

  private loadSavedSettings() {
    try {
      const saved = localStorage.getItem('deen_quiz_audio_settings');
      if (saved) {
        this.settings = { ...this.settings, ...JSON.parse(saved) };
      }
    } catch {
      // fallback to defaults
    }
  }

  /**
   * Browser autoplay policy requires user interaction before unmuted audio can play.
   * We attach a one-time gesture listener on the window to start Naat immediately upon first touch/click.
   */
  private setupAutoplayUnlock() {
    if (this.autoplayUnlockAttached || typeof window === 'undefined') return;
    this.autoplayUnlockAttached = true;

    const unlock = () => {
      if (this.settings.musicEnabled && !this.isMusicPlaying) {
        this.startMusic();
      }
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('click', unlock);
      window.removeEventListener('keydown', unlock);
    };

    window.addEventListener('pointerdown', unlock, { passive: true });
    window.addEventListener('click', unlock, { passive: true });
    window.addEventListener('keydown', unlock, { passive: true });
  }

  public saveSettings(newSettings: Partial<AudioSettings>) {
    this.settings = { ...this.settings, ...newSettings };
    try {
      localStorage.setItem('deen_quiz_audio_settings', JSON.stringify(this.settings));
    } catch {
      // ignore storage errors
    }
    this.applyVolumeChanges();
    if (!this.settings.musicEnabled && this.isMusicPlaying) {
      this.pauseMusic();
    } else if (this.settings.musicEnabled && !this.isMusicPlaying) {
      this.startMusic();
    }
  }

  public getSettings(): AudioSettings {
    return { ...this.settings };
  }

  public isPlaying(): boolean {
    return this.isMusicPlaying;
  }

  public getTrackTitle(): string {
    if (this.settings.musicTrack === 'naat_mp3') {
      return 'Meri Baat Ban Gayi Hai – Ghulam Mustafa Qadri';
    }
    if (this.settings.musicTrack === 'ambient_nasheed') {
      return 'Peaceful Ambient Nasheed';
    }
    if (this.settings.musicTrack === 'meditation_drone') {
      return 'Spiritual Meditation Drone';
    }
    return this.settings.customAudioName || 'Custom Audio';
  }

  private initAudioContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioContextClass();

      this.musicGainNode = this.ctx.createGain();
      this.musicGainNode.gain.setValueAtTime(this.settings.musicVolume * this.duckMultiplier, this.ctx.currentTime);
      this.musicGainNode.connect(this.ctx.destination);

      this.sfxGainNode = this.ctx.createGain();
      this.sfxGainNode.gain.setValueAtTime(this.settings.sfxVolume, this.ctx.currentTime);
      this.sfxGainNode.connect(this.ctx.destination);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private applyVolumeChanges() {
    const targetMusic = this.settings.musicEnabled ? this.settings.musicVolume * this.duckMultiplier : 0;
    const targetSfx = this.settings.sfxEnabled ? this.settings.sfxVolume : 0;

    if (this.ctx && this.musicGainNode && this.sfxGainNode) {
      this.musicGainNode.gain.setTargetAtTime(targetMusic, this.ctx.currentTime, 0.05);
      this.sfxGainNode.gain.setTargetAtTime(targetSfx, this.ctx.currentTime, 0.05);
    }

    if (this.naatAudio) {
      this.naatAudio.volume = Math.max(0, Math.min(1, targetMusic));
    }
    if (this.customAudio) {
      this.customAudio.volume = Math.max(0, Math.min(1, targetMusic));
    }
  }

  /**
   * Auto-duck background music during answer feedback (lowers music to 25%)
   */
  public duckAudio() {
    this.duckMultiplier = 0.25;
    this.applyVolumeChanges();
  }

  /**
   * Restore normal background music volume after feedback
   */
  public unduckAudio() {
    this.duckMultiplier = 1.0;
    this.applyVolumeChanges();
  }

  /**
   * Start or resume background music (Naat by default)
   */
  public startMusic() {
    if (!this.settings.musicEnabled) return;

    if (this.settings.musicTrack === 'naat_mp3') {
      this.playNaatAudio();
      return;
    }

    if (this.settings.musicTrack === 'custom' && this.settings.customAudioUrl) {
      this.playCustomAudio();
      return;
    }

    // Otherwise synthesized track
    this.playSynthesizedTrack();
  }

  private playNaatAudio() {
    this.stopSynthesizedMusic();
    this.stopCustomAudio();

    if (!this.naatAudio) {
      this.naatAudio = new Audio();
      this.naatAudio.loop = true;
      this.naatAudio.preload = 'auto';
      // Primary local path /naat.mp3 with fallback
      this.naatAudio.src = '/naat.mp3';

      this.naatAudio.onerror = () => {
        // Fallback to uploaded asset path if needed
        if (this.naatAudio && this.naatAudio.src.endsWith('/naat.mp3')) {
          this.naatAudio.src = '/assets/aistudio/Meri_Baat_Ban_Gayi_Hai_-_Ghulam_Mustafa_Qadri_-_Naat_-_M_Media_Gold_5d7a70c5.mp3';
          this.naatAudio.play().catch(() => {
            // If asset path also fails, fallback gracefully to peaceful synthesized drone
            this.playSynthesizedTrack();
          });
        } else {
          this.playSynthesizedTrack();
        }
      };
    }

    const targetVolume = this.settings.musicEnabled ? this.settings.musicVolume * this.duckMultiplier : 0;
    this.naatAudio.volume = Math.max(0, Math.min(1, targetVolume));

    this.naatAudio.play().then(() => {
      this.isMusicPlaying = true;
    }).catch(() => {
      // Browser blocked autoplay before user gesture; unlock will catch next touch
      this.isMusicPlaying = false;
    });
  }

  private playSynthesizedTrack() {
    if (this.isMusicPlaying && this.ambientOscillators.length > 0) return;
    this.stopNaatAudio();
    this.stopCustomAudio();

    this.initAudioContext();
    if (!this.ctx) return;

    const isMeditation = this.settings.musicTrack === 'meditation_drone';
    const frequencies = isMeditation
      ? [110.00, 164.81, 220.00, 277.18, 329.63] // A2, E3, A3, C#4, E4
      : [146.83, 220.00, 293.66, 349.23, 440.00]; // D3, A3, D4, F4, A4 (Hijaz/Bayati modal drone)

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(isMeditation ? 600 : 800, this.ctx.currentTime);
    filter.Q.setValueAtTime(2.0, this.ctx.currentTime);

    if (this.musicGainNode) {
      filter.connect(this.musicGainNode);
    }

    this.ambientOscillators = [];
    this.ambientGains = [];

    frequencies.forEach((freq, idx) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
      osc.detune.setValueAtTime((idx - 2) * 4, this.ctx.currentTime);

      const baseGain = 0.08 / (idx + 1);
      gain.gain.setValueAtTime(baseGain, this.ctx.currentTime);

      osc.connect(gain);
      gain.connect(filter);
      osc.start();

      this.ambientOscillators.push(osc);
      this.ambientGains.push(gain);
    });

    this.lfoOsc = this.ctx.createOscillator();
    const lfoGain = this.ctx.createGain();
    this.lfoOsc.frequency.setValueAtTime(0.12, this.ctx.currentTime);
    lfoGain.gain.setValueAtTime(250, this.ctx.currentTime);
    this.lfoOsc.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    this.lfoOsc.start();

    this.isMusicPlaying = true;
  }

  public pauseMusic() {
    if (this.naatAudio) {
      this.naatAudio.pause();
    }
    if (this.customAudio) {
      this.customAudio.pause();
    }
    this.stopSynthesizedMusic();
    this.isMusicPlaying = false;
  }

  public resumeMusic() {
    this.startMusic();
  }

  private stopSynthesizedMusic() {
    if (this.ambientOscillators.length > 0) {
      this.ambientOscillators.forEach(osc => {
        try { osc.stop(); osc.disconnect(); } catch {}
      });
      this.ambientOscillators = [];
    }
    if (this.lfoOsc) {
      try { this.lfoOsc.stop(); this.lfoOsc.disconnect(); } catch {}
      this.lfoOsc = null;
    }
  }

  private stopNaatAudio() {
    if (this.naatAudio) {
      this.naatAudio.pause();
    }
  }

  public toggleMusic(): boolean {
    if (this.isMusicPlaying) {
      this.pauseMusic();
      this.saveSettings({ musicEnabled: false });
      return false;
    } else {
      this.saveSettings({ musicEnabled: true });
      this.startMusic();
      return true;
    }
  }

  private playCustomAudio() {
    if (!this.settings.customAudioUrl) return;
    this.stopNaatAudio();
    this.stopSynthesizedMusic();

    if (!this.customAudio) {
      this.customAudio = new Audio();
      this.customAudio.loop = true;
    }

    this.customAudio.src = this.settings.customAudioUrl;
    const targetVolume = this.settings.musicEnabled ? this.settings.musicVolume * this.duckMultiplier : 0;
    this.customAudio.volume = Math.max(0, Math.min(1, targetVolume));
    this.customAudio.play().then(() => {
      this.isMusicPlaying = true;
    }).catch(() => {
      this.isMusicPlaying = false;
    });
  }

  private stopCustomAudio() {
    if (this.customAudio) {
      this.customAudio.pause();
      this.customAudio.currentTime = 0;
    }
  }

  public setCustomAudio(url: string, name: string) {
    this.saveSettings({
      musicTrack: 'custom',
      customAudioUrl: url,
      customAudioName: name
    });
    if (this.settings.musicEnabled) {
      this.playCustomAudio();
    }
  }

  /* ---------------- SOUND EFFECTS (SFX) ---------------- */

  public playButtonClick() {
    if (!this.settings.sfxEnabled) return;
    this.initAudioContext();
    if (!this.ctx || !this.sfxGainNode) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(600, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + 0.05);

    gain.gain.setValueAtTime(0.18, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);

    osc.connect(gain);
    gain.connect(this.sfxGainNode);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.06);
  }

  public playCorrect() {
    if (!this.settings.sfxEnabled) return;
    this.initAudioContext();
    if (!this.ctx || !this.sfxGainNode) return;

    // Heavenly uplifting major chord chime: C5 (523Hz) -> E5 (659Hz) -> G5 (784Hz) -> C6 (1046Hz)
    const notes = [523.25, 659.25, 783.99, 1046.50];
    notes.forEach((freq, i) => {
      if (!this.ctx || !this.sfxGainNode) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime + i * 0.06);

      gain.gain.setValueAtTime(0, this.ctx.currentTime + i * 0.06);
      gain.gain.linearRampToValueAtTime(0.22, this.ctx.currentTime + i * 0.06 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + i * 0.06 + 0.45);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);

      osc.start(this.ctx.currentTime + i * 0.06);
      osc.stop(this.ctx.currentTime + i * 0.06 + 0.5);
    });
  }

  public playIncorrect() {
    if (!this.settings.sfxEnabled) return;
    this.initAudioContext();
    if (!this.ctx || !this.sfxGainNode) return;

    // Soft, compassionate low chime (non-harsh gentle reminder)
    const notes = [311.13, 293.66]; // Eb4 -> D4
    notes.forEach((freq, i) => {
      if (!this.ctx || !this.sfxGainNode) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime + i * 0.12);

      gain.gain.setValueAtTime(0, this.ctx.currentTime + i * 0.12);
      gain.gain.linearRampToValueAtTime(0.18, this.ctx.currentTime + i * 0.12 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + i * 0.12 + 0.35);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);

      osc.start(this.ctx.currentTime + i * 0.12);
      osc.stop(this.ctx.currentTime + i * 0.12 + 0.4);
    });
  }

  public playLevelUnlocked() {
    if (!this.settings.sfxEnabled) return;
    this.initAudioContext();
    if (!this.ctx || !this.sfxGainNode) return;

    // Grand golden arpeggio celebration: D4, F#4, A4, D5, F#5, A5
    const chord = [293.66, 369.99, 440.00, 587.33, 739.99, 880.00];
    chord.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGainNode) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime + idx * 0.08);

      gain.gain.setValueAtTime(0, this.ctx.currentTime + idx * 0.08);
      gain.gain.linearRampToValueAtTime(0.24, this.ctx.currentTime + idx * 0.08 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + idx * 0.08 + 0.8);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);

      osc.start(this.ctx.currentTime + idx * 0.08);
      osc.stop(this.ctx.currentTime + idx * 0.08 + 0.9);
    });
  }

  public playQuizCompleted() {
    this.playLevelUnlocked();
  }

  public playDailyReward() {
    if (!this.settings.sfxEnabled) return;
    this.initAudioContext();
    if (!this.ctx || !this.sfxGainNode) return;

    // Shimmering crystal bell sequence
    const bells = [659.25, 880.00, 1046.50, 1318.51, 1567.98];
    bells.forEach((freq, i) => {
      if (!this.ctx || !this.sfxGainNode) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime + i * 0.05);

      gain.gain.setValueAtTime(0.18, this.ctx.currentTime + i * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + i * 0.05 + 0.4);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);

      osc.start(this.ctx.currentTime + i * 0.05);
      osc.stop(this.ctx.currentTime + i * 0.05 + 0.45);
    });
  }
}

export const soundService = new SoundService();
