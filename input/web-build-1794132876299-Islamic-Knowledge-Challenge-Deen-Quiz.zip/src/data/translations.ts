import { Language } from '../types/quiz';

export interface TranslationDictionary {
  appName: string;
  appSubtitle: string;
  tagline: string;
  bismillah: string;
  playQuiz: string;
  dailyChallenge: string;
  categories: string;
  levels: string;
  leaderboard: string;
  howToPlay: string;
  settings: string;
  quickPlay: string;
  difficulty: string;
  easy: string;
  medium: string;
  hard: string;
  expert: string;
  question: string;
  of: string;
  score: string;
  highScore: string;
  timer: string;
  streak: string;
  streakBonus: string;
  nextQuestion: string;
  finishQuiz: string;
  correctFeedback: string;
  incorrectFeedback: string;
  timeUp: string;
  reference: string;
  explanation: string;
  lifelines: string;
  fiftyFifty: string;
  hint: string;
  extraTime: string;
  watchAdForHint: string;
  resultsTitle: string;
  alhamdulillah: string;
  mashallah: string;
  excellentPerformance: string;
  goodEffort: string;
  keepLearning: string;
  correctAnswers: string;
  wrongAnswers: string;
  accuracy: string;
  timeSpent: string;
  playAgain: string;
  nextLevel: string;
  home: string;
  reviewAnswers: string;
  yourAnswer: string;
  correctAnswer: string;
  levelUnlocked: string;
  levelTitle: string;
  starsEarned: string;
  dailyRewardClaimed: string;
  claimDailyReward: string;
  dailyStreak: string;
  days: string;
  todayChallengeCompleted: string;
  startDailyChallenge: string;
  audioSettings: string;
  backgroundNasheed: string;
  soundEffects: string;
  volume: string;
  soundTrack: string;
  peaceNasheed: string;
  spiritualDrone: string;
  customAudio: string;
  uploadCustomNaat: string;
  languageSelect: string;
  selectLanguage: string;
  theme: string;
  emeraldTheme: string;
  goldTheme: string;
  midnightTheme: string;
  resetProgress: string;
  resetConfirmTitle: string;
  resetConfirmMessage: string;
  confirmReset: string;
  cancel: string;
  back: string;
  close: string;
  share: string;
  stats: string;
  totalQuizzes: string;
  totalAnswered: string;
  rankTitle: string;
  studentOfKnowledge: string;
  seekerOfTruth: string;
  knowledgeableScholar: string;
  masterOfDeen: string;
  admobTestBanner: string;
  admobSimulation: string;
  adClosingIn: string;
  skipAd: string;
  rewardEarned: string;
  apkPackagingGuide: string;
  rulesDisclaimer: string;
  authenticReferenceNote: string;
}

export const translations: Record<Language, TranslationDictionary> = {
  en: {
    appName: "Islamic Knowledge Challenge",
    appSubtitle: "Deen Quiz",
    tagline: "Enrich your heart and mind with authentic Islamic knowledge",
    bismillah: "In the name of Allah, the Most Gracious, the Most Merciful",
    playQuiz: "Play Quiz",
    dailyChallenge: "Daily Challenge",
    categories: "Categories",
    levels: "20 Levels",
    leaderboard: "Stats & Rank",
    howToPlay: "How to Play",
    settings: "Settings",
    quickPlay: "Quick Play",
    difficulty: "Difficulty",
    easy: "Easy",
    medium: "Medium",
    hard: "Hard",
    expert: "Expert",
    question: "Question",
    of: "of",
    score: "Score",
    highScore: "High Score",
    timer: "Timer",
    streak: "Streak",
    streakBonus: "Streak Bonus!",
    nextQuestion: "Next Question",
    finishQuiz: "View Results",
    correctFeedback: "Masha'Allah! Correct!",
    incorrectFeedback: "Incorrect answer",
    timeUp: "Time is up!",
    reference: "Authentic Reference",
    explanation: "Learn More",
    lifelines: "Lifelines",
    fiftyFifty: "50:50",
    hint: "Context Hint",
    extraTime: "+15s Time",
    watchAdForHint: "Unlock Lifeline",
    resultsTitle: "Quiz Complete!",
    alhamdulillah: "Alhamdulillah!",
    mashallah: "Masha'Allah!",
    excellentPerformance: "Outstanding Islamic knowledge! May Allah increase your wisdom.",
    goodEffort: "Great effort! Continuous learning brings you closer to the Deen.",
    keepLearning: "Keep learning and seeking knowledge from authentic sources.",
    correctAnswers: "Correct Answers",
    wrongAnswers: "Incorrect Answers",
    accuracy: "Accuracy",
    timeSpent: "Time Taken",
    playAgain: "Try Again",
    nextLevel: "Next Level",
    home: "Home Menu",
    reviewAnswers: "Review All Questions",
    yourAnswer: "Your Choice",
    correctAnswer: "Correct Answer",
    levelUnlocked: "Level Unlocked!",
    levelTitle: "Level",
    starsEarned: "Stars Earned",
    dailyRewardClaimed: "Daily Streak Reward Claimed!",
    claimDailyReward: "Claim Daily Bonus",
    dailyStreak: "Daily Streak",
    days: "Days",
    todayChallengeCompleted: "Today's challenge completed! Come back tomorrow.",
    startDailyChallenge: "Start Today's Quiz (10 Qs)",
    audioSettings: "Audio & Nasheed",
    backgroundNasheed: "Peaceful Ambient Nasheed",
    soundEffects: "Sound Effects (SFX)",
    volume: "Volume",
    soundTrack: "Audio Style",
    peaceNasheed: "Peaceful Hijaz Nasheed",
    spiritualDrone: "Serene Spiritual Drone",
    customAudio: "Custom Audio / Naat URL",
    uploadCustomNaat: "Use Custom Licensed Naat File",
    languageSelect: "Language",
    selectLanguage: "Choose Language",
    theme: "Visual Theme",
    emeraldTheme: "Emerald Mosque",
    goldTheme: "Royal Amber Gold",
    midnightTheme: "Midnight Sapphire",
    resetProgress: "Reset All Progress",
    resetConfirmTitle: "Reset Game Data?",
    resetConfirmMessage: "Are you sure you want to reset your levels, high scores, and statistics? This action cannot be undone.",
    confirmReset: "Yes, Reset Everything",
    cancel: "Cancel",
    back: "Back",
    close: "Close",
    share: "Share Result",
    stats: "Islamic Mastery Statistics",
    totalQuizzes: "Quizzes Completed",
    totalAnswered: "Questions Answered",
    rankTitle: "Knowledge Rank",
    studentOfKnowledge: "Talib-e-Ilm (Student of Knowledge)",
    seekerOfTruth: "Salik (Seeker of Wisdom)",
    knowledgeableScholar: "Alim-ul-Qalb (Enlightened Heart)",
    masterOfDeen: "Faqih-e-Deen (Master of Knowledge)",
    admobTestBanner: "AdMob Test Banner (Mobile 320x50)",
    admobSimulation: "AdMob Interstitial Simulation",
    adClosingIn: "Reward unlocks in",
    skipAd: "Skip & Continue",
    rewardEarned: "Reward Activated!",
    apkPackagingGuide: "Android APK & AdMob Setup Guide",
    rulesDisclaimer: "All questions are curated from verified Quranic verses, Sahih Hadith, and authentic Islamic classical history.",
    authenticReferenceNote: "Verified Islamic Reference:"
  },
  ur: {
    appName: "اسلامک نالج چیلنج",
    appSubtitle: "دین کوئز",
    tagline: "مستند اسلامی معلومات کے ساتھ اپنے دل و دماغ کو منور کیجیے",
    bismillah: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
    playQuiz: "کوئز کھیلیں",
    dailyChallenge: "روزانہ چیلنج",
    categories: "اقسام و موضوعات",
    levels: "۲۰ درجات (لیولز)",
    leaderboard: "نتائج و رینک",
    howToPlay: "کھیلنے کا طریقہ",
    settings: "ترتیبات (سیٹنگز)",
    quickPlay: "فوری کوئز",
    difficulty: "مشکل کا درجہ",
    easy: "آسان",
    medium: "متوسط",
    hard: "مشکل",
    expert: "ماہرانہ",
    question: "سوال",
    of: "از",
    score: "اسکور",
    highScore: "بہترین اسکور",
    timer: "وقت",
    streak: "مسلسل درست",
    streakBonus: "مسلسل بونس!",
    nextQuestion: "اگلا سوال",
    finishQuiz: "نتائج دیکھیں",
    correctFeedback: "ما شاء اللہ! درست جواب!",
    incorrectFeedback: "غلط جواب",
    timeUp: "وقت ختم ہو گیا!",
    reference: "مستند حوالہ",
    explanation: "مزید معلومات",
    lifelines: "مددگار لائف لائنز",
    fiftyFifty: "۵۰:۵۰ (دو غلط جواب ختم)",
    hint: "قرآنی / حدیثی اشارہ",
    extraTime: "+۱۵ سیکنڈ",
    watchAdForHint: "لائف لائن حاصل کریں",
    resultsTitle: "کوئز مکمل ہوا!",
    alhamdulillah: "الحمد لله!",
    mashallah: "ما شاء اللہ!",
    excellentPerformance: "شاندار اسلامی معلومات! اللہ تعالی آپ کے علم و عمل میں برکت عطا فرمائے۔",
    goodEffort: "بہترین کوشش! علم دین کا حصول مسلسل جاری رکھیے۔",
    keepLearning: "مستند کتب و ذرائع سے علم دین حاصل کرتے رہیے۔",
    correctAnswers: "درست جوابات",
    wrongAnswers: "غلط جوابات",
    accuracy: "درستگی کا تناسب",
    timeSpent: "صرف شدہ وقت",
    playAgain: "دوبارہ کھیلیں",
    nextLevel: "اگلا درجہ (لیول)",
    home: "مرکزی صفحہ",
    reviewAnswers: "تمام سوالات کا جائزہ لیں",
    yourAnswer: "آپ کا جواب",
    correctAnswer: "صحیح جواب",
    levelUnlocked: "نیا لیول کھل گیا!",
    levelTitle: "درجہ نمبر",
    starsEarned: "حاصل کردہ ستارے",
    dailyRewardClaimed: "روزانہ انعام وصول کر لیا گیا!",
    claimDailyReward: "روزانہ بونس وصول کریں",
    dailyStreak: "مسلسل حاضری",
    days: "دن",
    todayChallengeCompleted: "آج کا چیلنج مکمل ہو گیا! کل دوبارہ تشریف لائیں۔",
    startDailyChallenge: "آج کا کوئز شروع کریں (۱۰ سوالات)",
    audioSettings: "آواز و نعت شریف",
    backgroundNasheed: "پرسکون پس منظر نشید",
    soundEffects: "آوازی اثرات (SFX)",
    volume: "آواز کا حجم",
    soundTrack: "آواز کا انداز",
    peaceNasheed: "پرسکون حجازی نشید",
    spiritualDrone: "روحانی پرسکون دھن",
    customAudio: "اپنی پسندیدہ نعت کا ربط",
    uploadCustomNaat: "لائسنس یافتہ نعت کی فائل لگائیں",
    languageSelect: "زبان کا انتخاب",
    selectLanguage: "زبان منتخب کیجیے",
    theme: "ظاہری انداز (تھیم)",
    emeraldTheme: "زمردی مسجد (سبز)",
    goldTheme: "شاہی عنبری سنہرا",
    midnightTheme: "نیلمی رات",
    resetProgress: "تمام ریکارڈ ختم کریں",
    resetConfirmTitle: "کیا آپ واقعی ریکارڈ مٹانا چاہتے ہیں؟",
    resetConfirmMessage: "کیا آپ تمام درجات، اسکورز اور اعداد و شمار کو دوبارہ صفر کرنا چاہتے ہیں؟ یہ عمل واپس نہیں ہو سکتا۔",
    confirmReset: "ہاں، سب کچھ ری سیٹ کریں",
    cancel: "منسوخ",
    back: "واپس",
    close: "بند کریں",
    share: "نتیجہ شیئر کریں",
    stats: "علمی پیش رفت کے اعداد و شمار",
    totalQuizzes: "مکمل کردہ کوئز",
    totalAnswered: "حل کردہ سوالات",
    rankTitle: "علمی منصب",
    studentOfKnowledge: "طالب علم",
    seekerOfTruth: "سالکِ راہِ حق",
    knowledgeableScholar: "عالمِ دین",
    masterOfDeen: "فقیہِ امت",
    admobTestBanner: "ایڈموب ٹیسٹ بینر (۳۲۰×۵۰)",
    admobSimulation: "ایڈموب اشتہار کی نمائش",
    adClosingIn: "انعام حاصل ہونے کا وقت:",
    skipAd: "چھوڑیں اور آگے بڑھیں",
    rewardEarned: "انعام فعال ہو گیا!",
    apkPackagingGuide: "اینڈرائیڈ اے پی کے اور ایڈموب رہنمائی",
    rulesDisclaimer: "تمام سوالات قرآن کریم، صحاح ستہ اور مستند اسلامی تاریخ سے ماخوذ و تصدیق شدہ ہیں۔",
    authenticReferenceNote: "مستند اسلامی حوالہ:"
  },
  roman: {
    appName: "Islamic Knowledge Challenge",
    appSubtitle: "Deen Quiz",
    tagline: "Mustanad Islami maloomaat se apna dil aur dimagh munawwar kijiye",
    bismillah: "Bismillahir Rahmanir Raheem",
    playQuiz: "Quiz Khelein",
    dailyChallenge: "Rozana Challenge",
    categories: "Categories",
    levels: "20 Levels",
    leaderboard: "Stats & Rank",
    howToPlay: "Khelne Ka Tareeqa",
    settings: "Settings",
    quickPlay: "Quick Quiz",
    difficulty: "Mushkil Ka Darja",
    easy: "Aasan",
    medium: "Darmiyana",
    hard: "Mushkil",
    expert: "Mahirana",
    question: "Sawaal",
    of: "ka",
    score: "Score",
    highScore: "Behtareen Score",
    timer: "Waqt",
    streak: "Streak",
    streakBonus: "Streak Bonus!",
    nextQuestion: "Agla Sawaal",
    finishQuiz: "Nateeja Dekhein",
    correctFeedback: "Masha'Allah! Sahi Jawab!",
    incorrectFeedback: "Ghalat Jawab",
    timeUp: "Waqt Khatam Ho Gaya!",
    reference: "Mustanad Hawala",
    explanation: "Mazeed Maloomaat",
    lifelines: "Lifelines",
    fiftyFifty: "50:50 (Do Ghalat Khatam)",
    hint: "Ishaara (Hint)",
    extraTime: "+15s Waqt",
    watchAdForHint: "Lifeline Hasil Karein",
    resultsTitle: "Quiz Mukammal Hua!",
    alhamdulillah: "Alhamdulillah!",
    mashallah: "Masha'Allah!",
    excellentPerformance: "Shandar Islami maloomaat! Allah Ta'ala aap ke ilm mein barkat ata farmaye.",
    goodEffort: "Behtareen koshish! Ilm-e-Deen ka husool musalsal jari rakhein.",
    keepLearning: "Mustanad kitabon se ilm-e-deen hasil karte rahein.",
    correctAnswers: "Durust Jawabaat",
    wrongAnswers: "Ghalat Jawabaat",
    accuracy: "Durusti Ka Tanasub",
    timeSpent: "Laga Hua Waqt",
    playAgain: "Dobara Khelein",
    nextLevel: "Agla Level",
    home: "Home Menu",
    reviewAnswers: "Tamam Sawalaat Ka Jaiza",
    yourAnswer: "Aap Ka Intekhab",
    correctAnswer: "Sahi Jawab",
    levelUnlocked: "Naya Level Khul Gaya!",
    levelTitle: "Level No.",
    starsEarned: "Hasil Shuda Sitare",
    dailyRewardClaimed: "Daily Streak Inaam Wasool Ho Gaya!",
    claimDailyReward: "Daily Bonus Wasool Karein",
    dailyStreak: "Rozana Streak",
    days: "Din",
    todayChallengeCompleted: "Aaj ka challenge mukammal ho gaya! Kal dobara aaiye.",
    startDailyChallenge: "Aaj Ka Quiz Shuru Karein (10 Sawaal)",
    audioSettings: "Awaaz & Naat Shareef",
    backgroundNasheed: "Pur-sukoon Background Nasheed",
    soundEffects: "Sound Effects (SFX)",
    volume: "Volume",
    soundTrack: "Audio Style",
    peaceNasheed: "Pur-sukoon Hijazi Nasheed",
    spiritualDrone: "Roohani Pur-sukoon Dhun",
    customAudio: "Apni Pasandida Naat Ka Link",
    uploadCustomNaat: "Licensed Naat File Lagayein",
    languageSelect: "Zuban Ka Intekhab",
    selectLanguage: "Zuban Chuniye",
    theme: "Theme",
    emeraldTheme: "Zamrudi Masjid (Green)",
    goldTheme: "Shahi Ambari Sonehra (Gold)",
    midnightTheme: "Neelam Raat (Blue)",
    resetProgress: "Tamam Record Reset Karein",
    resetConfirmTitle: "Kya aap record mitana chahte hain?",
    resetConfirmMessage: "Kya aap tamam levels aur scores ko dobara zero karna chahte hain? Yeh wapas nahi ho sakega.",
    confirmReset: "Haan, Sab Reset Karein",
    cancel: "Cancel",
    back: "Wapas",
    close: "Band Karein",
    share: "Nateeja Share Karein",
    stats: "Ilmi Taraqqi Ke Stats",
    totalQuizzes: "Mukammal Quizzes",
    totalAnswered: "Hal Shuda Sawalaat",
    rankTitle: "Ilmi Manasab",
    studentOfKnowledge: "Talib-e-Ilm",
    seekerOfTruth: "Salik-e-Haq",
    knowledgeableScholar: "Alim-e-Deen",
    masterOfDeen: "Faqeeh-e-Millat",
    admobTestBanner: "AdMob Test Banner (320x50)",
    admobSimulation: "AdMob Ad Simulation",
    adClosingIn: "Inaam khulne ka waqt:",
    skipAd: "Skip Karein",
    rewardEarned: "Inaam Mil Gaya!",
    apkPackagingGuide: "Android APK & AdMob Rahnumai",
    rulesDisclaimer: "Tamam sawalaat Quran-e-Kareem, Sahih Ahadees aur mustanad Islami tareekh se maakhuz hain.",
    authenticReferenceNote: "Mustanad Islami Hawala:"
  }
};
