import { Category } from '../types/quiz';

export const categories: Category[] = [
  {
    id: 1,
    name: {
      en: "Quran Knowledge",
      ur: "قرآن مجید کا علم",
      roman: "Quran Majeed Ka Ilm"
    },
    description: {
      en: "Surahs, Ayahs, revelations, virtues and divine wisdom",
      ur: "سورتیں، آیات، نزولِ وحی اور قرآنی فضائل و حکمت",
      roman: "Suratein, aayat, nuzool-e-wahi aur Qurani fazail"
    },
    iconName: "BookOpen",
    gradient: "from-emerald-700 to-teal-900",
    accentColor: "#10b981"
  },
  {
    id: 2,
    name: {
      en: "Hadith Knowledge",
      ur: "حدیث شریف کا علم",
      roman: "Hadith Shareef Ka Ilm"
    },
    description: {
      en: "Sayings of the Prophet ﷺ, Sihah Sitta, and Sunnah teachings",
      ur: "فرمانِ مصطفی ﷺ، صحاح ستہ اور سنن و مستند احادیث",
      roman: "Farman-e-Mustafa ﷺ, Sihah Sitta aur Sunnat taleemat"
    },
    iconName: "ScrollText",
    gradient: "from-amber-700 to-amber-950",
    accentColor: "#f59e0b"
  },
  {
    id: 3,
    name: {
      en: "Seerat-un-Nabi ﷺ",
      ur: "سیرت النبی ﷺ",
      roman: "Seerat-un-Nabi ﷺ"
    },
    description: {
      en: "Blessed life of the Prophet Muhammad ﷺ, events, and character",
      ur: "رسول اللہ ﷺ کی مبارک حیاتِ طیبہ، غزوات اور اخلاقِ حسنہ",
      roman: "Rasool Allah ﷺ ki pak zindagi, ghazwat aur akhlaaq"
    },
    iconName: "HeartHandshake",
    gradient: "from-teal-800 to-emerald-950",
    accentColor: "#14b8a6"
  },
  {
    id: 4,
    name: {
      en: "Islamic History",
      ur: "اسلامی تاریخ",
      roman: "Islami Tareekh"
    },
    description: {
      en: "Khulafa-e-Rashideen, major battles, golden era, and civilisations",
      ur: "خلفائے راشدین، اہم معرکے، فتوحات اور اسلامی سنہری دور",
      roman: "Khulafa-e-Rashideen, ahem marake aur sunheri daur"
    },
    iconName: "Landmark",
    gradient: "from-stone-800 to-emerald-950",
    accentColor: "#a8a29e"
  },
  {
    id: 5,
    name: {
      en: "Prophets in Islam",
      ur: "انبیائے کرام علیہم السلام",
      roman: "Ambiya-e-Kiram (A.S)"
    },
    description: {
      en: "Stories, miracles, and missions of Allah's chosen Messengers",
      ur: "اللہ کے برگزیدہ رسولوں اور پیغمبروں کے واقعات و معجزات",
      roman: "Allah ke pyare paighambaron ke waqiaat aur mojazaat"
    },
    iconName: "Flame",
    gradient: "from-amber-800 to-emerald-950",
    accentColor: "#f59e0b"
  },
  {
    id: 6,
    name: {
      en: "Islamic General Knowledge",
      ur: "اسلامی معلوماتِ عامہ",
      roman: "Islami Maloomaat-e-Aama"
    },
    description: {
      en: "Mosques, holy cities, landmarks, Islamic heritage, and terms",
      ur: "مقدس مساجد، متبرک مقامات، اسلامی اصطلاحات اور شعائر",
      roman: "Muqaddas masajid, mutabarrak maqamaat aur istilahat"
    },
    iconName: "Globe2",
    gradient: "from-emerald-800 to-cyan-950",
    accentColor: "#06b6d4"
  },
  {
    id: 7,
    name: {
      en: "Sahaba-e-Kiram",
      ur: "صحابہ کرام رضی اللہ عنہم",
      roman: "Sahaba-e-Kiram (R.A)"
    },
    description: {
      en: "Companions of the Prophet ﷺ, virtues, sacrifices, and titles",
      ur: "جانثار اصحابِ رسول ﷺ کی سیرت، القابات اور قربانیاں",
      roman: "Jannisaar ashaab-e-Rasool ﷺ ki seerat aur qurbaniyan"
    },
    iconName: "Users",
    gradient: "from-emerald-900 to-green-950",
    accentColor: "#22c55e"
  },
  {
    id: 8,
    name: {
      en: "Five Pillars of Islam",
      ur: "ارکانِ اسلام",
      roman: "Arkaan-e-Islam"
    },
    description: {
      en: "Shahada, Salah, Zakat, Sawm (Fasting), and Hajj guidelines",
      ur: "کلمہ طیبہ، نماز، زکوٰۃ، روزہ اور حج کے احکام و فضائل",
      roman: "Kalima, Namaz, Zakat, Roza aur Hajj ke ahkaam"
    },
    iconName: "ShieldCheck",
    gradient: "from-yellow-700 to-emerald-950",
    accentColor: "#eab308"
  },
  {
    id: 9,
    name: {
      en: "Islamic Months",
      ur: "اسلامی مہینے اور ایام",
      roman: "Islami Maheene Aur Ayyam"
    },
    description: {
      en: "Hijri calendar, sacred months, Eid days, and blessed dates",
      ur: "قمری سال، حرمت والے مہینے، ایامِ عید اور مبارک راتیں",
      roman: "Qamri saal, hurmat wale maheene, Eid aur ahem tareekhein"
    },
    iconName: "MoonStar",
    gradient: "from-cyan-900 to-emerald-950",
    accentColor: "#38bdf8"
  },
  {
    id: 10,
    name: {
      en: "Basic Islamic Education",
      ur: "بنیادی اسلامی تعلیمات",
      roman: "Bunyaadi Islami Taleemaat"
    },
    description: {
      en: "Iman, Wudu, Taharah, basic Duas, Islamic etiquettes, and morals",
      ur: "ایمانیات، وضو، طہارت، روزمرہ مسنون دعائیں اور اسلامی آداب",
      roman: "Imaaniyat, wudu, pakizgi, masnoon duaaein aur aadaab"
    },
    iconName: "Compass",
    gradient: "from-teal-900 to-emerald-950",
    accentColor: "#2dd4bf"
  }
];
