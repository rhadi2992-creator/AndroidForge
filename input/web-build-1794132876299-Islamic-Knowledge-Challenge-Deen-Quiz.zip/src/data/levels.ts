import { LevelConfig, Question } from '../types/quiz';
import { allQuestions, shuffleQuestionOptions } from './questions';

export const levels: LevelConfig[] = [
  // Level 1: Beginner
  {
    level: 1,
    title: {
      en: "First Steps in Deen",
      ur: "دین کی پہلی کرن",
      roman: "Deen Ki Pehli Kiran"
    },
    tier: 'beginner',
    difficulty: 'easy',
    requiredStarsToUnlock: 0,
    targetScoreToPass: 7,
    questionIds: [101, 102, 201, 301, 501, 601, 701, 801, 901, 1001]
  },
  // Levels 2–5: Basic Islamic Knowledge
  {
    level: 2,
    title: {
      en: "Pillars of Faith & Prayers",
      ur: "ارکانِ ایمان اور نماز",
      roman: "Arkaan-e-Iman Aur Namaz"
    },
    tier: 'basic',
    difficulty: 'easy',
    requiredStarsToUnlock: 1,
    targetScoreToPass: 7,
    questionIds: [802, 803, 818, 821, 1002, 1003, 1004, 1011, 603, 615]
  },
  {
    level: 3,
    title: {
      en: "Quranic Foundations",
      ur: "قرآنی بنیادیں اور سورتیں",
      roman: "Qurani Bunyadein Aur Surahs"
    },
    tier: 'basic',
    difficulty: 'easy',
    requiredStarsToUnlock: 2,
    targetScoreToPass: 7,
    questionIds: [103, 104, 116, 117, 121, 203, 212, 217, 302, 502]
  },
  {
    level: 4,
    title: {
      en: "Prophetic Radiance & Makkah",
      ur: "مکہ مکرمہ اور اخلاقِ مصطفی ﷺ",
      roman: "Makkah Aur Akhlaaq-e-Mustafa ﷺ"
    },
    tier: 'basic',
    difficulty: 'easy',
    requiredStarsToUnlock: 4,
    targetScoreToPass: 7,
    questionIds: [303, 304, 315, 321, 401, 503, 602, 702, 703, 903]
  },
  {
    level: 5,
    title: {
      en: "The Early Believers",
      ur: "اوائل اسلام کے روشن ستارے",
      roman: "Awail-e-Islam Ke Roshan Sitare"
    },
    tier: 'basic',
    difficulty: 'easy',
    requiredStarsToUnlock: 6,
    targetScoreToPass: 7,
    questionIds: [305, 704, 706, 712, 717, 806, 904, 1015, 1021, 1022]
  },
  // Levels 6–10: Intermediate
  {
    level: 6,
    title: {
      en: "Echoes of Cave Hira & Wahi",
      ur: "نزولِ وحی اور غارِ حرا",
      roman: "Nuzool-e-Wahi Aur Ghaar-e-Hira"
    },
    tier: 'intermediate',
    difficulty: 'medium',
    requiredStarsToUnlock: 8,
    targetScoreToPass: 7,
    questionIds: [105, 106, 107, 108, 118, 306, 316, 204, 205, 206]
  },
  {
    level: 7,
    title: {
      en: "Night of Ascension (Mi'raj)",
      ur: "شبِ معراج اور فرضیتِ صلاۃ",
      roman: "Shab-e-Miraj Aur Farziyat-e-Salah"
    },
    tier: 'intermediate',
    difficulty: 'medium',
    requiredStarsToUnlock: 10,
    targetScoreToPass: 7,
    questionIds: [307, 308, 604, 605, 606, 804, 805, 905, 908, 1005]
  },
  {
    level: 8,
    title: {
      en: "Hijrah & Islamic State",
      ur: "ہجرتِ مدینہ اور میثاقِ مدینہ",
      roman: "Hijrat-e-Madinah Aur Meesaq"
    },
    tier: 'intermediate',
    difficulty: 'medium',
    requiredStarsToUnlock: 12,
    targetScoreToPass: 7,
    questionIds: [309, 311, 402, 404, 504, 505, 506, 705, 707, 718]
  },
  {
    level: 9,
    title: {
      en: "Badr & Islamic Valor",
      ur: "غزوہ بدر اور معرکہ حق و باطل",
      roman: "Ghazwa Badr Aur Maraka-e-Haq"
    },
    tier: 'intermediate',
    difficulty: 'medium',
    requiredStarsToUnlock: 15,
    targetScoreToPass: 7,
    questionIds: [310, 314, 405, 406, 412, 413, 713, 807, 812, 813]
  },
  {
    level: 10,
    title: {
      en: "Islamic Etiquettes & Purity",
      ur: "طہارت، آداب اور سننِ نبوی",
      roman: "Taharat, Aadaab Aur Sunan"
    },
    tier: 'intermediate',
    difficulty: 'medium',
    requiredStarsToUnlock: 18,
    targetScoreToPass: 7,
    questionIds: [213, 214, 219, 222, 611, 612, 616, 906, 907, 1006]
  },
  // Levels 11–15: Advanced
  {
    level: 11,
    title: {
      en: "Surah Yasin & Quranic Secrets",
      ur: "قلب القرآن اور اعجازِ قرآن",
      roman: "Qalb al-Quran Aur Aijaz"
    },
    tier: 'advanced',
    difficulty: 'hard',
    requiredStarsToUnlock: 21,
    targetScoreToPass: 7,
    questionIds: [109, 110, 111, 112, 119, 207, 208, 209, 215, 218]
  },
  {
    level: 12,
    title: {
      en: "Stories of the Righteous Prophets",
      ur: "صبرِ ایوب اور احسن القصص",
      roman: "Sabr-e-Ayyub Aur Ahsan al-Qasas"
    },
    tier: 'advanced',
    difficulty: 'hard',
    requiredStarsToUnlock: 24,
    targetScoreToPass: 7,
    questionIds: [507, 508, 509, 513, 514, 516, 518, 519, 317, 318]
  },
  {
    level: 13,
    title: {
      en: "Sacred Sanctuaries & History",
      ur: "مقدس مقامات اور اسلامی سنہری دور",
      roman: "Muqaddas Maqamaat Aur Golden Era"
    },
    tier: 'advanced',
    difficulty: 'hard',
    requiredStarsToUnlock: 27,
    targetScoreToPass: 7,
    questionIds: [407, 408, 414, 415, 418, 419, 607, 608, 613, 617]
  },
  {
    level: 14,
    title: {
      en: "Champions of Truth & Sahaba",
      ur: "جانثارانِ رسول اور ان کے مناقب",
      roman: "Jannisaaran-e-Rasool Ke Manaqib"
    },
    tier: 'advanced',
    difficulty: 'hard',
    requiredStarsToUnlock: 30,
    targetScoreToPass: 7,
    questionIds: [708, 709, 714, 715, 719, 721, 808, 809, 814, 815]
  },
  {
    level: 15,
    title: {
      en: "Sacred Months & Spiritual Highs",
      ur: "مقدس مہینے اور روحانی درجات",
      roman: "Muqaddas Maheene Aur Roohaniyat"
    },
    tier: 'advanced',
    difficulty: 'hard',
    requiredStarsToUnlock: 33,
    targetScoreToPass: 7,
    questionIds: [909, 914, 916, 918, 920, 1007, 1008, 1009, 1012, 1017]
  },
  // Levels 16–20: Expert
  {
    level: 16,
    title: {
      en: "Sciences of Quran & Recitation",
      ur: "علوم القرآن اور ناسخ و منسوخ",
      roman: "Uloom al-Quran Aur Rasm"
    },
    tier: 'expert',
    difficulty: 'expert',
    requiredStarsToUnlock: 36,
    targetScoreToPass: 7,
    questionIds: [113, 114, 115, 120, 122, 403, 722, 614, 618, 811]
  },
  {
    level: 17,
    title: {
      en: "Principles of Hadith & Sanad",
      ur: "اصولِ حدیث، جرح و تعدیل اور اسناد",
      roman: "Usool-e-Hadith Aur Isnad"
    },
    tier: 'expert',
    difficulty: 'expert',
    requiredStarsToUnlock: 40,
    targetScoreToPass: 7,
    questionIds: [202, 210, 211, 216, 220, 312, 313, 319, 320, 322]
  },
  {
    level: 18,
    title: {
      en: "Prophetic Lineage & Ancient Civilizations",
      ur: "اولوالعزم رسول اور قوم عاد و ثمود",
      roman: "Ulul-Azm Rasool Aur Aad wa Samood"
    },
    tier: 'expert',
    difficulty: 'expert',
    requiredStarsToUnlock: 44,
    targetScoreToPass: 7,
    questionIds: [510, 511, 512, 515, 517, 520, 521, 522, 710, 711]
  },
  {
    level: 19,
    title: {
      en: "Pioneering Muslim Scholars & Thinkers",
      ur: "عظیم مسلم مفکرین اور سائنسی فتوحات",
      roman: "Muslim Mufakkireen Aur Science"
    },
    tier: 'expert',
    difficulty: 'expert',
    requiredStarsToUnlock: 48,
    targetScoreToPass: 7,
    questionIds: [409, 410, 416, 420, 421, 609, 610, 621, 716, 720]
  },
  {
    level: 20,
    title: {
      en: "Mastery of Deen & Comprehensive Fiqh",
      ur: "فقیہِ امت اور حتمی امتحان",
      roman: "Faqeeh-e-Ummat Aur Hatmi Imtehaan"
    },
    tier: 'expert',
    difficulty: 'expert',
    requiredStarsToUnlock: 52,
    targetScoreToPass: 8,
    questionIds: [810, 816, 819, 820, 822, 910, 911, 917, 921, 1014]
  }
];

export function getLevelConfig(levelNumber: number): LevelConfig | undefined {
  return levels.find(l => l.level === levelNumber);
}

export function getQuestionsForLevel(levelNumber: number): Question[] {
  const cfg = getLevelConfig(levelNumber);
  if (!cfg) return [];
  const qMap = new Map(allQuestions.map(q => [q.id, q]));
  const questions = cfg.questionIds.map(id => qMap.get(id)).filter((q): q is Question => Boolean(q));
  return questions.map(shuffleQuestionOptions);
}
