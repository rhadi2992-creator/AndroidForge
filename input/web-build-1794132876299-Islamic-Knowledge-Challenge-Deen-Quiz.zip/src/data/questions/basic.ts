import { Question } from '../../types/quiz';

export const basicQuestions: Question[] = [
  {
    id: 1001,
    categoryId: 10,
    difficulty: 'easy',
    question: {
      en: "How many essential articles of faith (Iman) are outlined in Hadith Jibreel and the Quran?",
      ur: "حدیث جبرائیل اور قرآنی تعلیمات کے مطابق بنیادی ایمانیات (ایمان کے ارکان) کل کتنے ہیں؟",
      roman: "Hadith Jibreel ke mutabiq bunyadi Imanaat (articles of faith) kitne hain?"
    },
    options: {
      en: ["6 Articles", "5 Articles", "7 Articles", "4 Articles"],
      ur: ["۶ ایمانیات (ارکانِ ایمان)", "۵ ارکان", "۷ ارکان", "۴ ارکان"],
      roman: ["6 Arkaan-e-Iman", "5", "7", "4"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Hadith 1) & Surah Al-Baqarah (2:285)",
      ur: "صحیح مسلم، کتاب الایمان، حدیث ۱ اور سورۃ البقرہ، آیت ۲۸۵",
      roman: "Sahih Muslim 1, Surah Al-Baqarah 285"
    },
    explanation: {
      en: "The six articles are belief in: Allah, His Angels, His Revealed Books, His Messengers, the Last Day, and the Divine Decree (Qadar).",
      ur: "ایمان کے چھ ارکان ہیں: اللہ پر، اس کے فرشتوں پر، آسمانی کتابوں پر، رسولوں پر، آخرت کے دن پر اور تقدیرِ الٰہی پر ایمان۔",
      roman: "6 arkaan: Allah, Farishte, Kitabein, Rasool, Qayamat aur Taqdeer par iman."
    }
  },
  {
    id: 1002,
    categoryId: 10,
    difficulty: 'easy',
    question: {
      en: "With which hand are Muslims instructed by the Sunnah to eat and drink?",
      ur: "سنتِ نبوی ﷺ کے مطابق کھانا کھانے اور پانی پینے کے لیے کون سا ہاتھ استعمال کرنے کی تاکید ہے؟",
      roman: "Sunnah ke mutabiq khana khane aur peene ke liye konsa haath istemal karna chahiye?"
    },
    options: {
      en: ["The Right Hand", "The Left Hand", "Either hand equally", "Both hands together"],
      ur: ["دایاں ہاتھ (سیدھا ہاتھ)", "بایاں ہاتھ", "کوئی بھی ہاتھ", "دونوں ہاتھ ایک ساتھ"],
      roman: ["Daayan Haath (Seedha haath)", "Bayan haath", "Dono barabar", "Dono haath ek sath"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 36, Hadith 5008)",
      ur: "صحیح مسلم، کتاب الاشربۃ، حدیث ۵۰۰۸: 'كل بيمينك ومما يليك'",
      roman: "Sahih Muslim 5008"
    },
    explanation: {
      en: "The Prophet ﷺ taught Umar ibn Abi Salamah: 'Mention the name of Allah, eat with your right hand, and eat from what is in front of you.'",
      ur: "رسول اللہ ﷺ نے فرمایا: بسم اللہ پڑھو، دائیں ہاتھ سے کھاؤ اور اپنے آگے سے کھاؤ۔",
      roman: "Huzoor ﷺ ne daayein haath se khane aur peene ka hukum diya."
    }
  },
  {
    id: 1003,
    categoryId: 10,
    difficulty: 'easy',
    question: {
      en: "What should a Muslim say before starting any good action such as eating, drinking, or studying?",
      ur: "کھانے، پینے یا کسی بھی نیک کام کے آغاز پر کیا پڑھنا مسنون ہے؟",
      roman: "Khana khane ya koi bhi nek kaam shuru karne se pehle kya parhna chahiye?"
    },
    options: {
      en: ["Bismillahir Rahmanir Raheem", "Alhamdulillah", "Astaghfirullah", "Subhanallah"],
      ur: ["بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", "الْحَمْدُ لِلَّهِ", "أَسْتَغْفِرُ اللَّهَ", "سُبْحَانَ اللَّهِ"],
      roman: ["Bismillahir Rahmanir Raheem", "Alhamdulillah", "Astaghfirullah", "Subhanallah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 70, Hadith 5376)",
      ur: "صحیح بخاری، کتاب الاطعمۃ، حدیث ۵۳۷۶",
      roman: "Sahih Bukhari, Hadith 5376"
    },
    explanation: {
      en: "Saying Bismillah invites Allah's divine blessing (Barakah) and prevents Satan from sharing in one's food or work.",
      ur: "بسم اللہ پڑھ کر کام شروع کرنے سے اس میں برکت اور شیطان کے اثرات سے حفاظت رہتی ہے۔",
      roman: "Bismillah parhne se kaam mein barkat aati hai."
    }
  },
  {
    id: 1004,
    categoryId: 10,
    difficulty: 'easy',
    question: {
      en: "What should a Muslim say upon finishing a meal or when experiencing a blessing?",
      ur: "کھانے سے فارغ ہو کر یا کوئی بھی نعمت ملنے پر شکرانے کے طور پر کیا کہنا مسنون ہے؟",
      roman: "Khana khatam karne ya koi nemat milne par kya kehna chahiye?"
    },
    options: {
      en: ["Alhamdulillah (All praise is for Allah)", "Bismillah", "La hawla wala quwwata illa billah", "Allahu Akbar"],
      ur: ["الْحَمْدُ لِلَّهِ (تمام تعریفیں اللہ کے لیے ہیں)", "بِسْمِ اللَّهِ", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "اللَّهُ أَكْبَرُ"],
      roman: ["Alhamdulillah (Tamam tareefein Allah ke liye hain)", "Bismillah", "La hawla wala quwwata", "Allahu Akbar"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 48, Hadith 6932)",
      ur: "صحیح مسلم، کتاب الذکر والدعاء، حدیث ۶۹۳۲",
      roman: "Sahih Muslim 6932"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Allah is pleased with a servant who eats a meal and praises Him for it, or drinks a drink and praises Him for it.'",
      ur: "حضور ﷺ نے فرمایا: اللہ اس بندے سے راضی ہوتا ہے جو لقمہ کھا کر یا گھونٹ پی کر اللہ کی حمد بجا لائے۔",
      roman: "Alhamdulillah keh kar Allah ka shukr ada karna chahiye."
    }
  },
  {
    id: 1005,
    categoryId: 10,
    difficulty: 'medium',
    question: {
      en: "What is dry ablution using clean earth or stone when water is unavailable or cannot be used due to illness called?",
      ur: "پانی نہ ملنے یا بیماری کی صورت میں پاک مٹی سے وضو کا نعم البدل طہارت کا طریقہ کیا کہلاتا ہے؟",
      roman: "Pani na milne par paak mitti se jo wudu kiya jata hai use kya kehte hain?"
    },
    options: {
      en: ["Tayammum", "Istinja", "Masah", "Ghusl"],
      ur: ["تیمم", "استنجاء", "مسح", "غسل"],
      roman: ["Tayammum", "Istinja", "Masah", "Ghusl"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah An-Nisa (4:43) & Surah Al-Ma'idah (5:6)",
      ur: "سورۃ النساء آیت ۴۳ اور سورۃ المائدہ آیت ۶: 'فَتَيَمَّمُوا صَعِيدًا طَيِّبًا'",
      roman: "Surah An-Nisa 43, Surah Al-Ma'idah 6"
    },
    explanation: {
      en: "Tayammum involves intending purification, striking clean earth, wiping the face, and wiping the forearms up to the elbows.",
      ur: "تیمم میں پاک مٹی پر ہاتھ مار کر چہرے اور کہنیوں تک دونوں بازوؤں کا مسح کیا جاتا ہے۔",
      roman: "Tayammum paak mitti se chehre aur hathon ka masah karne ko kehte hain."
    }
  },
  {
    id: 1006,
    categoryId: 10,
    difficulty: 'medium',
    question: {
      en: "How many Farz (obligatory obligatory acts) are there in standard Wudu (Ablution)?",
      ur: "فقہ اسلامی کے مطابق وضو میں کل کتنے فرائض ہیں جن کے بغیر وضو نہیں ہوتا؟",
      roman: "Wudu ke kul kitne farz hain jinke baghair wudu nahi hota?"
    },
    options: {
      en: ["4 Fard Acts", "3 Fard Acts", "6 Fard Acts", "5 Fard Acts"],
      ur: ["۴ فرائض", "۳ فرائض", "۶ فرائض", "۵ فرائض"],
      roman: ["4 Farz", "3 Farz", "6 Farz", "5 Farz"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Ma'idah (5:6)",
      ur: "سورۃ المائدہ، آیت ۶ (فرائضِ وضو کا قرآنی نص)",
      roman: "Surah Al-Ma'idah, Ayah 6"
    },
    explanation: {
      en: "The four Fard of Wudu are: washing the whole face once, washing both arms up to elbows, wiping a quarter of head (Masah), and washing both feet to ankles.",
      ur: "وضو کے چار فرائض ہیں: چہرہ دھونا، کہنیوں سمیت دونوں ہاتھ دھونا، چوتھائی سر کا مسح کرنا اور ٹخنوں سمیت پاؤں دھونا۔",
      roman: "Wudu ke 4 farz hain: Chehra, baazu, sar ka masah aur paon dhona."
    }
  },
  {
    id: 1007,
    categoryId: 10,
    difficulty: 'medium',
    question: {
      en: "How many Farz (obligatory acts) are there in Ghusl (Full Ritual Bath)?",
      ur: "غسل کے بنیادی فرائض کتنے ہیں جن کی ادائیگی کے بغیر انسان پاک نہیں ہو سکتا؟",
      roman: "Ghusl ke kitne farz hain jinke baghair ghusl nahi hota?"
    },
    options: {
      en: ["3 Fard Acts", "2 Fard Acts", "4 Fard Acts", "5 Fard Acts"],
      ur: ["۳ فرائض (کلی کرنا، ناک میں پانی ڈالنا، پورے جسم پر پانی بہانا)", "۲ فرائض", "۴ فرائض", "۵ فرائض"],
      roman: ["3 Farz (Kulli, naak mein pani, poore jism par pani)", "2", "4", "5"]
    },
    correctAnswer: 0,
    reference: {
      en: "Classical Fiqh of Taharah",
      ur: "فقہ حنفی و کتبِ طہارت، فرائضِ غسل ثلاثۃ",
      roman: "Classical Fiqh of Taharah"
    },
    explanation: {
      en: "The three Fard of Ghusl are: gargling thoroughly (Madmadah), rinsing the nose (Istinshaq), and pouring water over the entire body leaving no dry spot.",
      ur: "غسل کے تین فرائض ہیں: اچھی طرح کلی کرنا، ناک کی نرم ہڈی تک پانی پہنچانا اور پورے بدن پر اس طرح پانی بہانا کہ بال برابر جگہ خشک نہ رہے۔",
      roman: "Ghusl ke 3 farz hain: Kulli karna, naak mein pani dalna aur poore badan par pani bahana."
    }
  },
  {
    id: 1008,
    categoryId: 10,
    difficulty: 'hard',
    question: {
      en: "What is the archangel responsible for blowing the Trumpet (Sur) to announce the Day of Resurrection called?",
      ur: "قیامت کے دن اللہ تعالیٰ کے حکم سے صور پھونکنے پر کون سے مقرب فرشتے مامور ہیں؟",
      roman: "Qayamat ke din Soor phoonkne wale muqarrab farishte ka naam kya hai?"
    },
    options: {
      en: ["Hazrat Israfil (AS)", "Hazrat Mika'il (AS)", "Hazrat Jibreel (AS)", "Hazrat Izra'il (AS)"],
      ur: ["حضرت اسرافیل علیہ السلام", "حضرت میکائیل علیہ السلام", "حضرت جبرائیل علیہ السلام", "حضرت عزرائیل علیہ السلام"],
      roman: ["Hazrat Israfil (A.S)", "Hazrat Mika'il (A.S)", "Hazrat Jibreel (A.S)", "Hazrat Izra'il (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Az-Zumar (39:68) & Jami at-Tirmidhi",
      ur: "سورۃ الزمر آیت ۶۸ اور جامع ترمذی، حدیث ۳۲۴۱",
      roman: "Surah Az-Zumar 68"
    },
    explanation: {
      en: "Hazrat Israfil (AS) holds the Trumpet ready, awaiting the divine command to sound the blast of destruction and the blast of resurrection.",
      ur: "حضرت اسرافیل علیہ السلام صور ہاتھ میں لیے حکم الٰہی کے منتظر ہیں، ان کے صور پھونکنے سے تمام مخلوق فنا اور پھر دوبارہ زندہ ہو گی۔",
      roman: "Hazrat Israfil (A.S) Qayamat ke din Soor phoonkein ge."
    }
  },
  {
    id: 1009,
    categoryId: 10,
    difficulty: 'hard',
    question: {
      en: "What are the two angels who question every deceased person in the grave about their Lord, religion, and Prophet called?",
      ur: "قبر میں ہر انسان سے اس کے رب، دین اور نبی کے متعلق سوالات کرنے والے دو فرشتوں کو کیا کہا جاتا ہے؟",
      roman: "Qabr mein sawalat poochhne wale do farishton ka kya naam hai?"
    },
    options: {
      en: ["Munkar and Nakeer", "Kiraman Katibeen", "Harut and Marut", "Malik and Ridwan"],
      ur: ["منکر اور نکیر", "کراماً کاتبین", "ہاروت اور ماروت", "مالک اور رضوان"],
      roman: ["Munkar aur Nakeer", "Kiraman Katibeen", "Harut wa Marut", "Malik wa Ridwan"]
    },
    correctAnswer: 0,
    reference: {
      en: "Jami at-Tirmidhi (Hadith 1071) & Sahih Bukhari",
      ur: "جامع ترمذی، کتاب الجنائز، سوال القبر، حدیث ۱۰۷۱",
      roman: "Jami at-Tirmidhi 1071"
    },
    explanation: {
      en: "Munkar and Nakeer ask three fundamental questions: Who is your Lord? What is your religion? Who was this man sent among you?",
      ur: "منکر اور نکیر قبر کے تین سوال پوچھتے ہیں: من ربک؟ ما دینک؟ اور من ھذا الرجل؟",
      roman: "Munkar aur Nakeer qabr mein 3 sawalat poochhte hain."
    }
  },
  {
    id: 1010,
    categoryId: 10,
    difficulty: 'expert',
    question: {
      en: "What are the honorable recording angels assigned on the right and left shoulders of every person called in the Quran?",
      ur: "ہر انسان کے دائیں اور بائیں کندھے پر نیکیاں اور برائیاں لکھنے والے معزز فرشتوں کو قرآن میں کیا کہا گیا ہے؟",
      roman: "Nekiyan aur buraiyan likhne wale farishton ko Quran mein kya farmaya gaya hai?"
    },
    options: {
      en: ["Kiraman Katibeen (The Noble Writers)", "Munkar and Nakeer", "Al-Mu'aqqibat", "Zabaniyah"],
      ur: ["کِرَامًا كَاتِبِينَ (معزز لکھنے والے)", "منکر اور نکیر", "المعقبات", "زبانیہ"],
      roman: ["Kiraman Katibeen", "Munkar wa Nakeer", "Mu'aqqibat", "Zabaniyah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Infitar (82:10-12) & Surah Qaf (50:17-18)",
      ur: "سورۃ الانفطار، آیات ۱۰ تا ۱۲: 'وَإِنَّ عَلَيْكُمْ لَحَافِظِينَ كِرَامًا كَاتِبِينَ'",
      roman: "Surah Al-Infitar 10-12"
    },
    explanation: {
      en: "The angel on the right records good deeds immediately, while the angel on the left waits patiently for repentance before recording sins.",
      ur: "دائیں طرف کا فرشتہ نیکیاں اور بائیں طرف کا فرشتہ برائیاں تحریر کرتا ہے، جنہیں کراماً کاتبین کہا گیا ہے۔",
      roman: "Kiraman Katibeen aamal likhne wale farishte hain."
    }
  },
  {
    id: 1011,
    categoryId: 10,
    difficulty: 'easy',
    question: {
      en: "What is the Sunnah manner of drinking water taught by the Prophet Muhammad ﷺ?",
      ur: "پانی پینے کے مسنون آداب کے متعلق رسول اللہ ﷺ کی کیا سنت ہے؟",
      roman: "Pani peene ke Sunnah aadaab kya hain?"
    },
    options: {
      en: [
        "Sitting down, saying Bismillah, and drinking in three pauses/sips",
        "Standing up and gulping in one breath",
        "Drinking with the left hand while walking",
        "Drinking without looking"
      ],
      ur: [
        "بیٹھ کر، دائیں ہاتھ سے بسم اللہ پڑھ کر اور تین سانسوں میں پینا",
        "کھڑے ہو کر ایک ہی سانس میں پینا",
        "چلتے ہوئے بائیں ہاتھ سے پینا",
        "بغیر دیکھے پینا"
      ],
      roman: [
        "Baith kar, Bismillah parh kar aur 3 saanson mein peena",
        "Khare ho kar ek saans mein",
        "Bayein haath se",
        "Baghair dekhe"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 36, Hadith 5030) & Sahih Bukhari",
      ur: "صحیح مسلم، آداب الشرب، حدیث ۵۰۳۰",
      roman: "Sahih Muslim 5030"
    },
    explanation: {
      en: "The Prophet ﷺ drank in three breaths, breathing outside the vessel and praising Allah at the end.",
      ur: "رسول اللہ ﷺ نے بیٹھ کر، دیکھ کر، برتن کے باہر سانس لے کر تین سانسوں میں پانی پینے کا حکم فرمایا۔",
      roman: "Pani baith kar 3 saans mein peena sunnat hai."
    }
  },
  {
    id: 1012,
    categoryId: 10,
    difficulty: 'medium',
    question: {
      en: "What is the Sunnah Dua recited when leaving home?",
      ur: "گھر سے باہر نکلتے وقت کون سی مبارک مسنون دعا پڑھنی چاہیے؟",
      roman: "Ghar se bahar nikalte waqt konsi masnoon dua parhni chahiye?"
    },
    options: {
      en: [
        "Bismillahi tawakkaltu 'alallahi, la hawla wa la quwwata illa billah",
        "Rabbana atina fid-dunya hasanah",
        "Subhanallahi wa bihamdihi",
        "Allahumma ajirni minan-naar"
      ],
      ur: [
        "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
        "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً",
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
        "اللَّهُمَّ أَجِرْنِي مِنَ النَّارِ"
      ],
      roman: [
        "Bismillahi tawakkaltu alallahi, la hawla wa la quwwata illa billah",
        "Rabbana aatina",
        "Subhanallahi wa bihamdihi",
        "Allahumma ajirni"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sunan Abi Dawud (Hadith 5095) & Jami at-Tirmidhi",
      ur: "سنن ابی داؤد، کتاب الادب، دعاء الخروج من البیت، حدیث ۵۰۹۵",
      roman: "Sunan Abu Dawood 5095"
    },
    explanation: {
      en: "The Prophet ﷺ said whoever says this upon leaving home is guided, defended, and protected, and Satan retreats from him.",
      ur: "جو شخص یہ دعا پڑھ کر نکلتا ہے فرشتے کہتے ہیں: تجھے کفایت کی گئی اور شیطان اس سے دور بھاگ جاتا ہے۔",
      roman: "Ghar se nikalte waqt yeh dua parhne se hifazat rehti hai."
    }
  },
  {
    id: 1013,
    categoryId: 10,
    difficulty: 'hard',
    question: {
      en: "What is the supreme sin in Islam that Allah states He will not forgive if a person dies upon it without repenting?",
      ur: "وہ کون سا سب سے بڑا اور ناقابلِ معافی گناہ ہے جس پر توبہ کے بغیر مرنے والے کو اللہ کبھی نہیں بخشے گا؟",
      roman: "Woh konsa sab se bara gunah hai jis par baghair tauba ke marne wale ko Allah kabhi nahi bakhshe ga?"
    },
    options: {
      en: ["Shirk (Associating partners with Allah)", "Theft", "Lying", "Neglect of fast"],
      ur: ["شِرک (اللہ تعالیٰ کے ساتھ کسی کو شریک ٹھہرانا)", "چوری کرنا", "جھوٹ بولنا", "روزہ قضا کرنا"],
      roman: ["Shirk (Allah ke sath kisi ko shareek karna)", "Chori", "Jhoot", "Roza qaza karna"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah An-Nisa (4:48 & 4:116)",
      ur: "سورۃ النساء، آیت ۴۸: 'إِنَّ اللَّهَ لَا يَغْفِرُ أَنْ يُشْرَكَ بِهِ وَيَغْفِرُ مَا دُونَ ذَٰلِكَ لِمَنْ يَشَاءُ'",
      roman: "Surah An-Nisa, Ayah 48"
    },
    explanation: {
      en: "Allah states: 'Indeed, Allah does not forgive association with Him, but He forgives what is less than that for whom He wills.'",
      ur: "قرآن مجید میں فرمایا گیا کہ اللہ شرک کو ہرگز معاف نہیں فرمائے گا، اس کے علاوہ جس گناہ کو چاہے بخش دے۔",
      roman: "Shirk sab se bara zulm aur azeem gunah hai."
    }
  },
  {
    id: 1014,
    categoryId: 10,
    difficulty: 'expert',
    question: {
      en: "What are the three cardinal signs of a hypocrite (Munafiq) identified by Prophet Muhammad ﷺ in Sahih Bukhari?",
      ur: "صحیح بخاری کی مشہور حدیث کے مطابق منافق کی تین واضح نشانیاں کون سی ہیں؟",
      roman: "Sahih Bukhari ke mutabiq Munafiq ki 3 nishaniyan konsi hain?"
    },
    options: {
      en: [
        "When he speaks he lies, when he promises he breaks it, and when trusted he betrays",
        "When he fasts he boasts, when he travels he complains, when he eats he wastes",
        "When he sleeps he snores, when he works he rests, when he gives he regrets",
        "When he walks he runs, when he writes he forgets, when he buys he bargains"
      ],
      ur: [
        "جب بات کرے تو جھوٹ بولے، وعدہ کرے تو خلاف ورزی کرے، اور امانت رکھی جائے تو خیانت کرے",
        "جب روزہ رکھے تو دکھاوا کرے، سفر میں شکایت کرے، کھانے میں ضیاع کرے",
        "نیند میں غافل ہو، کام چور ہو، صدقہ کر کے پچھتائے",
        "سودا کرے تو دھوکہ دے، بھول جائے اور تکبر کرے"
      ],
      roman: [
        "Jab bole to jhoot bole, wada kare to tode, aur amanat mein khayanat kare",
        "Roze mein dikhawa kare",
        "Sadqa kar ke pachtaye",
        "Ghafil ho"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 2, Hadith 33) & Sahih Muslim",
      ur: "صحیح بخاری، کتاب الایمان، علامۃ المنافق ثلاث، حدیث ۳۳",
      roman: "Sahih Bukhari 33, Sahih Muslim"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'The signs of the hypocrite are three: whenever he speaks he tells a lie, whenever he promises he breaks it, and whenever he is trusted he proves treacherous.'",
      ur: "فرمانِ نبوی ﷺ ہے: منافق کی تین نشانیاں ہیں: جب بولتا ہے جھوٹ بولتا ہے، وعدہ کرتا ہے تو توڑتا ہے، اور جب امانت دی جائے تو خیانت کرتا ہے۔",
      roman: "Huzoor ﷺ ne farmaya: Aayat-ul-munafiqi thalath: Iza haddasa kazaba, wa iza wa'ada akhlafa, wa iztumina khana."
    }
  },
  {
    id: 1015,
    categoryId: 10,
    difficulty: 'easy',
    question: {
      en: "What is the Sunnah Dua to recite when boarding a vehicle or mounting an animal for travel?",
      ur: "گاڑی، سواری یا جہاز پر سوار ہوتے وقت کون سی قرآنی مسنون دعا پڑھی جاتی ہے؟",
      roman: "Sawari par sawar hote waqt konsi masnoon dua parhi jati hai?"
    },
    options: {
      en: [
        "Subhanallazi sakh-khara lana haza wa ma kunna lahu muqrineen",
        "Bismillahi majreeha wa mursaha",
        "Alhamdulillahillazi at'amana wa saqana",
        "Rabbana hab lana min azwajina"
      ],
      ur: [
        "سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَٰذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَىٰ رَبِّنَا لَمُنْقَلِبُونَ",
        "بِسْمِ اللَّهِ مَجْرَاهَا وَمُرْسَاهَا",
        "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا",
        "رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا"
      ],
      roman: [
        "Subhanallazi sakh-khara lana haza wa ma kunna lahu muqrineen",
        "Bismillahi majreeha",
        "Alhamdulillahillazi at'amana",
        "Rabbana hab lana"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Az-Zukhruf (43:13-14) & Sunan Abi Dawud",
      ur: "سورۃ الزخرف، آیات ۱۳ تا ۱۴ اور سنن ابی داؤد، حدیث ۲۶۰۲",
      roman: "Surah Az-Zukhruf 13-14"
    },
    explanation: {
      en: "This prayer acknowledges Allah who made modern transport and animals subservient to humanity.",
      ur: "پاک ہے وہ ذات جس نے اس سواری کو ہمارے تابع کر دیا حالانکہ ہم اسے قابو میں لانے والے نہ تھے۔",
      roman: "Safar ki dua: Subhanallazi sakhara lana haza."
    }
  },
  {
    id: 1016,
    categoryId: 10,
    difficulty: 'medium',
    question: {
      en: "What is the Sunnah sleeping posture recommended by Prophet Muhammad ﷺ?",
      ur: "نبی کریم ﷺ کے ارشادات کے مطابق سونے کا مسنون طریقہ اور کروٹ کیا ہے؟",
      roman: "Huzoor ﷺ ke mutabiq sone ka masnoon tareeqa konsa hai?"
    },
    options: {
      en: [
        "Performing Wudu and lying on the right side with the right hand under the cheek",
        "Lying flat on the stomach face-down",
        "Sleeping on the left side with legs crossed",
        "Sleeping with light on"
      ],
      ur: [
        "باوضو ہو کر دائیں کروٹ لیٹنا اور دایاں ہاتھ رخسار کے نیچے رکھنا",
        "پیٹ کے بل اوندھا سونا",
        "بائیں کروٹ سونا",
        "روشنی جلا کر سونا"
      ],
      roman: [
        "Ba-wudu ho kar daayein karwat letna aur haath gaal ke neeche rakhna",
        "Pait ke bal aundha letna",
        "Bayein karwat letna",
        "Baghair wudu"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 79, Hadith 6311) & Sahih Muslim",
      ur: "صحیح بخاری، کتاب الدعوات، حدیث ۶۳۱۱",
      roman: "Sahih Bukhari 6311"
    },
    explanation: {
      en: "The Prophet ﷺ slept on his right side and forbade sleeping on the stomach, calling it a posture disliked by Allah.",
      ur: "آپ ﷺ نے سونے سے قبل وضو کرنے اور دائیں کروٹ سونے کی تعلیم دی اور پیٹ کے بل اوندھا سونے سے منع فرمایا۔",
      roman: "Daayein karwat let kar sona sunnat-e-Nabawi hai."
    }
  },
  {
    id: 1017,
    categoryId: 10,
    difficulty: 'hard',
    question: {
      en: "What is the prayer performed to ask Allah's divine guidance before making an important decision called?",
      ur: "کسی بھی اہم کام کا فیصلہ کرنے سے قبل اللہ تعالیٰ سے خیر و رہنمائی طلب کرنے کے لیے کون سی نماز پڑھی جاتی ہے؟",
      roman: "Ahem faisla karne se pehle Allah se khair aur rehnumai ke liye konsi namaz parhi jati hai?"
    },
    options: {
      en: ["Salat al-Istikhara", "Salat al-Hajah", "Salat at-Tawbah", "Salat al-Kusuf"],
      ur: ["نمازِ استخارہ (دعائے استخارہ کے ساتھ)", "نمازِ حاجت", "نمازِ توبہ", "نمازِ کسوف"],
      roman: ["Salat al-Istikhara", "Salat al-Hajah", "Salat at-Tawbah", "Salat al-Kusuf"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 19, Hadith 1162)",
      ur: "صحیح بخاری، کتاب التہجد، باب ما جاء فی التطوع مثنی مثنی، حدیث ۱۱۶۲",
      roman: "Sahih Bukhari 1162"
    },
    explanation: {
      en: "Jabir (RA) said the Prophet ﷺ used to teach them the Istikhara prayer for every matter just as he taught a Surah from the Quran.",
      ur: "حضرت جابر رضی اللہ عنہ فرماتے ہیں کہ رسول اللہ ﷺ ہمیں تمام معاملات میں استخارہ اس طرح سکھاتے جیسے قرآن کی سورت سکھاتے تھے۔",
      roman: "Namaz-e-Istikhara kisi bhi kaam mein Allah se behtari talab karne ke liye parhi jati hai."
    }
  },
  {
    id: 1018,
    categoryId: 10,
    difficulty: 'medium',
    question: {
      en: "What is the Dua recited upon entering a mosque according to the Sunnah?",
      ur: "مسجد میں داخل ہوتے وقت دایاں پاؤں اندر رکھ کر کون سی مسنون دعا پڑھنی چاہیے؟",
      roman: "Masjid mein daakhil hote waqt konsi dua parhni chahiye?"
    },
    options: {
      en: [
        "Allahumma-ftah lee abwaba rahmatik",
        "Allahumma inni as'aluka min fadlik",
        "Bismillahi tawakkaltu 'alallah",
        "Rabbighfir lee wali-walidayya"
      ],
      ur: [
        "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ (اے اللہ میرے لیے اپنی رحمت کے دروازے کھول دے)",
        "اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ",
        "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ",
        "رَبِّ اغْفِرْ لِي وَلِوَالِدَيَّ"
      ],
      roman: [
        "Allahumma-ftah lee abwaba rahmatik",
        "Allahumma inni as'aluka min fadlik",
        "Bismillahi tawakkaltu",
        "Rabbighfir lee"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 4, Hadith 1515)",
      ur: "صحیح مسلم، کتاب صلاۃ المسافرین، دعاء دخول المسجد، حدیث ۱۵۱۵",
      roman: "Sahih Muslim 1515"
    },
    explanation: {
      en: "The Prophet ﷺ taught: When entering the mosque, send blessings on the Prophet and say: 'O Allah, open for me the doors of Your mercy.'",
      ur: "رسول اللہ ﷺ نے سکھایا کہ مسجد میں داخل ہوتے وقت درود شریف کے بعد رحمت کے دروازے کھولنے کی دعا مانگو۔",
      roman: "Masjid mein dakhil hote waqt 'Allahumma-ftah lee abwaba rahmatik' parhna sunnat hai."
    }
  },
  {
    id: 1019,
    categoryId: 10,
    difficulty: 'hard',
    question: {
      en: "What is the special two-Rakat voluntary prayer offered upon entering a mosque before sitting down called?",
      ur: "مسجد میں داخل ہو کر بیٹھنے سے پہلے اللہ کے گھر کی تعظیم میں ادا کی جانے والی دو رکعت نماز کیا کہلاتی ہے؟",
      roman: "Masjid mein baithne se pehle do rakat namaz parhne ko kya kehte hain?"
    },
    options: {
      en: ["Tahiyyat al-Masjid", "Tahiyyat al-Wudu", "Salat ad-Duha", "Salat al-Awwabin"],
      ur: ["تحیۃ المسجد (مسجد کی تعظیم کی نماز)", "تحیۃ الوضو", "نمازِ چاشت (ضحیٰ)", "نمازِ اوابین"],
      roman: ["Tahiyyat al-Masjid", "Tahiyyat al-Wudu", "Salat ad-Duha", "Salat al-Awwabeen"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 8, Hadith 444) & Sahih Muslim",
      ur: "صحیح بخاری، حدیث ۴۴۴: 'إذا دخل أحدكم المسجد فلا يجلس حتى يصلي ركعتين'",
      roman: "Sahih Bukhari 444"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'When one of you enters the mosque, let him not sit down until he prays two Rakats.'",
      ur: "رسول اللہ ﷺ نے فرمایا: جب تم میں سے کوئی مسجد میں آئے تو بیٹھنے سے پہلے دو رکعت نماز ادا کرے۔",
      roman: "Tahiyyat al-Masjid baithne se pehle parhna sunnat hai."
    }
  },
  {
    id: 1020,
    categoryId: 10,
    difficulty: 'expert',
    question: {
      en: "What are the three essential components of sincere repentance (Tawbah Nasuh) required for a sin against Allah's rights?",
      ur: "حقوق اللہ کے گناہ سے سچی اور مخلصانہ توبہ (توبہ نصوح) کی تین لازمی شرائط کیا ہیں؟",
      roman: "Sachi tauba (Tawbah Nasooh) ki 3 lazmi sharait kya hain?"
    },
    options: {
      en: [
        "Immediate cessation of the sin, deep remorse in the heart, and firm resolve never to return to it",
        "Paying gold charity only",
        "Travelling to Makkah only",
        "Crying loudly in public"
      ],
      ur: [
        "گناہ کو فوراً چھوڑ دینا، دل سے شرمندہ و پشیمان ہونا، اور آئندہ کبھی نہ کرنے کا پکا ارادہ کرنا",
        "صرف سونا خیرات کرنا",
        "صرف مکہ کا سفر کرنا",
        "لوگوں کے سامنے چیخنا"
      ],
      roman: [
        "Gunah foran chorna, dil se sharminda hona, aur aainda na karne ka pakka azam",
        "Sirf sona khairat karna",
        "Sirf safar karna",
        "Cheekhna"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Riyad us-Saliheen (Imam an-Nawawi, Chapter on Tawbah)",
      ur: "ریاض الصالحین، باب التوبۃ و شرائط التوبۃ النَّصوح",
      roman: "Riyad us-Saliheen, Bab at-Tawbah"
    },
    explanation: {
      en: "Scholars explain: Repentance requires quitting the sin, feeling remorse ('An-nadamu tawbah'), and resolving not to repeat it. If a human right is involved, restitution is also mandatory.",
      ur: "امام نووی نے فرمایا: توبہ نصوح کے لیے گناہ ترک کرنا، ندامت محسوس کرنا اور دوبارہ نہ لوٹنے کا عزم کرنا لازم ہے۔ حقوق العباد میں حق واپس لوٹانا بھی شرط ہے۔",
      roman: "Tawbah ke liye nadamat, gunah chorna aur aainda na karne ka azam zaroori hai."
    }
  },
  {
    id: 1021,
    categoryId: 10,
    difficulty: 'easy',
    question: {
      en: "What did the Prophet ﷺ state brings the most heavy weight on the scale of good deeds (Mizan) on the Day of Judgment?",
      ur: "قیامت کے دن نیکیوں کے پلڑے (میزان) میں سب سے وزنی اور بھاری چیز کیا ہو گی؟",
      roman: "Qayamat ke din Mizan par sab se wazni cheez kya hogi?"
    },
    options: {
      en: [
        "Good Character and Manners (Husn al-Khuluq)",
        "Physical strength",
        "Tribal lineage",
        "Worldly popularity"
      ],
      ur: [
        "اچھے اخلاق اور حسنِ سلوک (حُسْنُ الْخُلُقِ)",
        "جسمانی طاقت",
        "خاندانی حسب نسب",
        "دنیاوی شہرت"
      ],
      roman: [
        "Achha Akhlaaq (Husn-e-Khulq)",
        "Taqat",
        "Khandani nasab",
        "Dunya ki shohrat"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Jami at-Tirmidhi (Hadith 2002) & Sunan Abi Dawud",
      ur: "جامع ترمذی، ابواب البر والصلۃ، حدیث ۲۰۰۲: 'ما شيء أثقل في ميزان المؤمن يوم القيامة من حسن الخلق'",
      roman: "Jami at-Tirmidhi, Hadith 2002"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Nothing is heavier upon the scale of a believer on the Day of Resurrection than good character.'",
      ur: "رسول اللہ ﷺ نے فرمایا: قیامت کے دن مومن کے میزان میں حسن اخلاق سے زیادہ وزنی کوئی چیز نہیں ہوگی۔",
      roman: "Huzoor ﷺ ne farmaya ke meezan par achha akhlaaq sab se bhaari hoga."
    }
  },
  {
    id: 1022,
    categoryId: 10,
    difficulty: 'medium',
    question: {
      en: "What is the famous Ayat that summarizes the entire creed of monotheism (Tawheed) in 4 concise verses?",
      ur: "وہ کون سی مختصر سورۃ مبارکہ ہے جو چار آیات میں خالص عقیدہ توحید کی بنیاد بیان کرتی ہے؟",
      roman: "Konsi Surah 4 aayat mein mukammal Tawheed ka bayaan karti hai?"
    },
    options: {
      en: ["Surah Al-Ikhlas (Qul Huwallahu Ahad)", "Surah Al-Falaq", "Surah An-Nas", "Surah Al-Kafirun"],
      ur: ["سورۃ الاخلاص (قُلْ هُوَ اللَّهُ أَحَدٌ)", "سورۃ الفلق", "سورۃ الناس", "سورۃ الکافرون"],
      roman: ["Surah Al-Ikhlas (Qul Huwallahu Ahad)", "Surah Al-Falaq", "Surah An-Nas", "Surah Al-Kafirun"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Ikhlas (Chapter 112)",
      ur: "سورۃ الاخلاص (سورۃ نمبر ۱۱۲)",
      roman: "Surah Al-Ikhlas"
    },
    explanation: {
      en: "Surah Al-Ikhlas affirms Allah is One, As-Samad (the Eternal Refuge), neither begets nor is born, and has no equivalent.",
      ur: "سورۃ الاخلاص اعلان کرتی ہے کہ اللہ ایک ہے، بے نیاز ہے، نہ اس کی کوئی اولاد ہے نہ وہ کسی کی اولاد ہے اور نہ کوئی اس کا ہمسر ہے۔",
      roman: "Surah Al-Ikhlas mein Tawheed ka mukammal ailan hai."
    }
  }
];
