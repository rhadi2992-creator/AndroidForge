import { Question } from '../../types/quiz';

export const hadithQuestions: Question[] = [
  {
    id: 201,
    categoryId: 2,
    difficulty: 'easy',
    question: {
      en: "According to the famous Hadith, actions are judged by what?",
      ur: "مشہور حدیث مبارکہ کے مطابق اعمال کا دارومدار کس چیز پر ہے؟",
      roman: "Mashhoor Hadees ke mutabiq aamal ka daromadar kis cheez par hai?"
    },
    options: {
      en: ["Wealth", "Intentions (Niyyah)", "Knowledge", "Status"],
      ur: ["دولت پر", "نیتوں پر", "علم پر", "عہدے پر"],
      roman: ["Daulat par", "Niyyaton par", "Ilm par", "Uhde par"]
    },
    correctAnswer: 1,
    reference: {
      en: "Sahih Bukhari (Hadith 1) & Sahih Muslim (Hadith 1907)",
      ur: "صحیح بخاری، حدیث ۱ اور صحیح مسلم، حدیث ۱۹۰۷",
      roman: "Sahih Bukhari 1 wa Sahih Muslim 1907"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Innamal a'malu bin-niyyat' (Actions are according to intentions). It is the opening Hadith of Sahih Bukhari.",
      ur: "حضور اکرم ﷺ نے ارشاد فرمایا: 'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ' (اعمال کا دارومدار صرف نیتوں پر ہے)۔",
      roman: "Huzoor ﷺ ne farmaya: Innamal a'maalu bin-niyyaat (Aamal ka daromadar niyyat par hai)."
    }
  },
  {
    id: 202,
    categoryId: 2,
    difficulty: 'easy',
    question: {
      en: "What are the six canonical compilations of Hadith known as in Islamic scholarship?",
      ur: "اہل سنت کے ہاں حدیث شریف کی چھ مستند ترین کتابوں کے مجموعے کو کیا کہا جاتا ہے؟",
      roman: "Ahadees ki 6 mustanad kitabon ke majmooe ko kya kehte hain?"
    },
    options: {
      en: ["Sihah Sitta", "Kutub Arba'a", "Musnad Ahmad", "Muwatta Malik"],
      ur: ["صحاح ستہ", "کتب اربعہ", "مسند احمد", "مؤطا امام مالک"],
      roman: ["Sihah Sitta", "Kutub Arba'a", "Musnad Ahmad", "Muwatta"]
    },
    correctAnswer: 0,
    reference: {
      en: "Uloom al-Hadith consensus",
      ur: "اصولِ حدیث و علوم الحدیث",
      roman: "Uloom al-Hadith consensus"
    },
    explanation: {
      en: "Sihah Sitta (The Authentic Six) consists of Sahih Bukhari, Sahih Muslim, Sunan Abi Dawud, Jami at-Tirmidhi, Sunan an-Nasa'i, and Sunan Ibn Majah.",
      ur: "صحاح ستہ میں صحیح بخاری، صحیح مسلم، سنن ابی داؤد، جامع ترمذی، سنن نسائی اور سنن ابن ماجہ شامل ہیں۔",
      roman: "Sihah Sitta mein Bukhari, Muslim, Abu Dawood, Tirmidhi, Nasa'i aur Ibn Majah shamil hain."
    }
  },
  {
    id: 203,
    categoryId: 2,
    difficulty: 'easy',
    question: {
      en: "Complete the Hadith: 'Seeking knowledge is an obligation upon every...'",
      ur: "حدیث پاک مکمل کریں: 'علم کا طلب کرنا ہر _____ پر فرض ہے۔'",
      roman: "Hadees mukammal karein: 'Ilm ka talab karna har _____ par farz hai.'"
    },
    options: {
      en: ["Scholar", "Muslim", "Leader", "Elder"],
      ur: ["عالم پر", "مسلمان پر", "حکمران پر", "بزرگ پر"],
      roman: ["Aalim par", "Musalman par", "Hukmraan par", "Buzurg par"]
    },
    correctAnswer: 1,
    reference: {
      en: "Sunan Ibn Majah (Hadith 224)",
      ur: "سنن ابن ماجہ، مقدمہ، حدیث ۲۲۴",
      roman: "Sunan Ibn Majah, Hadith 224"
    },
    explanation: {
      en: "The Prophet ﷺ stated: 'Talabul ilmi faridatun 'ala kulli Muslim' (Seeking knowledge is obligatory upon every Muslim).",
      ur: "فرمانِ رسول ﷺ ہے: 'طَلَبُ الْعِلْمِ فَرِيضَةٌ عَلَى كُلِّ مُسْلِمٍ' (علم حاصل کرنا ہر مسلمان پر فرض ہے)۔",
      roman: "Huzoor ﷺ ne farmaya: Talab-ul-ilmi fareedatun ala kulli Muslim."
    }
  },
  {
    id: 204,
    categoryId: 2,
    difficulty: 'medium',
    question: {
      en: "Which companion narrated the highest number of Hadiths from the Prophet ﷺ?",
      ur: "رسول اللہ ﷺ سے سب سے زیادہ احادیث مبارکہ روایت کرنے والے صحابی کون ہیں؟",
      roman: "Rasool Allah ﷺ se sab se zyada ahadees kis Sahabi ne riwayat ki hain?"
    },
    options: {
      en: ["Hazrat Abu Hurairah (RA)", "Hazrat Abdullah ibn Umar (RA)", "Hazrat Anas ibn Malik (RA)", "Hazrat Jabir ibn Abdullah (RA)"],
      ur: ["حضرت ابوہریرہ رضی اللہ عنہ", "حضرت عبداللہ بن عمر رضی اللہ عنہ", "حضرت انس بن مالک رضی اللہ عنہ", "حضرت جابر بن عبداللہ رضی اللہ عنہ"],
      roman: ["Hazrat Abu Hurairah (R.A)", "Hazrat Abdullah bin Umar (R.A)", "Hazrat Anas bin Malik (R.A)", "Hazrat Jabir bin Abdullah (R.A)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tahdhib at-Tahdhib (Ibn Hajar)",
      ur: "سیر اعلام النبلاء اور تہذیب التہذیب",
      roman: "Siyar A'lam an-Nubala"
    },
    explanation: {
      en: "Hazrat Abu Hurairah (RA) narrated 5,374 Hadiths, having dedicated his life to preserving prophetic traditions in Suffah.",
      ur: "حضرت ابوہریرہ رضی اللہ عنہ نے ۵۳۷۴ احادیث مبارکہ روایت فرمائیں، جو تمام صحابہ میں سب سے زیادہ تعداد ہے۔",
      roman: "Hazrat Abu Hurairah (R.A) ne 5,374 ahadees riwayat farmayi hain."
    }
  },
  {
    id: 205,
    categoryId: 2,
    difficulty: 'medium',
    question: {
      en: "What did the Prophet ﷺ describe as 'half of faith' (Shatr al-Iman)?",
      ur: "نبی کریم ﷺ نے کس چیز کو 'نصف ایمان' (آدھا ایمان) قرار دیا؟",
      roman: "Nabi Kareem ﷺ ne kis cheez ko 'nisf iman' (aadha iman) qarar diya?"
    },
    options: {
      en: ["Purity / Cleanliness (At-Tuhur)", "Charity (Sadaqah)", "Patience (Sabr)", "Fasting (Sawm)"],
      ur: ["طہارت اور پاکیزگی", "صدقہ و خیرات", "صبر و شکر", "روزہ رکھنا"],
      roman: ["Taharat aur Paakizgi", "Sadaqah", "Sabr", "Roza"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 2, Hadith 432)",
      ur: "صحیح مسلم، کتاب الطہارۃ، حدیث ۴۳۲",
      roman: "Sahih Muslim, Kitab at-Taharah, Hadith 432"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'At-tuhuru shatrul iman' (Purity is half of faith). Cleanliness is spiritual and physical in Islam.",
      ur: "حدیث نبوی ﷺ ہے: 'الطُّهُورُ شَطْرُ الإِيمَانِ' (پاکیزگی اور طہارت آدھا ایمان ہے)۔",
      roman: "Huzoor ﷺ ne farmaya: At-tahooru shatrul iman (Paakizgi aadha iman hai)."
    }
  },
  {
    id: 206,
    categoryId: 2,
    difficulty: 'medium',
    question: {
      en: "According to Hadith, what is considered an act of charity (Sadaqah) when meeting your brother?",
      ur: "حدیث نبوی ﷺ کے مطابق اپنے مسلمان بھائی سے کس طرح ملنا صدقہ شمار ہوتا ہے؟",
      roman: "Hadees ke mutabiq apne musalman bhai se kaise milna sadaqah shumar hota hai?"
    },
    options: {
      en: ["Giving money", "Smiling at him", "Giving a gift", "Giving advice"],
      ur: ["روپیہ پیسہ دینا", "مسکرا کر ملنا (تبسم)", "تحفہ پیش کرنا", "نصیحت کرنا"],
      roman: ["Paisa dena", "Muskura kar milna (Tabassum)", "Tohfa dena", "Naseehat karna"]
    },
    correctAnswer: 1,
    reference: {
      en: "Jami at-Tirmidhi (Hadith 1956)",
      ur: "جامع ترمذی، ابواب البر والصلۃ، حدیث ۱۹۵۶",
      roman: "Jami at-Tirmidhi, Hadith 1956"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Your smiling in the face of your brother is charity for you' (تبسمك في وجه أخيك لك صدقة).",
      ur: "رسول اللہ ﷺ نے فرمایا: اپنے بھائی کے سامنے تمہارا مسکرانا تمہارے لیے صدقہ ہے۔",
      roman: "Huzoor ﷺ ne farmaya ke apne bhai ke samne muskurana bhi sadaqah hai."
    }
  },
  {
    id: 207,
    categoryId: 2,
    difficulty: 'hard',
    question: {
      en: "Which famous Hadith is known as 'Hadith Jibreel', detailing Islam, Iman, and Ihsan?",
      ur: "اسلام، ایمان اور احسان کے درجات بیان کرنے والی مشہور حدیث کو کیا کہا جاتا ہے؟",
      roman: "Islam, Iman aur Ihsan ko bayaan karne wali mashhoor hadees ko kya kehte hain?"
    },
    options: {
      en: ["Hadith Jibreel", "Hadith Qudsi", "Hadith Kisa", "Hadith Thaqalayn"],
      ur: ["حدیثِ جبرائیل", "حدیثِ قدسی", "حدیثِ کساء", "حدیثِ ثقلین"],
      roman: ["Hadith-e-Jibreel", "Hadith-e-Qudsi", "Hadith-e-Kisa", "Hadith-e-Saqalain"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 1, Hadith 1)",
      ur: "صحیح مسلم، کتاب الایمان، حدیث ۱",
      roman: "Sahih Muslim, Kitab al-Iman, Hadith 1"
    },
    explanation: {
      en: "Hadith Jibreel is the opening Hadith of Sahih Muslim where Angel Jibreel came in human form to teach the believers their religion.",
      ur: "حضرت عمر فاروق رضی اللہ عنہ سے مروی حدیث جبرائیل میں اسلام کے ارکان، ایمان کے اجزاء اور احسان کی تعریف واضح کی گئی ہے۔",
      roman: "Hadith Jibreel mein Hazrat Jibreel (A.S) ne aakar Islam, Iman aur Ihsan ki taleem di."
    }
  },
  {
    id: 208,
    categoryId: 2,
    difficulty: 'hard',
    question: {
      en: "What is a 'Hadith Qudsi' in Islamic classification?",
      ur: "اصولِ حدیث میں 'حدیثِ قدسی' کس کو کہا جاتا ہے؟",
      roman: "Usool-e-Hadith mein 'Hadith-e-Qudsi' kis ko kehte hain?"
    },
    options: {
      en: [
        "A Hadith where the Prophet ﷺ quotes words/meanings directly from Allah",
        "A Hadith narrated only by angels",
        "A Hadith strictly about Jerusalem",
        "A Hadith fabricated by narrators"
      ],
      ur: [
        "وہ حدیث جس میں رسول اللہ ﷺ اللہ تعالیٰ کا ارشاد نقل فرمائیں",
        "وہ حدیث جو صرف فرشتے روایت کریں",
        "وہ حدیث جو بیت المقدس کے متعلق ہو",
        "من گھڑت حدیث"
      ],
      roman: [
        "Woh hadees jisme Huzoor ﷺ Allah Ta'ala ka farman naqal farmayein",
        "Woh hadees jo farishte riwayat karein",
        "Bait-ul-Muqaddas ki hadees",
        "Ghalat hadees"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Al-Muqaddimah fi Usul al-Hadith (Ibn as-Salah)",
      ur: "مقدمہ ابن الصلاح فی علوم الحدیث",
      roman: "Muqaddimah Ibn as-Salah"
    },
    explanation: {
      en: "In Hadith Qudsi, the meaning is from Allah while the wording is phrased by Prophet Muhammad ﷺ (distinct from the Quran).",
      ur: "حدیث قدسی وہ ہے جس میں معنی اور مفہوم اللہ تعالیٰ کی طرف سے ہو اور الفاظ رسول اللہ ﷺ کے ہوں۔",
      roman: "Hadith-e-Qudsi mein maani Allah Ta'ala ki taraf se hota hai aur alfaaz Huzoor ﷺ ke."
    }
  },
  {
    id: 209,
    categoryId: 2,
    difficulty: 'hard',
    question: {
      en: "What is the primary compilation of Hadiths by Imam Malik ibn Anas titled?",
      ur: "امام دار الہجرہ حضرت امام مالک بن انس رحمہ اللہ کے مشہور مجموعہ حدیث کا کیا نام ہے؟",
      roman: "Imam Malik (R.A) ke mashhoor majmooa-e-hadees ka naam kya hai?"
    },
    options: {
      en: ["Al-Muwatta", "Al-Musnad", "As-Sunan", "Al-Mustadrak"],
      ur: ["المؤطا (مؤطا امام مالک)", "المسند", "السنن", "المستدرک"],
      roman: ["Al-Muwatta", "Al-Musnad", "As-Sunan", "Al-Mustadrak"]
    },
    correctAnswer: 0,
    reference: {
      en: "Al-Muwatta of Imam Malik",
      ur: "المؤطا امام مالک، تدوینِ حدیث کا شاہکار",
      roman: "Al-Muwatta Imam Malik"
    },
    explanation: {
      en: "Al-Muwatta is one of the earliest and most authentic compilations of Hadith and Fiqh from the scholars of Madinah.",
      ur: "المؤطا امام مالک مدینہ منورہ کے فقہ اور مستند احادیث کا اولین اور معتبر ترین مجموعہ ہے۔",
      roman: "Al-Muwatta Madinah Munawwarah ke uloom aur ahadees ka azeem tareen majmooa hai."
    }
  },
  {
    id: 210,
    categoryId: 2,
    difficulty: 'expert',
    question: {
      en: "What was the birth city of Imam Muhammad ibn Isma'il al-Bukhari?",
      ur: "صحیح بخاری کے مؤلف حضرت امام محمد بن اسماعیل بخاری کس شہر میں پیدا ہوئے؟",
      roman: "Imam Bukhari (R.A) kis shehar mein paida hue the?"
    },
    options: {
      en: ["Bukhara (Uzbekistan)", "Samarkand", "Nishapur", "Baghdad"],
      ur: ["بخارا (ازبکستان)", "سمرقند", "نیشاپور", "بغداد"],
      roman: ["Bukhara (Uzbekistan)", "Samarkand", "Nishapur", "Baghdad"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh Baghdad (Al-Khatib al-Baghdadi)",
      ur: "تاریخ بغداد، خطیب بغدادی و طبقات الشافعیہ",
      roman: "Tarikh Baghdad"
    },
    explanation: {
      en: "Imam Bukhari was born in 194 AH in Bukhara (in modern Uzbekistan) and travelled across the Islamic world verifying Hadiths.",
      ur: "امام بخاری ۱۹۴ ہجری میں بخارا میں پیدا ہوئے اور انہوں نے سولہ سال کی مسلسل محنت سے صحیح بخاری تالیف فرمائی۔",
      roman: "Imam Bukhari 194 Hijri mein Bukhara mein paida hue."
    }
  },
  {
    id: 211,
    categoryId: 2,
    difficulty: 'expert',
    question: {
      en: "In Hadith terminology, what is a Hadith called whose chain of transmission reaches the Prophet ﷺ directly?",
      ur: "علم حدیث کی اصطلاح میں وہ حدیث جس کی سند رسول اللہ ﷺ تک پہنچتی ہو، کیا کہلاتی ہے؟",
      roman: "Usool-e-Hadith mein woh hadees jiski sanad Nabi ﷺ tak pohnche kya kehlati hai?"
    },
    options: {
      en: ["Marfu' (Elevated)", "Mawquf (Halted at Sahabi)", "Maqtu' (Severed at Tabi'i)", "Mursal"],
      ur: ["مرفوع", "موقوف", "مقطوع", "مرسل"],
      roman: ["Marfu'", "Mawqoof", "Maqtoo'", "Mursal"]
    },
    correctAnswer: 0,
    reference: {
      en: "Nukhbat al-Fikar (Ibn Hajar al-Asqalani)",
      ur: "نخبۃ الفکر فی مصطلح اہل الاثر (ابن حجر عسقلانی)",
      roman: "Nukhbat al-Fikar"
    },
    explanation: {
      en: "A Marfu' Hadith is attributed directly to Prophet Muhammad ﷺ (his word, action, or tacit approval).",
      ur: "حدیث مرفوع وہ روایت ہے جس کی نسبت رسول اللہ ﷺ کے قول، فعل یا تقریر کی طرف کی جائے۔",
      roman: "Marfu' hadees woh hoti hai jo seedhi Rasool Allah ﷺ ki taraf mansoob ho."
    }
  },
  {
    id: 212,
    categoryId: 2,
    difficulty: 'easy',
    question: {
      en: "Complete the Hadith: 'None of you truly believes until he loves for his brother what he...'",
      ur: "حدیث نبوی ﷺ مکمل کریں: 'تم میں سے کوئی مومن نہیں ہو سکتا جب تک اپنے بھائی کے لیے وہ نہ چاہے جو...'",
      roman: "Hadees mukammal karein: 'Tum mein se koi momin nahi ho sakta jab tak apne bhai ke liye woh na chahe jo...'"
    },
    options: {
      en: ["Loves for himself", "Wishes for his family", "Can afford to give", "Desires for his wealth"],
      ur: ["وہ اپنے لیے پسند کرتا ہے", "وہ اپنے خاندان کے لیے چاہتا ہے", "جو اس کے پاس زائد ہو", "جو اس کی دولت میں ہو"],
      roman: ["Woh apne liye pasand karta hai", "Apne khandan ke liye chahe", "Jo zayed ho", "Jo uski daulat ho"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Hadith 13) & Sahih Muslim (Hadith 45)",
      ur: "صحیح بخاری حدیث ۱۳، صحیح مسلم حدیث ۴۵",
      roman: "Sahih Bukhari 13, Sahih Muslim 45"
    },
    explanation: {
      en: "Prophet Muhammad ﷺ said: 'None of you has faith until he loves for his brother or neighbor what he loves for himself.'",
      ur: "رسول اللہ ﷺ نے فرمایا: تم میں سے کوئی اس وقت تک کامل مومن نہیں ہو سکتا جب تک اپنے بھائی کے لیے وہی پسند نہ کرے جو اپنے لیے کرتا ہے۔",
      roman: "Huzoor ﷺ ne farmaya: Laa yu'minu ahadukum hatta yuhibba li-akhihi ma yuhibbu li-nafsihi."
    }
  },
  {
    id: 213,
    categoryId: 2,
    difficulty: 'medium',
    question: {
      en: "What did the Prophet ﷺ describe as a fortress against sins and hellfire?",
      ur: "فرمانِ نبوی ﷺ کے مطابق کون سی عبادت گناہوں اور جہنم سے ڈھال ہے؟",
      roman: "Farman-e-Nabawi ﷺ ke mutabiq konsi ibadat dhaal (shield) hai?"
    },
    options: {
      en: ["Fasting (As-Sawm)", "Pilgrimage (Al-Hajj)", "Charity (As-Sadaqah)", "Recitation (At-Tilawah)"],
      ur: ["روزہ (الصوم جُنَّة)", "حج", "صدقہ", "تلاوت"],
      roman: ["Roza (As-Sawmu Junnah)", "Hajj", "Sadaqah", "Tilawat"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Hadith 1894) & Sahih Muslim (Hadith 1151)",
      ur: "صحیح بخاری حدیث ۱۸۹۴، صحیح مسلم حدیث ۱۱۵۱",
      roman: "Sahih Bukhari 1894, Sahih Muslim 1151"
    },
    explanation: {
      en: "The Prophet ﷺ declared: 'As-Sawmu Junnah' (Fasting is a protective shield against evil and the Fire).",
      ur: "رسول اللہ ﷺ نے فرمایا: 'الصَّوْمُ جُنَّةٌ' (روزہ برائیوں اور جہنم کی آگ سے بچاؤ کے لیے ڈھال ہے)۔",
      roman: "Huzoor ﷺ ne farmaya: As-sawmu junnah (Roza dhaal hai)."
    }
  },
  {
    id: 214,
    categoryId: 2,
    difficulty: 'medium',
    question: {
      en: "What did the Prophet ﷺ say regarding the status of a mother?",
      ur: "فرمانِ مصطفی ﷺ کے مطابق ماں کے متعلق کیا عظمت بیان فرمائی گئی؟",
      roman: "Nabi Kareem ﷺ ne maa ke mutalliq kya azeem rutba bayaan farmaya?"
    },
    options: {
      en: [
        "Paradise lies at her feet",
        "She deserves half your wealth",
        "She is the head of state",
        "She decides your pilgrimage"
      ],
      ur: [
        "جنت ماؤں کے قدموں تلے ہے",
        "وہ آدھی دولت کی حقدار ہے",
        "وہ حاکم وقت ہے",
        "وہ حج کا فیصلہ کرے"
      ],
      roman: [
        "Jannat maon ke qadmon tale hai",
        "Woh aadhi daulat ki haqdaar hai",
        "Woh haakim hai",
        "Hajj ka faisla kare"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sunan an-Nasa'i (Hadith 3104)",
      ur: "سنن نسائی، کتاب الجہاد، حدیث ۳۱۰۴",
      roman: "Sunan an-Nasa'i, Hadith 3104"
    },
    explanation: {
      en: "The Prophet ﷺ told Jahimah (RA): 'Stay with her (your mother), for Paradise is under her feet.'",
      ur: "رسول کریم ﷺ نے صحابی سے فرمایا: اپنی ماں کی خدمت میں لازم رہو کیونکہ جنت اس کے قدموں کے نیچے ہے۔",
      roman: "Huzoor ﷺ ne farmaya: Apni maa ki khidmat karo kyunke Jannat uske qadmon tale hai."
    }
  },
  {
    id: 215,
    categoryId: 2,
    difficulty: 'hard',
    question: {
      en: "Which compilation of Hadith was authored by Imam Abu Dawud Sulaiman ibn al-Ash'ath?",
      ur: "امام ابو داؤد سلیمان بن اشعث سجستانی رحمہ اللہ کی شہرہ آفاق کتاب کا کیا نام ہے؟",
      roman: "Imam Abu Dawood (R.A) ki mashhoor kitab ka naam kya hai?"
    },
    options: {
      en: ["Sunan Abi Dawud", "Sahih Muslim", "Jami at-Tirmidhi", "Sunan an-Nasa'i"],
      ur: ["سنن ابی داؤد", "صحیح مسلم", "جامع ترمذی", "سنن نسائی"],
      roman: ["Sunan Abi Dawood", "Sahih Muslim", "Jami at-Tirmidhi", "Sunan an-Nasa'i"]
    },
    correctAnswer: 0,
    reference: {
      en: "Classical Hadith Biography",
      ur: "کتبِ اسماء الرجال و طبقات المحدثین",
      roman: "Tabaqat al-Muhadditheen"
    },
    explanation: {
      en: "Sunan Abi Dawud is renowned especially for legal Hadiths (Ahadith al-Ahkam) related to Fiqh jurisprudence.",
      ur: "سنن ابی داؤد احکام اور فقہی مسائل کی احادیث کا عظیم الشان اور معتبر ترین ماخذ ہے۔",
      roman: "Sunan Abi Dawood fiqh aur ahkaam ki ahadees ka azeem majmooa hai."
    }
  },
  {
    id: 216,
    categoryId: 2,
    difficulty: 'expert',
    question: {
      en: "What is a 'Mutawatir' Hadith in Hadith terminology?",
      ur: "علمِ حدیث میں 'حدیثِ متواتر' کسے کہا جاتا ہے؟",
      roman: "Ilm-e-Hadith mein 'Hadith-e-Mutawatir' kis ko kehte hain?"
    },
    options: {
      en: [
        "A Hadith narrated by so many independent chains at every level that fabrication is impossible",
        "A Hadith narrated by only one companion",
        "A weak Hadith with hidden flaws",
        "A Hadith found only in one book"
      ],
      ur: [
        "وہ حدیث جسے ہر دور میں اتنی کثیر تعداد نے روایت کیا ہو کہ جھوٹ پر متفق ہونا ناممکن ہو",
        "وہ حدیث جو صرف ایک صحابی نے بیان کی ہو",
        "ضعیف حدیث",
        "وہ حدیث جو صرف ایک کتاب میں ہو"
      ],
      roman: [
        "Woh hadees jise har daur mein itni bari tadaad ne riwayat kiya ho ke jhoot ka imkan na ho",
        "Sirf aik Sahabi ki riwayat",
        "Zaeef hadees",
        "Aik kitab ki hadees"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Tadrib ar-Rawi (Imam Jalaluddin as-Suyuti)",
      ur: "تدریب الراوی فی شرح تقریب النواوی (علامہ سیوطی)",
      roman: "Tadreeb ar-Rawi"
    },
    explanation: {
      en: "Mutawatir gives absolute definitive certainty ('Ilm Qat'i) because a vast group transmitted it without collusion.",
      ur: "حدیث متواتر قطعی علم کا فائدہ دیتی ہے کیونکہ اس کے راویوں کی تعداد ہر طبقے میں اتنی زیادہ ہوتی ہے کہ جھوٹ کا کوئی شائبہ نہیں رہتا۔",
      roman: "Mutawatir hadees yaqeeni aur qat'i ilm deti hai."
    }
  },
  {
    id: 217,
    categoryId: 2,
    difficulty: 'easy',
    question: {
      en: "What did the Prophet ﷺ say about the best person among Muslims?",
      ur: "رسول اللہ ﷺ نے مسلمانوں میں سب سے بہتر کس شخص کو قرار دیا؟",
      roman: "Rasool Allah ﷺ ne musalmanon mein sab se behtar kis shakhs ko farmaya?"
    },
    options: {
      en: [
        "The one who learns the Quran and teaches it",
        "The one who has the most wealth",
        "The one who builds the tallest building",
        "The one who travels the most"
      ],
      ur: [
        "جو قرآن سیکھے اور دوسروں کو سکھائے",
        "جو سب سے زیادہ مالدار ہو",
        "جو اونچی عمارتیں بنائے",
        "جو سب سے زیادہ سفر کرے"
      ],
      roman: [
        "Jo Quran seekhe aur doosron ko sikhaye",
        "Jo sab se zyada ameer ho",
        "Jo unchi imarat banaye",
        "Jo sab se zyada safar kare"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 66, Hadith 5027)",
      ur: "صحیح بخاری، فضائل القرآن، حدیث ۵۰۲۷",
      roman: "Sahih Bukhari, Hadith 5027"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Khayrukum man ta'allamal-Qur'ana wa 'allamah' (The best among you are those who learn the Quran and teach it).",
      ur: "فرمانِ نبوی ﷺ ہے: 'خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ' (تم میں سب سے بہتر وہ ہے جو قرآن سیکھے اور اسے دوسروں کو سکھائے)۔",
      roman: "Huzoor ﷺ ne farmaya: Khairukum man ta'allamal-Qur'ana wa 'allamah."
    }
  },
  {
    id: 218,
    categoryId: 2,
    difficulty: 'hard',
    question: {
      en: "Which famous scholar compiled the authentic collection 'Riyad us-Saliheen'?",
      ur: "احادیث مبارکہ کا عظیم اور مقبول مجموعہ 'ریاض الصالحین' کس جلیل القدر عالم نے مرتب فرمایا؟",
      roman: "Mashhoor kitab 'Riyad us-Saliheen' kis azeem aalim ne murattab farmayi?"
    },
    options: {
      en: ["Imam Yahya ibn Sharaf an-Nawawi", "Imam Ibn Kathir", "Imam Al-Ghazali", "Imam Al-Qurtubi"],
      ur: ["امام یحییٰ بن شرف النووی رحمہ اللہ", "امام ابن کثیر رحمہ اللہ", "امام غزالی رحمہ اللہ", "امام قرطبی رحمہ اللہ"],
      roman: ["Imam an-Nawawi (R.A)", "Imam Ibn Kathir", "Imam Al-Ghazali", "Imam Al-Qurtubi"]
    },
    correctAnswer: 0,
    reference: {
      en: "Riyad us-Saliheen introduction",
      ur: "مقدمہ ریاض الصالحین، امام نووی",
      roman: "Riyad us-Saliheen Intro"
    },
    explanation: {
      en: "Imam an-Nawawi (d. 676 AH) compiled Riyad us-Saliheen (Gardens of the Righteous) containing core moral Hadiths.",
      ur: "امام نووی رحمہ اللہ نے روزمرہ اسلامی اخلاق اور احکام پر مبنی یہ شاہکار مجموعہ ترتیب دیا۔",
      roman: "Imam Nawawi (R.A) ne Riyad us-Saliheen taseef farmayi."
    }
  },
  {
    id: 219,
    categoryId: 2,
    difficulty: 'medium',
    question: {
      en: "What should a Muslim say upon hearing a brother sneeze when he praises Allah?",
      ur: "جب مسلمان بھائی چھینک کر 'الحمد لله' کہے تو سننے والے پر کیا جواب دینا مسنون ہے؟",
      roman: "Jab musalman bhai cheenk kar 'Alhamdulillah' kahe to kya jawab dena chahiye?"
    },
    options: {
      en: ["Yarhamukallah (May Allah have mercy on you)", "Jazakallah", "Subhanallah", "Barakallah"],
      ur: ["يَرْحَمُكَ اللَّهُ (اللہ تم پر رحم فرمائے)", "جَزَاكَ اللَّهُ", "سُبْحَانَ اللَّهِ", "بَارَكَ اللَّهُ"],
      roman: ["Yarhamukallah", "Jazakallah", "Subhanallah", "Barakallah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 78, Hadith 6224)",
      ur: "صحیح بخاری، کتاب الادب، حدیث ۶۲۲۴",
      roman: "Sahih Bukhari, Hadith 6224"
    },
    explanation: {
      en: "The Prophet ﷺ taught: When one sneezes and says 'Alhamdulillah', the listener should reply 'Yarhamukallah'.",
      ur: "رسول اللہ ﷺ نے چھینک کے آداب میں سکھایا کہ چھینکنے والا 'الحمد لله' کہے اور سننے والا 'يرحمك الله' کہے۔",
      roman: "Huzoor ﷺ ne cheenkne wale ke jawab mein 'Yarhamukallah' kehne ka hukum diya."
    }
  },
  {
    id: 220,
    categoryId: 2,
    difficulty: 'expert',
    question: {
      en: "What does the term 'Isnad' refer to in Hadith studies?",
      ur: "علم حدیث میں لفظ 'اسناد' یا 'سند' کا کیا مفہوم ہے؟",
      roman: "Ilm-e-Hadith mein 'Isnad' ya 'Sanad' kis ko kehte hain?"
    },
    options: {
      en: [
        "The chain of narrators transmitting the Hadith text back to the source",
        "The physical paper on which the Hadith was written",
        "The grammatical vowels of the Arabic text",
        "The chapter index of a book"
      ],
      ur: [
        "راویوں کا وہ مسلسل سلسلہ جو حدیث کے متن کو رسول اللہ ﷺ تک پہنچائے",
        "کاغذ کی قسم",
        "عربی زبان کے اعراب",
        "کتاب کی فہرست"
      ],
      roman: [
        "Rawiyon ka silsila jo hadees ke matan ko Huzoor ﷺ tak pohnchaye",
        "Kaghaz ki qisam",
        "Arabi ke e'raab",
        "Kitab ki fehrist"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Introduction to Sahih Muslim (Imam Muslim)",
      ur: "مقدمہ صحیح مسلم، اہمیتِ اسناد",
      roman: "Muqaddimah Sahih Muslim"
    },
    explanation: {
      en: "Abdullah ibn al-Mubarak said: 'The Isnad is part of the religion; without it, anyone could say whatever they wish.'",
      ur: "عبد اللہ بن مبارک رحمہ اللہ نے فرمایا: اسناد دین کا حصہ ہے، اگر اسناد نہ ہوتی تو جو چاہتا جو منہ میں آتا کہہ دیتا۔",
      roman: "Isnad rawiyon ki zanjeer hai jis se hadees ki sehad ka pata chalta hai."
    }
  },
  {
    id: 221,
    categoryId: 2,
    difficulty: 'easy',
    question: {
      en: "According to Hadith, what wipes away sins like water extinguishes fire?",
      ur: "فرمانِ نبوی ﷺ کے مطابق کون سا نیک عمل گناہوں کو اس طرح مٹا دیتا ہے جیسے پانی آگ کو بجھاتا ہے؟",
      roman: "Farman-e-Nabawi ke mutabiq konsa amal gunahon ko aise bujhata hai jaise pani aag ko?"
    },
    options: {
      en: ["Charity (Sadaqah)", "Sleeping early", "Trading", "Travelling"],
      ur: ["صدقہ و خیرات", "جلدی سونا", "تجارت کرنا", "سفر کرنا"],
      roman: ["Sadaqah wa Khairat", "Sona", "Tijarat", "Safar"]
    },
    correctAnswer: 0,
    reference: {
      en: "Jami at-Tirmidhi (Hadith 2616)",
      ur: "جامع ترمذی، ابواب الایمان، حدیث ۲۶۱۶",
      roman: "Jami at-Tirmidhi, Hadith 2616"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Sadaqah extinguishes sin as water extinguishes fire' (الصدقة تطفئ الخطيئة كما يطفئ الماء النار).",
      ur: "رسول اللہ ﷺ نے فرمایا: صدقہ گناہوں کو ایسے بجھا دیتا ہے جیسے پانی آگ کو بجھا دیتا ہے۔",
      roman: "Huzoor ﷺ ne farmaya: As-sadaqatu tutfi'ul-khati'ata kama yutfi'ul-maa'un-naar."
    }
  },
  {
    id: 222,
    categoryId: 2,
    difficulty: 'medium',
    question: {
      en: "What did the Prophet ﷺ state regarding the strong believer versus the weak believer?",
      ur: "طاقتور مومن اور کمزور مومن کے متعلق فرمانِ نبوی ﷺ کیا ہے؟",
      roman: "Taqatwar momin aur kamzor momin ke mutalliq Hadees-e-Pak kya hai?"
    },
    options: {
      en: [
        "The strong believer is better and more beloved to Allah, though there is good in both",
        "The weak believer has no reward",
        "Physical strength is discouraged",
        "Only scholars can be strong"
      ],
      ur: [
        "طاقتور مومن اللہ کو زیادہ محبوب اور بہتر ہے، اگرچہ دونوں میں خیر ہے",
        "کمزور مومن کا کوئی اجر نہیں",
        "جسمانی طاقت ناپسندیدہ ہے",
        "صرف علماء طاقتور ہیں"
      ],
      roman: [
        "Taqatwar momin Allah ko zyada mehboob hai, halanke dono mein khair hai",
        "Kamzor momin ka ajar nahi",
        "Taqat buri cheez hai",
        "Sirf ulema taqatwar hain"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 46, Hadith 6774)",
      ur: "صحیح مسلم، کتاب القدر، حدیث ۶۷۷۴",
      roman: "Sahih Muslim, Hadith 6774"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'The strong believer is better and more beloved to Allah than the weak believer, while there is good in both.'",
      ur: "رسول کریم ﷺ نے فرمایا: طاقتور مومن اللہ کے نزدیک کمزور مومن سے بہتر اور زیادہ محبوب ہے اور دونوں میں خیر ہے۔",
      roman: "Al-Mu'minul-qawiyyu khayrun wa ahabbu ilallahi minal-mu'minid-da'eef."
    }
  }
];
