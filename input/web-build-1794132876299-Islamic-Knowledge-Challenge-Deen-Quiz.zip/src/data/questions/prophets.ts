import { Question } from '../../types/quiz';

export const prophetsQuestions: Question[] = [
  {
    id: 501,
    categoryId: 5,
    difficulty: 'easy',
    question: {
      en: "Who was the first human being and the first Prophet of Allah created from clay?",
      ur: "اللہ تعالیٰ کے حکم سے مٹی سے پیدا ہونے والے سب سے پہلے انسان اور پہلے نبی کون تھے؟",
      roman: "Mitti se paida hone wale pehle insaan aur pehle Nabi kon the?"
    },
    options: {
      en: ["Hazrat Adam (AS)", "Hazrat Nuh (AS)", "Hazrat Ibrahim (AS)", "Hazrat Idris (AS)"],
      ur: ["حضرت آدم علیہ السلام", "حضرت نوح علیہ السلام", "حضرت ابراہیم علیہ السلام", "حضرت ادریس علیہ السلام"],
      roman: ["Hazrat Adam (A.S)", "Hazrat Nuh (A.S)", "Hazrat Ibrahim (A.S)", "Hazrat Idris (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Baqarah (2:30-34)",
      ur: "سورۃ البقرہ، آیات ۳۰ تا ۳۴",
      roman: "Surah Al-Baqarah, Ayahs 30-34"
    },
    explanation: {
      en: "Allah fashioned Hazrat Adam (AS) as the father of humanity (Abu al-Bashar) and commanded the angels to prostrate to him.",
      ur: "اللہ تعالیٰ نے حضرت آدم علیہ السلام کو مٹی سے تخلیق فرمایا اور فرشتوں کو ان کے آگے سجدہ تعظیمی کا حکم دیا۔",
      roman: "Hazrat Adam (A.S) pehle insaan aur pehle Nabi hain."
    }
  },
  {
    id: 502,
    categoryId: 5,
    difficulty: 'easy',
    question: {
      en: "Which Prophet is known as 'Khalilullah' (The Intimate Friend of Allah)?",
      ur: "کس جلیل القدر پیغمبر کو 'خلیل اللہ' (اللہ کا گہرا دوست) کا لقب حاصل ہے؟",
      roman: "Kis pyare paighambar ko 'Khalilullah' ka laqab hasil hai?"
    },
    options: {
      en: ["Hazrat Ibrahim (AS)", "Hazrat Musa (AS)", "Hazrat Isa (AS)", "Hazrat Dawud (AS)"],
      ur: ["حضرت ابراہیم علیہ السلام", "حضرت موسیٰ علیہ السلام", "حضرت عیسیٰ علیہ السلام", "حضرت داؤد علیہ السلام"],
      roman: ["Hazrat Ibrahim (A.S)", "Hazrat Musa (A.S)", "Hazrat Isa (A.S)", "Hazrat Dawud (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah An-Nisa (4:125)",
      ur: "سورۃ النساء، آیت ۱۲۵: 'وَاتَّخَذَ اللَّهُ إِبْرَاهِيمَ خَلِيلًا'",
      roman: "Surah An-Nisa, Ayah 125"
    },
    explanation: {
      en: "Allah states in the Quran: 'And Allah took Ibrahim as an intimate friend' (Khalil).",
      ur: "قرآن مجید میں فرمایا گیا کہ اللہ نے ابراہیم علیہ السلام کو اپنا خلیل بنایا۔",
      roman: "Hazrat Ibrahim (A.S) ko Quran mein 'Khalilullah' farmaya gaya hai."
    }
  },
  {
    id: 503,
    categoryId: 5,
    difficulty: 'easy',
    question: {
      en: "Which Prophet built the Ark (Fulk) by Allah's inspiration to survive the Great Deluge?",
      ur: "اللہ کے حکم سے کس پیغمبر نے عظیم طوفان سے بچاؤ کے لیے عظیم الشان کشتی (سفینہ) تیار فرمائی؟",
      roman: "Kis Nabi ne tufaan se bachne ke liye azeem kashti (Ark) banayi thi?"
    },
    options: {
      en: ["Hazrat Nuh (AS)", "Hazrat Hud (AS)", "Hazrat Salih (AS)", "Hazrat Lut (AS)"],
      ur: ["حضرت نوح علیہ السلام", "حضرت ہود علیہ السلام", "حضرت صالح علیہ السلام", "حضرت لوط علیہ السلام"],
      roman: ["Hazrat Nuh (A.S)", "Hazrat Hud (A.S)", "Hazrat Salih (A.S)", "Hazrat Lut (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Hud (11:37-38)",
      ur: "سورۃ ہود، آیات ۳۷ تا ۳۸",
      roman: "Surah Hud, Ayahs 37-38"
    },
    explanation: {
      en: "Hazrat Nuh (AS) preached for 950 years and constructed the Ark upon Mount Judi as instructed by Allah.",
      ur: "حضرت نوح علیہ السلام نے ساڑھے نو سو سال دعوت دی اور اللہ کی وحی سے کشتی تعمیر فرمائی جو کوہِ جودی پر ٹھہری۔",
      roman: "Hazrat Nuh (A.S) ne 950 saal dawat di aur kashti banayi."
    }
  },
  {
    id: 504,
    categoryId: 5,
    difficulty: 'medium',
    question: {
      en: "Which Prophet spoke directly to Allah without the medium of an angel at Mount Tur, earning the title 'Kalimullah'?",
      ur: "کس پیغمبر نے کوہِ طور پر فرشتہ کے واسطے کے بغیر براہِ راست کلامِ الٰہی کا شرف پایا اور 'کلیم اللہ' کہلائے؟",
      roman: "Kis Nabi ne Koh-e-Toor par baghair farishte ke Allah se kalaam kiya aur 'Kaleemullah' kehlaye?"
    },
    options: {
      en: ["Hazrat Musa (AS)", "Hazrat Harun (AS)", "Hazrat Isa (AS)", "Hazrat Yahya (AS)"],
      ur: ["حضرت موسیٰ علیہ السلام", "حضرت ہارون علیہ السلام", "حضرت عیسیٰ علیہ السلام", "حضرت یحییٰ علیہ السلام"],
      roman: ["Hazrat Musa (A.S)", "Hazrat Harun (A.S)", "Hazrat Isa (A.S)", "Hazrat Yahya (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah An-Nisa (4:164)",
      ur: "سورۃ النساء، آیت ۱۶۴: 'وَكَلَّمَ اللَّهُ مُوسَىٰ تَكْلِيمًا'",
      roman: "Surah An-Nisa, Ayah 164"
    },
    explanation: {
      en: "Allah says in the Quran: 'And to Musa Allah spoke directly' (Takleema), hence he is titled Kalimullah.",
      ur: "اللہ تعالیٰ نے قرآن میں گواہی دی کہ اللہ نے موسیٰ علیہ السلام سے کلام فرمایا۔",
      roman: "Hazrat Musa (A.S) ko 'Kalimullah' kaha jata hai kyunki unhon ne Allah se kalaam kiya."
    }
  },
  {
    id: 505,
    categoryId: 5,
    difficulty: 'medium',
    question: {
      en: "Which Prophet was swallowed by a massive whale (Hut) and called upon Allah from the depths of darkness?",
      ur: "کون سے پیغمبر مچھلی کے پیٹ میں گئے اور تاریکیوں میں اللہ تعالیٰ کو پکارا؟",
      roman: "Konsay Nabi machhli ke pait mein gaye aur tareekiyon mein Allah ko pukara?"
    },
    options: {
      en: ["Hazrat Yunus (AS) / Dhun-Nun", "Hazrat Ayyub (AS)", "Hazrat Zakariyya (AS)", "Hazrat Ilyas (AS)"],
      ur: ["حضرت یونس علیہ السلام (ذو النون)", "حضرت ایوب علیہ السلام", "حضرت زکریا علیہ السلام", "حضرت الیاس علیہ السلام"],
      roman: ["Hazrat Yunus (A.S) / Dhun-Noon", "Hazrat Ayyub (A.S)", "Hazrat Zakariyya (A.S)", "Hazrat Ilyas (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Anbiya (21:87)",
      ur: "سورۃ الانبیاء، آیت ۸۷",
      roman: "Surah Al-Anbiya, Ayah 87"
    },
    explanation: {
      en: "Hazrat Yunus (AS) called from the whale's belly: 'La ilaha illa Anta, Subhanaka inni kuntu minaz-zalimeen', and Allah rescued him.",
      ur: "حضرت یونس علیہ السلام نے مچھلی کے پیٹ میں آیت کریمہ 'لا إله إلا أنت سبحانك إني كنت من الظالمين' کا ورد کیا۔",
      roman: "Hazrat Yunus (A.S) ne machhli ke pait mein Ayat-e-Kareema parhi aur nijaat payi."
    }
  },
  {
    id: 506,
    categoryId: 5,
    difficulty: 'medium',
    question: {
      en: "Which Prophet was gifted with the ability to understand the language of birds, animals, and jinns, and ruled an empire with wind subservient to him?",
      ur: "کس نبی کو پرندوں، جانوروں اور جنات کی زبان سمجھنے اور ہواؤں پر تصرف کی بے مثال بادشاہت دی گئی؟",
      roman: "Kis Nabi ko parindon, janwaron ki zuban samajhne aur hawaon par hukumat di gayi?"
    },
    options: {
      en: ["Hazrat Sulaiman (AS)", "Hazrat Dawud (AS)", "Hazrat Yusuf (AS)", "Hazrat Shuaib (AS)"],
      ur: ["حضرت سلیمان علیہ السلام", "حضرت داؤد علیہ السلام", "حضرت یوسف علیہ السلام", "حضرت شعیب علیہ السلام"],
      roman: ["Hazrat Sulaiman (A.S)", "Hazrat Dawud (A.S)", "Hazrat Yusuf (A.S)", "Hazrat Shuaib (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah An-Naml (27:16) & Surah Saba",
      ur: "سورۃ النمل، آیت ۱۶: 'عُلِّمْنَا مَنْطِقَ الطَّيْرِ'",
      roman: "Surah An-Naml, Ayah 16"
    },
    explanation: {
      en: "Hazrat Sulaiman (AS), son of Prophet Dawud (AS), was granted miracles including understanding animal speech, command of jinn, and copper springs.",
      ur: "حضرت سلیمان علیہ السلام نے فرمایا: ہمیں پرندوں کی بولی سکھائی گئی اور ہر چیز میں سے حصہ دیا گیا۔",
      roman: "Hazrat Sulaiman (A.S) ko parindon ki zuban aur jinnaat par hukumat di gayi."
    }
  },
  {
    id: 507,
    categoryId: 5,
    difficulty: 'hard',
    question: {
      en: "Which Prophet is celebrated in the Quran for his extraordinary patience (Sabr) during years of severe illness and loss of wealth and family?",
      ur: "قرآن مجید میں شدید ترین بیماری اور مال و اولاد کے امتحان پر کس نبی کا صبر ضرب المثل بنا؟",
      roman: "Shadeed beemari aur aazmaish par sabr ke liye kis Nabi ka zikr Quran mein aya hai?"
    },
    options: {
      en: ["Hazrat Ayyub (AS)", "Hazrat Yaqub (AS)", "Hazrat Nuh (AS)", "Hazrat Lut (AS)"],
      ur: ["حضرت ایوب علیہ السلام (صبرِ ایوب)", "حضرت یعقوب علیہ السلام", "حضرت نوح علیہ السلام", "حضرت لوط علیہ السلام"],
      roman: ["Hazrat Ayyub (A.S)", "Hazrat Yaqub (A.S)", "Hazrat Nuh (A.S)", "Hazrat Lut (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Sad (38:44)",
      ur: "سورۃ ص، آیت ۴۴: 'إِنَّا وَجَدْنَاهُ صَابِرًا نِعْمَ الْعَبْدُ إِنَّهُ أَوَّابٌ'",
      roman: "Surah Sad, Ayah 44"
    },
    explanation: {
      en: "Allah praised Prophet Ayyub (AS): 'Indeed, We found him patient, an excellent servant; indeed, he was one repeatedly turning to Allah.'",
      ur: "اللہ تعالیٰ نے حضرت ایوب علیہ السلام کے بارے میں گواہی دی: 'بیشک ہم نے انہیں صابر پایا، کیا ہی خوب بندہ تھا۔'",
      roman: "Allah Ta'ala ne Hazrat Ayyub (A.S) ko sabr karne wala behtareen banda farmaya."
    }
  },
  {
    id: 508,
    categoryId: 5,
    difficulty: 'hard',
    question: {
      en: "Which Surah in the Holy Quran is entirely dedicated to the life story of a Prophet and described by Allah as 'Ahsan al-Qasas' (The Best of Stories)?",
      ur: "کس سورۃ مبارکہ کو اللہ تعالیٰ نے قرآن میں 'احسن القصص' (سب سے خوبصورت ترین قصہ) قرار دیا ہے؟",
      roman: "Kis Surah ko Allah ne 'Ahsan al-Qasas' (behtareen qissa) farmaya hai?"
    },
    options: {
      en: ["Surah Yusuf", "Surah Maryam", "Surah Hud", "Surah Al-Qasas"],
      ur: ["سورۃ یوسف", "سورۃ مریم", "سورۃ ہود", "سورۃ القصص"],
      roman: ["Surah Yusuf", "Surah Maryam", "Surah Hud", "Surah Al-Qasas"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Yusuf (12:3)",
      ur: "سورۃ یوسف، آیت ۳: 'نَحْنُ نَقُصُّ عَلَيْكَ أَحْسَنَ الْقَصَصِ'",
      roman: "Surah Yusuf, Ayah 3"
    },
    explanation: {
      en: "Surah Yusuf recounts the dreams, trials, enslavement, chastity, and royal ascension of Prophet Yusuf (AS) with profound moral lessons.",
      ur: "سورۃ یوسف میں حضرت یوسف علیہ السلام کے کنویں سے مصر کے تخت تک پہنچنے اور عفو و درگزر کا سبق آموز واقعہ ہے۔",
      roman: "Surah Yusuf ko Quran mein 'Ahsan al-Qasas' kaha gaya hai."
    }
  },
  {
    id: 509,
    categoryId: 5,
    difficulty: 'hard',
    question: {
      en: "Which Prophet was miraculously born without a biological father to the virgin Sayyida Maryam (AS)?",
      ur: "سیدہ مریم علیہا السلام کی گود میں بغیر باپ کے معجزانہ طور پر کون سے برگزیدہ رسول پیدا ہوئے؟",
      roman: "Sayyida Maryam (A.S) ke haan baghair baap ke mojazaati tor par konse Nabi paida hue?"
    },
    options: {
      en: ["Hazrat Isa (Jesus) AS", "Hazrat Yahya (John) AS", "Hazrat Zakariyya AS", "Hazrat Musa AS"],
      ur: ["حضرت عیسیٰ علیہ السلام (مسیح ابن مریم)", "حضرت یحییٰ علیہ السلام", "حضرت زکریا علیہ السلام", "حضرت موسیٰ علیہ السلام"],
      roman: ["Hazrat Isa (A.S)", "Hazrat Yahya (A.S)", "Hazrat Zakariyya (A.S)", "Hazrat Musa (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Maryam (19:19-21) & Surah Al-Imran (3:45-47)",
      ur: "سورۃ مریم آیات ۱۹ تا ۲۱، سورۃ آل عمران آیت ۴۷",
      roman: "Surah Maryam 19-21"
    },
    explanation: {
      en: "Hazrat Isa (AS) was created by Allah's word ('Kun' - Be) and given miracles including speaking in infancy and healing the blind and leper by Allah's leave.",
      ur: "حضرت عیسیٰ علیہ السلام اللہ کے کلمہ 'کُن' سے پیدا ہوئے اور انہوں نے گہوارے میں کلام فرما کر والدہ کی پاکدامنی ثابت کی۔",
      roman: "Hazrat Isa (A.S) Allah ke hukum se baghair baap ke paida hue."
    }
  },
  {
    id: 510,
    categoryId: 5,
    difficulty: 'expert',
    question: {
      en: "Which Prophet is known by the Hebrew and Quranic title 'Israil' (Servant of God), after whom Bani Isra'il are named?",
      ur: "کن پیغمبر کا لقب مبارک 'اسرائیل' (عبد اللہ / اللہ کا بندہ) تھا جن کی نسبت سے قوم 'بنی اسرائیل' کہلائی؟",
      roman: "Kis Nabi ka laqab 'Isra'il' tha jinki aulad Bani Isra'il kehlayi?"
    },
    options: {
      en: ["Hazrat Yaqub (Jacob) AS", "Hazrat Ishaq (Isaac) AS", "Hazrat Yusuf (Joseph) AS", "Hazrat Ibrahim AS"],
      ur: ["حضرت یعقوب علیہ السلام", "حضرت اسحاق علیہ السلام", "حضرت یوسف علیہ السلام", "حضرت ابراہیم علیہ السلام"],
      roman: ["Hazrat Yaqub (A.S)", "Hazrat Ishaq (A.S)", "Hazrat Yusuf (A.S)", "Hazrat Ibrahim (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Imran (3:93) & Surah Maryam (19:58)",
      ur: "سورۃ آل عمران آیت ۹۳، سورۃ مریم آیت ۵۸",
      roman: "Surah Al-Imran 93, Surah Maryam 58"
    },
    explanation: {
      en: "Hazrat Yaqub (AS), son of Ishaq (AS) and grandson of Ibrahim (AS), is Israil whose 12 sons fathered the 12 tribes.",
      ur: "حضرت یعقوب علیہ السلام کا لقب اسرائیل تھا، اور ان کے بارہ بیٹوں سے بنی اسرائیل کے بارہ قبائل وجود میں آئے۔",
      roman: "Hazrat Yaqub (A.S) ka laqab Isra'il tha aur unke 12 bete the."
    }
  },
  {
    id: 511,
    categoryId: 5,
    difficulty: 'expert',
    question: {
      en: "To which ancient Arabian people was Prophet Hud (AS) sent with the message of Tawheed?",
      ur: "حضرت ہود علیہ السلام کو کس قدیم اور طاقتور عرب قوم کی طرف مبعوث فرمایا گیا تھا؟",
      roman: "Hazrat Hud (A.S) ko kis qadeem Arab qoum ki taraf bheja gaya tha?"
    },
    options: {
      en: ["The People of 'Ad ( قوم عاد )", "The People of Thamud", "The People of Madyan", "The People of Ar-Rass"],
      ur: ["قومِ عاد", "قومِ ثمود", "اہلِ مدین", "اصحاب الرس"],
      roman: ["Qoum-e-Aad", "Qoum-e-Samood", "Ahl-e-Madyan", "As-hab ar-Rass"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Hud (11:50)",
      ur: "سورۃ ہود، آیت ۵۰: 'وَإِلَىٰ عَادٍ أَخَاهُمْ هُودًا'",
      roman: "Surah Hud, Ayah 50"
    },
    explanation: {
      en: "Allah sent Prophet Hud (AS) to 'Ad, who were endowed with giant stature and built lofty pillars (Iram) in Al-Ahqaf.",
      ur: "قومِ عاد احقاف کے ریتلے علاقوں میں رہتی تھی اور اپنی بے مثال جسمانی طاقت اور ستونوں والی عمارتوں پر مغرور تھی۔",
      roman: "Hazrat Hud (A.S) Qoum-e-Aad ki taraf maboos hue."
    }
  },
  {
    id: 512,
    categoryId: 5,
    difficulty: 'expert',
    question: {
      en: "To which people was Prophet Salih (AS) sent, for whom a miraculous she-camel emerged from the rock as a sign?",
      ur: "کس قوم کی طرف حضرت صالح علیہ السلام بھیجے گئے جن کے لیے چٹان سے زندہ اونٹنی (ناقۃ اللہ) ظاہر ہوئی؟",
      roman: "Hazrat Salih (A.S) kis qoum ki taraf bheje gaye jahan pahaad se oontni nikli?"
    },
    options: {
      en: ["The People of Thamud ( قوم ثمود )", "The People of 'Ad", "The People of Lut", "The People of Saba"],
      ur: ["قومِ ثمود", "قومِ عاد", "قومِ لوط", "قومِ سبا"],
      roman: ["Qoum-e-Samood", "Qoum-e-Aad", "Qoum-e-Lut", "Qoum-e-Saba"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-A'raf (7:73)",
      ur: "سورۃ الاعراف، آیت ۷۳: 'وَإِلَىٰ ثَمُودَ أَخَاهُمْ صَالِحًا'",
      roman: "Surah Al-A'raf, Ayah 73"
    },
    explanation: {
      en: "Thamud carved dwellings into rocky mountains at Al-Hijr (Mada'in Salih) and were destroyed when they hamstrung the miracle she-camel.",
      ur: "قوم ثمود نے پہاڑوں کو تراش کر گھر بنائے اور جب انہوں نے اللہ کی اونٹنی کو قتل کیا تو ہولناک چنگھاڑ کے ذریعے ہلاک کر دیے گئے۔",
      roman: "Hazrat Salih (A.S) Qoum-e-Samood ki taraf bheje gaye the."
    }
  },
  {
    id: 513,
    categoryId: 5,
    difficulty: 'easy',
    question: {
      en: "Which son did Prophet Ibrahim (AS) take to sacrifice in the plain of Mina in obedience to Allah's divine dream?",
      ur: "خوابِ الٰہی کے حکم کی تعمیل میں حضرت ابراہیم علیہ السلام نے کس فرزندِ ارجمند کو قربانی کے لیے پیش فرمایا؟",
      roman: "Hazrat Ibrahim (A.S) ne kis bete ki qurbani ka hukum pura karne ki koshish ki?"
    },
    options: {
      en: ["Hazrat Ismail (Ishmael) AS", "Hazrat Ishaq (Isaac) AS", "Hazrat Yaqub AS", "Hazrat Yusuf AS"],
      ur: ["حضرت اسماعیل علیہ السلام (ذبیح اللہ)", "حضرت اسحاق علیہ السلام", "حضرت یعقوب علیہ السلام", "حضرت یوسف علیہ السلام"],
      roman: ["Hazrat Ismail (A.S) / Zabeehullah", "Hazrat Ishaq (A.S)", "Hazrat Yaqub (A.S)", "Hazrat Yusuf (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah As-Saffat (37:101-107)",
      ur: "سورۃ الصافات، آیات ۱۰۱ تا ۱۰۷",
      roman: "Surah As-Saffat, Ayahs 101-107"
    },
    explanation: {
      en: "Hazrat Ismail (AS) willingly submitted to the sacrifice, and Allah ransomed him with a noble ram, establishing the Sunnah of Eid al-Adha.",
      ur: "حضرت اسماعیل علیہ السلام نے بخوشی فرمایا: 'اے اباجان! آپ کو جو حکم دیا گیا ہے کر گزریے'۔ اللہ نے دنبہ فدیہ میں دیا۔",
      roman: "Hazrat Ismail (A.S) ne qurbani par sabr kiya aur Allah ne jannati dumba fidiya diya."
    }
  },
  {
    id: 514,
    categoryId: 5,
    difficulty: 'medium',
    question: {
      en: "Which divine scripture was revealed to Prophet Dawud (David) AS?",
      ur: "اللہ تعالیٰ نے حضرت داؤد علیہ السلام پر کون سی آسمانی کتاب نازل فرمائی تھی؟",
      roman: "Allah Ta'ala ne Hazrat Dawud (A.S) par konsi aasmani kitab nazil farmayi?"
    },
    options: {
      en: ["Zabur (Psalms)", "Tawrat (Torah)", "Injeel (Gospel)", "Suhuf Ibrahim"],
      ur: ["زبور", "تورات", "انجیل", "صحفِ ابراہیم"],
      roman: ["Zaboor", "Tawrat", "Injeel", "Suhuf-e-Ibrahim"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah An-Nisa (4:163)",
      ur: "سورۃ النساء، آیت ۱۶۳: 'وَآتَيْنَا دَاوُودَ زَبُورًا'",
      roman: "Surah An-Nisa, Ayah 163"
    },
    explanation: {
      en: "Allah states in the Quran: 'And to Dawud We gave the Zabur.' Prophet Dawud possessed a beautiful voice that made birds join his praises.",
      ur: "قرآن مجید میں فرمایا گیا: اور ہم نے داؤد علیہ السلام کو زبور عطا فرمائی۔ آپ کی تسبیح کے ساتھ پہاڑ اور پرندے بھی تسبیح کرتے تھے۔",
      roman: "Hazrat Dawud (A.S) par Zaboor nazil hui."
    }
  },
  {
    id: 515,
    categoryId: 5,
    difficulty: 'medium',
    question: {
      en: "Which Prophet was known as 'Khatam an-Nabiyyin' (The Seal of the Prophets), after whom there is no prophet?",
      ur: "قرآن مجید کے مطابق 'خاتم النبیین' (تمام انبیاء کے سلسلے کو ختم فرمانے والے) کون ہیں؟",
      roman: "Quran Majeed ke mutabiq 'Khatam-un-Nabiyyeen' kon hain jinke baad koi nabi nahi aayega?"
    },
    options: {
      en: ["Prophet Muhammad ﷺ", "Hazrat Isa (AS)", "Hazrat Musa (AS)", "Hazrat Ibrahim (AS)"],
      ur: ["حضرت محمد مصطفیٰ ﷺ", "حضرت عیسیٰ علیہ السلام", "حضرت موسیٰ علیہ السلام", "حضرت ابراہیم علیہ السلام"],
      roman: ["Hazrat Muhammad Mustafa ﷺ", "Hazrat Isa (A.S)", "Hazrat Musa (A.S)", "Hazrat Ibrahim (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Ahzab (33:40)",
      ur: "سورۃ الاحزاب، آیت ۴۰: 'وَلَٰكِنْ رَسُولَ اللَّهِ وَخَاتَمَ النَّبِيِّينَ'",
      roman: "Surah Al-Ahzab, Ayah 40"
    },
    explanation: {
      en: "Prophet Muhammad ﷺ is the final Prophet and Messenger sent to all humankind, sealing revelation forever.",
      ur: "نبی کریم ﷺ آخری نبی ہیں جن کے بعد قیامت تک کوئی نیا نبی مبعوث نہیں ہو سکتا، یہ اسلام کا بنیادی عقیدہ ہے۔",
      roman: "Huzoor ﷺ aakhri nabi hain aur Nabuwwat ka silsila aap par mukammal ho chuka."
    }
  },
  {
    id: 516,
    categoryId: 5,
    difficulty: 'hard',
    question: {
      en: "Which Prophet was thrown into a blazing inferno by King Nimrod, but Allah commanded the fire to be cool and peaceful for him?",
      ur: "نمرود بادشاہ نے کس نبی کو دہکتی ہوئی آگ میں پھینکا مگر اللہ نے آگ کو ٹھنڈی اور سلامتی والی بنا دیا؟",
      roman: "Namrood ne kis nabi ko aag mein phenka aur Allah ne aag ko thanda aur salamati bana diya?"
    },
    options: {
      en: ["Hazrat Ibrahim (AS)", "Hazrat Lut (AS)", "Hazrat Zakariyya (AS)", "Hazrat Yahya (AS)"],
      ur: ["حضرت ابراہیم علیہ السلام", "حضرت لوط علیہ السلام", "حضرت زکریا علیہ السلام", "حضرت یحییٰ علیہ السلام"],
      roman: ["Hazrat Ibrahim (A.S)", "Hazrat Lut (A.S)", "Hazrat Zakariyya (A.S)", "Hazrat Yahya (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Anbiya (21:69)",
      ur: "سورۃ الانبیاء، آیت ۶۹: 'قُلْنَا يَا نَارُ كُونِي بَرْدًا وَسَلَامًا عَلَىٰ إِبْرَاهِيمَ'",
      roman: "Surah Al-Anbiya, Ayah 69"
    },
    explanation: {
      en: "Allah commanded the raging fire: 'O fire, be coolness and peace upon Ibrahim', miraculously preserving him untouched.",
      ur: "اللہ تعالیٰ نے آگ کو حکم دیا: 'اے آگ! ابراہیم پر ٹھنڈی اور سلامتی والی ہو جا'۔",
      roman: "Allah ne aag ko hukum diya: Ya naaru koonee bardan wa salaman ala Ibrahim."
    }
  },
  {
    id: 517,
    categoryId: 5,
    difficulty: 'expert',
    question: {
      en: "Which Prophet was known as 'Khatib al-Anbiya' (The Orator of the Prophets) for his eloquence when preaching against cheating in weights and measures in Madyan?",
      ur: "ناپ تول میں کمی کرنے والی قومِ مدین کو فصیح نصیحت فرمانے کی وجہ سے کس نبی کو 'خطیب الانبیاء' کہا جاتا ہے؟",
      roman: "Madyan ke logon ko naap tol ki naseehat karne wale 'Khateeb al-Ambiya' kon the?"
    },
    options: {
      en: ["Hazrat Shuaib (AS)", "Hazrat Salih (AS)", "Hazrat Ilyas (AS)", "Hazrat Al-Yasa (AS)"],
      ur: ["حضرت شعیب علیہ السلام", "حضرت صالح علیہ السلام", "حضرت الیاس علیہ السلام", "حضرت الیسع علیہ السلام"],
      roman: ["Hazrat Shuaib (A.S)", "Hazrat Salih (A.S)", "Hazrat Ilyas (A.S)", "Hazrat Al-Yasa (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-A'raf (7:85) & Tafsir Ibn Kathir",
      ur: "سورۃ الاعراف آیت ۸۵، تفسیر ابن کثیر",
      roman: "Surah Al-A'raf 85"
    },
    explanation: {
      en: "Hazrat Shuaib (AS) called the people of Madyan and Aykah to honest trading and monotheism with unmatched eloquence.",
      ur: "حضرت شعیب علیہ السلام کی فصاحت و بلاغت کی وجہ سے مفسرین نے انہیں خطیب الانبیاء کا لقب دیا ہے۔",
      roman: "Hazrat Shuaib (A.S) ko 'Khateeb al-Ambiya' kaha jata hai."
    }
  },
  {
    id: 518,
    categoryId: 5,
    difficulty: 'medium',
    question: {
      en: "Which young Prophet was granted wisdom and prophethood while still a youth and was martyred for righteousness, son of Prophet Zakariyya (AS)?",
      ur: "حضرت زکریا علیہ السلام کے وہ نیک فرزند کون سے نبی تھے جنہیں بچپن میں ہی حکمت عطا ہوئی؟",
      roman: "Hazrat Zakariyya (A.S) ke farzand konse nabi the jinhein bachpan mein hikmat mili?"
    },
    options: {
      en: ["Hazrat Yahya (John) AS", "Hazrat Isa (AS)", "Hazrat Harun (AS)", "Hazrat Ilyas (AS)"],
      ur: ["حضرت یحییٰ علیہ السلام", "حضرت عیسیٰ علیہ السلام", "حضرت ہارون علیہ السلام", "حضرت الیاس علیہ السلام"],
      roman: ["Hazrat Yahya (A.S)", "Hazrat Isa (A.S)", "Hazrat Harun (A.S)", "Hazrat Ilyas (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Maryam (19:12)",
      ur: "سورۃ مریم، آیت ۱۲: 'وَآتَيْنَاهُ الْحُكْمَ صَبِيًّا'",
      roman: "Surah Maryam, Ayah 12"
    },
    explanation: {
      en: "Allah states: 'And We gave him judgment while yet a boy' (Wa ataynahul-hukma sabiyya).",
      ur: "قرآن پاک میں حضرت یحییٰ علیہ السلام کی پاکیزگی، حلم اور بچپن میں ہی علم و حکمت عطا کیے جانے کی تعریف فرمائی گئی۔",
      roman: "Hazrat Yahya (A.S) ko Allah ne bachpan mein hi hikmat ata farmayi."
    }
  },
  {
    id: 519,
    categoryId: 5,
    difficulty: 'hard',
    question: {
      en: "What was the miraculous spring of pure water that gushed forth in the barren desert of Makkah beneath the infant feet of Hazrat Ismail (AS)?",
      ur: "مکہ مکرمہ کی بے آب و گیاہ وادی میں شیر خوار حضرت اسماعیل علیہ السلام کی ایڑیوں کے نیچے سے کون سا معجزاتی چشمہ جاری ہوا؟",
      roman: "Hazrat Ismail (A.S) ke qadmon tale Makkah mein konsa mojezati chashma phoota?"
    },
    options: {
      en: ["Well of Zamzam", "Salsabil", "Kawthar", "Kafur"],
      ur: ["آبِ زمزم (چشمہ زمزم)", "سلسبیل", "کوثر", "کافور"],
      roman: ["Zamzam Ka Chashma", "Salsabeel", "Kawthar", "Kafoor"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 60, Hadith 583)",
      ur: "صحیح بخاری، احادیث الانبیاء، حدیث ۵۸۳",
      roman: "Sahih Bukhari, Hadith 583"
    },
    explanation: {
      en: "Hazrat Hajirah ran between Safa and Marwah searching for water, and Angel Jibreel struck the earth, causing Zamzam to flow perpetually.",
      ur: "حضرت ہاجرہ رضی اللہ عنہا صفا اور مروہ کے درمیان دوڑیں، پھر جبرائیل علیہ السلام نے زمین پر ضرب لگائی اور زمزم ابل پڑا۔",
      roman: "Aab-e-Zamzam Hazrat Hajirah aur Ismail (A.S) ke waqie se shuru hua."
    }
  },
  {
    id: 520,
    categoryId: 5,
    difficulty: 'expert',
    question: {
      en: "Which Prophet was granted the miracle of iron becoming malleable like wax in his hands?",
      ur: "کس پیغمبر کے دستِ مبارک میں لوہا موم کی طرح نرم ہو جاتا تھا اور وہ زرہیں بناتے تھے؟",
      roman: "Kis Nabi ke haath mein loha mom ki tarah narm ho jata tha?"
    },
    options: {
      en: ["Hazrat Dawud (David) AS", "Hazrat Sulaiman (AS)", "Hazrat Idris (AS)", "Hazrat Dhul-Kifl (AS)"],
      ur: ["حضرت داؤد علیہ السلام", "حضرت سلیمان علیہ السلام", "حضرت ادریس علیہ السلام", "حضرت ذوالکفل علیہ السلام"],
      roman: ["Hazrat Dawud (A.S)", "Hazrat Sulaiman (A.S)", "Hazrat Idris (A.S)", "Hazrat Dhul-Kifl (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Saba (34:10)",
      ur: "سورۃ سبا، آیت ۱۰: 'وَأَلَنَّا لَهُ الْحَدِيدَ'",
      roman: "Surah Saba, Ayah 10"
    },
    explanation: {
      en: "Allah says in Surah Saba: 'And We made iron soft for him', allowing him to weave protective chainmail armour with his hands.",
      ur: "اللہ تعالیٰ نے ارشاد فرمایا: اور ہم نے ان کے لیے لوہے کو نرم کر دیا۔ آپ علیہ السلام ہاتھ سے دفاعی زرہیں بناتے تھے۔",
      roman: "Allah ne farmaya: Wa alanna lahul-hadeed (Aur humne unke liye lohe ko narm kar diya)."
    }
  },
  {
    id: 521,
    categoryId: 5,
    difficulty: 'easy',
    question: {
      en: "How many Prophets and Messengers are mentioned by name in the Holy Quran?",
      ur: "قرآن مجید میں کل کتنے انبیائے کرام علیہم السلام کے اسمائے گرامی نام بنام مذکور ہیں؟",
      roman: "Quran Majeed mein kul kitne Ambiya-e-Kiram ke naam aaye hain?"
    },
    options: {
      en: ["25 Prophets", "12 Prophets", "40 Prophets", "100 Prophets"],
      ur: ["۲۵ انبیائے کرام", "۱۲ انبیاء", "۴۰ انبیاء", "۱۰۰ انبیاء"],
      roman: ["25 Ambiya", "12 Ambiya", "40 Ambiya", "100 Ambiya"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tafsir Ibn Kathir (Surah Al-An'am 6:83-86)",
      ur: "تفسیر ابن کثیر، سورۃ الانعام آیات ۸۳ تا ۸۶",
      roman: "Tafsir Ibn Kathir, Surah Al-An'am"
    },
    explanation: {
      en: "Exactly 25 Prophets and Messengers are mentioned by name in the Quran, from Adam to Muhammad ﷺ.",
      ur: "قرآن پاک میں صراحت کے ساتھ ۲۵ انبیائے کرام کے نام مبارک آئے ہیں۔",
      roman: "Quran Majeed mein 25 Ambiya-e-Kiram ke naam ba-qayeda zikr hain."
    }
  },
  {
    id: 522,
    categoryId: 5,
    difficulty: 'expert',
    question: {
      en: "Who were the five great Arch-Prophets of firm resolve mentioned as 'Ulul-'Azm' in the Quran?",
      ur: "قرآن مجید میں اولوالعزم رسولوں کی جماعت کن پانچ جلیل القدر پیغمبروں پر مشتمل ہے؟",
      roman: "Quran mein 'Ulul-Azm' kin 5 azeem tareen Rasoolon ko kaha gaya hai?"
    },
    options: {
      en: [
        "Nuh, Ibrahim, Musa, Isa, and Muhammad ﷺ",
        "Adam, Nuh, Ibrahim, Ismail, and Ishaq",
        "Dawud, Sulaiman, Yusuf, Yunus, and Ayyub",
        "Idris, Hud, Salih, Shuaib, and Lut"
      ],
      ur: [
        "حضرت نوح، حضرت ابراہیم، حضرت موسیٰ، حضرت عیسیٰ اور حضرت محمد ﷺ",
        "حضرت آدم، نوح، ابراہیم، اسماعیل اور اسحاق",
        "حضرت داؤد، سلیمان، یوسف، یونس اور ایوب",
        "حضرت ادریس، ہود، صالح، شعیب اور لوط"
      ],
      roman: [
        "Nuh, Ibrahim, Musa, Isa, aur Muhammad ﷺ",
        "Adam, Nuh, Ibrahim, Ismail, Ishaq",
        "Dawud, Sulaiman, Yusuf, Yunus, Ayyub",
        "Idris, Hud, Salih, Shuaib, Lut"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Ahqaf (46:35) & Surah Al-Ahzab (33:7)",
      ur: "سورۃ الاحقاف آیت ۳۵ اور سورۃ الاحزاب آیت ۷",
      roman: "Surah Al-Ahqaf 35, Surah Al-Ahzab 7"
    },
    explanation: {
      en: "The Ulul-'Azm (Prophets of Firm Resolve) bore the heaviest trials with steadfast patience: Nuh, Ibrahim, Musa, Isa, and Muhammad ﷺ.",
      ur: "قرآن نے فرمایا: 'فَاصْبِرْ كَمَا صَبَرَ أُولُو الْعَزْمِ مِنَ الرُّسُلِ'۔ یہ پانچوں عظیم ترین آزمائشوں پر ثابت قدم رہے۔",
      roman: "Ulul-Azm Ambiya mein Nuh, Ibrahim, Musa, Isa aur Muhammad ﷺ shamil hain."
    }
  }
];
