import { Question } from '../../types/quiz';

export const historyQuestions: Question[] = [
  {
    id: 401,
    categoryId: 4,
    difficulty: 'easy',
    question: {
      en: "Who was the first Caliph of Islam (Khalifat ar-Rasul) after the Prophet's ﷺ demise?",
      ur: "وصالِ نبوی ﷺ کے بعد مسلمانوں کے پہلے خلیفہ راشد کون منتخب ہوئے؟",
      roman: "Wisal-e-Nabawi ke baad musalmanon ke pehle Khalifa-e-Rashid kon muntakhab hue?"
    },
    options: {
      en: ["Hazrat Abu Bakr As-Siddiq (RA)", "Hazrat Umar Farooq (RA)", "Hazrat Uthman Ghani (RA)", "Hazrat Ali Al-Murtaza (RA)"],
      ur: ["حضرت ابوبکر صدیق رضی اللہ عنہ", "حضرت عمر فاروق رضی اللہ عنہ", "حضرت عثمان غنی رضی اللہ عنہ", "حضرت علی المرتضیٰ رضی اللہ عنہ"],
      roman: ["Hazrat Abu Bakr As-Siddiq (R.A)", "Hazrat Umar Farooq (R.A)", "Hazrat Uthman Ghani (R.A)", "Hazrat Ali Al-Murtaza (R.A)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 62, Hadith 19)",
      ur: "صحیح بخاری، فضائل ابی بکر، حدیث ۱۹",
      roman: "Sahih Bukhari, Fazail Abu Bakr 19"
    },
    explanation: {
      en: "Hazrat Abu Bakr (RA) was pledged allegiance at Saqifah Bani Sa'idah and led the Ummah with wisdom and resolve from 11-13 AH.",
      ur: "سقیفہ بنی ساعدہ میں بیعت کے بعد حضرت ابوبکر صدیق رضی اللہ عنہ خلیفہ اول بنے اور امت کو فتنوں سے بچایا۔",
      roman: "Hazrat Abu Bakr (R.A) musalmanon ke pehle Khalifa-e-Rashid the."
    }
  },
  {
    id: 402,
    categoryId: 4,
    difficulty: 'easy',
    question: {
      en: "Which Caliph conquered Jerusalem (Bait al-Maqdis) peacefully in 637 CE (16 AH) and granted religious freedom to Christians?",
      ur: "کس خلیفہ راشد کے دور میں ۱۶ ہجری میں بیت المقدس بغیر جنگ کے فتح ہوا اور عیسائیوں کو امان دی گئی؟",
      roman: "Kis Khalifa-e-Rashid ke daur mein 16 Hijri mein Bait-ul-Muqaddas fatah hua?"
    },
    options: {
      en: ["Hazrat Umar ibn Al-Khattab (RA)", "Hazrat Abu Bakr (RA)", "Hazrat Uthman (RA)", "Hazrat Ali (RA)"],
      ur: ["حضرت عمر بن خطاب رضی اللہ عنہ", "حضرت ابوبکر صدیق رضی اللہ عنہ", "حضرت عثمان غنی رضی اللہ عنہ", "حضرت علی رضی اللہ عنہ"],
      roman: ["Hazrat Umar bin Al-Khattab (R.A)", "Hazrat Abu Bakr", "Hazrat Uthman", "Hazrat Ali"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh at-Tabari & Al-Bidayah wan-Nihayah",
      ur: "تاریخ طبری و البدایہ والنہایہ، فتح بیت المقدس و معاہدہ عمر",
      roman: "Tarikh at-Tabari, Fath Bait al-Maqdis"
    },
    explanation: {
      en: "Hazrat Umar (RA) travelled in person to receive the keys from Patriarch Sophronius and wrote the famous Treaty of Umar protecting churches and lives.",
      ur: "حضرت عمر رضی اللہ عنہ نے خود بیت المقدس تشریف لے جا کر چابیاں لیں اور عیسائیوں کو جان، مال اور عبادت گاہوں کی امان کا عہد نامہ تحریر فرمایا۔",
      roman: "Hazrat Umar (R.A) ne Bait-ul-Muqaddas fatah kiya aur Tareekhi Ahd-nama likha."
    }
  },
  {
    id: 403,
    categoryId: 4,
    difficulty: 'easy',
    question: {
      en: "During whose Caliphate was the official standardized compilation of the Quran (Mushaf Uthmani) prepared and distributed?",
      ur: "کس خلیفہ راشد کے دور میں قرآن مجید کا مستند اور متفقہ نسخہ (مصحف عثمانی) تیار کر کے تمام بلادِ اسلامیہ میں بھیجا گیا؟",
      roman: "Kis Khalifa-e-Rashid ke daur mein standard Mushaf-e-Usmani tayar kiya gaya?"
    },
    options: {
      en: ["Hazrat Uthman ibn Affan (RA)", "Hazrat Abu Bakr (RA)", "Hazrat Umar (RA)", "Hazrat Mu'awiyah (RA)"],
      ur: ["حضرت عثمان بن عفان رضی اللہ عنہ", "حضرت ابوبکر صدیق رضی اللہ عنہ", "حضرت عمر فاروق رضی اللہ عنہ", "حضرت معاویہ رضی اللہ عنہ"],
      roman: ["Hazrat Uthman bin Affan (R.A)", "Hazrat Abu Bakr", "Hazrat Umar", "Hazrat Mu'awiyah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 66, Hadith 4987)",
      ur: "صحیح بخاری، جمع القرآن، حدیث ۴۹۸۷",
      roman: "Sahih Bukhari, Hadith 4987"
    },
    explanation: {
      en: "Hazrat Uthman (RA) appointed a committee led by Zayd ibn Thabit to produce master copies in the Quraysh dialect, earning him the title 'Jami' al-Quran'.",
      ur: "حضرت عثمان غنی رضی اللہ عنہ نے امت کو ایک قرآت اور رسم الخط پر متحد فرمایا اور نقل کروا کر بڑے مراکز میں نسخے بھجوائے۔",
      roman: "Hazrat Uthman (R.A) ne Quran Pak ko ek rasm-ul-khat par jama farmaya."
    }
  },
  {
    id: 404,
    categoryId: 4,
    difficulty: 'medium',
    question: {
      en: "Where did the fourth Rightly Guided Caliph, Hazrat Ali ibn Abi Talib (RA), establish the administrative capital?",
      ur: "چوتھے خلیفہ راشد حضرت علی المرتضیٰ رضی اللہ عنہ نے دار الخلافہ کس شہر کو بنایا؟",
      roman: "Hazrat Ali (R.A) ne apna dar-ul-khilafa kis shehar ko banaya?"
    },
    options: {
      en: ["Kufa (Iraq)", "Damascus", "Cairo", "Basra"],
      ur: ["کوفہ (عراق)", "دمشق", "قاہرہ", "بصرہ"],
      roman: ["Kufa (Iraq)", "Dimashq", "Qahirah", "Basra"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh al-Khulafa (Imam As-Suyuti)",
      ur: "تاریخ الخلفاء، علامہ جلال الدین سیوطی",
      roman: "Tarikh al-Khulafa, Imam As-Suyuti"
    },
    explanation: {
      en: "Hazrat Ali (RA) shifted the seat of government from Madinah to Kufa due to strategic and regional considerations.",
      ur: "حضرت علی رضی اللہ عنہ نے سیاسی و انتظامی ضرورتوں کے تحت مدینہ منورہ سے دارالخلافہ کوفہ منتقل فرمایا۔",
      roman: "Hazrat Ali (R.A) ne khilafat ka markaz Kufa ko banaya."
    }
  },
  {
    id: 405,
    categoryId: 4,
    difficulty: 'medium',
    question: {
      en: "Who was the legendary Muslim commander who liberated Jerusalem from Crusader rule in 1187 CE after the Battle of Hattin?",
      ur: "۱۱۸۷ء میں معرکہ حطین کے بعد بیت المقدس کو صلیبیوں کے قبضے سے آزاد کرانے والے عظیم مسلم مجاہد کون تھے؟",
      roman: "1187 mein Bait-ul-Muqaddas ko azaad karane wale azeem mujahid kon the?"
    },
    options: {
      en: ["Salahuddin Al-Ayyubi (Saladin)", "Tariq ibn Ziyad", "Mahmud Ghaznavi", "Nur ad-Din Zangi"],
      ur: ["سلطان صلاح الدین ایوبی رحمہ اللہ", "طارق بن زیاد", "محمود غزنوی", "نور الدین زنگی"],
      roman: ["Sultan Salahuddin Ayyubi", "Tariq bin Ziyad", "Mahmud Ghaznavi", "Nooruddin Zangi"]
    },
    correctAnswer: 0,
    reference: {
      en: "Al-Kamil fit-Tarikh (Ibn al-Athir)",
      ur: "الکامل فی التاریخ، فتح القدس و سیرت صلاح الدین",
      roman: "Al-Kamil fit-Tarikh"
    },
    explanation: {
      en: "Sultan Salahuddin Ayyubi recaptured Jerusalem with noble chivalry, pardoning captives and forbidding revenge.",
      ur: "سلطان صلاح الدین ایوبی نے رحم و کرم اور شجاعت کا بے مثال مظاہرہ کرتے ہوئے بیت المقدس کو آزاد کروایا۔",
      roman: "Sultan Salahuddin Ayyubi ne 1187 mein Bait-ul-Muqaddas ko azaad karaya."
    }
  },
  {
    id: 406,
    categoryId: 4,
    difficulty: 'medium',
    question: {
      en: "Which Muslim general led the conquest of the Iberian Peninsula (Spain/Andalusia) in 711 CE, landing at Gibraltar (Jabal Tariq)?",
      ur: "۷۱۱ء میں اسپین (اندلس) فتح کرنے والے مسلمان جرنیل کون تھے جن کے نام پر 'جبل طارق' (جبرالٹر) موسوم ہوا؟",
      roman: "711 mein Spain (Andalusia) fatah karne wale Muslim sipah-salar kon the?"
    },
    options: {
      en: ["Tariq ibn Ziyad", "Musa ibn Nusayr", "Uqbah ibn Nafi", "Amr ibn Al-Aas"],
      ur: ["طارق بن زیاد", "موسیٰ بن نصیر", "عقبہ بن نافع", "عمرو بن العاص"],
      roman: ["Tariq bin Ziyad", "Musa bin Nusayr", "Uqbah bin Nafi", "Amr bin Al-Aas"]
    },
    correctAnswer: 0,
    reference: {
      en: "Nafh at-Tib min Ghusn al-Andalus ar-Ratib (Al-Maqqari)",
      ur: "نفح الطیب من غصن الاندلس الرطیب، فتوحات اندلس",
      roman: "Nafh at-Tib, Fath Andalusia"
    },
    explanation: {
      en: "Tariq ibn Ziyad crossed the strait and landed at the rock named after him: Jabal Tariq (Gibraltar).",
      ur: "طارق بن زیاد نے آبنائے عبور کر کے اندلس فتح کیا اور اس چٹان کا نام ان کے نام پر 'جبل طارق' پڑا۔",
      roman: "Tariq bin Ziyad ne Gibraltar (Jabal Tariq) ke raste Spain fatah kiya."
    }
  },
  {
    id: 407,
    categoryId: 4,
    difficulty: 'hard',
    question: {
      en: "In which year of the Islamic calendar was the Hijrah migration officially adopted as the start of the Hijri calendar under Hazrat Umar (RA)?",
      ur: "امیر المؤمنین حضرت عمر فاروق رضی اللہ عنہ نے کس سن میں صحابہ کے مشورے سے سنِ ہجری کا باضابطہ آغاز فرمایا؟",
      roman: "Hazrat Umar (R.A) ne kis saal Hijri calendar ka aaghaaz farmaya?"
    },
    options: {
      en: ["16 or 17 AH", "10 AH", "20 AH", "25 AH"],
      ur: ["۱۶ یا ۱۷ ہجری", "۱۰ ہجری", "۲۰ ہجری", "۲۵ ہجری"],
      roman: ["16 ya 17 Hijri", "10 Hijri", "20 Hijri", "25 Hijri"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh at-Tabari & Ibn Kathir",
      ur: "تاریخ طبری، ذکر وضع التاریخ الہجری فی عہد عمر",
      roman: "Tarikh at-Tabari, Hijri Calendar"
    },
    explanation: {
      en: "Hazrat Umar (RA) consulted the companions in 16–17 AH and established the Hijrah from Makkah to Madinah as the start of the Islamic calendar.",
      ur: "حضرت عمر فاروق رضی اللہ عنہ نے حضرت علی اور دیگر صحابہ کے مشورے سے رسول اللہ ﷺ کی ہجرت کے سال کو اسلامی تقویم کی بنیاد بنایا۔",
      roman: "Hazrat Umar (R.A) ne 16-17 Hijri mein Hijrat-e-Nabawi se calendar shuru kiya."
    }
  },
  {
    id: 408,
    categoryId: 4,
    difficulty: 'hard',
    question: {
      en: "What was the famous intellectual academy and library founded in Baghdad during the Abbasid Golden Age called?",
      ur: "عباسی سنہری دور میں بغداد میں قائم ہونے والی شہرہ آفاق علمی اکیڈمی اور کتب خانے کا کیا نام تھا؟",
      roman: "Abbasi daur mein Baghdad mein qaim azeem scientific academy ka kya naam tha?"
    },
    options: {
      en: ["Bayt al-Hikmah (House of Wisdom)", "Dar al-Arqam", "Al-Azhar", "Al-Qarawiyyin"],
      ur: ["بیت الحکمت (ہاؤس آف وزڈم)", "دار الارقم", "جامعہ الازہر", "جامعہ قرویین"],
      roman: ["Bayt al-Hikmah (House of Wisdom)", "Dar al-Arqam", "Al-Azhar", "Al-Qarawiyyin"]
    },
    correctAnswer: 0,
    reference: {
      en: "The Venture of Islam (Marshall Hodgson)",
      ur: "تاریخ الخلفاء و تاریخ التمدن الاسلامی",
      roman: "Tarikh al-Khulafa"
    },
    explanation: {
      en: "Bayt al-Hikmah flourished under Caliphs Harun al-Rashid and Al-Ma'mun, spearheading massive translation and original scientific breakthroughs.",
      ur: "بیت الحکمت ہارون الرشید اور مامون الرشید کے دور میں سائنس، طب، فلکیات اور فلسفے کا عالمی مرکز بنا۔",
      roman: "Bayt al-Hikmah Baghdad mein uloom aur science ka azeem markaz tha."
    }
  },
  {
    id: 409,
    categoryId: 4,
    difficulty: 'expert',
    question: {
      en: "In which year did Sultan Mehmed II (Fatih) conquer Constantinople (Istanbul), fulfilling the prophetic prophecy?",
      ur: "سلطان محمد فاتح رحمہ اللہ نے کس سال قسطنطنیہ (استنبول) فتح کر کے بشارتِ نبوی کو پورا کیا؟",
      roman: "Sultan Mehmed Fatih ne kis saal Constantinople (Istanbul) fatah kiya?"
    },
    options: {
      en: ["1453 CE", "1258 CE", "1517 CE", "1099 CE"],
      ur: ["۱۴۵۳ء", "۱۲۵۸ء", "۱۵۱۷ء", "۱۰۹۹ء"],
      roman: ["1453 CE", "1258 CE", "1517 CE", "1099 CE"]
    },
    correctAnswer: 0,
    reference: {
      en: "Musnad Ahmad (Hadith 18977) & Ottoman Chronicles",
      ur: "مسند احمد، حدیث ۱۸۹۷۷: 'لتفتحن القسطنطنية فلنعم الامير اميرها'",
      roman: "Musnad Ahmad, Hadith 18977"
    },
    explanation: {
      en: "On 29 May 1453 CE, Sultan Mehmed Fatih conquered Constantinople at age 21, making it the capital of the Ottoman Sultanate.",
      ur: "۲۹ مئی ۱۴۵۳ء کو ۲۱ سالہ عثمانی سلطان محمد فاتح نے قسطنطنیہ فتح کر کے بازنطینی سلطنت کا خاتمہ کیا۔",
      roman: "1453 mein Sultan Mehmed ne Istanbul fatah kiya."
    }
  },
  {
    id: 410,
    categoryId: 4,
    difficulty: 'expert',
    question: {
      en: "What was the battle in 1260 CE where the Mamluks halted the Mongol expansion into Egypt and the Levant?",
      ur: "۱۲۶۰ء میں وہ کون سا تاریخی معرکہ تھا جس میں مملوکوں نے منگولوں کے ناقابلِ تسخیر طوفان کو شکست دی؟",
      roman: "1260 mein kis marake mein Mamlukon ne Mongol faujon ko shikast di?"
    },
    options: {
      en: ["Battle of Ain Jalut", "Battle of Yarmouk", "Battle of Manzikert", "Battle of Qadisiyyah"],
      ur: ["معرکہ عین جالوت", "معرکہ یرموک", "معرکہ ملازکرد", "معرکہ قادسیہ"],
      roman: ["Battle of Ain Jalut", "Battle of Yarmouk", "Battle of Manzikert", "Battle of Qadisiyyah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Al-Bidayah wan-Nihayah (Ibn Kathir)",
      ur: "البدایہ والنہایہ، حوادث سنہ ۶۵۸ ہجری، معرکہ عین جالوت",
      roman: "Al-Bidayah wan-Nihayah, 658 AH"
    },
    explanation: {
      en: "At Ain Jalut in Palestine, Sultan Saifuddin Qutuz and General Baibars decisively routed the Mongol army, saving Cairo and the Muslim heartlands.",
      ur: "فلسطین کے مقام عین جالوت پر سلطان قطز اور رکن الدین بیبرس نے منگولوں کو تاریخی شکست سے دوچار کیا۔",
      roman: "Ain Jalut ke maidan mein Mongolon ki پیش قدمی روک دی گئی۔"
    }
  },
  {
    id: 411,
    categoryId: 4,
    difficulty: 'easy',
    question: {
      en: "Which righteous Caliph is renowned as 'Umar the Second' for restoring absolute justice during the Umayyad era?",
      ur: "بنو امیہ کے کس خلیفہ کو عدل و انصاف اور زہد کی وجہ سے 'عمر ثانی' کہا جاتا ہے؟",
      roman: "Banu Umayyah ke kis khalifa ko 'Umar Saani' (doosra Umar) kaha jata hai?"
    },
    options: {
      en: ["Hazrat Umar ibn Abd al-Aziz (RA)", "Mu'awiyah ibn Abi Sufyan", "Abdul Malik ibn Marwan", "Walid ibn Abdul Malik"],
      ur: ["حضرت عمر بن عبدالعزیز رحمہ اللہ", "حضرت معاویہ بن ابی سفیان", "عبدالملک بن مروان", "ولید بن عبدالملک"],
      roman: ["Hazrat Umar bin Abdul Aziz (R.A)", "Hazrat Mu'awiyah", "Abdul Malik bin Marwan", "Walid bin Abdul Malik"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Umar ibn Abd al-Aziz (Ibn Abd al-Hakam)",
      ur: "سیرت عمر بن عبدالعزیز، تاریخ الخلفاء",
      roman: "Sirat Umar bin Abdul Aziz"
    },
    explanation: {
      en: "Hazrat Umar ibn Abd al-Aziz ruled with exemplary piety and justice from 99 to 101 AH, eliminating poverty so Zakat went unclaimed.",
      ur: "آپ رحمہ اللہ نے خلافت راشدہ کا نمونہ زندہ کیا، ان کے دور میں بیت المال اتنا مالدار ہوا کہ زکوٰۃ لینے والا نہ ملتا تھا۔",
      roman: "Hazrat Umar bin Abdul Aziz ne azeem adl qaim kiya aur inhein Umar Saani kehte hain."
    }
  },
  {
    id: 412,
    categoryId: 4,
    difficulty: 'medium',
    question: {
      en: "What was the historic battle in 636 CE where Muslims under Khalid ibn al-Walid defeated the Byzantine Roman Empire?",
      ur: "۶۳۶ء (۱۵ ہجری) میں حضرت خالد بن ولید رضی اللہ عنہ کی قیادت میں بازنطینی رومی فوج کے خلاف کون سا عظیم معرکہ لڑا گیا؟",
      roman: "Hazrat Khalid bin Walid (R.A) ki qiyadat mein Roomi fauj ke khilaf konsa maraka lara gaya?"
    },
    options: {
      en: ["Battle of Yarmouk", "Battle of Qadisiyyah", "Battle of Nihawand", "Battle of Mu'tah"],
      ur: ["معرکہ یرموک", "معرکہ قادسیہ", "معرکہ نہاوند", "معرکہ موتہ"],
      roman: ["Battle of Yarmouk", "Battle of Qadisiyyah", "Battle of Nihawand", "Battle of Mu'tah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Al-Bidayah wan-Nihayah & Tabari",
      ur: "تاریخ طبری، معرکہ یرموک و فتح شام",
      roman: "Tarikh at-Tabari, Yarmouk"
    },
    explanation: {
      en: "The Battle of Yarmouk opened Syria and Palestine to Islam and ended Byzantine control over the Levant.",
      ur: "معرکہ یرموک میں مسلمانوں نے بازنطینی رومی فوج کو شکست فاش دی جس کے بعد سارا شام فتح ہو گیا۔",
      roman: "Yarmouk ki jung mein Roomi fauj ko tareekhi shikast hui."
    }
  },
  {
    id: 413,
    categoryId: 4,
    difficulty: 'medium',
    question: {
      en: "Which commander led the Muslim army to decisive victory over the Sasanian Persian Empire at the Battle of Al-Qadisiyyah in 636 CE?",
      ur: "معرکہ قادسیہ (۱۵ ہجری) میں کس عظیم صحابی نے ساسانی ایرانی سلطنت کے خلاف مسلم لشکر کی سپہ سالاری کی؟",
      roman: "Maraka-e-Qadisiyyah mein kis Sahabi ne fatah-e-Iran ki qiyadat ki?"
    },
    options: {
      en: ["Hazrat Sa'd ibn Abi Waqqas (RA)", "Hazrat Abu Ubaidah (RA)", "Hazrat Amr ibn Al-Aas (RA)", "Hazrat Shurahbil ibn Hasana (RA)"],
      ur: ["حضرت سعد بن ابی وقاص رضی اللہ عنہ", "حضرت ابو عبیدہ رضی اللہ عنہ", "حضرت عمرو بن العاص رضی اللہ عنہ", "حضرت شرحبیل بن حسنہ رضی اللہ عنہ"],
      roman: ["Hazrat Sa'd bin Abi Waqqas (R.A)", "Hazrat Abu Ubaidah", "Hazrat Amr bin Al-Aas", "Hazrat Shurahbil"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh at-Tabari",
      ur: "تاریخ طبری، فتوحاتِ عراق و ایران",
      roman: "Tarikh at-Tabari, Qadisiyyah"
    },
    explanation: {
      en: "Hazrat Sa'd ibn Abi Waqqas (RA), one of the Ten Promised Paradise (Ashara Mubashara), led the victory at Qadisiyyah.",
      ur: "حضرت سعد بن ابی وقاص رضی اللہ عنہ نے رستم کی سربراہی والی ایرانی فوج کو قادسیہ میں شکست دی۔",
      roman: "Hazrat Sa'd bin Abi Waqqas (R.A) ne Qadisiyyah mein azeem fateh payi."
    }
  },
  {
    id: 414,
    categoryId: 4,
    difficulty: 'hard',
    question: {
      en: "Which university founded in Fez, Morocco in 859 CE by Fatima al-Fihri is recognized as the oldest existing university in the world?",
      ur: "۸۵۹ء میں فاس (مراکش) میں فاطمہ الفہری نے دنیا کی سب سے پرانی اور قدیم ترین یونیورسٹی کی بنیاد رکھی، اس کا کیا نام ہے؟",
      roman: "Morocco mein Fatima al-Fihri ki qaim karda dunya ki qadeem tareen university ka kya naam hai?"
    },
    options: {
      en: ["University of Al-Qarawiyyin", "Al-Azhar University", "Nizamiyya", "Sankore University"],
      ur: ["جامعہ قرویین (فاس، مراکش)", "جامعہ الازہر (مصر)", "جامعہ نظامیہ (بغداد)", "سنکورے یونیورسٹی"],
      roman: ["Al-Qarawiyyin (Morocco)", "Al-Azhar (Egypt)", "Nizamiyya (Baghdad)", "Sankore"]
    },
    correctAnswer: 0,
    reference: {
      en: "UNESCO & Guinness World Records",
      ur: "یونیسکو و گنیز ریکارڈز برائے قدیم ترین جامعات",
      roman: "UNESCO World Records"
    },
    explanation: {
      en: "Fatima al-Fihri used her entire inheritance to establish the Mosque and University of Al-Qarawiyyin in 859 CE.",
      ur: "جامعہ قرویین دنیا کی اولین تسلیم شدہ ڈگری دینے والی یونیورسٹی ہے جو تاحال سرگرم عمل ہے۔",
      roman: "Al-Qarawiyyin dunya ki sab se qadeem mustanad university hai."
    }
  },
  {
    id: 415,
    categoryId: 4,
    difficulty: 'hard',
    question: {
      en: "What was the tragic tragedy of Karbala where Imam Hussain (RA) and his companions attained martyrdom in 61 AH?",
      ur: "۶۱ ہجری میں نواسہ رسول حضرت امام حسین رضی اللہ عنہ اور ان کے جانثاروں کا المناک سانحہ شہادت کس مقام پر پیش آیا؟",
      roman: "61 Hijri mein Hazrat Imam Hussain (R.A) ki shahadat ka waqia kis maqam par hua?"
    },
    options: {
      en: ["Karbala (Iraq)", "Kufa", "Damascus", "Madinah"],
      ur: ["کربلا (عراق)", "کوفہ", "دمشق", "مدینہ منورہ"],
      roman: ["Karbala (Iraq)", "Kufa", "Dimashq", "Madinah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh at-Tabari & Al-Bidayah wan-Nihayah",
      ur: "تاریخ طبری و البدایہ والنہایہ، مقتل الحسین رضی اللہ عنہ",
      roman: "Tarikh at-Tabari, Karbala"
    },
    explanation: {
      en: "On 10th Muharram 61 AH (Day of Ashura), Hazrat Imam Hussain (RA) stood firm for truth, justice, and Islamic principles at Karbala.",
      ur: "۱۰ محرم ۶۱ ہجری کو حضرت امام حسین رضی اللہ عنہ نے حق و صداقت اور دین کی سربلندی کے لیے میدانِ کربلا میں عظیم قربانی پیش فرمائی۔",
      roman: "10 Muharram 61 Hijri ko Karbala ke maidan mein Imam Hussain (R.A) ne azeem shahadat payi."
    }
  },
  {
    id: 416,
    categoryId: 4,
    difficulty: 'expert',
    question: {
      en: "Who was the great Muslim traveler and geographer who journeyed over 73,000 miles across Africa, the Middle East, India, and China in the 14th century?",
      ur: "چودھویں صدی عیسوی میں ۷۳ ہزار میل سے زائد کا سفر طے کرنے والے مشہور مسلم سیاح کون تھے؟",
      roman: "14th century ke mashhoor tareen Muslim sayyah (traveler) kon the?"
    },
    options: {
      en: ["Ibn Battuta", "Ibn Khaldun", "Al-Idrisi", "Al-Biruni"],
      ur: ["ابن بطوطہ (محمد بن عبداللہ)", "ابن خلدون", "الشریف الادریسی", "ابو ریحان البیرونی"],
      roman: ["Ibn Battuta", "Ibn Khaldun", "Al-Idrisi", "Al-Biruni"]
    },
    correctAnswer: 0,
    reference: {
      en: "Rihla Ibn Battuta (Tuhfat an-Nuzzar)",
      ur: "رحلہ ابن بطوطہ، تحفۃ النظار فی غرائب الامصار",
      roman: "Rihla Ibn Battuta"
    },
    explanation: {
      en: "Ibn Battuta of Tangier spent 30 years travelling throughout the Islamic world and documented civilisations in his famous 'Rihla'.",
      ur: "ابن بطوطہ نے ۳۰ سال تک سفر کیا اور اپنے سفرنامے 'رحلہ' میں اس دور کی دنیا کے مشاہدات قلمبند کیے۔",
      roman: "Ibn Battuta ne 30 saal tak dunya ka safar kiya aur tareekh-e-alam likhi."
    }
  },
  {
    id: 417,
    categoryId: 4,
    difficulty: 'easy',
    question: {
      en: "How many years did the Rightly Guided Caliphate (Khilafat ar-Rashidah) officially span in Islamic history?",
      ur: "خلافتِ راشدہ کا مجموعی دورانیہ تاریخ اسلام میں تقریباً کتنے سال پر محیط رہا؟",
      roman: "Khilafat-e-Rashidah ka kul arsa kitne saal raha?"
    },
    options: {
      en: ["Approximately 30 years (11–40 AH)", "40 years", "50 years", "20 years"],
      ur: ["تقریباً ۳۰ سال (۱۱ تا ۴۰ ہجری)", "۴۰ سال", "۵۰ سال", "۲۰ سال"],
      roman: ["Taqreeban 30 saal (11-40 Hijri)", "40 saal", "50 saal", "20 saal"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sunan Abi Dawud (Hadith 4646)",
      ur: "سنن ابی داؤد، کتاب السنۃ، حدیث ۴۶۴۶",
      roman: "Sunan Abu Dawood, Hadith 4646"
    },
    explanation: {
      en: "The Prophet ﷺ foretold: 'The Caliphate of Prophethood will last for thirty years, then Allah will give the kingdom to whomever He wills.'",
      ur: "رسول اللہ ﷺ نے فرمایا: میرے بعد خلافتِ نبوت ۳۰ سال رہے گی، پھر اللہ جسے چاہے گا بادشاہت عطا فرمائے گا۔",
      roman: "Huzoor ﷺ ne farmaya ke Khilafat-e-Nabuwwat 30 saal rahegi."
    }
  },
  {
    id: 418,
    categoryId: 4,
    difficulty: 'medium',
    question: {
      en: "What was the magnificent capital of Muslim Spain (Andalusia) famous for its Great Mosque and paved lit streets?",
      ur: "مسلم اندلس کا وہ عظیم دار الحکومت کون سا تھا جو جامع مسجد اور علمی لائبریریوں کی وجہ سے یورپ کا گوہر کہلایا؟",
      roman: "Muslim Spain ka azeem tareen markaz konsa shehar tha jahan Jamia Masjid waqia thi?"
    },
    options: {
      en: ["Cordoba (Qurtubah)", "Granada (Gharnatah)", "Seville (Ishbiliyah)", "Toledo (Tulaytulah)"],
      ur: ["قرطبہ (کوردوبا)", "غرناطہ", "اشبیلیہ", "طلیطلہ"],
      roman: ["Qurtubah (Cordoba)", "Gharnatah (Granada)", "Ishbiliyah (Seville)", "Tulaytulah (Toledo)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Islamic Spain History (W. Montgomery Watt)",
      ur: "تاریخ اندلس و تمدنِ اسلام",
      roman: "History of Islamic Spain"
    },
    explanation: {
      en: "Cordoba under Abd al-Rahman III was the most advanced city in Europe with 70 libraries, paved streets, and public baths.",
      ur: "قرطبہ دسویں صدی میں علم و فن کا عالمی مرکز تھا جہاں کی عظیم الشان جامع مسجد آج بھی فن تعمیر کا نمونہ ہے۔",
      roman: "Qurtubah (Cordoba) Europe ka sab se roshan aur taraqqi yafta shehar tha."
    }
  },
  {
    id: 419,
    categoryId: 4,
    difficulty: 'hard',
    question: {
      en: "Who was the founder of the Umayyad Caliphate with its capital in Damascus?",
      ur: "دمشق کو دار الخلافہ بنانے والی بنو امیہ خلافت کے بانی کون سے صحابی تھے؟",
      roman: "Banu Umayyah khilafat ke baani konse sahabi the?"
    },
    options: {
      en: ["Hazrat Mu'awiyah ibn Abi Sufyan (RA)", "Yazid ibn Mu'awiyah", "Marwan ibn al-Hakam", "Sulaiman ibn Abd al-Malik"],
      ur: ["حضرت معاویہ بن ابی سفیان رضی اللہ عنہ", "یزید بن معاویہ", "مروان بن الحکم", "سلیمان بن عبدالملک"],
      roman: ["Hazrat Mu'awiyah (R.A)", "Yazid", "Marwan", "Sulaiman"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh al-Khulafa & Ibn Kathir",
      ur: "البدایہ والنہایہ، قیامِ دولتِ امویہ",
      roman: "Al-Bidayah wan-Nihayah"
    },
    explanation: {
      en: "Hazrat Mu'awiyah (RA) founded the Umayyad dynasty in 41 AH after the reconciliation with Hazrat Hasan (RA) ('Am al-Jama'ah).",
      ur: "۴۱ ہجری میں حضرت حسن رضی اللہ عنہ کے صلح فرمانے (عام الجماعۃ) کے بعد حضرت معاویہ نے حکومت سنبھالی۔",
      roman: "41 Hijri Aam-ul-Jama'ah ke baad Hazrat Mu'awiyah (R.A) ne daulat-e-umawiyyah qaim ki."
    }
  },
  {
    id: 420,
    categoryId: 4,
    difficulty: 'expert',
    question: {
      en: "What was the battle in 1071 CE where the Seljuk Sultan Alp Arslan routed the Byzantine Empire, opening Anatolia (Turkey) to Islam?",
      ur: "۱۰۷۱ء میں سلجوق سلطان الپ ارسلان نے رومی شہنشاہ کو شکست دے کر اناطولیہ (موجودہ ترکی) کے دروازے کھولے، اس جنگ کا کیا نام ہے؟",
      roman: "1071 mein Sultan Alp Arslan ne kis jung mein Roomi badshah ko haraya tha?"
    },
    options: {
      en: ["Battle of Manzikert (Malazgirt)", "Battle of Nicopolis", "Battle of Mohacs", "Battle of Kosovo"],
      ur: ["معرکہ ملازکرد (ملازگرت)", "معرکہ نکوپولس", "معرکہ موہاکس", "معرکہ کوسوو"],
      roman: ["Battle of Manzikert", "Battle of Nicopolis", "Battle of Mohacs", "Battle of Kosovo"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh Salajiqa (Ibn al-Athir)",
      ur: "الکامل فی التاریخ، تاریخ سلجوقیہ، معرکہ ملازکرد",
      roman: "Tarikh Salajiqa"
    },
    explanation: {
      en: "The Battle of Manzikert in 1071 CE was a turning point that transformed Anatolia permanently into a Muslim heartland.",
      ur: "معرکہ ملازکرد میں سلطان الپ ارسلان نے قیصرِ روم رومانوس کو قیدی بنا کر اناطولیہ پر اسلامی تسلط قائم کیا۔",
      roman: "Manzikert ki jung ne Turkey (Anatolia) mein Islam ki aamad ko yaqeeni banaya."
    }
  },
  {
    id: 421,
    categoryId: 4,
    difficulty: 'expert',
    question: {
      en: "Who was the renowned polymath and philosopher who authored the 'Muqaddimah' and founded modern sociology and historiography?",
      ur: "عظیم مسلم مفکر اور مؤرخ جنہوں نے فلسفہ تاریخ اور عمرانیات (سوشل سائنس) کی بنیاد 'مقدمہ' لکھ کر رکھی، کون تھے؟",
      roman: "Modern sociology aur falsafa-e-tareekh ke baani 'Muqaddimah' ke musannif kon the?"
    },
    options: {
      en: ["Ibn Khaldun", "Ibn Sina (Avicenna)", "Al-Farabi", "Ibn Rushd (Averroes)"],
      ur: ["علامہ ابن خلدون", "ابن سینا", "الفارابی", "ابن رشد"],
      roman: ["Ibn Khaldun", "Ibn Sina", "Al-Farabi", "Ibn Rushd"]
    },
    correctAnswer: 0,
    reference: {
      en: "The Muqaddimah (An Introduction to History)",
      ur: "مقدمہ ابن خلدون فی علم التاریخ و العمران",
      roman: "Muqaddimah Ibn Khaldun"
    },
    explanation: {
      en: "Ibn Khaldun (1332–1406 CE) introduced the concept of 'Asabiyyah' (social cohesion) and scientific laws governing the rise and fall of civilizations.",
      ur: "علامہ ابن خلدون نے اپنی کتاب 'مقدمہ' میں عصبیت اور تہذیبوں کے عروج و زوال کے سائنسی اصول بیان کیے۔",
      roman: "Ibn Khaldun ne 'Muqaddimah' likh kar dunya ko falsafa-e-tareekh sikhaya."
    }
  }
];
