import { Question } from '../../types/quiz';

export const quranQuestions: Question[] = [
  {
    id: 101,
    categoryId: 1,
    difficulty: 'easy',
    question: {
      en: "How many Surahs (chapters) are there in the Holy Quran?",
      ur: "قرآن مجید میں کل کتنی سورتیں ہیں؟",
      roman: "Quran Majeed mein kul kitni Surahs hain?"
    },
    options: {
      en: ["110", "114", "112", "116"],
      ur: ["۱۱۰", "۱۱۴", "۱۱۲", "۱۱۶"],
      roman: ["110", "114", "112", "116"]
    },
    correctAnswer: 1,
    reference: {
      en: "Consensus of the Ummah / Quranic compilation",
      ur: "اجماع امت و توقیفی ترتیبِ مصحف",
      roman: "Ijma-e-Ummat wa tartib-e-Quran"
    },
    explanation: {
      en: "The Holy Quran consists of 114 Surahs, starting with Surah Al-Fatihah and concluding with Surah An-Nas.",
      ur: "قرآن کریم ۱۱۴ سورتوں پر مشتمل ہے، جس کا آغاز سورۃ الفاتحہ اور اختتام سورۃ الناس پر ہوتا ہے۔",
      roman: "Quran Majeed 114 Surahs par mushtamil hai, aaghaz Surah Al-Fatihah aur ikhtitam Surah An-Nas par hota hai."
    }
  },
  {
    id: 102,
    categoryId: 1,
    difficulty: 'easy',
    question: {
      en: "Which Surah is considered the 'Mother of the Book' (Umm al-Kitab)?",
      ur: "کس سورۃ مبارکہ کو 'ام الکتاب' کہا جاتا ہے؟",
      roman: "Kis Surah ko 'Umm al-Kitab' kaha jata hai?"
    },
    options: {
      en: ["Surah Al-Baqarah", "Surah Yasin", "Surah Al-Fatihah", "Surah Al-Ikhlas"],
      ur: ["سورۃ البقرہ", "سورۃ یٰس", "سورۃ الفاتحہ", "سورۃ الاخلاص"],
      roman: ["Surah Al-Baqarah", "Surah Yaseen", "Surah Al-Fatihah", "Surah Al-Ikhlas"]
    },
    correctAnswer: 2,
    reference: {
      en: "Sahih Bukhari (Book 60, Hadith 227)",
      ur: "صحیح بخاری، کتاب التفسیر، حدیث ۲۲۷",
      roman: "Sahih Bukhari, Kitab-ut-Tafseer, Hadith 227"
    },
    explanation: {
      en: "Surah Al-Fatihah is named Umm al-Kitab (Mother of the Book) and Sab' al-Mathani (The Seven Oft-Repeated Verses).",
      ur: "سورۃ الفاتحہ کو ام الکتاب اور سبع مثانی کہا جاتا ہے جو ہر نماز کی رکعت میں تلاوت کی جاتی ہے۔",
      roman: "Surah Al-Fatihah ko Umm al-Kitab kaha jata hai kyunki yeh deen ke bunyadi mazameen par mushtamil hai."
    }
  },
  {
    id: 103,
    categoryId: 1,
    difficulty: 'easy',
    question: {
      en: "Which is the longest Surah in the Holy Quran?",
      ur: "قرآن مجید کی سب سے طویل ترین سورۃ کون سی ہے؟",
      roman: "Quran Majeed ki sab se lambi Surah konsi hai?"
    },
    options: {
      en: ["Surah Al-Imran", "Surah Al-Baqarah", "Surah An-Nisa", "Surah Al-Ma'idah"],
      ur: ["سورۃ آل عمران", "سورۃ البقرہ", "سورۃ النساء", "سورۃ المائدہ"],
      roman: ["Surah Al-Imran", "Surah Al-Baqarah", "Surah An-Nisa", "Surah Al-Ma'idah"]
    },
    correctAnswer: 1,
    reference: {
      en: "Surah Al-Baqarah (286 Ayahs)",
      ur: "سورۃ البقرہ (۲۸۶ آیات مبارکہ)",
      roman: "Surah Al-Baqarah (286 Ayahs)"
    },
    explanation: {
      en: "Surah Al-Baqarah is the longest Surah, containing 286 verses and the greatest Ayah, Ayat al-Kursi.",
      ur: "سورۃ البقرہ قرآن کریم کی طویل ترین سورۃ ہے جس کی ۲۸۶ آیات ہیں۔",
      roman: "Surah Al-Baqarah Quran ki sab se bari Surah hai jis mein 286 aayat hain."
    }
  },
  {
    id: 104,
    categoryId: 1,
    difficulty: 'easy',
    question: {
      en: "Which is the shortest Surah in the Holy Quran?",
      ur: "قرآن مجید کی سب سے مختصر ترین سورۃ کون سی ہے؟",
      roman: "Quran Majeed ki sab se choti Surah konsi hai?"
    },
    options: {
      en: ["Surah Al-Asr", "Surah Al-Ikhlas", "Surah Al-Kawthar", "Surah An-Nasr"],
      ur: ["سورۃ العصر", "سورۃ الاخلاص", "سورۃ الکوثر", "سورۃ النصر"],
      roman: ["Surah Al-Asr", "Surah Al-Ikhlas", "Surah Al-Kawthar", "Surah An-Nasr"]
    },
    correctAnswer: 2,
    reference: {
      en: "Surah Al-Kawthar (Chapter 108, 3 Ayahs)",
      ur: "سورۃ الکوثر (سورۃ نمبر ۱۰۸، ۳ آیات)",
      roman: "Surah Al-Kawthar (Surah 108, 3 Aayat)"
    },
    explanation: {
      en: "Surah Al-Kawthar contains only 3 short verses and 10 words.",
      ur: "سورۃ الکوثر قرآن کی سب سے مختصر سورت ہے جس میں ۳ آیات اور ۱۰ کلمات ہیں۔",
      roman: "Surah Al-Kawthar sab se choti Surah hai jis mein sirf 3 aayat hain."
    }
  },
  {
    id: 105,
    categoryId: 1,
    difficulty: 'medium',
    question: {
      en: "In which cave was the first revelation of the Quran sent down?",
      ur: "قرآن مجید کی پہلی وحی کس غار میں نازل ہوئی تھی؟",
      roman: "Quran Majeed ki pehli wahi kis ghaar mein nazil hui?"
    },
    options: {
      en: ["Cave of Thawr", "Cave of Hira", "Cave of Uhud", "Cave of Safa"],
      ur: ["غارِ ثور", "غارِ حرا", "غارِ احد", "غارِ صفا"],
      roman: ["Ghaar-e-Thawr", "Ghaar-e-Hira", "Ghaar-e-Uhud", "Ghaar-e-Safa"]
    },
    correctAnswer: 1,
    reference: {
      en: "Sahih Bukhari (Book 1, Hadith 3)",
      ur: "صحیح بخاری، بدء الوحی، حدیث ۳",
      roman: "Sahih Bukhari, Bad'ul Wahi, Hadith 3"
    },
    explanation: {
      en: "The first 5 verses of Surah Al-Alaq ('Iqra') were revealed to the Prophet ﷺ in Cave Hira on Jabal an-Nour.",
      ur: "پہلی وحی (سورۃ العلق کی ابتدائی ۵ آیات) جبل النور پر واقع غارِ حرا میں نازل ہوئی۔",
      roman: "Pehli wahi Surah Al-Alaq ki 5 aayat Jabal-e-Noor par waqia Ghaar-e-Hira mein nazil hui."
    }
  },
  {
    id: 106,
    categoryId: 1,
    difficulty: 'medium',
    question: {
      en: "Which Surah does not begin with Bismillahir Rahmanir Raheem?",
      ur: "قرآن پاک کی کس سورۃ کے آغاز میں بسم اللہ الرحمٰن الرحیم نہیں لکھی جاتی؟",
      roman: "Quran Pak ki kis Surah ke shuru mein Bismillah nahi hai?"
    },
    options: {
      en: ["Surah At-Tawbah", "Surah Al-Anfal", "Surah Yunus", "Surah Hud"],
      ur: ["سورۃ التوبہ", "سورۃ الانفال", "سورۃ یونس", "سورۃ ہود"],
      roman: ["Surah At-Tawbah", "Surah Al-Anfal", "Surah Yunus", "Surah Hud"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah At-Tawbah (Chapter 9)",
      ur: "سورۃ التوبہ (سورۃ نمبر ۹)",
      roman: "Surah At-Tawbah (Surah No. 9)"
    },
    explanation: {
      en: "Surah At-Tawbah (Bara'ah) does not begin with Bismillah as it declared divine renunciation against treaty-breakers.",
      ur: "سورۃ التوبہ کے شروع میں بسم اللہ نہیں ہے، جبکہ سورۃ النمل میں بسم اللہ دو مرتبہ آئی ہے۔",
      roman: "Surah At-Tawbah ke aaghaz mein Bismillah nahi hai."
    }
  },
  {
    id: 107,
    categoryId: 1,
    difficulty: 'medium',
    question: {
      en: "In which Surah does Bismillah appear twice?",
      ur: "قرآن مجید کی کس سورۃ میں بسم اللہ الرحمٰن الرحیم دو مرتبہ آئی ہے؟",
      roman: "Quran Majeed ki kis Surah mein Bismillah do martaba aayi hai?"
    },
    options: {
      en: ["Surah An-Naml", "Surah Maryam", "Surah Al-Qasas", "Surah Ar-Rahman"],
      ur: ["سورۃ النمل", "سورۃ مریم", "سورۃ القصص", "سورۃ الرحمٰن"],
      roman: ["Surah An-Naml", "Surah Maryam", "Surah Al-Qasas", "Surah Ar-Rahman"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah An-Naml (27:30)",
      ur: "سورۃ النمل، آیت ۳۰",
      roman: "Surah An-Naml, Ayah 30"
    },
    explanation: {
      en: "Surah An-Naml has Bismillah at its start and inside verse 30 in the letter sent by Prophet Sulaiman (AS) to Bilqis.",
      ur: "سورۃ النمل کی آیت ۳۰ میں حضرت سلیمان علیہ السلام کے خط کا ذکر ہے: إِنَّهُ مِنْ سُلَيْمَانَ وَإِنَّهُ بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ۔",
      roman: "Surah An-Naml ki aayat 30 mein Hazrat Sulaiman (A.S) ke khat ka zikr hai."
    }
  },
  {
    id: 108,
    categoryId: 1,
    difficulty: 'medium',
    question: {
      en: "Which verse in the Quran is known as the greatest verse (Ayat al-Kursi)?",
      ur: "قرآن مجید کی سب سے عظیم ترین آیت 'آیت الکرسی' کس سورۃ میں ہے؟",
      roman: "Ayat al-Kursi Quran ki kis Surah mein waqia hai?"
    },
    options: {
      en: ["Surah Al-Baqarah (2:255)", "Surah Al-Imran (3:18)", "Surah An-Nur (24:35)", "Surah Al-Hashr (59:22)"],
      ur: ["سورۃ البقرہ (آیت ۲۵۵)", "سورۃ آل عمران (آیت ۱۸)", "سورۃ النور (آیت ۳۵)", "سورۃ الحشر (آیت ۲۲)"],
      roman: ["Surah Al-Baqarah (Ayah 255)", "Surah Al-Imran (Ayah 18)", "Surah An-Nur (Ayah 35)", "Surah Al-Hashr (Ayah 22)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 4, Hadith 1768)",
      ur: "صحیح مسلم، صلاۃ المسافرین، حدیث ۱۷۶۸",
      roman: "Sahih Muslim, Hadith 1768"
    },
    explanation: {
      en: "The Prophet ﷺ confirmed to Ubayy ibn Ka'b (RA) that Ayat al-Kursi (2:255) is the greatest verse in the Book of Allah.",
      ur: "رسول اللہ ﷺ نے حضرت ابی بن کعب رضی اللہ عنہ کے سوال کے جواب میں تصدیق فرمائی کہ آیت الکرسی قرآن کی سب سے بڑی آیت ہے۔",
      roman: "Huzoor ﷺ ne tasdeeq farmayi ke Ayat al-Kursi (2:255) Quran ki sab se azeem aayat hai."
    }
  },
  {
    id: 109,
    categoryId: 1,
    difficulty: 'hard',
    question: {
      en: "Which Surah is known as the 'Heart of the Quran' (Qalb al-Quran)?",
      ur: "کس سورۃ کو 'قلب القرآن' (قرآن کا دل) کہا گیا ہے؟",
      roman: "Kis Surah ko 'Qalb al-Quran' (Quran ka dil) kaha gaya hai?"
    },
    options: {
      en: ["Surah Ar-Rahman", "Surah Al-Mulk", "Surah Yasin", "Surah Al-Waqi'ah"],
      ur: ["سورۃ الرحمٰن", "سورۃ الملک", "سورۃ یٰس", "سورۃ الواقعہ"],
      roman: ["Surah Ar-Rahman", "Surah Al-Mulk", "Surah Yaseen", "Surah Al-Waqi'ah"]
    },
    correctAnswer: 2,
    reference: {
      en: "Sunan at-Tirmidhi (Hadith 2887)",
      ur: "جامع ترمذی، ابواب فضائل القرآن، حدیث ۲۸۸۷",
      roman: "Jami at-Tirmidhi, Hadith 2887"
    },
    explanation: {
      en: "Prophet Muhammad ﷺ mentioned: 'Everything has a heart, and the heart of the Quran is Surah Yasin.'",
      ur: "حدیث مبارکہ میں فرمایا گیا کہ ہر چیز کا ایک دل ہوتا ہے اور قرآن مجید کا دل سورۃ یٰس ہے۔",
      roman: "Hadees shareef mein farmaya gaya ke har cheez ka dil hota hai aur Quran ka dil Surah Yaseen hai."
    }
  },
  {
    id: 110,
    categoryId: 1,
    difficulty: 'hard',
    question: {
      en: "Reciting which Surah is equivalent to one-third of the Holy Quran in reward?",
      ur: "کس سورۃ کی تلاوت کا ثواب ایک تہائی قرآن (تہائی حصہ) کے برابر بتایا گیا ہے؟",
      roman: "Kis Surah ki tilawat ka sawab aik tehai (1/3rd) Quran ke barabar hai?"
    },
    options: {
      en: ["Surah Al-Ikhlas", "Surah Al-Falaq", "Surah Al-Kafirun", "Surah Al-Fatihah"],
      ur: ["سورۃ الاخلاص", "سورۃ الفلق", "سورۃ الکافرون", "سورۃ الفاتحہ"],
      roman: ["Surah Al-Ikhlas", "Surah Al-Falaq", "Surah Al-Kafirun", "Surah Al-Fatihah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 66, Hadith 5013)",
      ur: "صحیح بخاری، فضائل القرآن، حدیث ۵۰۱۳",
      roman: "Sahih Bukhari, Fazail-ul-Quran, Hadith 5013"
    },
    explanation: {
      en: "Surah Al-Ikhlas encapsulates pure Tawheed (Oneness of Allah), hence equaling one-third of Quranic themes.",
      ur: "سورۃ الاخلاص توحیدِ خالص پر مبنی ہے، جس کی تلاوت پر ثلث القرآن (ایک تہائی قرآن) کا ثواب ملتا ہے۔",
      roman: "Surah Al-Ikhlas mukammal Tawheed ka bayaan hai, is liye yeh 1/3 Quran ke barabar hai."
    }
  },
  {
    id: 111,
    categoryId: 1,
    difficulty: 'hard',
    question: {
      en: "Which woman is the only female explicitly mentioned by personal name in the Holy Quran?",
      ur: "قرآن مجید میں کس خاتون کا ذاتی نام صراحت کے ساتھ ذکر کیا گیا ہے؟",
      roman: "Quran Majeed mein kis khatoon ka zaati naam zikr kiya gaya hai?"
    },
    options: {
      en: ["Sayyida Khadijah", "Sayyida Maryam", "Sayyida Fatimah", "Sayyida Asiya"],
      ur: ["سیدہ خدیجہ", "سیدہ مریم علیہا السلام", "سیدہ فاطمہ", "سیدہ آسیہ"],
      roman: ["Sayyida Khadijah", "Sayyida Maryam (A.S)", "Sayyida Fatimah", "Sayyida Asiya"]
    },
    correctAnswer: 1,
    reference: {
      en: "Surah Maryam (Chapter 19) & Surah Al-Imran (3:42)",
      ur: "سورۃ مریم اور سورۃ آل عمران، آیت ۴۲",
      roman: "Surah Maryam wa Surah Al-Imran, Ayah 42"
    },
    explanation: {
      en: "Sayyida Maryam (mother of Prophet Isa AS) is the only woman mentioned by name, appearing 34 times across the Quran.",
      ur: "سیدہ مریم علیہا السلام وہ واحد خاتون ہیں جن کا نام مبارک قرآن کریم میں ۳۴ مرتبہ صراحت سے آیا ہے۔",
      roman: "Sayyida Maryam (A.S) Quran mein naam se zikr hone wali wahid khatoon hain."
    }
  },
  {
    id: 112,
    categoryId: 1,
    difficulty: 'hard',
    question: {
      en: "Which Sahabi (Companion) is explicitly mentioned by his personal name in the Quran?",
      ur: "قرآن مجید میں کس صحابی رسول ﷺ کا ذاتی نام مبارک صراحت سے آیا ہے؟",
      roman: "Quran Majeed mein kis Sahabi (R.A) ka zaati naam aya hai?"
    },
    options: {
      en: ["Abu Bakr As-Siddiq", "Umar ibn Al-Khattab", "Zayd ibn Harithah", "Ali ibn Abi Talib"],
      ur: ["حضرت ابوبکر صدیق", "حضرت عمر بن خطاب", "حضرت زید بن حارثہ", "حضرت علی المرتضیٰ"],
      roman: ["Hazrat Abu Bakr", "Hazrat Umar", "Hazrat Zayd bin Harithah", "Hazrat Ali"]
    },
    correctAnswer: 2,
    reference: {
      en: "Surah Al-Ahzab (33:37)",
      ur: "سورۃ الاحزاب، آیت ۳۷",
      roman: "Surah Al-Ahzab, Ayah 37"
    },
    explanation: {
      en: "Allah states in Surah Al-Ahzab: 'So when Zayd had concluded his purpose with her...' (فلما قضى زيد منها وطرا).",
      ur: "سورۃ الاحزاب کی آیت ۳۷ میں حضرت زید بن حارثہ رضی اللہ عنہ کا اسم گرامی صراحت کے ساتھ مذکور ہے۔",
      roman: "Surah Al-Ahzab (33:37) mein Hazrat Zayd bin Harithah (R.A) ka naam mubarak aya hai."
    }
  },
  {
    id: 113,
    categoryId: 1,
    difficulty: 'expert',
    question: {
      en: "Which Surah is also titled 'Surah Bani Isra'il'?",
      ur: "قرآن مجید کی کس سورۃ کا دوسرا معروف نام 'سورۃ بنی اسرائیل' ہے؟",
      roman: "Kis Surah ka doosra naam 'Surah Bani Isra'il' hai?"
    },
    options: {
      en: ["Surah Al-Isra", "Surah Yunus", "Surah Taha", "Surah Al-Anbiya"],
      ur: ["سورۃ الاسراء", "سورۃ یونس", "سورۃ طٰہٰ", "سورۃ الانبیاء"],
      roman: ["Surah Al-Isra", "Surah Yunus", "Surah Taha", "Surah Al-Anbiya"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Isra (Chapter 17)",
      ur: "سورۃ الاسراء (سورۃ نمبر ۱۷)",
      roman: "Surah Al-Isra (Surah No. 17)"
    },
    explanation: {
      en: "Surah 17 is known both as Surah Al-Isra (The Night Journey) and Surah Bani Isra'il due to its discourse on the Children of Israel.",
      ur: "سورۃ نمبر ۱۷ کو سورۃ الاسراء اور سورۃ بنی اسرائیل دونوں ناموں سے جانا جاتا ہے۔",
      roman: "Surah Al-Isra ko Surah Bani Isra'il bhi kehte hain."
    }
  },
  {
    id: 114,
    categoryId: 1,
    difficulty: 'expert',
    question: {
      en: "How many Sujud (prostrations of recitation - Sajdah at-Tilawah) are there in the Holy Quran according to the Hanafi school?",
      ur: "قرآن مجید میں تلاوت کے کل کتنے سجدے (سجدہ تلاوت) ہیں؟",
      roman: "Quran Majeed mein Sajda-e-Tilawat ki kul tadaad kitni hai?"
    },
    options: {
      en: ["12", "14", "15", "16"],
      ur: ["۱۲", "۱۴", "۱۵", "۱۶"],
      roman: ["12", "14", "15", "16"]
    },
    correctAnswer: 1,
    reference: {
      en: "Classical Tafseer & Fiqh Consensus",
      ur: "اجماع فقہائے کرام و مصاحف عثمانیہ",
      roman: "Fiqh aur Masahif-e-Usmaniya"
    },
    explanation: {
      en: "There are 14 agreed places of Sajdah at-Tilawah marked in the standard Mushaf of the Quran.",
      ur: "عام متداول مصاحف میں سجدہ تلاوت کی کل تعداد ۱۴ بتائی جاتی ہے۔",
      roman: "Mutadawil Quran ke nuskho mein kul 14 sajde tilawat hain."
    }
  },
  {
    id: 115,
    categoryId: 1,
    difficulty: 'expert',
    question: {
      en: "Which verse in the Quran is the longest single verse?",
      ur: "قرآن مجید کی سب سے لمبی اور طویل ترین اکیلی آیت کون سی ہے؟",
      roman: "Quran Majeed ki sab se lambi wahid aayat konsi hai?"
    },
    options: {
      en: ["Ayat ad-Dayn (Surah Al-Baqarah 2:282)", "Ayat al-Kursi (Surah Al-Baqarah 2:255)", "Surah An-Nur (24:35)", "Surah Al-Fath (48:29)"],
      ur: ["آیت الدین (سورۃ البقرہ، آیت ۲۸۲)", "آیت الکرسی (سورۃ البقرہ، آیت ۲۵۵)", "آیت النور (سورۃ النور، آیت ۳۵)", "آخری آیت فتح (سورۃ الفتح، آیت ۲۹)"],
      roman: ["Ayat ad-Dayn (Surah Baqarah 2:282)", "Ayat al-Kursi (Surah Baqarah 2:255)", "Ayat an-Noor (24:35)", "Surah Al-Fath (48:29)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Baqarah (2:282)",
      ur: "سورۃ البقرہ، آیت ۲۸۲ (آیتِ قرض و دستاویز)",
      roman: "Surah Al-Baqarah, Ayah 282"
    },
    explanation: {
      en: "Ayat ad-Dayn (the Debt verse, 2:282) spans an entire full page in the standard Mushaf.",
      ur: "آیت نمبر ۲۸۲ (آیتِ دین/قرض کے احکام) قرآن پاک کی سب سے طویل آیت ہے جو پورے ایک صفحے پر محیط ہے۔",
      roman: "Ayat ad-Dayn (2:282) qarz aur muaamlaat ke baare mein hai aur sab se lambi aayat hai."
    }
  },
  {
    id: 116,
    categoryId: 1,
    difficulty: 'easy',
    question: {
      en: "How many Manzils (stages) is the Holy Quran divided into for weekly completion?",
      ur: "ہفتہ وار تلاوتِ قرآن مکمل کرنے کے لیے قرآن کریم کو کتنی منازل میں تقسیم کیا گیا ہے؟",
      roman: "Quran Majeed ko kitni manzilon mein taqseem kiya gaya hai?"
    },
    options: {
      en: ["5", "7", "10", "14"],
      ur: ["۵", "۷", "۱۰", "۱۴"],
      roman: ["5", "7", "10", "14"]
    },
    correctAnswer: 1,
    reference: {
      en: "Sunan Abu Dawud (Hadith 1393)",
      ur: "سنن ابی داؤد، حدیث ۱۳۹۳",
      roman: "Sunan Abu Dawood, Hadith 1393"
    },
    explanation: {
      en: "The Quran is divided into 7 Manzils to facilitate completing one full recitation in seven days (one week).",
      ur: "قرآن مجید کو ۷ منازل میں بانٹا گیا ہے تاکہ ایک ہفتے میں روزانہ ایک منزل پڑھ کر پورا قرآن مکمل کیا جا سکے۔",
      roman: "Quran ko 7 manzilon mein baanta gaya hai taake 7 din mein tilawat mukammal ho sake."
    }
  },
  {
    id: 117,
    categoryId: 1,
    difficulty: 'medium',
    question: {
      en: "How many Paras (Juz) are there in the Holy Quran?",
      ur: "قرآن مجید میں کل کتنے پارے (اجزاء) ہیں؟",
      roman: "Quran Majeed mein kul kitne pare (Juz) hain?"
    },
    options: {
      en: ["28", "29", "30", "32"],
      ur: ["۲۸", "۲۹", "۳۰", "۳۲"],
      roman: ["28", "29", "30", "32"]
    },
    correctAnswer: 2,
    reference: {
      en: "Standard Quranic division",
      ur: "مصاحف شریفہ کی عمومی تقسیم",
      roman: "Quranic standard division"
    },
    explanation: {
      en: "The Quran is divided into 30 equal Juz (Paras) to facilitate daily recitation, especially in Ramadan.",
      ur: "قرآن مجید ۳۰ پاروں میں منقسم ہے تاکہ ماہِ رمضان اور روزمرہ میں آسانی سے تلاوت کی جا سکے۔",
      roman: "Quran Majeed mein 30 pare hain."
    }
  },
  {
    id: 118,
    categoryId: 1,
    difficulty: 'medium',
    question: {
      en: "Which Surah protects against the punishment of the grave when recited regularly?",
      ur: "کون سی سورۃ مبارکہ روزانہ تلاوت کرنے والے کو عذابِ قبر سے محفوظ رکھتی ہے؟",
      roman: "Konsi Surah rozana parhne wale ko azaab-e-qabr se mehfooz rakhti hai?"
    },
    options: {
      en: ["Surah Al-Mulk", "Surah As-Sajdah", "Surah Al-Jumu'ah", "Surah At-Tahrim"],
      ur: ["سورۃ الملک", "سورۃ السجدہ", "سورۃ الجمعہ", "سورۃ التحریم"],
      roman: ["Surah Al-Mulk", "Surah As-Sajdah", "Surah Al-Jumu'ah", "Surah At-Tahrim"]
    },
    correctAnswer: 0,
    reference: {
      en: "Jami at-Tirmidhi (Hadith 2891)",
      ur: "جامع ترمذی، فضائل القرآن، حدیث ۲۸۹۱",
      roman: "Jami at-Tirmidhi, Hadith 2891"
    },
    explanation: {
      en: "Prophet Muhammad ﷺ called Surah Al-Mulk 'Al-Mani'ah' (the protector) that shields from grave trials.",
      ur: "رسول اللہ ﷺ نے فرمایا کہ سورۃ الملک عذاب قبر سے روکنے اور شفاعت کرنے والی سورت ہے۔",
      roman: "Huzoor ﷺ ne Surah Al-Mulk ko azaab-e-qabr se bachane wali Surah farmaya."
    }
  },
  {
    id: 119,
    categoryId: 1,
    difficulty: 'hard',
    question: {
      en: "Which angel was entrusted with delivering the divine revelation of the Quran?",
      ur: "قرآن مجید کی وحی لانے پر کون سے مقرب فرشتے مامور تھے؟",
      roman: "Quran Majeed ki wahi lane par konse farishte mamoor the?"
    },
    options: {
      en: ["Jibreel (Gabriel) AS", "Mika'il (Michael) AS", "Israfil AS", "Malik AS"],
      ur: ["حضرت جبرائیل علیہ السلام", "حضرت میکائیل علیہ السلام", "حضرت اسرافیل علیہ السلام", "حضرت مالک علیہ السلام"],
      roman: ["Hazrat Jibreel (A.S)", "Hazrat Mika'il (A.S)", "Hazrat Israfil (A.S)", "Hazrat Malik (A.S)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Ash-Shu'ara (26:193) & Surah Al-Baqarah (2:97)",
      ur: "سورۃ الشعراء آیت ۱۹۳ اور سورۃ البقرہ آیت ۹۷",
      roman: "Surah Ash-Shu'ara 193 wa Surah Baqarah 97"
    },
    explanation: {
      en: "Allah calls Angel Jibreel (AS) 'Ar-Ruh al-Amin' (The Trustworthy Spirit) who brought the Quran to the Prophet's ﷺ heart.",
      ur: "حضرت جبرائیل علیہ السلام کو روح الامین کہا گیا ہے جنہوں نے اللہ کے اذن سے رسول اللہ ﷺ پر وحی نازل فرمائی۔",
      roman: "Hazrat Jibreel (A.S) Allah ke hukum se wahi-e-Ilahi laye."
    }
  },
  {
    id: 120,
    categoryId: 1,
    difficulty: 'expert',
    question: {
      en: "How many Makki and Madani Surahs are generally classified in the Quran?",
      ur: "قرآن مجید کی سورتوں کی مکی اور مدنی عمومی تقسیم کیا ہے؟",
      roman: "Quran Majeed mein Makki aur Madani Surahs ki aam tadaad kitni hai?"
    },
    options: {
      en: ["86 Makki, 28 Madani", "70 Makki, 44 Madani", "90 Makki, 24 Madani", "80 Makki, 34 Madani"],
      ur: ["۸۶ مکی، ۲۸ مدنی", "۷۰ مکی، ۴۴ مدنی", "۹۰ مکی، ۲۴ مدنی", "۸۰ مکی، ۳۴ مدنی"],
      roman: ["86 Makki, 28 Madani", "70 Makki, 44 Madani", "90 Makki, 24 Madani", "80 Makki, 34 Madani"]
    },
    correctAnswer: 0,
    reference: {
      en: "Al-Itqan fi Ulum al-Quran (Imam As-Suyuti)",
      ur: "الاتقان فی علوم القرآن (علامہ جلال الدین سیوطی)",
      roman: "Al-Itqan fi Uloom al-Quran"
    },
    explanation: {
      en: "According to the majority of Quranic scholars, 86 Surahs were revealed before Hijrah (Makki) and 28 after Hijrah (Madani).",
      ur: "اکثر مفسرین کے مطابق ہجرت سے قبل نازل ہونے والی سورتیں ۸۶ (مکی) اور بعد از ہجرت ۲۸ (مدنی) ہیں۔",
      roman: "Aam tor par 86 Makki aur 28 Madani Surahs shumar hoti hain."
    }
  },
  {
    id: 121,
    categoryId: 1,
    difficulty: 'easy',
    question: {
      en: "What was the very first word of the Holy Quran revealed to Prophet Muhammad ﷺ?",
      ur: "نبی کریم ﷺ پر نازل ہونے والی وحی کا سب سے پہلا لفظ کیا تھا؟",
      roman: "Nabi Kareem ﷺ par nazil hone wali wahi ka pehla lafz kya tha?"
    },
    options: {
      en: ["Iqra (Read/Proclaim)", "Qul (Say)", "Al-Hamd (Praise)", "Bismillah"],
      ur: ["اقْرَأْ (پڑھیے)", "قُلْ (کہہ دیجیے)", "الْحَمْدُ (تمام تعریفیں)", "بِسْمِ اللَّهِ"],
      roman: ["Iqra (Parhiye)", "Qul (Keh dijiye)", "Al-Hamd", "Bismillah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Alaq (96:1)",
      ur: "سورۃ العلق، آیت ۱",
      roman: "Surah Al-Alaq, Ayah 1"
    },
    explanation: {
      en: "The first word commanded by Angel Jibreel (AS) was 'Iqra' (Read!) in the name of your Lord Who created.",
      ur: "غار حرا میں پہلی وحی کا پہلا کلمہ 'اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ' تھا۔",
      roman: "Pehla lafz 'Iqra' tha jis ke maana hain 'Parhiye'."
    }
  },
  {
    id: 122,
    categoryId: 1,
    difficulty: 'expert',
    question: {
      en: "Which fruit is specifically mentioned in the Quran as being in Jannah along with olive and date palm?",
      ur: "قرآن مجید میں کھجور اور زیتون کے ساتھ جنت کی کس نعمت اور پھل کا خاص ذکر آیا ہے؟",
      roman: "Quran mein khajoor aur zaitoon ke sath kis phal ka zikr aya hai?"
    },
    options: {
      en: ["Pomegranate (Rumman)", "Apple (Tuffah)", "Orange (Burtuqal)", "Mango (Anba)"],
      ur: ["انار (رُمَّان)", "سیب (تفاح)", "سنگترہ (برتقال)", "آم (انبہ)"],
      roman: ["Anaar (Rumman)", "Saib", "Malta", "Aam"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Ar-Rahman (55:68)",
      ur: "سورۃ الرحمٰن، آیت ۶۸",
      roman: "Surah Ar-Rahman, Ayah 68"
    },
    explanation: {
      en: "Allah states in Surah Ar-Rahman: 'In both of them are fruit and date palms and pomegranates' (فيهما فاكهة ونخل ورمان).",
      ur: "سورۃ الرحمٰن کی آیت ۶۸ میں فرمایا گیا: فِيهِمَا فَاكِهَةٌ وَنَخْلٌ وَرُمَّانٌ (ان میں میوے، کھجوریں اور انار ہیں)۔",
      roman: "Surah Ar-Rahman mein 'Nakhl wa Rumman' (Khajoor aur Anaar) ka zikr hai."
    }
  }
];
