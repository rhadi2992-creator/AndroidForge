import { Question } from '../../types/quiz';

export const seeratQuestions: Question[] = [
  {
    id: 301,
    categoryId: 3,
    difficulty: 'easy',
    question: {
      en: "In which blessed city was the Prophet Muhammad ﷺ born?",
      ur: "حضور اکرم ﷺ کی ولادت باسعادت کس مقدس شہر میں ہوئی؟",
      roman: "Huzoor Akram ﷺ ki wiladat-e-ba-saadat kis muqaddas shehar mein hui?"
    },
    options: {
      en: ["Makkah al-Mukarramah", "Madinah al-Munawwarah", "Ta'if", "Jerusalem (Al-Quds)"],
      ur: ["مکہ مکرمہ", "مدینہ منورہ", "طائف", "بیت المقدس"],
      roman: ["Makkah Mukarramah", "Madinah Munawwarah", "Ta'if", "Bait-ul-Muqaddas"]
    },
    correctAnswer: 0,
    reference: {
      en: "Ar-Raheeq Al-Makhtum (The Sealed Nectar)",
      ur: "الرحیق المختوم، تاریخِ ولادتِ مصطفی ﷺ",
      roman: "Ar-Raheeq Al-Makhtum"
    },
    explanation: {
      en: "Prophet Muhammad ﷺ was born in Makkah in the Year of the Elephant (571 CE) into the noble Banu Hashim clan of Quraysh.",
      ur: "آپ ﷺ کی ولادتِ باسعادت مکہ مکرمہ میں عام الفیل (۵۷۱ء) کے سال قریش کے معزز قبیلے بنو ہاشم میں ہوئی۔",
      roman: "Huzoor ﷺ ki wiladat Makkah Mukarramah mein Aam-ul-Feel (571 CE) mein hui."
    }
  },
  {
    id: 302,
    categoryId: 3,
    difficulty: 'easy',
    question: {
      en: "What was the name of the Prophet's ﷺ blessed father, who passed away before his birth?",
      ur: "حضور اکرم ﷺ کے والد ماجد کا اسم گرامی کیا تھا جن کا وصال ولادت سے قبل ہو گیا تھا؟",
      roman: "Huzoor ﷺ ke walid-e-majid ka naam kya tha jinka inteqal wiladat se pehle ho gaya tha?"
    },
    options: {
      en: ["Hazrat Abdullah", "Hazrat Abu Talib", "Hazrat Abdul Muttalib", "Hazrat Hamzah"],
      ur: ["حضرت عبداللہ", "حضرت ابو طالب", "حضرت عبدالمطلب", "حضرت حمزہ"],
      roman: ["Hazrat Abdullah", "Hazrat Abu Talib", "Hazrat Abdul Muttalib", "Hazrat Hamzah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Ibn Hisham",
      ur: "سیرت ابن ہشام و طبقات ابن سعد",
      roman: "Sirat Ibn Hisham"
    },
    explanation: {
      en: "Hazrat Abdullah ibn Abdul Muttalib passed away in Yathrib (Madinah) while returning from a trade journey prior to the Prophet's ﷺ birth.",
      ur: "حضرت عبداللہ رضی اللہ عنہ شام سے تجارتی سفر سے واپسی پر یثرب (مدینہ منورہ) میں وفات پا گئے تھے۔",
      roman: "Hazrat Abdullah (R.A) Huzoor ﷺ ki wiladat se pehle Yathrib mein wafaat pa gaye the."
    }
  },
  {
    id: 303,
    categoryId: 3,
    difficulty: 'easy',
    question: {
      en: "Who was the blessed foster mother who nursed Prophet Muhammad ﷺ during his early childhood in the desert?",
      ur: "وہ کون سی خوش نصیب دایہ ہیں جنہوں نے بچپن میں رسول اللہ ﷺ کو رضاعت و پرورش کا شرف بخشا؟",
      roman: "Woh konsi khush-naseeb daai hain jinhon ne bachpan mein Huzoor ﷺ ki parwarish ki?"
    },
    options: {
      en: ["Hazrat Halimah Sa'diyyah", "Hazrat Umm Ayman", "Hazrat Thuwaybah", "Hazrat Fatimah bint Asad"],
      ur: ["حضرت حلیمہ سعدیہ", "حضرت ام ایمن", "حضرت ثویبہ", "حضرت فاطمہ بنت اسد"],
      roman: ["Hazrat Halimah Sa'diyyah", "Hazrat Umm Ayman", "Hazrat Thuwaybah", "Hazrat Fatimah bint Asad"]
    },
    correctAnswer: 0,
    reference: {
      en: "Ar-Raheeq Al-Makhtum & Sahih Muslim",
      ur: "الرحیق المختوم، قبیلہ بنو سعد میں رضاعت",
      roman: "Ar-Raheeq Al-Makhtum"
    },
    explanation: {
      en: "Hazrat Halimah Sa'diyyah of the Banu Sa'd tribe fostered the young Prophet ﷺ for several years where barakah filled her household.",
      ur: "حضرت حلیمہ سعدیہ رضی اللہ عنہا نے بنو سعد کے صحرا میں آپ ﷺ کی رضاعت و دیکھ بھال کا شرف پایا۔",
      roman: "Hazrat Halimah Sa'diyyah ne Banu Sa'd ke qabilay mein Huzoor ﷺ ki dekh-bhaal ki."
    }
  },
  {
    id: 304,
    categoryId: 3,
    difficulty: 'easy',
    question: {
      en: "What titles did the people of Makkah give to the Prophet ﷺ even before Islam due to his honesty and truthfulness?",
      ur: "اعلانِ نبوت سے قبل اہل مکہ آپ ﷺ کی سچائی اور امانت داری کی وجہ سے کن القابات سے پکارتے تھے؟",
      roman: "Ailaan-e-Nabuwwat se pehle ahl-e-Makkah Huzoor ﷺ ko kin alqabaat se pukarte the?"
    },
    options: {
      en: ["As-Sadiq and Al-Amin", "Al-Hakim and Al-Khatib", "Al-Qari and Az-Zahid", "Al-Mu'allim and Al-Faruq"],
      ur: ["الصادق اور الامین (سچا اور امانت دار)", "الحکیم اور الخطیب", "القاری اور الزاہد", "المعلم اور الفاروق"],
      roman: ["As-Sadiq aur Al-Ameen", "Al-Hakim aur Al-Khatib", "Al-Qari aur Az-Zahid", "Al-Muallim aur Al-Farooq"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Ibn Hisham",
      ur: "سیرت ابن ہشام، اخلاقِ مصطفی قبل از نبوت",
      roman: "Sirat Ibn Hisham"
    },
    explanation: {
      en: "The Quraysh acknowledged his impeccable character by calling him 'As-Sadiq' (The Truthful) and 'Al-Amin' (The Trustworthy).",
      ur: "اہلِ مکہ آپ ﷺ کی بے داغ صداقت کی وجہ سے آپ کو 'الصادق' (سب سے سچا) اور 'الامین' (امانت دار) کہتے تھے۔",
      roman: "Quraysh aap ko As-Sadiq (sacha) aur Al-Ameen (amanatdar) kehte the."
    }
  },
  {
    id: 305,
    categoryId: 3,
    difficulty: 'medium',
    question: {
      en: "Who was the first woman and the very first person to accept Islam at the hands of the Prophet ﷺ?",
      ur: "نبی کریم ﷺ کی دعوت پر سب سے پہلے اسلام قبول کرنے والی خاتون کون تھیں؟",
      roman: "Nabi Kareem ﷺ ki dawat par sab se pehle Islam qabool karne wali khatoon konsi theen?"
    },
    options: {
      en: ["Hazrat Khadijah bint Khuwaylid (RA)", "Hazrat Aisha (RA)", "Hazrat Fatimah (RA)", "Hazrat Sawdah (RA)"],
      ur: ["ام المؤمنین حضرت خدیجۃ الکبریٰ رضی اللہ عنہا", "ام المؤمنین حضرت عائشہ رضی اللہ عنہا", "سیدہ فاطمۃ الزہراء رضی اللہ عنہا", "ام المؤمنین حضرت سودہ رضی اللہ عنہا"],
      roman: ["Hazrat Khadijah (R.A)", "Hazrat Aisha (R.A)", "Hazrat Fatimah (R.A)", "Hazrat Sawdah (R.A)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 1, Hadith 3)",
      ur: "صحیح بخاری، آغازِ وحی، حدیث ۳",
      roman: "Sahih Bukhari, Bad'ul Wahi 3"
    },
    explanation: {
      en: "Hazrat Khadijah (RA) comforted the Prophet ﷺ after the first revelation and immediately embraced Islam without hesitation.",
      ur: "سیدہ خدیجہ الکبریٰ رضی اللہ عنہا نے پہلی وحی کے موقع پر آپ ﷺ کی ڈھارس بندھائی اور سب سے پہلے ایمان لائیں۔",
      roman: "Hazrat Khadijah (R.A) ne pehli wahi ke baad foran sab se pehle Islam qabool farmaya."
    }
  },
  {
    id: 306,
    categoryId: 3,
    difficulty: 'medium',
    question: {
      en: "How old was Prophet Muhammad ﷺ when he received the first divine revelation in Cave Hira?",
      ur: "جب غارِ حرا میں پہلی وحی نازل ہوئی تو اس وقت حضور اکرم ﷺ کی عمر مبارک کتنی تھی؟",
      roman: "Ghaar-e-Hira mein pehli wahi ke waqt Huzoor ﷺ ki umar mubarak kitni thi?"
    },
    options: {
      en: ["40 lunar years", "25 years", "33 years", "50 years"],
      ur: ["۴۰ سال", "۲۵ سال", "۳۳ سال", "۵۰ سال"],
      roman: ["40 saal", "25 saal", "33 saal", "50 saal"]
    },
    correctAnswer: 0,
    reference: {
      en: "Ar-Raheeq Al-Makhtum & Ibn Sa'd",
      ur: "الرحیق المختوم، بعثت نبوی ﷺ",
      roman: "Ar-Raheeq Al-Makhtum"
    },
    explanation: {
      en: "The Prophet ﷺ was bestowed with Prophethood at the age of 40 in the month of Ramadan.",
      ur: "آپ ﷺ کو ۴۰ سال کی عمر مبارک میں ماہِ رمضان میں منصبِ نبوت سے سرفراز کیا گیا۔",
      roman: "Huzoor ﷺ ko 40 saal ki umar mubarak mein Nabuwwat ata hui."
    }
  },
  {
    id: 307,
    categoryId: 3,
    difficulty: 'medium',
    question: {
      en: "What was the miraculous heavenly animal on which the Prophet ﷺ journeyed during the Night Journey (Al-Isra)?",
      ur: "واقعہ معراج (اسراء) میں رسول اللہ ﷺ نے کس آسمانی سواری پر سفر فرمایا تھا؟",
      roman: "Waqia-e-Miraj (Isra) mein Huzoor ﷺ ne kis aasmani sawari par safar farmaya?"
    },
    options: {
      en: ["Al-Buraq", "Al-Qaswa", "Ad-Duldul", "Al-Abwa"],
      ur: ["بُراق", "قصواء", "دُلدُل", "ابواء"],
      roman: ["Al-Buraq", "Al-Qaswa", "Ad-Duldul", "Al-Abwa"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 54, Hadith 429) & Sahih Muslim",
      ur: "صحیح بخاری، حدیث ۴۲۹ اور صحیح مسلم، حدیث ۱۶۲",
      roman: "Sahih Bukhari 429 wa Sahih Muslim 162"
    },
    explanation: {
      en: "Al-Buraq was a white, swift winged steed that moved at the speed of sight between Masjid al-Haram and Masjid al-Aqsa.",
      ur: "براق وہ جنتی سواری تھی جس پر آپ ﷺ نے مسجد الحرام سے مسجد اقصیٰ تک کا فاصلہ پلک جھپکتے طے فرمایا۔",
      roman: "Al-Buraq woh noorani sawari thi jis par Masjid-e-Haram se Masjid-e-Aqsa ka safar hua."
    }
  },
  {
    id: 308,
    categoryId: 3,
    difficulty: 'medium',
    question: {
      en: "What greatest gift was prescribed for the Muslim Ummah during the heavenly journey of Mi'raj?",
      ur: "معراج النبی ﷺ کی رات امتِ مسلمہ کو اللہ تعالیٰ کی طرف سے کیا سب سے بڑا تحفہ عطا فرمایا گیا؟",
      roman: "Miraj ki raat Ummat-e-Muslima ko kya azeem tohfa mila?"
    },
    options: {
      en: ["The Five Daily Prayers (Salah)", "Zakat", "Hajj", "Fasting Ramadan"],
      ur: ["پانچ وقت کی نمازیں", "زکوٰۃ", "حج", "رمضان کے روزے"],
      roman: ["Paanch waqt ki Namaz", "Zakat", "Hajj", "Ramzan ke Roze"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Hadith 349) & Sahih Muslim (Hadith 162)",
      ur: "صحیح بخاری حدیث ۳۴۹، صحیح مسلم حدیث ۱۶۲",
      roman: "Sahih Bukhari 349, Sahih Muslim 162"
    },
    explanation: {
      en: "Initially 50 prayers were decreed, reduced out of mercy through Prophet Musa's (AS) counsel to 5 prayers, retaining the reward of 50.",
      ur: "شبِ معراج پانچ وقت کی فرض نمازیں عطا ہوئیں جن کی ادائیگی پانچ اور اجر پچاس نمازوں کے برابر رکھا گیا۔",
      roman: "Shab-e-Miraj 5 waqt ki Namaz farz hui jiska ajar 50 namazon ke barabar hai."
    }
  },
  {
    id: 309,
    categoryId: 3,
    difficulty: 'hard',
    question: {
      en: "What was the name of the camel that the Prophet ﷺ rode during the Hijrah to Madinah?",
      ur: "ہجرتِ مدینہ کے موقع پر رسول اللہ ﷺ کی سواری والی اونٹنی کا کیا نام تھا؟",
      roman: "Hijrat-e-Madinah ke waqt Huzoor ﷺ ki sawari wali oontni ka kya naam tha?"
    },
    options: {
      en: ["Al-Qaswa", "Al-Baiza", "As-Sahba", "Al-Adba"],
      ur: ["قَصواء", "بیضاء", "صہباء", "عضباء"],
      roman: ["Al-Qaswa", "Al-Baiza", "As-Sahba", "Al-Adba"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Ibn Hisham & Zad al-Ma'ad",
      ur: "سیرت ابن ہشام و زاد المعاد فی ہدی خیر العباد",
      roman: "Sirat Ibn Hisham"
    },
    explanation: {
      en: "Al-Qaswa was the blessed she-camel that knelt down at the exact site where Masjid an-Nabawi was subsequently built.",
      ur: "قصواء وہ مبارک اونٹنی تھی جو مدینہ منورہ پہنچ کر اس مقام پر بیٹھی جہاں بعد میں مسجد نبوی تعمیر ہوئی۔",
      roman: "Al-Qaswa woh mubarak oontni thi jo Masjid an-Nabawi ke maqam par baithi thi."
    }
  },
  {
    id: 310,
    categoryId: 3,
    difficulty: 'hard',
    question: {
      en: "In which Islamic year did the decisive first major battle, Ghazwa-e-Badr, take place?",
      ur: "حق و باطل کا پہلا فیصلہ کن معرکہ 'غزوہ بدر' کس ہجری سال میں واقع ہوا؟",
      roman: "Haq wa baatil ka pehla maraka 'Ghazwa-e-Badr' kis Hijri saal mein hua?"
    },
    options: {
      en: ["2 AH (17th Ramadan)", "1 AH", "3 AH", "5 AH"],
      ur: ["۲ ہجری (۱۷ رمضان المبارک)", "۱ ہجری", "۳ ہجری", "۵ ہجری"],
      roman: ["2 Hijri (17 Ramzan)", "1 Hijri", "3 Hijri", "5 Hijri"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Anfal & Tarikh at-Tabari",
      ur: "سورۃ الانفال (یوم الفرقان) و تاریخ طبری",
      roman: "Surah Al-Anfal & Tarikh at-Tabari"
    },
    explanation: {
      en: "Ghazwa Badr occurred on 17 Ramadan 2 AH, where 313 Muslims triumphed over 1,000 Quraysh fighters with divine assistance.",
      ur: "غزوہ بدر ۱۷ رمضان ۲ ہجری کو پیش آیا جس میں ۳۱۳ مسلمانوں نے ایک ہزار کے لشکر پر اللہ کی مدد سے فتح حاصل کی۔",
      roman: "Ghazwa Badr 17 Ramzan 2 Hijri ko lara gaya jis mein 313 musalman fatah-yaab hue."
    }
  },
  {
    id: 311,
    categoryId: 3,
    difficulty: 'hard',
    question: {
      en: "Who accompanied the Prophet ﷺ during his historic migration (Hijrah) from Makkah to Madinah in Cave Thawr?",
      ur: "ہجرتِ مدینہ کے دوران غارِ ثور میں رسول اللہ ﷺ کے ساتھ کون سے جانثار رفیق موجود تھے؟",
      roman: "Hijrat-e-Madinah ke dauran Ghaar-e-Thawr mein Huzoor ﷺ ke sath konse sahabi the?"
    },
    options: {
      en: ["Hazrat Abu Bakr As-Siddiq (RA)", "Hazrat Umar ibn Al-Khattab (RA)", "Hazrat Ali ibn Abi Talib (RA)", "Hazrat Uthman ibn Affan (RA)"],
      ur: ["حضرت ابوبکر صدیق رضی اللہ عنہ", "حضرت عمر فاروق رضی اللہ عنہ", "حضرت علی المرتضیٰ رضی اللہ عنہ", "حضرت عثمان غنی رضی اللہ عنہ"],
      roman: ["Hazrat Abu Bakr As-Siddiq (R.A)", "Hazrat Umar (R.A)", "Hazrat Ali (R.A)", "Hazrat Uthman (R.A)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah At-Tawbah (9:40)",
      ur: "سورۃ التوبہ، آیت ۴۰: 'إِذْ يَقُولُ لِصَاحِبِهِ لَا تَحْزَنْ إِنَّ اللَّهَ مَعَنَا'",
      roman: "Surah At-Tawbah, Ayah 40"
    },
    explanation: {
      en: "The Quran mentions Hazrat Abu Bakr (RA) as 'the companion' (ثاني اثنين إذ هما في الغار) whom the Prophet comforted with 'Do not grieve, Allah is with us.'",
      ur: "قرآن مجید میں حضرت ابوبکر صدیق رضی اللہ عنہ کو 'ثاني اثنين' (دو میں سے دوسرا) اور رسول اللہ ﷺ کا صاحب (ساتھی) کہا گیا ہے۔",
      roman: "Surah Tawbah 40 mein Hazrat Abu Bakr (R.A) ka zikr 'Saani-yasnain' ke tor par aya hai."
    }
  },
  {
    id: 312,
    categoryId: 3,
    difficulty: 'expert',
    question: {
      en: "Which companion was buried first in the Jannat al-Baqi cemetery after the Hijrah to Madinah?",
      ur: "ہجرت کے بعد مدینہ منورہ کے قبرستان 'جنت البقیع' میں دفن ہونے والے سب سے پہلے مہاجر صحابی کون تھے؟",
      roman: "Jannat al-Baqi mein dafn hone wale pehle muhajir sahabi kon the?"
    },
    options: {
      en: ["Hazrat Uthman ibn Maz'un (RA)", "Hazrat Mus'ab ibn Umayr (RA)", "Hazrat Hamzah (RA)", "Hazrat Zayd ibn Harithah (RA)"],
      ur: ["حضرت عثمان بن مظعون رضی اللہ عنہ", "حضرت مصعب بن عمیر رضی اللہ عنہ", "حضرت حمزہ رضی اللہ عنہ", "حضرت زید بن حارثہ رضی اللہ عنہ"],
      roman: ["Hazrat Uthman bin Maz'oon (R.A)", "Hazrat Mus'ab bin Umayr (R.A)", "Hazrat Hamzah (R.A)", "Hazrat Zayd bin Harithah (R.A)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Al-Bidayah wan-Nihayah (Ibn Kathir)",
      ur: "البدایہ والنہایہ و طبقات ابن سعد",
      roman: "Al-Bidayah wan-Nihayah"
    },
    explanation: {
      en: "Hazrat Uthman ibn Maz'un (RA) was the first Muhajir buried in Baqi' al-Gharqad; the Prophet ﷺ placed a stone at his grave.",
      ur: "حضرت عثمان بن مظعون رضی اللہ عنہ جنت البقیع میں دفن ہونے والے اولین صحابی تھے، جن کی قبر پر حضور ﷺ نے پتھر رکھوایا۔",
      roman: "Hazrat Uthman bin Maz'oon (R.A) Jannat al-Baqi mein dafn hone wale pehle muhajir the."
    }
  },
  {
    id: 313,
    categoryId: 3,
    difficulty: 'expert',
    question: {
      en: "Who wrote down the clauses of the Treaty of Hudaybiyyah on behalf of the Muslims?",
      ur: "صلح حدیبیہ کی شرائط کو مسلمانوں کی طرف سے تحریر کرنے کی سعادت کس صحابی کو حاصل ہوئی؟",
      roman: "Sulah-e-Hudaybiyyah ki dastawaiz kis Sahabi ne tehreer farmayi thi?"
    },
    options: {
      en: ["Hazrat Ali ibn Abi Talib (RA)", "Hazrat Uthman ibn Affan (RA)", "Hazrat Zayd ibn Thabit (RA)", "Hazrat Mu'awiyah (RA)"],
      ur: ["حضرت علی بن ابی طالب رضی اللہ عنہ", "حضرت عثمان بن عفان رضی اللہ عنہ", "حضرت زید بن ثابت رضی اللہ عنہ", "حضرت معاویہ رضی اللہ عنہ"],
      roman: ["Hazrat Ali bin Abi Talib (R.A)", "Hazrat Uthman (R.A)", "Hazrat Zayd bin Thabit (R.A)", "Hazrat Mu'awiyah (R.A)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 53, Hadith 891)",
      ur: "صحیح بخاری، کتاب الشروط، حدیث ۸۹۱",
      roman: "Sahih Bukhari, Hadith 891"
    },
    explanation: {
      en: "Hazrat Ali (RA) wrote the treaty text; when the Quraysh objected to 'Muhammad Rasulullah', the Prophet ﷺ instructed him to write 'Muhammad ibn Abdullah'.",
      ur: "حضرت علی رضی اللہ عنہ نے صلح حدیبیہ کی دستاویز تحریر فرمائی، جب قریش نے رسول اللہ لکھنے پر اعتراض کیا تو آپ ﷺ نے مٹا کر محمد بن عبداللہ لکھوایا۔",
      roman: "Hazrat Ali (R.A) ne Sulah Hudaybiyyah ka muahida tehreer farmaya."
    }
  },
  {
    id: 314,
    categoryId: 3,
    difficulty: 'easy',
    question: {
      en: "In which year of Hijrah was Makkah peacefully conquered (Fath Makkah)?",
      ur: "مکہ مکرمہ کس سن ہجری میں بغیر خون خرابے کے فتح ہوا (فتحِ مکہ)؟",
      roman: "Makkah Mukarramah kis Hijri saal mein fatah hua (Fath Makkah)?"
    },
    options: {
      en: ["8 AH (20th Ramadan)", "6 AH", "9 AH", "10 AH"],
      ur: ["۸ ہجری (۲۰ رمضان المبارک)", "۶ ہجری", "۹ ہجری", "۱۰ ہجری"],
      roman: ["8 Hijri (20 Ramzan)", "6 Hijri", "9 Hijri", "10 Hijri"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Hadith 4275)",
      ur: "صحیح بخاری، مغازی فتح مکہ، حدیث ۴۲۷۵",
      roman: "Sahih Bukhari, Hadith 4275"
    },
    explanation: {
      en: "The Prophet ﷺ entered Makkah victorious on 20 Ramadan 8 AH with 10,000 companions, granting general amnesty to all.",
      ur: "۲۰ رمضان ۸ ہجری کو مکہ مکرمہ فتح ہوا اور نبی کریم ﷺ نے عام معافی (لا تثريب عليكم اليوم) کا اعلان فرمایا۔",
      roman: "Fath Makkah 8 Hijri mein hua aur Huzoor ﷺ ne aam maafi ka ailan farmaya."
    }
  },
  {
    id: 315,
    categoryId: 3,
    difficulty: 'medium',
    question: {
      en: "What was the name of the Prophet's ﷺ grandfather who cared for him after his mother passed away?",
      ur: "والدہ ماجدہ کی وفات کے بعد کس شفیق دادا جان نے رسول اللہ ﷺ کی کفالت فرمائی؟",
      roman: "Walida ki wafaat ke baad kis dada ne Huzoor ﷺ ki kafalat farmayi?"
    },
    options: {
      en: ["Hazrat Abdul Muttalib", "Hazrat Abu Talib", "Hazrat Hashim", "Hazrat Abd Manaf"],
      ur: ["حضرت عبدالمطلب", "حضرت ابو طالب", "حضرت ہاشم", "حضرت عبد مناف"],
      roman: ["Hazrat Abdul Muttalib", "Hazrat Abu Talib", "Hazrat Hashim", "Hazrat Abd Manaf"]
    },
    correctAnswer: 0,
    reference: {
      en: "Ar-Raheeq Al-Makhtum",
      ur: "الرحیق المختوم، کفالتِ عبدالمطلب",
      roman: "Ar-Raheeq Al-Makhtum"
    },
    explanation: {
      en: "Hazrat Abdul Muttalib deeply cherished the young Prophet ﷺ until his own passing when the Prophet was eight years old.",
      ur: "حضرت عبدالمطلب نے حضرت آمنہ رضی اللہ عنہا کی وفات کے بعد دو سال تک آپ ﷺ کی انتہائی محبت سے پرورش فرمائی۔",
      roman: "Hazrat Abdul Muttalib ne do saal tak Huzoor ﷺ ki kafalat ki."
    }
  },
  {
    id: 316,
    categoryId: 3,
    difficulty: 'medium',
    question: {
      en: "Who was the maternal nurse and companion who took care of the Prophet ﷺ after his mother's demise?",
      ur: "والدہ ماجدہ کی وفات کے بعد کون سی وفادار خادمہ اور مربی آپ ﷺ کو مکہ واپس لائیں؟",
      roman: "Hazrat Amina ki wafaat ke baad konsi mubarak khatoon Huzoor ﷺ ko Makkah layeen?"
    },
    options: {
      en: ["Hazrat Umm Ayman (Barakah) RA", "Hazrat Fatimah bint Asad", "Hazrat Asma bint Abi Bakr", "Hazrat Umm Kulthum"],
      ur: ["حضرت ام ایمن (برکہ) رضی اللہ عنہا", "حضرت فاطمہ بنت اسد", "حضرت اسماء بنت ابی بکر", "حضرت ام کلثوم"],
      roman: ["Hazrat Umm Ayman (Barakah) R.A", "Hazrat Fatimah bint Asad", "Hazrat Asma", "Hazrat Umm Kulthum"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tabaqat Ibn Sa'd & Sahih Muslim",
      ur: "طبقات ابن سعد، ذکر ام ایمن حبشیہ",
      roman: "Tabaqat Ibn Sa'd"
    },
    explanation: {
      en: "The Prophet ﷺ used to honor Umm Ayman (RA) saying: 'She is my mother after my mother.'",
      ur: "رسول اللہ ﷺ نے حضرت ام ایمن رضی اللہ عنہا کے متعلق فرمایا: 'یہ میری ماں کے بعد میری ماں ہیں۔'",
      roman: "Huzoor ﷺ ne farmaya: Umm Ayman meri maa ke baad meri maa hain."
    }
  },
  {
    id: 317,
    categoryId: 3,
    difficulty: 'hard',
    question: {
      en: "At what age did the Prophet Muhammad ﷺ marry Sayyida Khadijah (RA)?",
      ur: "ام المؤمنین حضرت خدیجہ رضی اللہ عنہا سے نکاح کے وقت حضور اکرم ﷺ کی عمر مبارک کتنی تھی؟",
      roman: "Sayyida Khadijah (R.A) se nikah ke waqt Huzoor ﷺ ki umar mubarak kitni thi?"
    },
    options: {
      en: ["25 years", "20 years", "30 years", "40 years"],
      ur: ["۲۵ سال", "۲۰ سال", "۳۰ سال", "۴۰ سال"],
      roman: ["25 saal", "20 saal", "30 saal", "40 saal"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Ibn Hisham & Zad al-Ma'ad",
      ur: "سیرت ابن ہشام، نکاحِ خدیجۃ الکبریٰ",
      roman: "Sirat Ibn Hisham"
    },
    explanation: {
      en: "The Prophet ﷺ was 25 years old when he married Sayyida Khadijah (RA) following her admiration of his honesty in the trade journey to Syria.",
      ur: "شام کے کامیاب تجارتی سفر اور صداقت و امانت داری کے مشاہدے کے بعد ۲۵ سال کی عمر میں نکاح مبارک ہوا۔",
      roman: "Huzoor ﷺ ki umar mubarak nikah ke waqt 25 saal thi."
    }
  },
  {
    id: 318,
    categoryId: 3,
    difficulty: 'hard',
    question: {
      en: "What was the Year of Sorrow (Aam al-Huzn) in the Prophetic biography?",
      ur: "سیرت النبی ﷺ میں 'عام الحزن' (غم کا سال) کس سال کو کہا جاتا ہے؟",
      roman: "Seerat mein 'Aam-ul-Huzn' (Gham ka saal) kis saal ko kehte hain?"
    },
    options: {
      en: [
        "The 10th year of Prophethood when Abu Talib and Hazrat Khadijah passed away",
        "The year of Ghazwa Uhud",
        "The year of the Boycott",
        "The year of passing away in Madinah"
      ],
      ur: [
        "نبوت کا دسواں سال جب حضرت ابو طالب اور سیدہ خدیجہ رضی اللہ عنہا کا وصال ہوا",
        "غزوہ احد کا سال",
        "شعب ابی طالب کی محصوری کا سال",
        "مدینہ میں وصال کا سال"
      ],
      roman: [
        "Nabuwwat ka 10wan saal jab Abu Talib aur Hazrat Khadijah ka inteqal hua",
        "Ghazwa Uhud ka saal",
        "Boycott ka saal",
        "Wafaat ka saal"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Ar-Raheeq Al-Makhtum & Ibn Hisham",
      ur: "الرحیق المختوم، عام الحزن",
      roman: "Ar-Raheeq Al-Makhtum"
    },
    explanation: {
      en: "In the 10th year of Prophethood, both his protective uncle Abu Talib and his beloved wife Hazrat Khadijah (RA) passed away.",
      ur: "نبوت کے دسویں سال آپ ﷺ کے سرپرست چچا ابو طالب اور رفیقہ حیات حضرت خدیجہ رضی اللہ عنہا کی وفات پر اسے غم کا سال کہا گیا۔",
      roman: "Nabuwwat ke 10wein saal Hazrat Khadijah aur Abu Talib dono ka inteqal hua."
    }
  },
  {
    id: 319,
    categoryId: 3,
    difficulty: 'expert',
    question: {
      en: "What was the name of the valley where the Quraysh boycotted the Banu Hashim clan for three harsh years?",
      ur: "وہ کون سی گھاٹی تھی جہاں قریش مکہ نے بنو ہاشم کا تین سال تک ظالمانہ معاشی و سماجی بائیکاٹ کیا؟",
      roman: "Quraysh ne Banu Hashim ka 3 saal tak kis ghaati mein boycott kiya tha?"
    },
    options: {
      en: ["Shi'b Abi Talib", "Wadi Fatima", "Wadi Nu'man", "Wadi Muhassar"],
      ur: ["شِعْبِ ابی طالب", "وادی فاطمہ", "وادی نعمان", "وادی محسر"],
      roman: ["Shi'b Abi Talib", "Wadi Fatima", "Wadi Nu'man", "Wadi Muhassar"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Ibn Hisham",
      ur: "سیرت ابن ہشام، محاصرہ شعب ابی طالب",
      roman: "Sirat Ibn Hisham"
    },
    explanation: {
      en: "From the 7th to the 10th year of Prophethood, Muslims endured extreme hunger in Shi'b Abi Talib until the parchment was eaten by termites.",
      ur: "نبوت کے ساتویں سے دسویں سال تک شعب ابی طالب میں صحابہ اور بنو ہاشم نے درختوں کے پتے کھا کر وقت گزارا۔",
      roman: "Shi'b Abi Talib mein 3 saal tak musalmanon par sakht tareen pabandi lagayi gayi."
    }
  },
  {
    id: 320,
    categoryId: 3,
    difficulty: 'expert',
    question: {
      en: "During the Farewell Pilgrimage (Hajjat al-Wida), on which plain did the Prophet ﷺ deliver his historic Farewell Sermon?",
      ur: "حجۃ الوداع کے موقع پر رسول اللہ ﷺ نے اپنا تاریخی آخری خطبہ کس میدان میں ارشاد فرمایا؟",
      roman: "Hajjat-ul-Wida ke moqa par Huzoor ﷺ ne apna aakhri khutba kis maidan mein diya?"
    },
    options: {
      en: ["Plain of Arafat (Mount of Mercy / Jabal ar-Rahmah)", "Muzdalifah", "Mina", "Al-Hudaibiyyah"],
      ur: ["میدانِ عرفات (جبل الرحمۃ کے قریب)", "مزدلفہ", "منیٰ", "حدیبیہ"],
      roman: ["Maidan-e-Arafat (Jabal ar-Rahmah)", "Muzdalifah", "Mina", "Hudaibiyyah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 7, Hadith 2803)",
      ur: "صحیح مسلم، کتاب الحج، حدیث ۲۸۰۳",
      roman: "Sahih Muslim, Hadith 2803"
    },
    explanation: {
      en: "On 9th Dhul Hijjah 10 AH, the Prophet ﷺ delivered the universal charter of human equality and Islamic brotherhood in Uranah valley at Arafat.",
      ur: "۹ ذوالحجہ ۱۰ ہجری کو میدان عرفات میں آپ ﷺ نے خطبہ حجۃ الوداع دیا جس میں تمام نسلوں کی برابری اور انسانی حقوق کا اعلان فرمایا۔",
      roman: "9 Zilhajj 10 Hijri ko Maidan-e-Arafat mein Huzoor ﷺ ne aakhri khutba farmaya."
    }
  },
  {
    id: 321,
    categoryId: 3,
    difficulty: 'easy',
    question: {
      en: "What was the name of the Prophet's ﷺ beloved mother?",
      ur: "حضور اکرم ﷺ کی والدہ ماجدہ کا اسم گرامی کیا تھا؟",
      roman: "Huzoor ﷺ ki walida majida ka naam kya tha?"
    },
    options: {
      en: ["Hazrat Aminah bint Wahb", "Hazrat Halimah", "Hazrat Asiyah", "Hazrat Safiyyah"],
      ur: ["حضرت آمنہ بنت وہب", "حضرت حلیمہ", "حضرت آسیہ", "حضرت صفاریہ"],
      roman: ["Hazrat Aminah bint Wahb", "Hazrat Halimah", "Hazrat Asiyah", "Hazrat Safiyyah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Ibn Hisham",
      ur: "سیرت ابن ہشام و کتبِ انساب",
      roman: "Sirat Ibn Hisham"
    },
    explanation: {
      en: "Hazrat Aminah belonged to the Banu Zuhrah clan of Quraysh and passed away at Al-Abwa when the Prophet was six years old.",
      ur: "حضرت آمنہ قریش کے معزز قبیلے بنو زہرہ سے تعلق رکھتی تھیں اور بمقام ابواء ان کا وصال ہوا۔",
      roman: "Hazrat Aminah (R.A) Huzoor ﷺ ki walida theen aur Abwa ke maqam par wafaat paayi."
    }
  },
  {
    id: 322,
    categoryId: 3,
    difficulty: 'expert',
    question: {
      en: "In which year did the Prophet ﷺ pass away to the Highest Companion (Ar-Rafiq al-A'la)?",
      ur: "رسول اللہ ﷺ نے کس سن ہجری میں رفیقِ اعلیٰ سے جا ملنے (وصال مبارک) کا سفر فرمایا؟",
      roman: "Rasool Allah ﷺ ka wisal mubarak kis Hijri saal mein hua?"
    },
    options: {
      en: ["11 AH (Rabi' al-Awwal)", "10 AH", "12 AH", "13 AH"],
      ur: ["۱۱ ہجری (ماہ ربیع الاول)", "۱۰ ہجری", "۱۲ ہجری", "۱۳ ہجری"],
      roman: ["11 Hijri (Rabi-ul-Awwal)", "10 Hijri", "12 Hijri", "13 Hijri"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 64, Hadith 4440)",
      ur: "صحیح بخاری، حدیث ۴۴۴۰، وفات النبی ﷺ",
      roman: "Sahih Bukhari, Hadith 4440"
    },
    explanation: {
      en: "Prophet Muhammad ﷺ passed away on Monday 12 Rabi' al-Awwal 11 AH in the chamber of Sayyida Aisha (RA) in Madinah.",
      ur: "نبی کریم ﷺ کا وصال ۱۲ ربیع الاول ۱۱ ہجری کو مدینہ منورہ میں سیدہ عائشہ رضی اللہ عنہا کے حجرہ مبارکہ میں ہوا۔",
      roman: "Huzoor ﷺ ka wisal 11 Hijri Rabi-ul-Awwal mein Madinah Munawwarah mein hua."
    }
  }
];
