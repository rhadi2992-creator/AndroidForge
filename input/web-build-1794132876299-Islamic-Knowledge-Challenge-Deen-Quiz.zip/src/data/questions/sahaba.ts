import { Question } from '../../types/quiz';

export const sahabaQuestions: Question[] = [
  {
    id: 701,
    categoryId: 7,
    difficulty: 'easy',
    question: {
      en: "Which companion was given the title 'As-Siddiq' (The Truthful) by the Prophet ﷺ after believing in the Night Journey (Isra and Mi'raj)?",
      ur: "واقعہ معراج کی بلا جھجھک تصدیق کرنے پر رسول اللہ ﷺ نے کس صحابی کو 'الصدیق' کا عظیم لقب عطا فرمایا؟",
      roman: "Waqia-e-Miraj ki foran tasdeeq karne par kis sahabi ko 'As-Siddiq' ka laqab mila?"
    },
    options: {
      en: ["Hazrat Abu Bakr (RA)", "Hazrat Umar (RA)", "Hazrat Uthman (RA)", "Hazrat Ali (RA)"],
      ur: ["حضرت ابوبکر رضی اللہ عنہ", "حضرت عمر رضی اللہ عنہ", "حضرت عثمان رضی اللہ عنہ", "حضرت علی رضی اللہ عنہ"],
      roman: ["Hazrat Abu Bakr (R.A)", "Hazrat Umar (R.A)", "Hazrat Uthman (R.A)", "Hazrat Ali (R.A)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Al-Mustadrak 'ala al-Sahihayn (Al-Hakim)",
      ur: "المستدرک علی الصحیحین، ذکر الصدیق اکبر رضی اللہ عنہ",
      roman: "Al-Mustadrak, Hakim"
    },
    explanation: {
      en: "When the Quraysh mocked the account of Mi'raj, Abu Bakr (RA) stated: 'If he said it, then it is true without doubt.'",
      ur: "جب مشرکین نے معراج پر اعتراض کیا تو آپ نے فرمایا: اگر میرے آقا ﷺ نے فرمایا ہے تو بالکل سچ فرمایا ہے۔",
      roman: "Hazrat Abu Bakr (R.A) ne farmaya: Agar Huzoor ﷺ ne farmaya hai to bilkul sach hai."
    }
  },
  {
    id: 702,
    categoryId: 7,
    difficulty: 'easy',
    question: {
      en: "Which companion was given the title 'Al-Faruq' (The One who Distinguishes between Truth and Falsehood)?",
      ur: "کس جلیل القدر صحابی کو حق اور باطل کے درمیان واضح فرق کر دینے والا 'الفاروق' کا لقب ملا؟",
      roman: "Haq aur baatil mein farq karne wale 'Al-Farooq' ka laqab kis sahabi ko mila?"
    },
    options: {
      en: ["Hazrat Umar ibn Al-Khattab (RA)", "Hazrat Abu Bakr (RA)", "Hazrat Uthman (RA)", "Hazrat Hamzah (RA)"],
      ur: ["حضرت عمر بن خطاب رضی اللہ عنہ", "حضرت ابوبکر صدیق رضی اللہ عنہ", "حضرت عثمان غنی رضی اللہ عنہ", "حضرت حمزہ رضی اللہ عنہ"],
      roman: ["Hazrat Umar bin Al-Khattab (R.A)", "Hazrat Abu Bakr", "Hazrat Uthman", "Hazrat Hamzah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh at-Tabari & Ibn Hajar",
      ur: "تاریخ الخلفاء، علامہ سیوطی، تسمیہ بالفاروق",
      roman: "Tarikh al-Khulafa"
    },
    explanation: {
      en: "Upon Hazrat Umar's (RA) conversion, Muslims prayed openly at the Ka'bah for the first time, distinguishing truth from falsehood.",
      ur: "حضرت عمر فاروق رضی اللہ عنہ کے اسلام لانے کے بعد مسلمانوں نے پہلی بار کعبہ میں اعلانیہ نماز ادا کی۔",
      roman: "Hazrat Umar (R.A) ke aane se Islam ko azeem izzat aur quwwat mili."
    }
  },
  {
    id: 703,
    categoryId: 7,
    difficulty: 'easy',
    question: {
      en: "Which companion was titled 'Dhun-Nurayn' (Possessor of the Two Lights) for marrying two daughters of the Prophet ﷺ?",
      ur: "حضور اکرم ﷺ کی دو صاحبزادیوں سے یکے بعد دیگرے نکاح کی سعادت پر کس صحابی کو 'ذو النورین' کہا جاتا ہے؟",
      roman: "Huzoor ﷺ ki do betiyon se nikah ki wajah se 'Zun-Noorain' kis sahabi ko kaha jata hai?"
    },
    options: {
      en: ["Hazrat Uthman ibn Affan (RA)", "Hazrat Ali (RA)", "Hazrat Talhah (RA)", "Hazrat Zubayr (RA)"],
      ur: ["حضرت عثمان بن عفان رضی اللہ عنہ", "حضرت علی رضی اللہ عنہ", "حضرت طلحہ رضی اللہ عنہ", "حضرت زبیر رضی اللہ عنہ"],
      roman: ["Hazrat Uthman bin Affan (R.A)", "Hazrat Ali", "Hazrat Talhah", "Hazrat Zubair"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 62, Hadith 29)",
      ur: "صحیح بخاری، مناقب عثمان رضی اللہ عنہ، حدیث ۲۹",
      roman: "Sahih Bukhari, Hadith 29"
    },
    explanation: {
      en: "Hazrat Uthman (RA) married Sayyida Ruqayyah (RA), and after her passing, married Sayyida Umm Kulthum (RA).",
      ur: "حضرت عثمان غنی رضی اللہ عنہ کے نکاح میں رسول اللہ ﷺ کی دو صاحبزادیاں سیدہ رقیہ اور ان کی وفات کے بعد سیدہ ام کلثوم آئیں۔",
      roman: "Hazrat Uthman (R.A) ko do nooron (betiyon) ki nisbat se Zun-Noorain kaha gaya."
    }
  },
  {
    id: 704,
    categoryId: 7,
    difficulty: 'easy',
    question: {
      en: "Which companion was known as 'Asadullah' (Lion of Allah) and 'Haydar' for his fearless valor?",
      ur: "کس شیرِ خدا صحابی کو ان کی بے خوف بہادری پر 'اسد اللہ' اور 'حیدرِ کرار' کا لقب دیا گیا؟",
      roman: "Kis Sahabi ko unki bahaduri par 'Asadullah' aur 'Haidar-e-Karrar' kaha gaya?"
    },
    options: {
      en: ["Hazrat Ali ibn Abi Talib (RA)", "Hazrat Khalid ibn al-Walid (RA)", "Hazrat Sa'd ibn Abi Waqqas (RA)", "Hazrat Hamzah (RA)"],
      ur: ["حضرت علی بن ابی طالب رضی اللہ عنہ", "حضرت خالد بن ولید رضی اللہ عنہ", "حضرت سعد بن ابی وقاص رضی اللہ عنہ", "حضرت حمزہ رضی اللہ عنہ"],
      roman: ["Hazrat Ali bin Abi Talib (R.A)", "Hazrat Khalid bin Walid", "Hazrat Sa'd bin Abi Waqqas", "Hazrat Hamzah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 44, Hadith 2404)",
      ur: "صحیح مسلم، فضائل علی بن ابی طالب، حدیث ۲۴۰۴",
      roman: "Sahih Muslim, Fazail Ali 2404"
    },
    explanation: {
      en: "At Ghazwa Khaybar, the Prophet ﷺ handed the banner to Hazrat Ali (RA), who breached the fortress of Qamus single-handedly.",
      ur: "غزوہ خیبر میں حضور ﷺ نے علم حضرت علی کو دیا جنہوں نے خیبر کا ناقابل تسخیر قلعہ فتح فرمایا۔",
      roman: "Hazrat Ali (R.A) ne Ghazwa-e-Khaibar mein azeem tareekhi shuja'at dikhayi."
    }
  },
  {
    id: 705,
    categoryId: 7,
    difficulty: 'medium',
    question: {
      en: "Which legendary military commander was conferred the title 'Sayfullah' (The Sword of Allah) by the Prophet ﷺ?",
      ur: "کس عظیم سپہ سالار کو نبی کریم ﷺ نے 'سیف اللہ' (اللہ کی تلوار) کا مبارک لقب عطا فرمایا؟",
      roman: "Kis azeem sipah salar ko Huzoor ﷺ ne 'Saifullah' (Allah ki talwar) ka laqab diya?"
    },
    options: {
      en: ["Hazrat Khalid ibn al-Walid (RA)", "Hazrat Abu Ubaidah (RA)", "Hazrat Amr ibn Al-Aas (RA)", "Hazrat Tariq ibn Ziyad"],
      ur: ["حضرت خالد بن ولید رضی اللہ عنہ", "حضرت ابو عبیدہ رضی اللہ عنہ", "حضرت عمرو بن العاص رضی اللہ عنہ", "طارق بن زیاد"],
      roman: ["Hazrat Khalid bin Walid (R.A)", "Hazrat Abu Ubaidah", "Hazrat Amr bin Al-Aas", "Tariq bin Ziyad"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 62, Hadith 3757)",
      ur: "صحیح بخاری، حدیث ۳۷۵۷: 'سيف من سيوف الله سلّه الله على المشركين'",
      roman: "Sahih Bukhari, Hadith 3757"
    },
    explanation: {
      en: "Following the Battle of Mu'tah, the Prophet ﷺ praised him: 'Khalid is a sword from among the swords of Allah.' He never lost any battle.",
      ur: "غزوہ موتہ کے بعد آپ ﷺ نے حضرت خالد بن ولید کو 'سیف من سیوف اللہ' (اللہ کی تلواروں میں سے ایک تلوار) فرمایا۔",
      roman: "Hazrat Khalid bin Walid (R.A) ne apni zindagi mein koi jung nahi haari."
    }
  },
  {
    id: 706,
    categoryId: 7,
    difficulty: 'medium',
    question: {
      en: "Who was the first Mu'adhin (caller to prayer) of Islam, known for his steadfast patience under torture in Makkah?",
      ur: "مکہ میں شدید تکالیف پر 'اَحَد اَحَد' کا نعرہ لگانے والے اسلام کے پہلے مؤذن کون تھے؟",
      roman: "Islam ke pehle Mu'azzin kon the jinhon ne Makkah mein sakht zulm par 'Ahad Ahad' pukara?"
    },
    options: {
      en: ["Hazrat Bilal ibn Rabah (RA)", "Hazrat Abdullah ibn Mas'ud (RA)", "Hazrat Ammar ibn Yasir (RA)", "Hazrat Suhayb ar-Rumi (RA)"],
      ur: ["حضرت بلال بن رباح رضی اللہ عنہ", "حضرت عبداللہ بن مسعود رضی اللہ عنہ", "حضرت عمار بن یاسر رضی اللہ عنہ", "حضرت صہیب رومی رضی اللہ عنہ"],
      roman: ["Hazrat Bilal bin Rabah (R.A)", "Hazrat Abdullah bin Mas'ud", "Hazrat Ammar bin Yasir", "Hazrat Suhaib Roomi"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari & Siyar A'lam an-Nubala",
      ur: "صحیح بخاری و سیر اعلام النبلاء، ترجمہ بلال بن رباح",
      roman: "Siyar A'lam an-Nubala"
    },
    explanation: {
      en: "Hazrat Bilal (RA) proclaimed 'Ahad! Ahad!' (One! One!) while crushed beneath boulders in the scorching sands of Makkah until Abu Bakr purchased his freedom.",
      ur: "حضرت بلال رضی اللہ عنہ کو مکہ کی تپتی ریت پر دہکتے پتھروں تلے تڑپایا گیا مگر وہ ایک اللہ کی توحید پر ثابت قدم رہے۔",
      roman: "Hazrat Bilal (R.A) ne sakht tareen zulm sahe aur Islam ke pehle mu'azzin bane."
    }
  },
  {
    id: 707,
    categoryId: 7,
    difficulty: 'medium',
    question: {
      en: "Which companion suggested digging the defensive trench (Khandaq) around Madinah during the Battle of the Confederates (Ahzab)?",
      ur: "غزوہ خندق (احزاب) کے موقع پر مدینہ کے گرد خندق کھودنے کا دانشمندانہ مشورہ کس صحابی نے دیا تھا؟",
      roman: "Ghazwa-e-Khandaq ke moqa par khandaq khodne ka mashwara kis Sahabi ne diya?"
    },
    options: {
      en: ["Hazrat Salman al-Farsi (RA)", "Hazrat Abu Hurairah (RA)", "Hazrat Abu Dharr al-Ghifari (RA)", "Hazrat Miqdad (RA)"],
      ur: ["حضرت سلمان فارسی رضی اللہ عنہ", "حضرت ابوہریرہ رضی اللہ عنہ", "حضرت ابو ذر غفاری رضی اللہ عنہ", "حضرت مقداد رضی اللہ عنہ"],
      roman: ["Hazrat Salman al-Farsi (R.A)", "Hazrat Abu Hurairah", "Hazrat Abu Dharr", "Hazrat Miqdad"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Ibn Hisham & Zad al-Ma'ad",
      ur: "سیرت ابن ہشام، غزوہ خندق و رائے سلمان فارسی",
      roman: "Sirat Ibn Hisham, Ghazwa Khandaq"
    },
    explanation: {
      en: "Hazrat Salman al-Farsi (RA) proposed the Persian strategy of digging a trench, which thwarted the 10,000-strong confederate coalition.",
      ur: "حضرت سلمان فارسی رضی اللہ عنہ نے خندق کھودنے کی دفاعی حکمت عملی تجویز فرمائی جس سے دشمن ناکام لوٹا۔",
      roman: "Hazrat Salman al-Farsi (R.A) ne Madinah ke difa ke liye khandaq ki tajweez di."
    }
  },
  {
    id: 708,
    categoryId: 7,
    difficulty: 'hard',
    question: {
      en: "Which companion was titled 'Amin al-Ummah' (The Trustworthy of the Ummah) by the Prophet ﷺ?",
      ur: "رسول اللہ ﷺ نے کس جلیل القدر صحابی کو 'امین الامۃ' (امت کا امانت دار) کا لقب عطا فرمایا؟",
      roman: "Huzoor ﷺ ne kis Sahabi ko 'Ameen-ul-Ummat' ka laqab diya?"
    },
    options: {
      en: ["Hazrat Abu Ubaidah ibn al-Jarrah (RA)", "Hazrat Sa'd ibn Abi Waqqas (RA)", "Hazrat Talhah (RA)", "Hazrat Abdur Rahman ibn Awf (RA)"],
      ur: ["حضرت ابوعبیدہ بن الجراح رضی اللہ عنہ", "حضرت سعد بن ابی وقاص رضی اللہ عنہ", "حضرت طلحہ بن عبیداللہ رضی اللہ عنہ", "حضرت عبدالرحمٰن بن عوف رضی اللہ عنہ"],
      roman: ["Hazrat Abu Ubaidah bin al-Jarrah (R.A)", "Hazrat Sa'd bin Abi Waqqas", "Hazrat Talhah", "Hazrat Abdur Rahman bin Awf"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 62, Hadith 3744)",
      ur: "صحیح بخاری، حدیث ۳۷۴۴: 'لكل أمة أمين وأمين هذه الأمة أبو عبيدة'",
      roman: "Sahih Bukhari, Hadith 3744"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Every nation has a trustworthy guardian, and the trustworthy guardian of this Ummah is Abu Ubaidah ibn al-Jarrah.'",
      ur: "حضور ﷺ نے فرمایا: ہر امت کا ایک امین ہوتا ہے اور اس امت کے امین ابو عبیدہ بن الجراح ہیں۔",
      roman: "Huzoor ﷺ ne Abu Ubaidah (R.A) ko Ameen-ul-Ummat farmaya."
    }
  },
  {
    id: 709,
    categoryId: 7,
    difficulty: 'hard',
    question: {
      en: "Which companion was titled 'Hawari Rasulullah' (The Disciple / Loyal Helper of the Messenger of Allah)?",
      ur: "کس صحابی کو حضور اکرم ﷺ نے 'حواریِ رسول اللہ' (رسول کا مخلص حامی و مددگار) قرار دیا؟",
      roman: "Huzoor ﷺ ne kis Sahabi ko 'Hawari-e-Rasool' ka khitaab diya?"
    },
    options: {
      en: ["Hazrat Az-Zubayr ibn al-Awwam (RA)", "Hazrat Talhah (RA)", "Hazrat Sa'd ibn Mu'adh (RA)", "Hazrat Usama ibn Zayd (RA)"],
      ur: ["حضرت زبیر بن العوام رضی اللہ عنہ", "حضرت طلحہ رضی اللہ عنہ", "حضرت سعد بن معاذ رضی اللہ عنہ", "حضرت اسامہ بن زید رضی اللہ عنہ"],
      roman: ["Hazrat Zubair bin al-Awwam (R.A)", "Hazrat Talhah", "Hazrat Sa'd bin Mu'adh", "Hazrat Usama bin Zayd"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 56, Hadith 2846) & Sahih Muslim",
      ur: "صحیح بخاری، حدیث ۲۸۴۶: 'إن لكل نبي حواريا وحواريّ الزبير'",
      roman: "Sahih Bukhari 2846"
    },
    explanation: {
      en: "The Prophet ﷺ said at the Battle of the Trench: 'Every Prophet has a disciple, and my disciple is Az-Zubayr.'",
      ur: "رسول اللہ ﷺ نے فرمایا: ہر نبی کا ایک حواری ہوتا ہے اور میرے حواری زبیر بن عوام ہیں۔",
      roman: "Huzoor ﷺ ne farmaya: Inna likulli nabiyyin hawariyan wa hawariyyaz-Zubair."
    }
  },
  {
    id: 710,
    categoryId: 7,
    difficulty: 'expert',
    question: {
      en: "How many companions were given the explicit glad tidings of Paradise in a single gathered Hadith ('Ashara Mubashara)?",
      ur: "وہ کتنے خوش نصیب صحابہ کرام ہیں جنہیں ایک ہی حدیث مبارکہ میں دنیا میں ہی جنتی ہونے کی بشارت دی گئی (عشرہ مبشرہ)؟",
      roman: "Ek hi hadees mein kitne sahaba ko jannat ki basharat mili (Ashara Mubashara)?"
    },
    options: {
      en: ["10 Companions", "7 Companions", "12 Companions", "14 Companions"],
      ur: ["۱۰ صحابہ کرام (عشرہ مبشرہ)", "۷ صحابہ", "۱۲ صحابہ", "۱۴ صحابہ"],
      roman: ["10 Sahaba (Ashara Mubashara)", "7 Sahaba", "12 Sahaba", "14 Sahaba"]
    },
    correctAnswer: 0,
    reference: {
      en: "Jami at-Tirmidhi (Hadith 3747) & Sunan Abi Dawud",
      ur: "جامع ترمذی، حدیث ۳۷۴۷، ابواب المناقب",
      roman: "Jami at-Tirmidhi, Hadith 3747"
    },
    explanation: {
      en: "The Ten Promised Paradise: Abu Bakr, Umar, Uthman, Ali, Talhah, Zubayr, Abdur Rahman ibn Awf, Sa'd ibn Abi Waqqas, Sa'id ibn Zayd, and Abu Ubaidah.",
      ur: "عشرہ مبشرہ میں خلفائے اربعہ کے ساتھ طلحہ، زبیر، عبدالرحمٰن بن عوف، سعد بن ابی وقاص، سعید بن زید اور ابوعبیدہ بن جراح شامل ہیں۔",
      roman: "Ashara Mubashara woh 10 azeem sahaba hain jinhein duniya mein Jannat ki basharat mili."
    }
  },
  {
    id: 711,
    categoryId: 7,
    difficulty: 'expert',
    question: {
      en: "Whose martyrdom caused the Throne of the Most Merciful ('Arsh ar-Rahman) to shake in the heavens?",
      ur: "کس انصاری صحابی جلیل کی شہادت پر عرشِ رحمٰن جھوم اٹھا اور لرز گیا؟",
      roman: "Kis Ansari sahabi ki shahadat par Arsh-e-Rahman jhoom utha?"
    },
    options: {
      en: ["Hazrat Sa'd ibn Mu'adh (RA)", "Hazrat Mus'ab ibn Umayr (RA)", "Hazrat Zayd ibn Harithah (RA)", "Hazrat Ja'far ibn Abi Talib (RA)"],
      ur: ["حضرت سعد بن معاذ رضی اللہ عنہ", "حضرت مصعب بن عمیر رضی اللہ عنہ", "حضرت زید بن حارثہ رضی اللہ عنہ", "حضرت جعفر بن ابی طالب رضی اللہ عنہ"],
      roman: ["Hazrat Sa'd bin Mu'adh (R.A)", "Hazrat Mus'ab bin Umayr", "Hazrat Zayd bin Harithah", "Hazrat Ja'far Tayyar"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 63, Hadith 3803) & Sahih Muslim",
      ur: "صحیح بخاری، حدیث ۳۸۰۳: 'اهتز عرش الرحمن لموت سعد بن معاذ'",
      roman: "Sahih Bukhari 3803 wa Sahih Muslim"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'The Throne of the Most Gracious shook upon the death of Sa'd ibn Mu'adh' due to his immense faith and sacrifice.",
      ur: "رسول اللہ ﷺ نے ارشاد فرمایا کہ سعد بن معاذ کی وفات پر رحمٰن کا عرش وجد میں آ گیا۔",
      roman: "Huzoor ﷺ ne farmaya: Ihtazza Arshur-Rahman li-mawti Sa'd bin Mu'adh."
    }
  },
  {
    id: 712,
    categoryId: 7,
    difficulty: 'easy',
    question: {
      en: "Who was the beloved youngest daughter of Prophet Muhammad ﷺ, titled 'Sayyidat Nisa' Ahl al-Jannah' (Leader of the Women of Paradise)?",
      ur: "رسول اللہ ﷺ کی سب سے چہیتی چھوٹی صاحبزادی کون تھیں جنہیں 'سیدہ نساء اہل الجنہ' (اہلِ جنت کی عورتوں کی سردار) کا لقب حاصل ہے؟",
      roman: "Huzoor ﷺ ki sab se choti beti kon theen jinhein Jannati aurton ki sardaar kaha gaya?"
    },
    options: {
      en: ["Sayyida Fatimah az-Zahra (RA)", "Sayyida Ruqayyah (RA)", "Sayyida Zainab (RA)", "Sayyida Umm Kulthum (RA)"],
      ur: ["سیدہ فاطمۃ الزہراء رضی اللہ عنہا", "سیدہ رقیہ رضی اللہ عنہا", "سیدہ زینب رضی اللہ عنہا", "سیدہ ام کلثوم رضی اللہ عنہا"],
      roman: ["Sayyida Fatimah az-Zahra (R.A)", "Sayyida Ruqayyah", "Sayyida Zainab", "Sayyida Umm Kulthum"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 62, Hadith 3767)",
      ur: "صحیح بخاری، مناقب فاطمہ، حدیث ۳۷۶۷: 'فاطمة بضعة مني'",
      roman: "Sahih Bukhari, Hadith 3767"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Fatimah is a part of me; whoever hurts her hurts me', and she is the mother of Hasan and Husain.",
      ur: "رسول اللہ ﷺ نے فرمایا: فاطمہ میرے جگر کا ٹکڑا ہے جس نے اسے ناراض کیا اس نے مجھے ناراض کیا۔",
      roman: "Sayyida Fatimah (R.A) Jannat ki tamam aurton ki sardaar hain."
    }
  },
  {
    id: 713,
    categoryId: 7,
    difficulty: 'medium',
    question: {
      en: "Which young companion was sent by the Prophet ﷺ to Madinah as the very first Islamic ambassador and teacher before the Hijrah?",
      ur: "ہجرت سے قبل نبی کریم ﷺ نے کس نوجوان صحابی کو قرآن سکھانے اور اسلام پھیلانے کے لیے مدینہ میں پہلا سفیر بنا کر بھیجا؟",
      roman: "Hijrat se pehle Madinah mein pehla safeer aur muallim ban kar konse naujawan Sahabi gaye the?"
    },
    options: {
      en: ["Hazrat Mus'ab ibn Umayr (RA)", "Hazrat Usama ibn Zayd (RA)", "Hazrat Mu'adh ibn Jabal (RA)", "Hazrat Zayd ibn Thabit (RA)"],
      ur: ["حضرت مصعب بن عمیر رضی اللہ عنہ", "حضرت اسامہ بن زید رضی اللہ عنہ", "حضرت معاذ بن جبل رضی اللہ عنہ", "حضرت زید بن ثابت رضی اللہ عنہ"],
      roman: ["Hazrat Mus'ab bin Umayr (R.A)", "Hazrat Usama bin Zayd", "Hazrat Mu'adh bin Jabal", "Hazrat Zayd bin Thabit"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Ibn Hisham & Sahih Bukhari",
      ur: "سیرت ابن ہشام و طبقات ابن سعد، مصعب بن عمیر اول سفیر",
      roman: "Sirat Ibn Hisham"
    },
    explanation: {
      en: "Hazrat Mus'ab ibn Umayr (RA) transformed Madinah with his gentle Quranic recitation, bringing leaders of Aws and Khazraj into Islam.",
      ur: "حضرت مصعب بن عمیر رضی اللہ عنہ نے مدینہ میں جا کر اپنے حسن اخلاق اور تلاوت سے ہر گھر میں اسلام کی روشنی پہنچائی۔",
      roman: "Hazrat Mus'ab bin Umayr (R.A) Madinah ke pehle Islamic safeer the."
    }
  },
  {
    id: 714,
    categoryId: 7,
    difficulty: 'hard',
    question: {
      en: "Which companion was referred to by the Prophet ﷺ as 'the most knowledgeable of my Ummah in what is Halal and Haram'?",
      ur: "رسول اللہ ﷺ نے کس صحابی کے بارے میں فرمایا کہ 'میری امت میں حلال و حرام کو سب سے زیادہ جاننے والے' ہیں؟",
      roman: "Huzoor ﷺ ne kis Sahabi ko halal wa haram ka sab se bara aalim qarar diya?"
    },
    options: {
      en: ["Hazrat Mu'adh ibn Jabal (RA)", "Hazrat Ubayy ibn Ka'b (RA)", "Hazrat Abdullah ibn Abbas (RA)", "Hazrat Salman al-Farsi (RA)"],
      ur: ["حضرت معاذ بن جبل رضی اللہ عنہ", "حضرت ابی بن کعب رضی اللہ عنہ", "حضرت عبداللہ بن عباس رضی اللہ عنہ", "حضرت سلمان فارسی رضی اللہ عنہ"],
      roman: ["Hazrat Mu'adh bin Jabal (R.A)", "Hazrat Ubayy bin Ka'b", "Hazrat Abdullah bin Abbas", "Hazrat Salman al-Farsi"]
    },
    correctAnswer: 0,
    reference: {
      en: "Jami at-Tirmidhi (Hadith 3790)",
      ur: "جامع ترمذی، ابواب المناقب، حدیث ۳۷۹۰: 'أعلمهم بالحلال والحرام معاذ بن جبل'",
      roman: "Jami at-Tirmidhi, Hadith 3790"
    },
    explanation: {
      en: "The Prophet ﷺ sent Mu'adh ibn Jabal (RA) as a judge and teacher to Yemen, holding his hand in love.",
      ur: "رسول اللہ ﷺ نے حضرت معاذ بن جبل رضی اللہ عنہ کو یمن کا قاضی بنا کر بھیجا اور ان کے علمی مقام کی تعریف فرمائی۔",
      roman: "Hazrat Mu'adh bin Jabal (R.A) halal wa haram ke sab se bare aalim the."
    }
  },
  {
    id: 715,
    categoryId: 7,
    difficulty: 'hard',
    question: {
      en: "Which cousin of the Prophet ﷺ was known as 'Tarjuman al-Quran' (The Interpreter of the Quran) due to the Prophet's special Dua for him?",
      ur: "رسول اللہ ﷺ کی خصوصی دعا کی برکت سے کس صحابی رسول کو 'ترجمان القرآن' اور 'حبر الامۃ' (امت کا دانشمند) کہا جاتا ہے؟",
      roman: "Huzoor ﷺ ki khas dua se kis Sahabi ko 'Tarjuman-ul-Quran' (Quran ka mufassir) kaha jata hai?"
    },
    options: {
      en: ["Hazrat Abdullah ibn Abbas (RA)", "Hazrat Abdullah ibn Mas'ud (RA)", "Hazrat Ali ibn Abi Talib (RA)", "Hazrat Zayd ibn Thabit (RA)"],
      ur: ["حضرت عبداللہ بن عباس رضی اللہ عنہ", "حضرت عبداللہ بن مسعود رضی اللہ عنہ", "حضرت علی بن ابی طالب رضی اللہ عنہ", "حضرت زید بن ثابت رضی اللہ عنہ"],
      roman: ["Hazrat Abdullah bin Abbas (R.A)", "Hazrat Abdullah bin Mas'ud", "Hazrat Ali", "Hazrat Zayd bin Thabit"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 3, Hadith 75)",
      ur: "صحیح بخاری، حدیث ۷۵: 'اللهم فقهه في الدين وعلمه التأويل'",
      roman: "Sahih Bukhari, Hadith 75"
    },
    explanation: {
      en: "The Prophet ﷺ embraced him and prayed: 'O Allah, teach him the Book and give him deep understanding of the Deen.'",
      ur: "رسول اللہ ﷺ نے ان کے حق میں دعا فرمائی: اے اللہ! اسے دین کی گہری سمجھ اور قرآن کی تفسیر کا علم عطا فرما۔",
      roman: "Hazrat Ibn Abbas (R.A) ko 'Tarjuman-ul-Quran' kaha jata hai."
    }
  },
  {
    id: 716,
    categoryId: 7,
    difficulty: 'expert',
    question: {
      en: "Which companion had angels descend from the heavens listening in visible light to his beautiful recitation of Surah Al-Baqarah?",
      ur: "کس جلیل القدر انصاری صحابی کی خوش الحان تلاوتِ قرآن سننے کے لیے فرشتے چراغوں کی مانند آسمان سے اتر آئے تھے؟",
      roman: "Kis Sahabi ki tilawat-e-Quran sunne ke liye farishte roshni ban kar aasman se utar aaye the?"
    },
    options: {
      en: ["Hazrat Usayd ibn Hudayr (RA)", "Hazrat Ubayy ibn Ka'b (RA)", "Hazrat Abu Musa al-Ash'ari (RA)", "Hazrat Salim Mawla Abi Hudhayfah (RA)"],
      ur: ["حضرت اسید بن حضیر رضی اللہ عنہ", "حضرت ابی بن کعب رضی اللہ عنہ", "حضرت ابو موسیٰ اشعری رضی اللہ عنہ", "حضرت سالم مولیٰ ابی حذیفہ رضی اللہ عنہ"],
      roman: ["Hazrat Usayd bin Hudayr (R.A)", "Hazrat Ubayy bin Ka'b", "Hazrat Abu Musa al-Ash'ari", "Hazrat Salim"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 66, Hadith 5018) & Sahih Muslim",
      ur: "صحیح بخاری، فضائل القرآن، نزول السکینۃ، حدیث ۵۰۱۸",
      roman: "Sahih Bukhari 5018 wa Sahih Muslim"
    },
    explanation: {
      en: "The Prophet ﷺ confirmed: 'Those were angels who came down to listen to your voice; had you continued, people would have seen them.'",
      ur: "حضور ﷺ نے فرمایا: وہ فرشتے تھے جو تمہاری تلاوت سن رہے تھے، اگر تم پڑھتے رہتے تو صبح لوگ انہیں کھلی آنکھوں سے دیکھتے۔",
      roman: "Hazrat Usayd bin Hudayr (R.A) ki tilawat par farishte utar aaye the."
    }
  },
  {
    id: 717,
    categoryId: 7,
    difficulty: 'easy',
    question: {
      en: "Who were the leaders of the youth of Paradise (Sayyida Shabab Ahl al-Jannah), grandsons of Prophet Muhammad ﷺ?",
      ur: "رسول اللہ ﷺ کے وہ کون سے پیارے نواسے ہیں جنہیں 'نوجوانانِ جنت کے سردار' فرمایا گیا؟",
      roman: "Huzoor ﷺ ke pyare nawase jinhein 'Jannat ke nojawano ke sardaar' farmaya gaya?"
    },
    options: {
      en: ["Hazrat Imam Hasan and Hazrat Imam Hussain (RA)", "Hazrat Qasim and Hazrat Abdullah", "Hazrat Ibrahim and Hazrat Zayd", "Hazrat Ali and Hazrat Hamzah"],
      ur: ["حضرت امام حسن اور حضرت امام حسین رضی اللہ عنہما", "حضرت قاسم اور حضرت عبداللہ", "حضرت ابراہیم اور حضرت زید", "حضرت علی اور حضرت حمزہ"],
      roman: ["Hazrat Imam Hasan wa Hazrat Imam Hussain (R.A)", "Hazrat Qasim wa Abdullah", "Hazrat Ibrahim wa Zayd", "Hazrat Ali wa Hamzah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Jami at-Tirmidhi (Hadith 3768)",
      ur: "جامع ترمذی، حدیث ۳۷۶۸: 'الحسن والحسين سيدا شباب أهل الجنة'",
      roman: "Jami at-Tirmidhi, Hadith 3768"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Al-Hasan and Al-Husain are the leaders of the youth of Paradise and my sweet basils in this world.'",
      ur: "رسول اللہ ﷺ نے فرمایا: حسن اور حسین جنت کے نوجوانوں کے سردار ہیں اور دنیا میں میرے دو پھول ہیں۔",
      roman: "Hasan aur Hussain (R.A) Jannat ke nojawano ke sardaar hain."
    }
  },
  {
    id: 718,
    categoryId: 7,
    difficulty: 'medium',
    question: {
      en: "Which wealthy companion bought the Well of Rumah in Madinah and dedicated it as a free water charity for all Muslims?",
      ur: "کس سخی صحابی نے مدینہ منورہ میں میٹھے پانی کا کنواں 'بئرِ رومہ' خرید کر مسلمانوں کے لیے ہمیشہ کے لیے وقف کر دیا؟",
      roman: "Madinah mein 'Beer-e-Roomah' khareed kar musalmanon ke liye kis Sahabi ne waqf kiya?"
    },
    options: {
      en: ["Hazrat Uthman ibn Affan (RA)", "Hazrat Abdur Rahman ibn Awf (RA)", "Hazrat Abu Bakr (RA)", "Hazrat Sa'd ibn Ubadah (RA)"],
      ur: ["حضرت عثمان بن عفان رضی اللہ عنہ", "حضرت عبدالرحمٰن بن عوف رضی اللہ عنہ", "حضرت ابوبکر صدیق رضی اللہ عنہ", "حضرت سعد بن عبادہ رضی اللہ عنہ"],
      roman: ["Hazrat Uthman bin Affan (R.A)", "Hazrat Abdur Rahman bin Awf", "Hazrat Abu Bakr", "Hazrat Sa'd bin Ubadah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 55, Hadith 2778)",
      ur: "صحیح بخاری، کتاب الوصایا، شراء بئر رومۃ، حدیث ۲۷۷۸",
      roman: "Sahih Bukhari, Hadith 2778"
    },
    explanation: {
      en: "Hazrat Uthman (RA) purchased the well for 35,000 dirhams and made his bucket equal to any Muslim's bucket, earning the Prophet's guarantee of Jannah.",
      ur: "حضرت عثمان غنی رضی اللہ عنہ نے یہ کنواں خرید کر وقفِ عام کیا اور نبی کریم ﷺ سے جنت کی خوشخبری پائی۔",
      roman: "Hazrat Uthman (R.A) ne Beer-e-Roomah khareed kar musalmanon ke liye aam kiya."
    }
  },
  {
    id: 719,
    categoryId: 7,
    difficulty: 'hard',
    question: {
      en: "Who was the companion known as the 'Keeper of the Secrets of the Prophet ﷺ' (Sahib Sirr ar-Rasul), entrusted with the names of the hypocrites?",
      ur: "رسول اللہ ﷺ کے 'رازدارِ خاص' (صاحبِ سرّ النبی) کون سے صحابی تھے جنہیں منافقین کے نام بتائے گئے تھے؟",
      roman: "Huzoor ﷺ ke 'Raazdar' (Sahib-e-Sirr) konse sahabi the jinhein munafiqeen ke naam maloom the?"
    },
    options: {
      en: ["Hazrat Hudhayfah ibn al-Yaman (RA)", "Hazrat Abu Dharr al-Ghifari (RA)", "Hazrat Miqdad ibn Amr (RA)", "Hazrat Ammar ibn Yasir (RA)"],
      ur: ["حضرت حذیفہ بن الیمان رضی اللہ عنہ", "حضرت ابو ذر غفاری رضی اللہ عنہ", "حضرت مقداد بن عمرو رضی اللہ عنہ", "حضرت عمار بن یاسر رضی اللہ عنہ"],
      roman: ["Hazrat Hudhayfah bin al-Yaman (R.A)", "Hazrat Abu Dharr", "Hazrat Miqdad", "Hazrat Ammar"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 62, Hadith 3743)",
      ur: "صحیح بخاری، حدیث ۳۷۴۳، صاحب سر النبی ﷺ",
      roman: "Sahih Bukhari, Hadith 3743"
    },
    explanation: {
      en: "Hazrat Umar (RA) would never lead the funeral prayer of a person unless Hudhayfah (RA) attended, verifying their sincerity in faith.",
      ur: "حضرت عمر فاروق رضی اللہ عنہ کسی کے جنازے میں اس وقت تک شرکت نہ فرماتے جب تک حذیفہ رضی اللہ عنہ شریک نہ ہوتے۔",
      roman: "Hazrat Hudhayfah (R.A) Huzoor ﷺ ke raazdar sahabi the."
    }
  },
  {
    id: 720,
    categoryId: 7,
    difficulty: 'expert',
    question: {
      en: "Which female companion fought heroically with a sword to defend the Prophet ﷺ at the critical climax of the Battle of Uhud?",
      ur: "غزوہ احد کے نازک ترین لمحے میں کس جانباز صحابیہ نے تلوار لے کر رسول اللہ ﷺ کا بہادری سے دفاع کیا؟",
      roman: "Ghazwa Uhud ke nazuk moqa par kis sahabia ne talwar se Huzoor ﷺ ka difa kiya?"
    },
    options: {
      en: ["Hazrat Nusaybah bint Ka'b (Umm 'Umarah) RA", "Hazrat Khawlah bint al-Azwar RA", "Hazrat Asma bint Abi Bakr RA", "Hazrat Umm Sulaym RA"],
      ur: ["حضرت نسیبہ بنت کعب (ام عمارہ) رضی اللہ عنہا", "حضرت خولہ بنت الازور رضی اللہ عنہا", "حضرت اسماء بنت ابی بکر رضی اللہ عنہا", "حضرت ام سلیم رضی اللہ عنہا"],
      roman: ["Hazrat Nusaybah bint Ka'b (Umm Umarah) R.A", "Hazrat Khawlah", "Hazrat Asma", "Hazrat Umm Sulaim"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Ibn Hisham & Siyar A'lam an-Nubala",
      ur: "سیرت ابن ہشام و سیر اعلام النبلاء، شجاعت ام عمارہ یوم احد",
      roman: "Sirat Ibn Hisham"
    },
    explanation: {
      en: "The Prophet ﷺ remarked: 'Whenever I turned right or left at Uhud, I saw Umm 'Umarah defending me.' She sustained 12 wounds in the battle.",
      ur: "رسول اللہ ﷺ نے فرمایا: احد کے دن میں دائیں مڑتا یا بائیں، ام عمارہ کو اپنی حفاظت میں شمشیر زنی کرتے پاتا۔",
      roman: "Hazrat Umm Umarah ne Ghazwa Uhud mein Huzoor ﷺ ka be-misaal difa kiya."
    }
  },
  {
    id: 721,
    categoryId: 7,
    difficulty: 'easy',
    question: {
      en: "Which esteemed mother of the believers (Umm al-Mu'minin) narrated over 2,210 Hadiths and was a supreme scholar of Fiqh, Tafsir, and medicine?",
      ur: "حرم نبوی کی کون سی ملکہ اور ام المؤمنین ۲۲۱۰ سے زائد احادیث کی راوی اور فقہ و طب کی عظیم الشان معلمہ تھیں؟",
      roman: "Konsi Umm-ul-Mu'mineen 2210 se zyada ahadees ki rawi aur fiqh ki azeem ustaad theen?"
    },
    options: {
      en: ["Sayyida Aisha Siddiqah (RA)", "Sayyida Hafsah (RA)", "Sayyida Umm Salama (RA)", "Sayyida Juwayriyyah (RA)"],
      ur: ["ام المؤمنین حضرت عائشہ صدیقہ رضی اللہ عنہا", "ام المؤمنین حضرت حفصہ رضی اللہ عنہا", "ام المؤمنین حضرت ام سلمہ رضی اللہ عنہا", "ام المؤمنین حضرت جویریہ رضی اللہ عنہا"],
      roman: ["Sayyida Aisha Siddiqah (R.A)", "Sayyida Hafsah", "Sayyida Umm Salama", "Sayyida Juwayriyyah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari & Jami at-Tirmidhi",
      ur: "جامع ترمذی، فضائل عائشہ صدیقہ رضی اللہ عنہا",
      roman: "Jami at-Tirmidhi, Fazail Aisha"
    },
    explanation: {
      en: "Abu Musa al-Ash'ari (RA) said: 'Never did we, the companions, find a problem difficult except that we asked Aisha and found knowledge with her.'",
      ur: "صحابہ فرماتے ہیں کہ جب بھی ہمیں کسی مسئلے میں مشکل پیش آتی تو ہم سیدہ عائشہ رضی اللہ عنہا سے رہنمائی پاتے تھے۔",
      roman: "Hazrat Aisha (R.A) ilm-e-hadees aur fiqh ki azeem tareen aalimah theen."
    }
  },
  {
    id: 722,
    categoryId: 7,
    difficulty: 'expert',
    question: {
      en: "Who was appointed by Hazrat Abu Bakr and Hazrat Uthman (RA) as the chief scribe to compile the Holy Quran into a single Mushaf?",
      ur: "خلافتِ ابوبکر اور خلافتِ عثمان دونوں میں قرآن مجید کو ایک مصحف میں جمع و تدوین کرنے والی کمیٹی کے سربراہ کون تھے؟",
      roman: "Quran Pak ko ek kitaab mein jama karne wale ahem katib-e-wahi sahabi kon the?"
    },
    options: {
      en: ["Hazrat Zayd ibn Thabit (RA)", "Hazrat Ubayy ibn Ka'b (RA)", "Hazrat Abdullah ibn Mas'ud (RA)", "Hazrat Mu'adh ibn Jabal (RA)"],
      ur: ["حضرت زید بن ثابت رضی اللہ عنہ", "حضرت ابی بن کعب رضی اللہ عنہ", "حضرت عبداللہ بن مسعود رضی اللہ عنہ", "حضرت معاذ بن جبل رضی اللہ عنہ"],
      roman: ["Hazrat Zayd bin Thabit (R.A)", "Hazrat Ubayy bin Ka'b", "Hazrat Abdullah bin Mas'ud", "Hazrat Mu'adh bin Jabal"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 66, Hadith 4986)",
      ur: "صحیح بخاری، حدیث ۴۹۸۶، جمع القرآن فی عہد ابی بکر وعثمان",
      roman: "Sahih Bukhari, Hadith 4986"
    },
    explanation: {
      en: "Hazrat Zayd ibn Thabit (RA) was the primary scribe of revelation praised for his youth, intellect, and precision in memorization.",
      ur: "حضرت زید بن ثابت رضی اللہ عنہ کاتب وحی تھے جنہیں دونوں خلفاء راشدین نے قرآن کی تدوین کی ذمہ داری سونپی۔",
      roman: "Hazrat Zayd bin Thabit (R.A) ne Quran Majeed ki tadween ka azeem fariza anjaam diya."
    }
  }
];
