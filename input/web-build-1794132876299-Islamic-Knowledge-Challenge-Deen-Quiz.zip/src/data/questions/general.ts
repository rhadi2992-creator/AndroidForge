import { Question } from '../../types/quiz';

export const generalQuestions: Question[] = [
  {
    id: 601,
    categoryId: 6,
    difficulty: 'easy',
    question: {
      en: "Which is the holiest sanctuary in Islam, housing the Holy Ka'bah?",
      ur: "اسلام کا سب سے مقدس اور بابرکت ترین مقام کون سا ہے جہاں خانہ کعبہ واقع ہے؟",
      roman: "Islam ka sab se muqaddas tareen maqam konsa hai jahan Khana-e-Kaba waqia hai?"
    },
    options: {
      en: ["Masjid al-Haram (Makkah)", "Masjid an-Nabawi (Madinah)", "Masjid al-Aqsa (Jerusalem)", "Masjid Quba"],
      ur: ["مسجد الحرام (مکہ مکرمہ)", "مسجد نبوی (مدینہ منورہ)", "مسجد اقصیٰ (بیت المقدس)", "مسجد قباء"],
      roman: ["Masjid al-Haram (Makkah)", "Masjid an-Nabawi (Madinah)", "Masjid al-Aqsa (Quds)", "Masjid Quba"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Imran (3:96)",
      ur: "سورۃ آل عمران، آیت ۹۶: 'إِنَّ أَوَّلَ بَيْتٍ وُضِعَ لِلنَّاسِ لَلَّذِي بِبَكَّةَ مُبَارَكًا'",
      roman: "Surah Al-Imran, Ayah 96"
    },
    explanation: {
      en: "Masjid al-Haram surrounds the Holy Ka'bah, the first house appointed for mankind for divine worship.",
      ur: "مسجد الحرام مکہ مکرمہ میں خانہ کعبہ کا احاطہ کیے ہوئے ہے جس کی طرف تمام مسلمان نماز میں رخ کرتے ہیں۔",
      roman: "Masjid al-Haram roo-e-zameen par banne wali pehli ibadat gah hai."
    }
  },
  {
    id: 602,
    categoryId: 6,
    difficulty: 'easy',
    question: {
      en: "What was the very first mosque built in Islamic history upon the Prophet's arrival in Madinah?",
      ur: "ہجرتِ مدینہ کے بعد اسلامی تاریخ میں سب سے پہلی کون سی مسجد تعمیر کی گئی؟",
      roman: "Islami tareekh mein banne wali sab se pehli masjid konsi thi?"
    },
    options: {
      en: ["Masjid Quba", "Masjid an-Nabawi", "Masjid al-Qiblatayn", "Masjid al-Jumu'ah"],
      ur: ["مسجد قباء", "مسجد نبوی", "مسجد قبلتین", "مسجد جمعہ"],
      roman: ["Masjid Quba", "Masjid an-Nabawi", "Masjid al-Qiblatain", "Masjid al-Jumu'ah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah At-Tawbah (9:108) & Sahih Bukhari",
      ur: "سورۃ التوبہ، آیت ۱۰۸: 'لَمَسْجِدٌ أُسِّسَ عَلَى التَّقْوَىٰ مِنْ أَوَّلِ يَوْمٍ'",
      roman: "Surah At-Tawbah, Ayah 108"
    },
    explanation: {
      en: "Masjid Quba was established on piety from the first day. A prayer in Masjid Quba carries the reward of an Umrah.",
      ur: "مسجد قباء تقویٰ کی بنیاد پر بننے والی اولین مسجد ہے، جس میں دو رکعت نفل کا ثواب ایک عمرہ کے برابر ہے۔",
      roman: "Masjid Quba pehli masjid thi jisme namaz parhne ka sawab Umrah ke barabar hai."
    }
  },
  {
    id: 603,
    categoryId: 6,
    difficulty: 'easy',
    question: {
      en: "What is the direction towards the Ka'bah faced by Muslims during prayer called?",
      ur: "نماز کی ادائیگی کے دوران خانہ کعبہ کی سمت رخ کرنے کو کیا کہتے ہیں؟",
      roman: "Namaz mein Khana-e-Kaba ki taraf rukh karne ko kya kehte hain?"
    },
    options: {
      en: ["Qiblah", "Mihrab", "Minbar", "Tawaf"],
      ur: ["قبلہ", "محراب", "منبر", "طواف"],
      roman: ["Qiblah", "Mihrab", "Minbar", "Tawaf"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Baqarah (2:144)",
      ur: "سورۃ البقرہ، آیت ۱۴۴: 'فَوَلِّ وَجْهَكَ شَطْرَ الْمَسْجِدِ الْحَرَامِ'",
      roman: "Surah Al-Baqarah, Ayah 144"
    },
    explanation: {
      en: "Allah instructed the Prophet ﷺ in 2 AH to turn towards the Sacred Mosque in Makkah, establishing the permanent Qiblah.",
      ur: "۲ ہجری میں تحویلِ قبلہ کا حکم ہوا اور بیت المقدس کے بعد ہمیشہ کے لیے کعبۃ اللہ کو قبلہ قرار دیا گیا۔",
      roman: "Qiblah Khana-e-Kaba ki taraf rukh karne ko kehte hain."
    }
  },
  {
    id: 604,
    categoryId: 6,
    difficulty: 'medium',
    question: {
      en: "Which three Mosques are specifically singled out by the Prophet ﷺ as sacred destinations for travel and pilgrimage?",
      ur: "فرمانِ رسول ﷺ کے مطابق ثواب کی نیت سے کن تین مساجد کا سفر کرنا مشروع اور فضیلت والا ہے؟",
      roman: "Nabi ﷺ ne sawab ki niyat se kin 3 masajid ki taraf safar karne ki targheeb di?"
    },
    options: {
      en: [
        "Masjid al-Haram, Masjid an-Nabawi, and Masjid al-Aqsa",
        "Masjid al-Haram, Masjid Quba, and Badshahi Mosque",
        "Masjid an-Nabawi, Blue Mosque, and Faisal Mosque",
        "Masjid al-Aqsa, Al-Azhar, and Umayyad Mosque"
      ],
      ur: [
        "مسجد الحرام، مسجد نبوی اور مسجد اقصیٰ",
        "مسجد الحرام، مسجد قباء اور بادشاہی مسجد",
        "مسجد نبوی، نیلی مسجد اور فیصل مسجد",
        "مسجد اقصیٰ، جامع الازہر اور جامع اموی"
      ],
      roman: [
        "Masjid al-Haram, Masjid an-Nabawi, wa Masjid al-Aqsa",
        "Masjid al-Haram, Masjid Quba, Badshahi Mosque",
        "Masjid an-Nabawi, Blue Mosque, Faisal Mosque",
        "Masjid al-Aqsa, Al-Azhar, Umayyad Mosque"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 21, Hadith 1189) & Sahih Muslim",
      ur: "صحیح بخاری، حدیث ۱۱۸۹ اور صحیح مسلم، حدیث ۱۳۹۷",
      roman: "Sahih Bukhari 1189 wa Sahih Muslim 1397"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Do not undertake journeys to visit any mosque except three: Masjid al-Haram, this Mosque of mine, and Masjid al-Aqsa.'",
      ur: "رسول اللہ ﷺ نے فرمایا: کجاوے نہ باندھے جائیں مگر تین مساجد کی طرف: مسجد الحرام، میری یہ مسجد اور مسجد اقصیٰ۔",
      roman: "Huzoor ﷺ ne Masjid al-Haram, Masjid an-Nabawi aur Masjid al-Aqsa ka safar karne ki taleem di."
    }
  },
  {
    id: 605,
    categoryId: 6,
    difficulty: 'medium',
    question: {
      en: "What was the first Qiblah of the Muslim Ummah before the command to face the Ka'bah?",
      ur: "تحویلِ قبلہ سے قبل مسلمان کس مقدس مقام کی طرف رخ کر کے نماز ادا کرتے تھے (قبلہ اول)؟",
      roman: "Khana-e-Kaba se pehle musalman kis taraf rukh kar ke namaz parhte the (Qibla-e-Awwal)?"
    },
    options: {
      en: ["Masjid al-Aqsa / Bait al-Maqdis (Jerusalem)", "Mount Sinai", "Cave Hira", "Masjid Quba"],
      ur: ["بیت المقدس / مسجد اقصیٰ", "کوہِ طور", "غارِ حرا", "مسجد قباء"],
      roman: ["Bait-ul-Muqaddas / Masjid al-Aqsa", "Koh-e-Toor", "Ghaar-e-Hira", "Masjid Quba"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 8, Hadith 399)",
      ur: "صحیح بخاری، صلاۃ الی القبلۃ، حدیث ۳۹۹",
      roman: "Sahih Bukhari, Hadith 399"
    },
    explanation: {
      en: "Muslims prayed facing Bait al-Maqdis (Al-Quds) for about 16 to 17 months after the Hijrah until the verse of Qiblah change was revealed.",
      ur: "مسلمان ہجرت کے بعد تقریباً ۱۶ یا ۱۷ ماہ تک بیت المقدس کی طرف رخ کر کے نماز ادا کرتے رہے، اس لیے اسے قبلہ اول کہا جاتا ہے۔",
      roman: "Bait-ul-Muqaddas musalmanon ka pehla qibla (Qibla-e-Awwal) tha."
    }
  },
  {
    id: 606,
    categoryId: 6,
    difficulty: 'medium',
    question: {
      en: "What is the semi-circular low wall adjacent to the Ka'bah that was part of the original foundation of Ibrahim (AS) called?",
      ur: "خانہ کعبہ کے ساتھ نصف دائرے کی شکل والی وہ دیوار جو اصل ابراہیمی کعبہ کا حصہ ہے، کیا کہلاتی ہے؟",
      roman: "Khana-e-Kaba ke sath nisf-daire wali jagah ko kya kehte hain jo Kaba ka hissa hai?"
    },
    options: {
      en: ["Hateem / Hijr Ismail", "Maqam Ibrahim", "Multazam", "Rukn Yamani"],
      ur: ["حطیم / حجر اسماعیل", "مقامِ ابراہیم", "ملتزم", "رکنِ یمانی"],
      roman: ["Hateem / Hijr Ismail", "Maqam-e-Ibrahim", "Multazam", "Rukn-e-Yamani"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 26, Hadith 1584)",
      ur: "صحیح بخاری، باب الحطیم، حدیث ۱۵۸۴",
      roman: "Sahih Bukhari, Hadith 1584"
    },
    explanation: {
      en: "Hateem (Hijr Ismail) is considered inside the Ka'bah; praying inside it is like praying inside the Ka'bah.",
      ur: "حطیم دراصل کعبۃ اللہ کی اندرونی حدود میں شامل ہے، اس میں نماز پڑھنا خانہ کعبہ کے اندر نماز پڑھنے کے مترادف ہے۔",
      roman: "Hateem Khana-e-Kaba ke andar ka hissa shumar hota hai."
    }
  },
  {
    id: 607,
    categoryId: 6,
    difficulty: 'hard',
    question: {
      en: "What is the sacred area of the Ka'bah wall between the Black Stone (Hajar al-Aswad) and the door of the Ka'bah called where prayers are granted?",
      ur: "حجر اسود اور کعبہ کے دروازے کے درمیان واقع وہ مبارک دیوار جہاں لپٹ کر دعائیں مانگی جاتی ہیں، کیا کہلاتی ہے؟",
      roman: "Hajar-e-Aswad aur Kaba ke darwaze ke darmiyan wali mubarak jagah ko kya kehte hain?"
    },
    options: {
      en: ["Al-Multazam", "Al-Meezab", "Al-Hateem", "Ar-Rukn ash-Shami"],
      ur: ["مُلتَزَم", "میزابِ رحمت", "حطیم", "رکن شامی"],
      roman: ["Al-Multazam", "Meezab-e-Rehmat", "Hateem", "Rukn-e-Shami"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sunan Abu Dawud & Al-Mustadrak",
      ur: "سنن ابی داؤد، مناسک الحج و احکام الالتزام",
      roman: "Sunan Abu Dawood"
    },
    explanation: {
      en: "Al-Multazam is where the Prophet ﷺ clung his chest, face, and hands to make heartfelt supplications.",
      ur: "ملتزم وہ مقام ہے جہاں رسول اللہ ﷺ اپنا سینہ اور رخسار مبارک رکھ کر انتہائی عاجزی سے دعا فرماتے تھے۔",
      roman: "Multazam par dua mangna masnoon aur qabooliyat ka khas muqam hai."
    }
  },
  {
    id: 608,
    categoryId: 6,
    difficulty: 'hard',
    question: {
      en: "What is the area in Masjid an-Nabawi between the Prophet's ﷺ blessed chamber and his pulpit (Minbar) described as?",
      ur: "مسجد نبوی میں روضہ رسول ﷺ اور منبر مبارک کے درمیان کی جگہ کو رسول اللہ ﷺ نے کیا قرار دیا؟",
      roman: "Masjid an-Nabawi mein Roza-e-Rasool ﷺ aur Minbar ke darmiyan ki jagah ko kya farmaya gaya?"
    },
    options: {
      en: [
        "A garden from the gardens of Paradise (Rawdah min Riyad al-Jannah)",
        "The highest tower of angels",
        "The gate of Israfil",
        "The station of kings"
      ],
      ur: [
        "جنت کے باغوں میں سے ایک باغ (ریاض الجنہ)",
        "فرشتوں کا مینار",
        "بابِ اسرافیل",
        "بادشاہوں کی نشست"
      ],
      roman: [
        "Jannat ke baghon mein se ek baagh (Riyad-ul-Jannah)",
        "Farishton ka meenar",
        "Bab-e-Israfil",
        "Badshahon ki jagah"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 21, Hadith 1195) & Sahih Muslim",
      ur: "صحیح بخاری، حدیث ۱۱۹۵، 'ما بين بيتي ومنبري روضة من رياض الجنة'",
      roman: "Sahih Bukhari 1195 wa Sahih Muslim"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Between my house and my pulpit is a garden from the gardens of Paradise.' It is carpeted in green today.",
      ur: "رسول اللہ ﷺ نے فرمایا: میرے گھر اور منبر کے درمیان والی جگہ جنت کے باغوں میں سے ایک باغ ہے۔",
      roman: "Huzoor ﷺ ne farmaya: Ma baina bayti wa minbari rawdatun min riyad-il-Jannah."
    }
  },
  {
    id: 609,
    categoryId: 6,
    difficulty: 'expert',
    question: {
      en: "Who was the Muslim scientist known as the 'Father of Algebra' who authored 'Kitab al-Jabr wal-Muqabala'?",
      ur: "الجبرا (علمِ حساب) کے بانی عظیم مسلم ریاضی دان کون تھے جن کی کتاب کے نام سے الجبرا کا لفظ اخذ ہوا؟",
      roman: "Algebra ke baani azeem Muslim mathematician kon the?"
    },
    options: {
      en: ["Muhammad ibn Musa al-Khwarizmi", "Al-Kindi", "Omar Khayyam", "Al-Battani"],
      ur: ["محمد بن موسیٰ الخوارزمی", "یعقوب بن اسحاق الکندی", "عمر خیام", "البَتانی"],
      roman: ["Al-Khwarizmi", "Al-Kindi", "Omar Khayyam", "Al-Battani"]
    },
    correctAnswer: 0,
    reference: {
      en: "History of Mathematics & Science",
      ur: "تاریخ سائنس و تدوینِ علم الحساب",
      roman: "History of Science"
    },
    explanation: {
      en: "Al-Khwarizmi (780–850 CE) invented algebra and algorithms (named after his name Al-Khwarizmi) in Baghdad's House of Wisdom.",
      ur: "الخوارزمی نے الجبرا ایجاد کیا اور دنیا میں 'Algorithm' کا لفظ انہی کے نام الخوارزمی سے منسوب ہے۔",
      roman: "Al-Khwarizmi ne Algebra ki bunyaad rakhi."
    }
  },
  {
    id: 610,
    categoryId: 6,
    difficulty: 'expert',
    question: {
      en: "Who authored 'The Canon of Medicine' (Al-Qanun fit-Tibb), the standard medical textbook in Europe and the Islamic world for over 600 years?",
      ur: "علم طب کا شہرہ آفاق شاہکار 'القانون فی الطب' کے مصنف عظیم طبیب و فلاسفر کون تھے؟",
      roman: "Tibb ki mashhoor kitab 'Al-Qanoon fit-Tibb' ke musannif kon the?"
    },
    options: {
      en: ["Ibn Sina (Avicenna)", "Abu Bakr al-Razi (Rhazes)", "Ibn an-Nafis", "Al-Zahrawi (Abulcasis)"],
      ur: ["ابن سینا (بو علی سینا)", "ابوبکر محمد بن زکریا الرازی", "ابن النفیس", "ابو القاسم الزہراوی"],
      roman: ["Ibn Sina (Avicenna)", "Al-Razi", "Ibn an-Nafis", "Al-Zahrawi"]
    },
    correctAnswer: 0,
    reference: {
      en: "History of Medicine (George Sarton)",
      ur: "تاریخ الحکماء و کتبِ طب اسلامی",
      roman: "History of Medicine"
    },
    explanation: {
      en: "Ibn Sina (980–1037 CE) codified medical knowledge into 14 volumes, diagnosing contagion, quarantine, and pharmacology.",
      ur: "بو علی سینا کا 'القانون فی الطب' صدیاں تک دنیا کی یونیورسٹیوں میں طب کی بنیادی درسی کتاب کے طور پر پڑھایا جاتا رہا۔",
      roman: "Ibn Sina (Avicenna) ne 'Al-Qanoon fit-Tibb' taseef farmayi."
    }
  },
  {
    id: 611,
    categoryId: 6,
    difficulty: 'easy',
    question: {
      en: "What is the traditional Islamic greeting and its translation?",
      ur: "مسلمانوں کا روایتی مسنون سلام اور اس کا معنی کیا ہے؟",
      roman: "Musalmanon ka masnoon salam kya hai aur iska matlab kya hai?"
    },
    options: {
      en: [
        "As-Salamu Alaykum (Peace be upon you)",
        "Sabah al-Khayr (Good morning)",
        "Ahlan wa Sahlan (Welcome)",
        "Marhaban (Greetings)"
      ],
      ur: [
        "السَّلَامُ عَلَيْكُمْ (تم پر سلامتی ہو)",
        "صباح الخیر",
        "اہلاً و سہلاً",
        "مرحباً"
      ],
      roman: [
        "As-Salamu Alaykum (Aap par salamati ho)",
        "Sabah al-Khair",
        "Ahlan wa Sahlan",
        "Marhaban"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 79, Hadith 6227)",
      ur: "صحیح بخاری، کتاب الاستئذان، افشاء السلام، حدیث ۶۲۲۷",
      roman: "Sahih Bukhari 6227"
    },
    explanation: {
      en: "The Prophet ﷺ commanded: 'Spread peace (Salam) among yourselves', which was the greeting taught by Allah to Adam (AS).",
      ur: "رسول اللہ ﷺ نے آپس میں سلام پھیلانے کا حکم دیا جو اہل جنت کا باہمی تحفہ ہے۔",
      roman: "Huzoor ﷺ ne salam ko aam karne ka hukum diya."
    }
  },
  {
    id: 612,
    categoryId: 6,
    difficulty: 'medium',
    question: {
      en: "What is the distinctive architectural niche in a mosque wall indicating the direction of Qiblah called?",
      ur: "مسجد کی اگلی دیوار میں قبلہ رخ کی نشاندہی کرنے والی محراب نما محرابی جگہ کیا کہلاتی ہے؟",
      roman: "Masjid ki agli deewar mein qibla ki taraf bani jagah ko kya kehte hain?"
    },
    options: {
      en: ["Mihrab", "Minbar", "Minaret", "Sahn"],
      ur: ["محراب", "منبر", "مینار", "صحن"],
      roman: ["Mihrab", "Minbar", "Meenar", "Sehan"]
    },
    correctAnswer: 0,
    reference: {
      en: "Islamic Architectural History",
      ur: "تاریخ عمارۃ المساجد فی الاسلام",
      roman: "Islamic Architecture"
    },
    explanation: {
      en: "The Mihrab guides the congregation towards Makkah and amplifies the Imam's voice during congregational prayer.",
      ur: "محراب مسجد کی وہ محرابی جگہ ہے جہاں امام کھڑے ہو کر نماز پڑھاتے ہیں اور یہ قبلہ رخ کی نشاندہی کرتی ہے۔",
      roman: "Mihrab imam ke khare hone aur qibla ki simt ki jagah hoti hai."
    }
  },
  {
    id: 613,
    categoryId: 6,
    difficulty: 'hard',
    question: {
      en: "Which pioneering Muslim physician was the first to distinguish between smallpox and measles in his treatise 'Kitab al-Jadari wal-Hasbah'?",
      ur: "وہ کون سے نامور مسلم طبیب تھے جنہوں نے چیچک اور خسرہ کے فرق پر دنیا کی پہلی کتاب تحریر کی؟",
      roman: "Cheechak (Smallpox) aur Khasra (Measles) mein farq bayaan karne wale pehle tabeeb kon the?"
    },
    options: {
      en: ["Abu Bakr al-Razi (Rhazes)", "Ibn Sina", "Ibn Rushd", "Al-Zahrawi"],
      ur: ["ابوبکر محمد بن زکریا الرازی", "ابن سینا", "ابن رشد", "ابوالقاسم الزہراوی"],
      roman: ["Al-Razi (Rhazes)", "Ibn Sina", "Ibn Rushd", "Al-Zahrawi"]
    },
    correctAnswer: 0,
    reference: {
      en: "History of Medicine (WHO recognition)",
      ur: "تاریخ الطب، علامہ رازی کی طبی تحقیقات",
      roman: "History of Medicine"
    },
    explanation: {
      en: "Al-Razi (865–925 CE) was chief physician of the Baghdad Hospital and a master of clinical observation.",
      ur: "امام رازی نے پہلی بار چیچک اور خسرہ کی طبی علامات کو الگ الگ واضح کیا۔",
      roman: "Al-Razi ne smallpox aur measles ke ilaj par pehli kitab likhi."
    }
  },
  {
    id: 614,
    categoryId: 6,
    difficulty: 'expert',
    question: {
      en: "What is the famous gold-embroidered black silk cloth that covers the Holy Ka'bah called?",
      ur: "خانہ کعبہ کو ڈھانپنے والے سیاہ ریشمی اور سنہری نقوش والے مقدس غلاف کو کیا کہا جاتا ہے؟",
      roman: "Khana-e-Kaba ke ghilaf ko kya kehte hain jo sonay ke dhaagon se tayar hota hai?"
    },
    options: {
      en: ["Kiswa", "Burda", "Ihram", "Qaba"],
      ur: ["کسوہ (غلافِ کعبہ)", "بردہ", "احرام", "قبا"],
      roman: ["Kiswa (Ghilaf-e-Kaba)", "Burda", "Ihram", "Qaba"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh Makkah al-Mukarramah",
      ur: "تاریخ مکہ مکرمہ و شرف الکعبۃ المشرفۃ",
      roman: "Tarikh Makkah"
    },
    explanation: {
      en: "The Kiswa is made of pure natural silk woven with Quranic verses in pure gold and silver threads and replaced annually on the 9th/1st of Muharram.",
      ur: "کسوہ وہ سیاہ ریشمی غلاف ہے جس پر سونے اور چاندی کے تاروں سے قرآنی آیات کی خطاطی کی جاتی ہے۔",
      roman: "Kiswa Khana-e-Kaba ke azeem ghilaf ka naam hai."
    }
  },
  {
    id: 615,
    categoryId: 6,
    difficulty: 'easy',
    question: {
      en: "What is the call to prayer chanted five times a day from minarets to summon believers to Salah called?",
      ur: "نماز کے اوقات میں مسلمانوں کو مسجد بلانے کے لیے دی جانے والی صدا کو کیا کہا جاتا ہے؟",
      roman: "Namaz ke waqt musalmanon ko pukarane ke liye jo sada di jati hai use kya kehte hain?"
    },
    options: {
      en: ["Adhan (Azan)", "Iqamah", "Tasbih", "Dhikr"],
      ur: ["اذان", "اقامت", "تسبیح", "ذکر"],
      roman: ["Azan (Adhan)", "Iqamat", "Tasbeeh", "Zikr"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 10, Hadith 604)",
      ur: "صحیح بخاری، کتاب الاذان، حدیث ۶۰۴",
      roman: "Sahih Bukhari, Hadith 604"
    },
    explanation: {
      en: "The Adhan was established in Madinah after the dream of Abdullah ibn Zayd (RA) and recited by Bilal (RA).",
      ur: "مدینہ منورہ میں حضرت عبداللہ بن زید رضی اللہ عنہ کے خواب کے بعد اذان کا آغاز ہوا اور حضرت بلال حبشی نے پہلی اذان دی۔",
      roman: "Azan namaz ki pukar hai jo Hazrat Bilal (R.A) ne pehli baar di."
    }
  },
  {
    id: 616,
    categoryId: 6,
    difficulty: 'medium',
    question: {
      en: "What is the elevated step-platform in a mosque from which the Imam delivers the Friday and Eid sermon (Khutbah) called?",
      ur: "مسجد میں وہ اونچا چبوترہ یا سیڑھیاں جہاں کھڑے ہو کر خطیب جمعہ اور عیدین کا خطبہ دیتے ہیں، کیا کہلاتی ہے؟",
      roman: "Masjid mein jahan khare ho kar Imam khutba dete hain us jagah ko kya kehte hain?"
    },
    options: {
      en: ["Minbar (Pulpit)", "Mihrab", "Dikka", "Riwaq"],
      ur: ["منبر", "محراب", "دکہ", "رواق"],
      roman: ["Minbar", "Mihrab", "Dikka", "Riwaq"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 13, Hadith 918)",
      ur: "صحیح بخاری، ابواب الجمعۃ، حدیث ۹۱۸",
      roman: "Sahih Bukhari, Hadith 918"
    },
    explanation: {
      en: "The Prophet ﷺ initially leaned against a date-palm trunk until a three-step wooden Minbar was constructed for him.",
      ur: "ابتداء میں آپ ﷺ کھجور کے تنے کا سہارا لیتے تھے، بعد میں تین سیڑھیوں والا منبر مبارک تیار کیا گیا۔",
      roman: "Minbar par khare ho kar Imam khutba deta hai."
    }
  },
  {
    id: 617,
    categoryId: 6,
    difficulty: 'hard',
    question: {
      en: "What is the golden water-spout on the roof of the Ka'bah through which rainwater discharges into the Hateem called?",
      ur: "خانہ کعبہ کی چھت پر لگا ہوا سونے کا پرنالہ جس سے بارش کا پانی حطیم میں گرتا ہے، کیا کہلاتا ہے؟",
      roman: "Khana-e-Kaba ki chat par sonay ke parnale ko kya kehte hain?"
    },
    options: {
      en: ["Meezab ar-Rahmah (Spout of Mercy)", "Meezab al-Haram", "Bab at-Tawbah", "Shadharwan"],
      ur: ["میزابِ رحمت", "میزابِ حرم", "باب التوبہ", "شاذروان"],
      roman: ["Meezab-e-Rehmat", "Meezab-e-Haram", "Baab-ut-Tawbah", "Shadharwaan"]
    },
    correctAnswer: 0,
    reference: {
      en: "Tarikh al-Kaba (Al-Azraqi)",
      ur: "اخبار مکہ، علامہ ازرقی، صفۃ المیزاب",
      roman: "Akhbar Makkah, Azraqi"
    },
    explanation: {
      en: "Meezab ar-Rahmah is plated with pure gold and directs rainwater from the roof into the sacred enclosure of the Hateem.",
      ur: "میزاب رحمت سونے کا پرنالہ ہے جس کا پانی حطیم میں گرتا ہے اور اس کے نیچے دعا مستجاب ہوتی ہے۔",
      roman: "Meezab-e-Rehmat sonay ka parnala hai jo Kaba ki chat par laga hai."
    }
  },
  {
    id: 618,
    categoryId: 6,
    difficulty: 'expert',
    question: {
      en: "Who was the legendary Andalusian surgeon known as the 'Father of Operative Surgery' who invented over 200 surgical instruments in 'Kitab al-Tasrif'?",
      ur: "اندلس کے عظیم جراح (سرجن) جنہوں نے ۲۰۰ سے زائد سرجری کے آلات ایجاد کیے اور 'کتاب التصریف' لکھی، کون تھے؟",
      roman: "Surgery ke baani azeem Muslim surgeon kon the jinhon ne 200 surgical tools banaye?"
    },
    options: {
      en: ["Abu al-Qasim al-Zahrawi (Abulcasis)", "Ibn Zuhr (Avenzoar)", "Ibn al-Baytar", "Al-Majusi"],
      ur: ["ابوالقاسم خلف بن عباس الزہراوی", "ابن زہر", "ابن البیطار", "علی بن عباس المجوسی"],
      roman: ["Al-Zahrawi (Abulcasis)", "Ibn Zuhr", "Ibn al-Baytar", "Al-Majusi"]
    },
    correctAnswer: 0,
    reference: {
      en: "Kitab al-Tasrif & Medical History",
      ur: "کتاب التصریف لمن عجز عن التالیف، تاریخ الجراحہ",
      roman: "Kitab al-Tasrif"
    },
    explanation: {
      en: "Al-Zahrawi (936–1013 CE) of Cordoba invented scalpels, bone saws, catgut stitches, and forceps still used today.",
      ur: "الزہراوی نے سرجری کے جدید آلات ڈیزائن کیے جو بعد میں صدیوں تک یورپ کی سرجری کی بنیاد بنے۔",
      roman: "Al-Zahrawi ne operative surgery ke bunyadi aalaat ijaad kiye."
    }
  },
  {
    id: 619,
    categoryId: 6,
    difficulty: 'easy',
    question: {
      en: "What is the small natural tooth-cleaning twig from the Arak tree recommended as a beloved Sunnah called?",
      ur: "پیلو کے درخت کی جڑ یا لکڑی سے دانت صاف کرنے کے لیے استعمال ہونے والی سنت کو کیا کہتے ہیں؟",
      roman: "Dant saaf karne ki masnoon lakri ko kya kehte hain?"
    },
    options: {
      en: ["Miswak (Siwak)", "Kohl", "Attar", "Qalam"],
      ur: ["مسواک", "سرمہ", "عطر", "قلم"],
      roman: ["Miswak", "Surma", "Attar", "Qalam"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 13, Hadith 887)",
      ur: "صحیح بخاری، حدیث ۸۸۷: 'لولا ان اشق على امتي لامرتهم بالسواك'",
      roman: "Sahih Bukhari 887"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Miswak is a purification for the mouth and a means of pleasing the Lord' (مطهرة للفم مرضاة للرب).",
      ur: "رسول اللہ ﷺ نے فرمایا: مسواک منہ کی صفائی کا ذریعہ اور رب تعالیٰ کی رضا کا سبب ہے۔",
      roman: "Miswak munh ki safai aur Allah ki raza ka zariya hai."
    }
  },
  {
    id: 620,
    categoryId: 6,
    difficulty: 'medium',
    question: {
      en: "Which Islamic city in Uzbekistan was renowned as a historic capital of Islamic learning, architecture, and silk road trade?",
      ur: "ازبکستان کا وہ تاریخی اسلامی شہر کون سا ہے جو نیلی ٹائلوں والی مساجد اور مدارس کی وجہ سے دنیا بھر میں مشہور ہے؟",
      roman: "Uzbekistan ka konsa shehar apni azeem islami tareekh aur masajid ke liye mashhoor hai?"
    },
    options: {
      en: ["Samarkand", "Damascus", "Aleppo", "Isfahan"],
      ur: ["سمرقند", "دمشق", "حلب", "اصفہان"],
      roman: ["Samarkand", "Dimashq", "Halab", "Isfahan"]
    },
    correctAnswer: 0,
    reference: {
      en: "Central Asian Islamic Heritage",
      ur: "تاریخ بلاد ماوراء النہر، سمرقند و بخارا",
      roman: "Central Asian Heritage"
    },
    explanation: {
      en: "Samarkand is famed for the Registan square, Ulugh Beg's observatory, and stunning Timurid blue domes.",
      ur: "سمرقند شاہراہ ریشم کا تاریخی موتی اور اسلامی فن تعمیر کا عظیم مرکز رہا ہے۔",
      roman: "Samarkand islami ilm aur fan-e-tameer ka azeem markaz tha."
    }
  },
  {
    id: 621,
    categoryId: 6,
    difficulty: 'expert',
    question: {
      en: "Who was the Muslim scientist who established modern optics and invented the camera obscura in his groundbreaking 'Kitab al-Manazir'?",
      ur: "علمِ بصریات (آپٹکس) کے بانی اور کیمرہ کے اصول ایجاد کرنے والے عظیم مسلم سائنسدان کون تھے؟",
      roman: "Optics ke baani aur camera ke usool ijaad karne wale Muslim scientist kon the?"
    },
    options: {
      en: ["Al-Hasan Ibn al-Haytham (Alhazen)", "Al-Biruni", "Jabir ibn Hayyan", "Al-Kindi"],
      ur: ["الحسن بن الہیثم", "ابو ریحان البیرونی", "جابر بن حیان", "الکندی"],
      roman: ["Ibn al-Haytham (Alhazen)", "Al-Biruni", "Jabir bin Hayyan", "Al-Kindi"]
    },
    correctAnswer: 0,
    reference: {
      en: "Kitab al-Manazir (Book of Optics)",
      ur: "کتاب المناظر، علامہ ابن الہیثم",
      roman: "Kitab al-Manazir"
    },
    explanation: {
      en: "Ibn al-Haytham proved that vision occurs when light reflects from objects into the eye, inventing the scientific experimental method.",
      ur: "ابن الہیثم نے ثابت کیا کہ روشنی آنکھوں میں داخل ہوتی ہے اور پن ہول کیمرے کے اصولوں کو متعارف کرایا۔",
      roman: "Ibn al-Haytham ne modern optics ki bunyaad rakhi."
    }
  }
];
