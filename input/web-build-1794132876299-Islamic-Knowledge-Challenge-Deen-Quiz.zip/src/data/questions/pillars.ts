import { Question } from '../../types/quiz';

export const pillarsQuestions: Question[] = [
  {
    id: 801,
    categoryId: 8,
    difficulty: 'easy',
    question: {
      en: "How many core pillars are there upon which the structure of Islam is built?",
      ur: "اسلام کی بنیادی عمارت کتنے ارکان (ستونوں) پر قائم کی گئی ہے؟",
      roman: "Islam ki bunyaad kitne arkaan (pillars) par rakhi gayi hai?"
    },
    options: {
      en: ["5 Pillars", "4 Pillars", "6 Pillars", "7 Pillars"],
      ur: ["۵ ارکان", "۴ ارکان", "۶ ارکان", "۷ ارکان"],
      roman: ["5 Arkaan", "4 Arkaan", "6 Arkaan", "7 Arkaan"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Hadith 8) & Sahih Muslim (Hadith 16)",
      ur: "صحیح بخاری، حدیث ۸ اور صحیح مسلم، حدیث ۱۶: 'بني الإسلام على خمس'",
      roman: "Sahih Bukhari 8, Sahih Muslim 16"
    },
    explanation: {
      en: "The Prophet ﷺ declared: 'Islam is built upon five: Shahada, Salah, Zakat, Hajj, and Sawm (Fasting) of Ramadan.'",
      ur: "رسول اللہ ﷺ نے ارشاد فرمایا: اسلام کی بنیاد پانچ چیزوں پر ہے: شہادتِ توحید و رسالت، نماز، زکوٰۃ، حج اور رمضان کے روزے۔",
      roman: "Islam ke 5 bunyadi arkaan hain: Kalima, Namaz, Zakat, Hajj aur Roza."
    }
  },
  {
    id: 802,
    categoryId: 8,
    difficulty: 'easy',
    question: {
      en: "What is the first and foundational pillar of Islam, the declaration of faith?",
      ur: "اسلام کا پہلا اور بنیادی رکن کون سا ہے جس کے بغیر کوئی شخص دائرہ اسلام میں داخل نہیں ہو سکتا؟",
      roman: "Islam ka pehla aur ahem tareen rukan konsa hai?"
    },
    options: {
      en: ["Ash-Shahadah (The Testimony of Faith)", "As-Salah (Prayer)", "Az-Zakat (Charity)", "As-Sawm (Fasting)"],
      ur: ["الشہادۃ (کلمہ شہادت و توحید)", "الصلاۃ (نماز)", "الزکوٰۃ", "الصوم (روزہ)"],
      roman: ["Ash-Shahadah (Kalima-e-Shahadat)", "As-Salah (Namaz)", "Az-Zakat", "As-Sawm (Roza)"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Muhammad (47:19) & Hadith Jibreel",
      ur: "سورۃ محمد آیت ۱۹ اور حدیث جبرائیل",
      roman: "Surah Muhammad 19"
    },
    explanation: {
      en: "The Shahadah affirms: 'There is no god but Allah, and Muhammad is the Messenger of Allah' (La ilaha illallah, Muhammadur Rasulullah).",
      ur: "شہادتِ توحید و رسالت کا اقرار زبان سے اور تصدیق دل سے کرنا ہر مومن کی اولین شرط ہے۔",
      roman: "Shahadat ka matlab hai gawahi dena ke Allah ke siwa koi mabood nahi aur Muhammad ﷺ Allah ke Rasool hain."
    }
  },
  {
    id: 803,
    categoryId: 8,
    difficulty: 'easy',
    question: {
      en: "How many obligatory (Fard) daily prayers are ordained upon every sane adult Muslim?",
      ur: "ہر عاقل و بالغ مسلمان پر روزانہ کتنی فرض نمازیں ادا کرنا لازم ہیں؟",
      roman: "Har musalman par rozana kitni farz namazein ada karna zaroori hain?"
    },
    options: {
      en: ["5 Prayers", "3 Prayers", "4 Prayers", "7 Prayers"],
      ur: ["۵ نمازیں", "۳ نمازیں", "۴ نمازیں", "۷ نمازیں"],
      roman: ["5 Namazein", "3 Namazein", "4 Namazein", "7 Namazein"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 2, Hadith 46)",
      ur: "صحیح بخاری، کتاب الایمان، صلوات الخمس، حدیث ۴۶",
      roman: "Sahih Bukhari, Hadith 46"
    },
    explanation: {
      en: "The five daily prayers are: Fajr (Dawn), Dhuhr (Noon), Asr (Afternoon), Maghrib (Sunset), and Isha (Night).",
      ur: "پانچ نمازیں یہ ہیں: فجر، ظہر، عصر، مغرب اور عشاء۔",
      roman: "Fajr, Zohr, Asr, Maghrib aur Isha yeh paanch farz namazein hain."
    }
  },
  {
    id: 804,
    categoryId: 8,
    difficulty: 'medium',
    question: {
      en: "What is the standard percentage rate of annual Zakat due on wealth that exceeds the Nisab threshold?",
      ur: "نصاب کو پہنچنے والے مال و دولت پر سال گزرنے کے بعد کتنے فیصد زکوٰۃ ادا کرنا فرض ہے؟",
      roman: "Nisab par poora saal guzarne ke baad kitne percent Zakat ada ki jati hai?"
    },
    options: {
      en: ["2.5% (one fortieth / 1/40th)", "5%", "10%", "1%"],
      ur: ["۲.۵ فیصد (چالیسواں حصہ)", "۵ فیصد", "۱۰ فیصد", "۱ فیصد"],
      roman: ["2.5% (40wan hissa)", "5%", "10%", "1%"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sunan Abi Dawud (Hadith 1573) & Sahih Bukhari",
      ur: "سنن ابی داؤد، کتاب الزکوٰۃ، حدیث ۱۵۷۳",
      roman: "Sunan Abu Dawood 1573"
    },
    explanation: {
      en: "Zakat is calculated at 2.5% on qualifying surplus wealth (gold, silver, cash, trade goods) held continuously for one lunar year.",
      ur: "زکوٰۃ کی شرح ڈھائی فیصد (۲.۵٪) ہے جو نصاب پر پورا ایک سال مکمل ہونے پر واجب ہوتی ہے۔",
      roman: "Zakat ki sharah 2.5% yaani 40wan hissa hai."
    }
  },
  {
    id: 805,
    categoryId: 8,
    difficulty: 'medium',
    question: {
      en: "What is the gold Nisab threshold for Zakat in modern metric weight?",
      ur: "سونے پر زکوٰۃ واجب ہونے کے لیے شرعی نصاب (ساڑھے سات تولہ) جدید گرام میں کتنا بنتا ہے؟",
      roman: "Sonay (Gold) par Zakat ka Nisab taqreeban kitne gram hota hai?"
    },
    options: {
      en: ["Approximately 85–87.48 grams of gold", "50 grams", "120 grams", "200 grams"],
      ur: ["تقریباً ۸۵ سے ۸۷.۴۸ گرام (ساڑھے سات تولہ)", "۵۰ گرام", "۱۲۰ گرام", "۲۰۰ گرام"],
      roman: ["Taqreeban 85-87.48 grams (7.5 tola)", "50 grams", "120 grams", "200 grams"]
    },
    correctAnswer: 0,
    reference: {
      en: "Islamic Fiqh Academy consensus & Classical Fiqh",
      ur: "مجمع الفقہ الاسلامی، مقدار نصاب الذہب (۲۰ مثقال)",
      roman: "Islamic Fiqh Academy, Nisab"
    },
    explanation: {
      en: "The classical Nisab for gold is 20 Dinars / Mithqals, which equals approximately 85 to 87.48 grams of 24k gold.",
      ur: "سونے کا نصاب ۲۰ مثقال یعنی ساڑھے سات تولہ ہے جو دورِ حاضر میں تقریباً ۸۵ تا ۸۷.۴۸ گرام ہے۔",
      roman: "Sonay ka nisab 85 se 87.48 gram banta hai."
    }
  },
  {
    id: 806,
    categoryId: 8,
    difficulty: 'medium',
    question: {
      en: "In which blessed month of the Islamic calendar is obligatory fasting (Sawm) observed from dawn to dusk?",
      ur: "اسلامی سال کے کس بابرکت مہینے میں طلوعِ فجر سے غروبِ آفتاب تک فرض روزے رکھے جاتے ہیں؟",
      roman: "Kis mubarak maheene mein subah sadiq se ghuroob-e-aftab tak farz roze rakhe jate hain?"
    },
    options: {
      en: ["Ramadan", "Muharram", "Rajab", "Sha'ban"],
      ur: ["ماہِ رمضان المبارک", "ماہِ محرم الحرام", "ماہِ رجب", "ماہِ شعبان"],
      roman: ["Ramzan al-Mubarak", "Muharram", "Rajab", "Sha'ban"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Baqarah (2:185)",
      ur: "سورۃ البقرہ، آیت ۱۸۵: 'شَهْرُ رَمَضَانَ الَّذِي أُنْزِلَ فِيهِ الْقُرْآنُ'",
      roman: "Surah Al-Baqarah, Ayah 185"
    },
    explanation: {
      en: "Fasting throughout the month of Ramadan was made obligatory in 2 AH to attain Taqwa (God-consciousness).",
      ur: "۲ ہجری میں ماہِ رمضان کے روزے فرض کیے گئے تاکہ اہل ایمان میں تقویٰ پیدا ہو۔",
      roman: "Ramzan al-Mubarak ke roze 2 Hijri mein farz hue."
    }
  },
  {
    id: 807,
    categoryId: 8,
    difficulty: 'hard',
    question: {
      en: "What is the pre-dawn meal eaten by fasting Muslims before Fajr begins called in the Sunnah?",
      ur: "صبح صادق سے پہلے روزے کی نیت سے کھائے جانے والے بابرکت کھانے کو کیا کہا جاتا ہے؟",
      roman: "Subah sadiq se pehle roza rakhne ke liye khaye jane wale khane ko kya kehte hain?"
    },
    options: {
      en: ["Suhur (Sehri)", "Iftar", "Walimah", "Aqiqa"],
      ur: ["سحور (سحری)", "افطار", "ولیمہ", "عقیقہ"],
      roman: ["Suhur (Sehri)", "Iftar", "Walimah", "Aqiqa"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 30, Hadith 1923) & Sahih Muslim",
      ur: "صحیح بخاری، حدیث ۱۹۲۳: 'تسحروا فإن في السحور بركة'",
      roman: "Sahih Bukhari 1923"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Take the pre-dawn meal (Suhur), for indeed there is blessing in Suhur.'",
      ur: "رسول اللہ ﷺ نے فرمایا: سحری کھایا کرو کیونکہ سحری کھانے میں برکت رکھی گئی ہے۔",
      roman: "Huzoor ﷺ ne farmaya: Tasahharoo fa-inna fis-suhoori barakah."
    }
  },
  {
    id: 808,
    categoryId: 8,
    difficulty: 'hard',
    question: {
      en: "What is the most supreme night of worship in Ramadan, described in the Quran as 'better than a thousand months'?",
      ur: "ماہِ رمضان کی وہ کون سی سب سے افضل اور مقدس رات ہے جس کی عبادت کو ہزار مہینوں سے افضل قرار دیا گیا؟",
      roman: "Ramzan ki konsi azeem raat hai jiski ibadat hazaar maheenon se behtar hai?"
    },
    options: {
      en: ["Laylat al-Qadr (The Night of Decree)", "Laylat al-Bara'ah", "Laylat al-Mi'raj", "Laylat al-Jumu'ah"],
      ur: ["لیلۃ القدر (شبِ قدر)", "شبِ برات", "شبِ معراج", "شبِ جمعہ"],
      roman: ["Laylat al-Qadr (Shab-e-Qadr)", "Shab-e-Baraat", "Shab-e-Miraj", "Shab-e-Jumu'ah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Qadr (97:1-3)",
      ur: "سورۃ القدر، آیات ۱ تا ۳: 'لَيْلَةُ الْقَدْرِ خَيْرٌ مِنْ أَلْفِ شَهْرٍ'",
      roman: "Surah Al-Qadr, Ayahs 1-3"
    },
    explanation: {
      en: "Surah Al-Qadr reveals that the Quran was sent down on Laylat al-Qadr, a single night worth more than 83 years and 4 months of continuous worship.",
      ur: "شب قدر میں عبادت کا اجر ۸۳ سال اور ۴ ماہ کی مسلسل عبادت سے بھی زیادہ ہے، جو رمضان کی طاق راتوں میں تلاش کی جاتی ہے۔",
      roman: "Laylat al-Qadr hazaar maheenon se behtar raat hai."
    }
  },
  {
    id: 809,
    categoryId: 8,
    difficulty: 'hard',
    question: {
      en: "What is the single most essential pillar and climax of Hajj, without which the pilgrimage is invalid (Al-Hajju 'Arafah)?",
      ur: "حج کا سب سے بڑا اور لازمی رکن کون سا ہے جس کے بغیر حج ادا نہیں ہوتا؟",
      roman: "Hajj ka sab se ahem tareen rukan konsa hai jiske baghair Hajj nahi hota?"
    },
    options: {
      en: [
        "Wuquf (Standing) at the Plain of Arafat on the 9th of Dhul Hijjah",
        "Staying in Mina on the 8th",
        "Shaving the head",
        "Stoning the Jamarat"
      ],
      ur: [
        "۹ ذوالحجہ کو میدانِ عرفات میں وقوف کرنا (الْحَجُّ عَرَفَةُ)",
        "۸ تاریخ کو منیٰ میں رات گزارنا",
        "سر کے بال منڈوانا",
        "جمرات پر کنکریاں مارنا"
      ],
      roman: [
        "9 Zilhajj ko Maidan-e-Arafat mein Waqoof karna",
        "Mina mein qayam",
        "Sar mundwana",
        "Rami Jamarat"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Jami at-Tirmidhi (Hadith 889) & Sunan Abi Dawud",
      ur: "جامع ترمذی، حدیث ۸۸۹: 'الْحَجُّ عَرَفَةُ'",
      roman: "Jami at-Tirmidhi, Hadith 889"
    },
    explanation: {
      en: "The Prophet ﷺ unequivocally stated: 'Al-Hajju 'Arafah' (Hajj is Arafat). Missing the presence in Arafat nullifies the pilgrimage.",
      ur: "رسول اللہ ﷺ نے فرمایا: حج دراصل عرفات کا نام ہے، ۹ ذوالحجہ کے دن زوال سے غروب تک وہاں حاضری فرضِ اعظم ہے۔",
      roman: "Huzoor ﷺ ne farmaya: Al-Hajju Arafah (Hajj Arafat hai)."
    }
  },
  {
    id: 810,
    categoryId: 8,
    difficulty: 'expert',
    question: {
      en: "How many circumambulations (Shawt) around the Holy Ka'bah constitute one complete Tawaf?",
      ur: "خانہ کعبہ کے گرد ایک مکمل طواف میں کتنے چکر (اشواط) لگائے جاتے ہیں؟",
      roman: "Khana-e-Kaba ke aik mukammal Tawaf mein kitne chakkar hote hain?"
    },
    options: {
      en: ["7 Circuits (Shawt)", "5 Circuits", "3 Circuits", "10 Circuits"],
      ur: ["۷ چکر (اشواط)", "۵ چکر", "۳ چکر", "۱۰ چکر"],
      roman: ["7 Chakkar", "5 Chakkar", "3 Chakkar", "10 Chakkar"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 25, Hadith 1603) & Sahih Muslim",
      ur: "صحیح بخاری، کتاب الحج، صفۃ الطواف، حدیث ۱۶۰۳",
      roman: "Sahih Bukhari 1603"
    },
    explanation: {
      en: "Every Tawaf consists of exactly 7 anti-clockwise circuits, starting and ending at the corner of the Black Stone (Hajar al-Aswad).",
      ur: "طواف حجر اسود سے شروع ہو کر حجر اسود پر ہی ختم ہوتا ہے اور اس کے کل ۷ چکر ہوتے ہیں۔",
      roman: "Tawaf Hajar-e-Aswad se shuru hota hai aur kul 7 chakkar lagaye jate hain."
    }
  },
  {
    id: 811,
    categoryId: 8,
    difficulty: 'expert',
    question: {
      en: "How many categories of eligible recipients of Zakat are explicitly designated by Allah in Surah At-Tawbah (9:60)?",
      ur: "سورۃ التوبہ کی آیت ۶۰ میں اللہ تعالیٰ نے مصارفِ زکوٰۃ (زکوٰۃ کے حقداروں کی اقسام) کتنے متعین فرمائے ہیں؟",
      roman: "Surah At-Tawbah (Ayah 60) mein Zakat ke kitne masarif (haqdaar categories) bataye gaye hain?"
    },
    options: {
      en: ["8 Categories (Asnaf)", "5 Categories", "6 Categories", "10 Categories"],
      ur: ["۸ مصارف (اقسام)", "۵ اقسام", "۶ اقسام", "۱۰ اقسام"],
      roman: ["8 Masarif (Categories)", "5 Categories", "6 Categories", "10 Categories"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah At-Tawbah (9:60)",
      ur: "سورۃ التوبہ، آیت ۶۰: 'إِنَّمَا الصَّدَقَاتُ لِلْفُقَرَاءِ وَالْمَسَاكِينِ...'",
      roman: "Surah At-Tawbah, Ayah 60"
    },
    explanation: {
      en: "The eight categories are: the poor (Fuqara), needy (Masakeen), Zakat workers, reconciling hearts, freeing captives, debtors, in the cause of Allah, and the stranded traveler.",
      ur: "قرآن میں ۸ مصارف ہیں: فقراء، مساکین، عاملین، مؤلفۃ القلوب، غلام آزاد کرانا، مقروض، فی سبیل اللہ اور مسافر۔",
      roman: "Surah Tawbah 60 mein Zakat ke 8 masarif bayaan kiye gaye hain."
    }
  },
  {
    id: 812,
    categoryId: 8,
    difficulty: 'easy',
    question: {
      en: "What is the walking and pacing back and forth between the two hills of Safa and Marwah during Hajj and Umrah called?",
      ur: "حج اور عمرہ کے دوران صفا اور مروہ کی دو پہاڑیوں کے درمیان سات چکر لگانے کو کیا کہا جاتا ہے؟",
      roman: "Safa aur Marwah ke darmiyan 7 chakkar lagane ko kya kehte hain?"
    },
    options: {
      en: ["Sa'i", "Tawaf", "Rami", "Ifrad"],
      ur: ["سعی", "طواف", "رمی", "افراد"],
      roman: ["Sa'ee", "Tawaf", "Rami", "Ifrad"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Baqarah (2:158) & Sahih Muslim",
      ur: "سورۃ البقرہ، آیت ۱۵۸: 'إِنَّ الصَّفَا وَالْمَرْوَةَ مِنْ شَعَائِرِ اللَّهِ'",
      roman: "Surah Al-Baqarah, Ayah 158"
    },
    explanation: {
      en: "Sa'i commemorates the desperate search of Hazrat Hajirah for water for infant Ismail (AS) between Safa and Marwah.",
      ur: "سعی حضرت ہاجرہ رضی اللہ عنہا کی اپنے لخت جگر اسماعیل علیہ السلام کے لیے پانی کی تلاش کی یاد میں سنتِ ابراہیمی ہے۔",
      roman: "Sa'ee Safa aur Marwah ke darmiyan 7 martaba chalne ko kehte hain."
    }
  },
  {
    id: 813,
    categoryId: 8,
    difficulty: 'medium',
    question: {
      en: "What is the special state of ritual consecration and simple unstitched white cloth worn by pilgrims for Hajj and Umrah called?",
      ur: "حج اور عمرہ ادا کرنے کے لیے نیت کر کے دو سفید غیر سلی چادروں کو زیب تن کرنے کی حالت کو کیا کہتے ہیں؟",
      roman: "Hajj aur Umrah ke liye pehni jane wali do safaid bina-sili chadoron ko kya kehte hain?"
    },
    options: {
      en: ["Ihram", "Kiswa", "Jubbah", "Kafan"],
      ur: ["احرام", "کسوہ", "جبہ", "کفن"],
      roman: ["Ihram", "Kiswa", "Jubbah", "Kafan"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 25, Hadith 1542)",
      ur: "صحیح بخاری، کتاب الحج، احکام الاحرام، حدیث ۱۵۴۲",
      roman: "Sahih Bukhari, Hadith 1542"
    },
    explanation: {
      en: "Ihram removes worldly distinctions of wealth and status, placing all pilgrims in absolute equality before Allah.",
      ur: "احرام انسان کو دنیاوی زیب و زینت سے الگ کر کے اللہ کے حضور تمام انسانوں کو برابری کی سطح پر کھڑا کرتا ہے۔",
      roman: "Ihram do baghair sili safaid chadoron par mushtamil hota hai."
    }
  },
  {
    id: 814,
    categoryId: 8,
    difficulty: 'medium',
    question: {
      en: "What is the special community night prayer performed in congregation exclusively during the nights of Ramadan?",
      ur: "ماہِ رمضان المبارک کی راتوں میں عشاء کے بعد باجماعت ادا کی جانے والی خصوصی سنت نماز کون سی ہے؟",
      roman: "Ramzan ki raton mein Isha ke baad ba-jamaat parhi jane wali khas namaz konsi hai?"
    },
    options: {
      en: ["Salat at-Tarawih", "Salat al-Istikhara", "Salat al-Kusuf", "Salat al-Awwabin"],
      ur: ["نمازِ تراویح", "نمازِ استخارہ", "نمازِ کسوف", "نمازِ اوابین"],
      roman: ["Salat-ut-Tarawih", "Namaz-e-Istikhara", "Namaz-e-Kusuf", "Namaz-e-Awwabeen"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Hadith 2009) & Sahih Muslim",
      ur: "صحیح بخاری، قیام رمضان (التراویح)، حدیث ۲۰۰۹",
      roman: "Sahih Bukhari 2009"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Whoever prays at night in Ramadan out of faith and seeking reward, his past sins will be forgiven.'",
      ur: "رسول اللہ ﷺ نے فرمایا: جس نے رمضان میں ایمان اور احتساب کے ساتھ قیام اللیل (تراویح) کیا، اس کے پچھلے گناہ معاف کر دیے جاتے ہیں۔",
      roman: "Namaz-e-Tarawih Ramzan al-Mubarak ki azeem sunnat-e-muakkadah hai."
    }
  },
  {
    id: 815,
    categoryId: 8,
    difficulty: 'hard',
    question: {
      en: "What is the charity of fast-breaking (Zakat al-Fitr / Sadaqat al-Fitr) that must be distributed before the Eid prayer?",
      ur: "عید الفطر کی نماز سے قبل غریبوں اور مسکینوں کو ادا کیا جانے والا مالی صدقہ کیا کہلاتا ہے؟",
      roman: "Eid-ul-Fitr ki namaz se pehle ada kiye jane wale wajib sadqe ko kya kehte hain?"
    },
    options: {
      en: ["Sadaqat al-Fitr (Zakat al-Fitr)", "Zakat al-Mal", "Ushr", "Kaffarah"],
      ur: ["صدقۃ الفطر (زکوٰۃ الفطر)", "زکوٰۃ المال", "عشر", "کفارہ"],
      roman: ["Sadaqat-ul-Fitr", "Zakat-ul-Maal", "Ushr", "Kaffarah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 24, Hadith 1503)",
      ur: "صحیح بخاری، کتاب الزکوٰۃ، فرض صدقۃ الفطر، حدیث ۱۵۰۳",
      roman: "Sahih Bukhari 1503"
    },
    explanation: {
      en: "The Prophet ﷺ made Zakat al-Fitr compulsory on every Muslim (man, woman, child) to purify the fast from idle talk and feed the poor.",
      ur: "رسول اللہ ﷺ نے صدقۃ الفطر روزوں کی کوتاہیوں کی طہارت اور مسکینوں کی خوشی کے لیے ہر مسلمان پر فرض فرمایا۔",
      roman: "Sadaqatul Fitr har musalman par Eid ki namaz se pehle wajib hai."
    }
  },
  {
    id: 816,
    categoryId: 8,
    difficulty: 'expert',
    question: {
      en: "What is the mandatory fast penalty (Kaffarah) for deliberately breaking a Ramadan fast without any valid excuse according to classical Fiqh?",
      ur: "بغیر کسی عذر کے جان بوجھ کر رمضان کا روزہ توڑ دینے کا شرعی کفارہ کیا ہے؟",
      roman: "Baghair kisi uzr ke jaan boojh kar Ramzan ka roza todne ka kaffarah kya hai?"
    },
    options: {
      en: [
        "Fasting for two consecutive lunar months (60 days) or feeding 60 needy people",
        "Fasting for 10 days",
        "Feeding 10 people only",
        "Reciting the entire Quran twice"
      ],
      ur: [
        "مسلسل ساٹھ (۶۰) دن کے روزے رکھنا یا ساٹھ مسکینوں کو دو وقت کھانا کھلانا",
        "دس دن کے روزے رکھنا",
        "صرف دس مسکینوں کو کھانا کھلانا",
        "دو مرتبہ قرآن مکمل کرنا"
      ],
      roman: [
        "Musalsal 60 din ke roze rakhna ya 60 miskeeno ko khana khilana",
        "10 din ke roze",
        "10 miskeen",
        "Do baar Quran"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 30, Hadith 1936) & Sahih Muslim",
      ur: "صحیح بخاری، حدیث ۱۹۳۶، کفارۃ الصوم عمدًا",
      roman: "Sahih Bukhari 1936"
    },
    explanation: {
      en: "The Prophet ﷺ instructed the man who violated his fast deliberately to free a slave, or fast 60 consecutive days, or feed 60 destitute individuals.",
      ur: "حدیث مبارکہ میں جان بوجھ کر روزہ توڑنے والے کے لیے ایک غلام آزاد کرنا، یا ساٹھ دن مسلسل روزے رکھنا، یا ساٹھ مسکینوں کو کھانا کھلانے کا حکم ہے۔",
      roman: "Roza jaan boojh kar todne par 60 lagataar roze ya 60 miskeeno ko khana khilana kaffarah hai."
    }
  },
  {
    id: 817,
    categoryId: 8,
    difficulty: 'easy',
    question: {
      en: "What is the Talbiyah chant proclaimed continuously by pilgrims during Hajj and Umrah starting with 'Labbayk'?",
      ur: "احرام باندھنے کے بعد حجاج کرام کی زبان پر جاری رہنے والا ترانہ 'تلبیہ' کس لفظ سے شروع ہوتا ہے؟",
      roman: "Hajj aur Umrah mein parha jane wala 'Talbiyah' kin alfaaz se shuru hota hai?"
    },
    options: {
      en: ["Labbayk Allahumma Labbayk", "Subhanallahi wa bihamdihi", "Astaghfirullah", "Allahu Akbar"],
      ur: ["لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ (میں حاضر ہوں اے اللہ، میں حاضر ہوں)", "سُبْحَانَ اللَّهِ", "أَسْتَغْفِرُ اللَّهَ", "اللَّهُ أَكْبَرُ"],
      roman: ["Labbayk Allahumma Labbayk", "Subhanallah", "Astaghfirullah", "Allahu Akbar"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 25, Hadith 1549)",
      ur: "صحیح بخاری، کتاب الحج، التلبیۃ، حدیث ۱۵۴۹",
      roman: "Sahih Bukhari, Hadith 1549"
    },
    explanation: {
      en: "The Talbiyah affirms: 'Labbayk Allahumma Labbayk, Labbayk la shareeka laka Labbayk' (Here I am at Your service, O Allah!).",
      ur: "تلبیہ کا مفہوم ہے: میں حاضر ہوں اے اللہ، تیرا کوئی شریک نہیں، بیشک تمام حمد و نعمت تیری ہے اور بادشاہی بھی تیری ہے۔",
      roman: "Talbiyah: Labbayk Allahumma Labbayk, Labbayka la shareeka laka Labbayk."
    }
  },
  {
    id: 818,
    categoryId: 8,
    difficulty: 'medium',
    question: {
      en: "How many total Farz (obligatory) Rakats are there combined in the five daily prayers in a standard non-traveling day?",
      ur: "پانچوں وقت کی یومیہ نمازوں میں کل کتنی فرض رکعتیں ادا کی جاتی ہیں؟",
      roman: "Paanchon waqt ki namazon mein kul kitni farz raka'at hoti hain?"
    },
    options: {
      en: ["17 Rakats (2+4+4+3+4)", "20 Rakats", "15 Rakats", "12 Rakats"],
      ur: ["۱۷ رکعتیں (فجر ۲، ظہر ۴، عصر ۴، مغرب ۳، عشاء ۴)", "۲۰ رکعتیں", "۱۵ رکعتیں", "۱۲ رکعتیں"],
      roman: ["17 Raka'at (Fajr 2, Zohr 4, Asr 4, Maghrib 3, Isha 4)", "20", "15", "12"]
    },
    correctAnswer: 0,
    reference: {
      en: "Classical Fiqh Consensus",
      ur: "اجماع فقہائے امت، رکعات الصلاۃ المفروضۃ",
      roman: "Classical Fiqh Consensus"
    },
    explanation: {
      en: "The 17 obligatory daily Rakats are: Fajr (2), Dhuhr (4), Asr (4), Maghrib (3), and Isha (4).",
      ur: "روزانہ کی ۱۷ فرض رکعات ہیں: فجر ۲، ظہر ۴، عصر ۴، مغرب ۳ اور عشاء ۴۔",
      roman: "Rozana 17 farz rakat hoti hain."
    }
  },
  {
    id: 819,
    categoryId: 8,
    difficulty: 'hard',
    question: {
      en: "What is the ritual of pelting the three stone pillars in Mina during Hajj commemorating Ibrahim's (AS) rejection of Shaytan called?",
      ur: "حج کے دوران منیٰ میں شیطان کے تین ستونوں (جمرات) پر کنکریاں مارنے کے عمل کو کیا کہا جاتا ہے؟",
      roman: "Mina mein teeno Jamarat par kankariyan marne ke amal ko kya kehte hain?"
    },
    options: {
      en: ["Rami al-Jamarat", "Wuquf", "Halq", "Nahr"],
      ur: ["رَمْيُ الْجَمَرَات (کنکریاں مارنا)", "وقوف", "حلق", "نحر"],
      roman: ["Rami al-Jamarat", "Waqoof", "Halq", "Nahr"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 7, Hadith 3144)",
      ur: "صحیح مسلم، کتاب الحج، رمی الجمار، حدیث ۳۱۴۴",
      roman: "Sahih Muslim, Hadith 3144"
    },
    explanation: {
      en: "Rami al-Jamarat reenacts Prophet Ibrahim (AS) casting seven pebbles at Satan whenever he attempted to whisper doubts.",
      ur: "حضرت ابراہیم علیہ السلام نے جب شیطان نے وسوسہ ڈالنے کی کوشش کی تو اسے سات کنکریاں مار کر بھگایا، یہ عمل اسی کی یاد ہے۔",
      roman: "Rami Jamarat mein 7 kankariyan maari jati hain."
    }
  },
  {
    id: 820,
    categoryId: 8,
    difficulty: 'expert',
    question: {
      en: "What is the agricultural tithe (Zakat on land produce) called in Islamic law, being 10% on naturally watered land?",
      ur: "زمین کی پیداوار اور فصلوں پر واجب ہونے والے اسلامی زرعی ٹیکس/زکوٰۃ کو کیا کہتے ہیں جو قدرتی بارش سے سیراب زمین پر ۱۰ فیصد ہے؟",
      roman: "Zameen ki paidaawar par jo 10% ya 5% Zakat hoti hai use kya kehte hain?"
    },
    options: {
      en: ["Ushr ( العشر )", "Jizyah", "Kharaj", "Fay'"],
      ur: ["عُشر (العشر)", "جزیہ", "خراج", "فیء"],
      roman: ["Ushr", "Jizyah", "Kharaj", "Fay'"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 24, Hadith 1483)",
      ur: "صحیح بخاری، کتاب الزکوٰۃ، فیما سقت السماء العشر، حدیث ۱۴۸۳",
      roman: "Sahih Bukhari 1483"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'On land irrigated by rain or springs, one-tenth (Ushr / 10%) is due, and on land irrigated by labor, one-twentieth (5%) is due.'",
      ur: "رسول اللہ ﷺ نے فرمایا: جس زمین کو بارش یا چشموں نے سیراب کیا اس میں دسواں حصہ (عشر) ہے، اور جو کنویں سے سیراب ہو اس میں بیسواں حصہ (نصف عشر) ہے۔",
      roman: "Ushr zameen ki faslon par ada kiya jane wala shara'i hissa hai."
    }
  },
  {
    id: 821,
    categoryId: 8,
    difficulty: 'easy',
    question: {
      en: "What is the essential ablution with pure water required before performing Salah called?",
      ur: "نماز ادا کرنے سے قبل پاک صاف پانی سے ہاتھ، منہ، بازو اور پاؤں دھونے کے عمل کو کیا کہتے ہیں؟",
      roman: "Namaz se pehle paak saaf pani se haath munh dhone ko kya kehte hain?"
    },
    options: {
      en: ["Wudu (Ablution)", "Tayammum", "Ghusl", "Taharah"],
      ur: ["وضو", "تیمم", "غسل", "طہارت"],
      roman: ["Wudu", "Tayammum", "Ghusl", "Taharah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Ma'idah (5:6)",
      ur: "سورۃ المائدہ، آیت ۶: 'يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا قُمْتُمْ إِلَى الصَّلَاةِ فَاغْسِلُوا وُجُوهَكُمْ...'",
      roman: "Surah Al-Ma'idah, Ayah 6"
    },
    explanation: {
      en: "The Holy Quran commands washing the face, hands to elbows, wiping the head, and washing feet to ankles as the prerequisites for prayer.",
      ur: "قرآن مجید میں چہرہ، کہنیوں سمیت ہاتھ، سر کا مسح اور ٹخنوں سمیت پاؤں دھونا وضو کے فرائض قرار دیے گئے۔",
      roman: "Wudu namaz ki kunji hai."
    }
  },
  {
    id: 822,
    categoryId: 8,
    difficulty: 'expert',
    question: {
      en: "Which special type of Hajj combines both Umrah and Hajj in a single continuous Ihram without taking off the Ihram between them?",
      ur: "حج کی وہ کون سی قسم ہے جس میں حاجی ایک ہی احرام میں عمرہ اور حج دونوں کی نیت کر کے احرام نہیں کھولتا؟",
      roman: "Hajj ki konsi qisam hai jisme ek hi ihram mein Umrah aur Hajj dono ada kiye jate hain?"
    },
    options: {
      en: ["Hajj al-Qiran", "Hajj at-Tamattu", "Hajj al-Ifrad", "Hajj al-Badal"],
      ur: ["حجِ قران", "حجِ تمتع", "حجِ افراد", "حجِ بدل"],
      roman: ["Hajj al-Qiran", "Hajj at-Tamattu", "Hajj al-Ifrad", "Hajj al-Badal"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 25, Hadith 1563) & Sahih Muslim",
      ur: "صحیح بخاری و مسلم، کتاب الحج، انواع الاحرام الثلاثۃ",
      roman: "Sahih Bukhari 1563"
    },
    explanation: {
      en: "Hajj al-Qiran combines Umrah and Hajj together without exiting Ihram, requiring a sacrificial animal (Hady).",
      ur: "حج قران میں عمرہ اور حج کا احرام ایک ساتھ باندھا جاتا ہے اور حاجی دسویں ذوالحجہ کی قربانی کے بعد ہی احرام کھولتا ہے۔",
      roman: "Hajj-e-Qiran mein Umrah aur Hajj dono ek hi ihram mein jama hote hain."
    }
  }
];
