import { Question } from '../../types/quiz';

export const monthsQuestions: Question[] = [
  {
    id: 901,
    categoryId: 9,
    difficulty: 'easy',
    question: {
      en: "What is the very first month of the Islamic lunar calendar?",
      ur: "اسلامی قمری سال کا سب سے پہلا مہینہ کون سا ہے؟",
      roman: "Islami Hijri saal ka sab se pehla maheena konsa hai?"
    },
    options: {
      en: ["Muharram al-Haram", "Safar", "Rabi' al-Awwal", "Ramadan"],
      ur: ["محرم الحرام", "صفر المظفر", "ربیع الاول", "رمضان المبارک"],
      roman: ["Muharram al-Haram", "Safar", "Rabi-ul-Awwal", "Ramzan"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 64, Hadith 4385)",
      ur: "صحیح بخاری، اشہر الحرم، حدیث ۴۳۸۵",
      roman: "Sahih Bukhari, Hadith 4385"
    },
    explanation: {
      en: "The Islamic calendar begins with Muharram and concludes with Dhul Hijjah, comprising 12 lunar months.",
      ur: "اسلامی سال کا آغاز محرم الحرام سے اور اختتام ذوالحجہ پر ہوتا ہے۔",
      roman: "Hijri calendar ka pehla maheena Muharram hai."
    }
  },
  {
    id: 902,
    categoryId: 9,
    difficulty: 'easy',
    question: {
      en: "How many sacred months (Al-Ashhur al-Hurum) are there according to the Quran and Sunnah?",
      ur: "قرآن مجید اور سنت نبوی ﷺ کے مطابق حرمت والے مقدس مہینے کل کتنے ہیں؟",
      roman: "Quran aur Sunnah ke mutabiq hurmat wale (sacred) maheene kitne hain?"
    },
    options: {
      en: ["4 Months", "3 Months", "2 Months", "6 Months"],
      ur: ["۴ مہینے (حرمت والے)", "۳ مہینے", "۲ مہینے", "۶ مہینے"],
      roman: ["4 Maheene", "3 Maheene", "2 Maheene", "6 Maheene"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah At-Tawbah (9:36) & Sahih Bukhari (Hadith 3197)",
      ur: "سورۃ التوبہ، آیت ۳۶: 'مِنْهَا أَرْبَعَةٌ حُرُمٌ'",
      roman: "Surah At-Tawbah, Ayah 36"
    },
    explanation: {
      en: "The four sacred months are: Dhul Qa'dah, Dhul Hijjah, Muharram (three consecutive), and Rajab.",
      ur: "چار حرمت والے مہینے ہیں: ذوالقعدہ، ذوالحجہ، محرم (مسلسل تین) اور ماہِ رجب۔",
      roman: "4 hurmat wale maheene hain: Zilhajj, Zilqad, Muharram aur Rajab."
    }
  },
  {
    id: 903,
    categoryId: 9,
    difficulty: 'easy',
    question: {
      en: "On which date of which Islamic month is Eid al-Fitr celebrated globally?",
      ur: "عید الفطر کس اسلامی مہینے کی پہلی تاریخ کو منائی جاتی ہے؟",
      roman: "Eid-ul-Fitr kis maheene ki pehli tareekh ko manayi jati hai?"
    },
    options: {
      en: ["1st Shawwal", "1st Ramadan", "10th Dhul Hijjah", "12th Rabi' al-Awwal"],
      ur: ["یکم شوال المکرم", "یکم رمضان", "۱۰ ذوالحجہ", "۱۲ ربیع الاول"],
      roman: ["1st Shawwal", "1st Ramzan", "10th Zilhajj", "12th Rabi-ul-Awwal"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 32, Hadith 1991)",
      ur: "صحیح بخاری، باب صوم یوم الفطر، حدیث ۱۹۹۱",
      roman: "Sahih Bukhari 1991"
    },
    explanation: {
      en: "Eid al-Fitr marks the celebratory conclusion of Ramadan on 1st Shawwal; fasting on this day is strictly forbidden.",
      ur: "یکم شوال کو رمضان کے روزوں کی تکمیل پر عید الفطر منائی جاتی ہے جس دن روزہ رکھنا حرام ہے۔",
      roman: "1 Shawwal ko Eid-ul-Fitr manayi jati hai."
    }
  },
  {
    id: 904,
    categoryId: 9,
    difficulty: 'easy',
    question: {
      en: "On which date of Dhul Hijjah is Eid al-Adha (Feast of the Sacrifice) celebrated?",
      ur: "عید الاضحیٰ (عیدِ قربان) کس اسلامی مہینے کی کس تاریخ کو منائی جاتی ہے؟",
      roman: "Eid-ul-Adha (Qurbani ki Eid) kis maheene ki kis tareekh ko hoti hai?"
    },
    options: {
      en: ["10th Dhul Hijjah", "9th Dhul Hijjah", "1st Muharram", "15th Sha'ban"],
      ur: ["۱۰ ذوالحجہ", "۹ ذوالحجہ", "یکم محرم", "۱۵ شعبان"],
      roman: ["10th Zilhajj", "9th Zilhajj", "1st Muharram", "15th Sha'ban"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 15, Hadith 948)",
      ur: "صحیح بخاری، کتاب العیدین، صلاۃ یوم النحر، حدیث ۹۴۸",
      roman: "Sahih Bukhari 948"
    },
    explanation: {
      en: "Eid al-Adha falls on the 10th of Dhul Hijjah following the Day of Arafat, celebrating Ibrahim's (AS) devotion.",
      ur: "۱۰ ذوالحجہ کو یوم النحر کہتے ہیں جس دن عید الاضحیٰ کی نماز اور جانوروں کی قربانی کی جاتی ہے۔",
      roman: "10 Zilhajj ko Eid-ul-Adha manayi jati hai."
    }
  },
  {
    id: 905,
    categoryId: 9,
    difficulty: 'medium',
    question: {
      en: "What is the 10th day of Muharram known as in the Islamic calendar, on which Musa (AS) was saved from Pharaoh?",
      ur: "ماہِ محرم کی دسویں تاریخ کو کیا کہا جاتا ہے جس دن اللہ نے حضرت موسیٰ علیہ السلام کو فرعون سے نجات دی؟",
      roman: "Muharram ki 10 tareekh ko kya kehte hain jis din Hazrat Musa (A.S) ko nijaat mili?"
    },
    options: {
      en: ["Yawm Ashura", "Yawm Arafah", "Yawm an-Nahr", "Laylat al-Qadr"],
      ur: ["یومِ عاشوراء (۱۰ محرم)", "یومِ عرفہ", "یومِ نحر", "لیلۃ القدر"],
      roman: ["Yawm-e-Ashura (10 Muharram)", "Yawm-e-Arafah", "Yawm-un-Nahr", "Laylat al-Qadr"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 30, Hadith 2004) & Sahih Muslim",
      ur: "صحیح بخاری، حدیث ۲۰۰۴، صوم یوم عاشوراء",
      roman: "Sahih Bukhari 2004"
    },
    explanation: {
      en: "The Prophet ﷺ fasted on Ashura and recommended fasting the 9th along with the 10th to be distinct from previous traditions.",
      ur: "رسول اللہ ﷺ نے یوم عاشوراء کا روزہ رکھا اور نویں یا گیارہویں تاریخ کو بھی ملا کر روزہ رکھنے کی ہدایت فرمائی۔",
      roman: "10 Muharram ko Yawm-e-Ashura kehte hain."
    }
  },
  {
    id: 906,
    categoryId: 9,
    difficulty: 'medium',
    question: {
      en: "What are the 11th, 12th, and 13th days of Dhul Hijjah called in Islamic terminology?",
      ur: "ذوالحجہ کی ۱۱، ۱۲ اور ۱۳ تاریخوں کو فقہ اسلامی میں کن ایام کے نام سے پکارا جاتا ہے؟",
      roman: "Zilhajj ki 11, 12 aur 13 tareekh ko kya kehte hain?"
    },
    options: {
      en: ["Ayyam at-Tashreeq (Days of Tashreeq)", "Ayyam al-Beed", "Ayyam al-Hurum", "Ayyam al-Fath"],
      ur: ["ایامِ تشریق (تکبیراتِ تشریق کے دن)", "ایامِ بیض", "ایامِ حرم", "ایامِ فتح"],
      roman: ["Ayyam-ut-Tashreeq", "Ayyam-ul-Beed", "Ayyam-e-Hurum", "Ayyam-e-Fath"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 6, Hadith 2679)",
      ur: "صحیح مسلم، کتاب الصیام، ایام التشریق ایام اکل وشرب، حدیث ۲۶۷۹",
      roman: "Sahih Muslim 2679"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'The days of Tashreeq are days of eating, drinking, and remembering Allah.' Fasting on these days is impermissible.",
      ur: "ایام تشریق کھانے پینے اور ذکر الٰہی کے دن ہیں جن میں ہر فرض نماز کے بعد تکبیر تشریق پڑھنا واجب ہے۔",
      roman: "Ayyam-ut-Tashreeq 11, 12 aur 13 Zilhajj ke din hain."
    }
  },
  {
    id: 907,
    categoryId: 9,
    difficulty: 'medium',
    question: {
      en: "What are the three middle days of every lunar month (13th, 14th, and 15th) called when fasting is Sunnah?",
      ur: "ہر چاند کے مہینے کی ۱۳، ۱۴ اور ۱۵ تاریخوں کو کیا کہا جاتا ہے جن میں روزہ رکھنا مسنون ہے؟",
      roman: "Har islami maheene ki 13, 14 aur 15 tareekh ko kya kehte hain jinme roza sunnat hai?"
    },
    options: {
      en: ["Ayyam al-Beed (The White Days of Full Moon)", "Ayyam at-Tashreeq", "Ayyam al-Qadr", "Ayyam ar-Rajab"],
      ur: ["ایامِ بیض (چودھویں کی چاندنی راتوں کے دن)", "ایامِ تشریق", "ایامِ قدر", "ایامِ رجب"],
      roman: ["Ayyam-ul-Beed", "Ayyam-ut-Tashreeq", "Ayyam-ul-Qadr", "Ayyam-e-Rajab"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sunan an-Nasa'i (Hadith 2420) & Jami at-Tirmidhi",
      ur: "سنن نسائی، حدیث ۲۴۲۰، صوم ثلاثة ایام من کل شہر",
      roman: "Sunan an-Nasa'i 2420"
    },
    explanation: {
      en: "Abu Hurairah (RA) said: 'My beloved Prophet ﷺ advised me to fast three days of every month: the 13th, 14th, and 15th (Ayyam al-Beed).'",
      ur: "رسول اللہ ﷺ نے ہر ماہ کے ایام بیض (۱۳، ۱۴، ۱۵ تاریخ) کے تین روزے رکھنے کی خصوصی ترغیب دی ہے۔",
      roman: "Ayyam-ul-Beed har maheene ki 13, 14, 15 tareekh hoti hain."
    }
  },
  {
    id: 908,
    categoryId: 9,
    difficulty: 'hard',
    question: {
      en: "In which blessed month did the Prophet's ﷺ miraculous Night Journey and Ascension (Al-Isra wal-Mi'raj) traditionally take place?",
      ur: "روایات کے مطابق رسول اللہ ﷺ کا واقعہ معراج (اسراء و معراج) کس اسلامی مہینے میں پیش آیا؟",
      roman: "Riwayat ke mutabiq waqia-e-Miraj kis Islami maheene mein pesh aya?"
    },
    options: {
      en: ["Rajab (27th Rajab)", "Sha'ban", "Rabi' al-Awwal", "Shawwal"],
      ur: ["ماہِ رجب المرجب (۲۷ رجب)", "ماہِ شعبان", "ماہِ ربیع الاول", "ماہِ شوال"],
      roman: ["Rajab (27 Rajab)", "Sha'ban", "Rabi-ul-Awwal", "Shawwal"]
    },
    correctAnswer: 0,
    reference: {
      en: "Classical Seerah & Ibn Kathir",
      ur: "البدایہ والنہایہ، ذکر الاسراء والمعراج فی رجب",
      roman: "Al-Bidayah wan-Nihayah"
    },
    explanation: {
      en: "According to popular consensus recorded by Ibn Ishaq and many historians, the Isra and Mi'raj occurred on the 27th night of Rajab.",
      ur: "مشہور اور مقبول روایت کے مطابق ۲۷ رجب کی شب کو آپ ﷺ کو معراج کی رفعتوں سے نوازا گیا۔",
      roman: "27 Rajab ko shab-e-Miraj manayi jati hai."
    }
  },
  {
    id: 909,
    categoryId: 9,
    difficulty: 'hard',
    question: {
      en: "Which Islamic month immediately precedes the holy month of Ramadan, during which the Prophet ﷺ fasted extensively?",
      ur: "رمضان المبارک سے متصل پہلے والا مہینہ کون سا ہے جس میں آپ ﷺ کثرت سے روزے رکھا کرتے تھے؟",
      roman: "Ramzan se pehle konsa maheena aata hai jisme Huzoor ﷺ kasrat se roze rakhte the?"
    },
    options: {
      en: ["Sha'ban", "Rajab", "Jumada al-Thani", "Safar"],
      ur: ["ماہِ شعبان المعظم", "ماہِ رجب", "جمادی الثانی", "ماہِ صفر"],
      roman: ["Sha'ban", "Rajab", "Jumada al-Thani", "Safar"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 30, Hadith 1969) & Sahih Muslim",
      ur: "صحیح بخاری، حدیث ۱۹۶۹، صوم شعبان",
      roman: "Sahih Bukhari 1969"
    },
    explanation: {
      en: "Sayyida Aisha (RA) narrated: 'I never saw the Prophet ﷺ fast more in any month than he did in Sha'ban.'",
      ur: "ام المؤمنین حضرت عائشہ رضی اللہ عنہا فرماتی ہیں کہ میں نے رسول اللہ ﷺ کو شعبان سے زیادہ کسی مہینے میں نفلی روزے رکھتے نہیں دیکھا۔",
      roman: "Sha'ban Ramzan se theek pehle aata hai."
    }
  },
  {
    id: 910,
    categoryId: 9,
    difficulty: 'expert',
    question: {
      en: "What is the 12th and final month of the Islamic calendar in which the annual Hajj pilgrimage is performed?",
      ur: "اسلامی تقویم کا بارہواں اور آخری مہینہ کون سا ہے جس میں فریضہ حج ادا کیا جاتا ہے؟",
      roman: "Hijri saal ka 12wan aur aakhri maheena konsa hai jisme Hajj ada hota hai?"
    },
    options: {
      en: ["Dhul Hijjah", "Dhul Qa'dah", "Shawwal", "Muharram"],
      ur: ["ذوالحجہ (ذوالحجۃ الحرام)", "ذوالقعدہ", "شوال", "محرم"],
      roman: ["Dhul Hijjah (Zilhajj)", "Dhul Qa'dah (Zilqad)", "Shawwal", "Muharram"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah Al-Hajj & Sahih Bukhari",
      ur: "سورۃ الحج و احادیث مناسکِ حج",
      roman: "Surah Al-Hajj"
    },
    explanation: {
      en: "Dhul Hijjah (The Month of the Pilgrimage) contains the sacred first 10 days, Day of Arafah, and Eid al-Adha.",
      ur: "ذوالحجہ سال کا آخری مہینہ ہے جس کے ابتدائی دس دن تمام دنوں میں سب سے زیادہ افضل اور محترم ہیں۔",
      roman: "Zilhajj mein Hajj ke tamam ahem manasik ada hote hain."
    }
  },
  {
    id: 911,
    categoryId: 9,
    difficulty: 'expert',
    question: {
      en: "How many days can an Islamic lunar month have depending on the sighting of the new crescent moon (Hilal)?",
      ur: "چاند کے رویت پر منحصر اسلامی قمری مہینہ کتنے دنوں پر مشتمل ہو سکتا ہے؟",
      roman: "Chand dekhne par mabni Islami maheena kitne din ka ho sakta hai?"
    },
    options: {
      en: ["Either 29 or 30 days", "Always 30 days", "Always 28 days", "30 or 31 days"],
      ur: ["یا ۲۹ دن یا ۳۰ دن", "ہمیشہ ۳۰ دن", "ہمیشہ ۲۸ دن", "۳۰ یا ۳۱ دن"],
      roman: ["Sirf 29 ya 30 din", "Hamesha 30", "Hamesha 28", "30 ya 31"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 30, Hadith 1907)",
      ur: "صحیح بخاری، حدیث ۱۹۰۷: 'الشهر هكذا وهكذا يعني تسعا وعشرين وثلاثين'",
      roman: "Sahih Bukhari 1907"
    },
    explanation: {
      en: "The Prophet ﷺ gestured with his blessed fingers: 'The month is like this and like this'—meaning 29 or 30 days.",
      ur: "رسول اللہ ﷺ نے فرمایا: مہینہ ۲۹ دن کا بھی ہوتا ہے اور ۳۰ دن کا بھی، چاند دیکھ کر روزہ رکھو اور چاند دیکھ کر افطار کرو۔",
      roman: "Islami maheena sirf 29 ya 30 din ka hota hai."
    }
  },
  {
    id: 912,
    categoryId: 9,
    difficulty: 'easy',
    question: {
      en: "In which Islamic month is the birth of the Prophet Muhammad ﷺ celebrated by Muslims across the globe?",
      ur: "حضور اکرم ﷺ کی ولادتِ باسعادت کس اسلامی مہینے میں ہوئی جس میں میلاد النبی منایا جاتا ہے؟",
      roman: "Huzoor ﷺ ki wiladat-e-ba-saadat kis Islami maheene mein hui?"
    },
    options: {
      en: ["Rabi' al-Awwal", "Rabi' al-Thani", "Rajab", "Ramadan"],
      ur: ["ماہِ ربیع الاول (۱۲ ربیع الاول)", "ربیع الثانی", "رجب", "رمضان"],
      roman: ["Rabi-ul-Awwal (12 Rabi-ul-Awwal)", "Rabi-us-Sani", "Rajab", "Ramzan"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sirat Ibn Hisham & Sahih Muslim",
      ur: "سیرت ابن ہشام و صحیح مسلم، صوم یوم الاثنین",
      roman: "Sirat Ibn Hisham"
    },
    explanation: {
      en: "Prophet Muhammad ﷺ was born on Monday in Rabi' al-Awwal in the Year of the Elephant.",
      ur: "آپ ﷺ پیر کے دن ماہ ربیع الاول میں تشریف لائے۔ پیر کے روزے کی فضیلت میں آپ نے فرمایا: اسی دن میں پیدا ہوا۔",
      roman: "Huzoor ﷺ ki wiladat Rabi-ul-Awwal ke maheene mein hui."
    }
  },
  {
    id: 913,
    categoryId: 9,
    difficulty: 'medium',
    question: {
      en: "What is the virtue of the first ten days of Dhul Hijjah described by Prophet Muhammad ﷺ?",
      ur: "ماہِ ذوالحجہ کے ابتدائی دس دنوں کے متعلق رسول اللہ ﷺ نے کیا فضیلت ارشاد فرمائی؟",
      roman: "Zilhajj ke pehle 10 dinon ke mutalliq Nabi ﷺ ne kya fazeelat bayaan farmayi?"
    },
    options: {
      en: [
        "There are no days in which righteous deeds are more beloved to Allah than these ten days",
        "They are ordinary days",
        "Fasting is forbidden in all ten days",
        "Trading is discouraged"
      ],
      ur: [
        "اللہ کے نزدیک ان دس دنوں کے نیک اعمال سے زیادہ کوئی دن پسندیدہ نہیں",
        "یہ عام دنوں کی طرح ہیں",
        "ان دسوں دنوں میں روزہ رکھنا منع ہے",
        "تجارت کرنا منع ہے"
      ],
      roman: [
        "Allah ko in 10 dinon ke nek aamal se zyada koi aamal pasand nahi",
        "Aam din hain",
        "Roza haram hai",
        "Tijarat mana hai"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 15, Hadith 969)",
      ur: "صحیح بخاری، حدیث ۹۶۹: 'ما من أيام العمل الصالح فيها أحب إلى الله من هذه الأيام'",
      roman: "Sahih Bukhari, Hadith 969"
    },
    explanation: {
      en: "The Prophet ﷺ declared the first ten days of Dhul Hijjah the greatest days of the entire year for good deeds.",
      ur: "رسول اللہ ﷺ نے فرمایا کہ ذوالحجہ کے ابتدائی دس دنوں کی نیکی اللہ کو سب سے زیادہ محبوب ہے۔",
      roman: "Huzoor ﷺ ne Zilhajj ke pehle 10 dinon ko saal ke behtareen din farmaya."
    }
  },
  {
    id: 914,
    categoryId: 9,
    difficulty: 'hard',
    question: {
      en: "What is the 9th day of Dhul Hijjah, the day of standing before Allah on the plain of Arafat, known as?",
      ur: "ذوالحجہ کی نویں تاریخ کو کیا کہا جاتا ہے جس دن حجاج کرام میدانِ عرفات میں اکٹھے ہوتے ہیں؟",
      roman: "9 Zilhajj ko kya kehte hain jis din haji Arafat mein khare hote hain?"
    },
    options: {
      en: ["Yawm Arafah (Day of Arafah)", "Yawm an-Nahr", "Yawm at-Tarwiyah", "Yawm al-Qarr"],
      ur: ["یومِ عرفہ (۹ ذوالحجہ)", "یومِ نحر", "یومِ ترویہ", "یومِ قر"],
      roman: ["Yawm-e-Arafah (9 Zilhajj)", "Yawm-un-Nahr", "Yawm-ut-Tarwiyah", "Yawm-ul-Qarr"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 6, Hadith 2603)",
      ur: "صحیح مسلم، صوم یوم عرفۃ یکفر سنتین، حدیث ۲۶۰۳",
      roman: "Sahih Muslim 2603"
    },
    explanation: {
      en: "Fasting on the Day of Arafah for non-pilgrims expiates the sins of the preceding year and the coming year.",
      ur: "غیر حجاج کے لیے یوم عرفہ کا روزہ پچھلے اور اگلے سال کے گناہوں کا کفارہ بن جاتا ہے۔",
      roman: "Yawm-e-Arafah ka roza do saalon ke gunahon ko mita deta hai."
    }
  },
  {
    id: 915,
    categoryId: 9,
    difficulty: 'medium',
    question: {
      en: "What is the 8th day of Dhul Hijjah called when pilgrims set out from Makkah to camp in Mina?",
      ur: "۸ ذوالحجہ کا وہ مبارک دن کیا کہلاتا ہے جب حجاج کرام مکہ سے منیٰ کی طرف روانہ ہوتے ہیں؟",
      roman: "8 Zilhajj ka din kya kehlata hai jab haji Mina rawana hote hain?"
    },
    options: {
      en: ["Yawm at-Tarwiyah", "Yawm Arafah", "Yawm an-Nahr", "Yawm al-Jumu'ah"],
      ur: ["یومِ ترویہ (۸ ذوالحجہ)", "یومِ عرفہ", "یومِ نحر", "یومِ جمعہ"],
      roman: ["Yawm-ut-Tarwiyah (8 Zilhajj)", "Yawm-e-Arafah", "Yawm-un-Nahr", "Yawm-e-Jumu'ah"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 25, Hadith 1653)",
      ur: "صحیح بخاری، احکام الخروج الی منی یوم الترویۃ، حدیث ۱۶۵۳",
      roman: "Sahih Bukhari 1653"
    },
    explanation: {
      en: "Yawm at-Tarwiyah is named from ancient pilgrims gathering and watering their camels in preparation for the days of Hajj ahead.",
      ur: "یومِ ترویہ کو اس لیے یہ نام دیا گیا کیونکہ حاجی پانی کا انتظام کر کے منیٰ میں پانچ نمازیں ادا کرتے تھے۔",
      roman: "8 Zilhajj ko Yawm-ut-Tarwiyah kehte hain."
    }
  },
  {
    id: 916,
    categoryId: 9,
    difficulty: 'hard',
    question: {
      en: "Which Islamic month follows Ramadan, during which fasting six voluntary days carries the reward of fasting the whole year?",
      ur: "رمضان کے فوراً بعد آنے والے کس مہینے میں چھ نفلی روزے رکھنے پر پورے سال کے روزوں کا ثواب ملتا ہے؟",
      roman: "Ramzan ke foran baad kis maheene mein 6 nafl roze rakhne par poore saal ka sawab milta hai?"
    },
    options: {
      en: ["Shawwal", "Sha'ban", "Dhul Qa'dah", "Muharram"],
      ur: ["ماہِ شوال المکرم (شش عیدی روزے)", "شعبان", "ذوالقعدہ", "محرم"],
      roman: ["Shawwal (6 Roze)", "Sha'ban", "Dhul Qa'dah", "Muharram"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Muslim (Book 6, Hadith 2614)",
      ur: "صحیح مسلم، حدیث ۲۶۱۴: 'من صام رمضان ثم اتبعه ستا من شوال كان كصيام الدهر'",
      roman: "Sahih Muslim 2614"
    },
    explanation: {
      en: "The Prophet ﷺ said: 'Whoever fasts Ramadan and follows it with six days from Shawwal, it is as if he fasted for a lifetime.'",
      ur: "رسول اللہ ﷺ نے فرمایا: جس نے رمضان کے روزے رکھے پھر شوال کے چھ روزے رکھے، تو یہ ایسا ہے جیسے اس نے عمر بھر روزے رکھے۔",
      roman: "Shawal ke 6 roze rakhna poore saal ke rozo ke barabar hai."
    }
  },
  {
    id: 917,
    categoryId: 9,
    difficulty: 'expert',
    question: {
      en: "What was the pre-Islamic practice of artificially shifting and postponing sacred months for warfare that was abolished by the Quran in 9:37?",
      ur: "زمانۂ جاہلیت میں جنگ کرنے کی خاطر حرمت والے مہینوں کو آگے پیچھے کر دینے کی بدعت کو کیا کہا جاتا تھا جسے قرآن نے باطل کیا؟",
      roman: "Zamana-e-Jahiliyat mein hurmat wale maheenon ko badalne ko kya kehte the jise Quran ne haraam qarar diya?"
    },
    options: {
      en: ["An-Nasi' ( النَّسِيءُ )", "Al-Qirab", "Al-Ba'al", "Al-Ilaf"],
      ur: ["النسیء (مہینوں کو آگے پیچھے کرنا)", "القراب", "البعل", "الایلاف"],
      roman: ["An-Nasee'", "Al-Qirab", "Al-Ba'al", "Al-Ilaf"]
    },
    correctAnswer: 0,
    reference: {
      en: "Surah At-Tawbah (9:37)",
      ur: "سورۃ التوبہ، آیت ۳۷: 'إِنَّمَا النَّسِيءُ زِيَادَةٌ فِي الْكُفْرِ'",
      roman: "Surah At-Tawbah, Ayah 37"
    },
    explanation: {
      en: "The Quran condemned An-Nasi' as an increase in disbelief, restoring the twelve natural lunar cycles ordained by Allah.",
      ur: "قرآن نے اعلان فرمایا کہ نسیء کفر میں زیادتی ہے، اور مہینوں کی قدرتی ترتیب کو دوبارہ بحال فرمایا۔",
      roman: "Nasee' maheenon mein her pher karne ko kehte the."
    }
  },
  {
    id: 918,
    categoryId: 9,
    difficulty: 'easy',
    question: {
      en: "What is the blessed night of the 15th of Sha'ban known as in the Indian subcontinent and Muslim world?",
      ur: "۱۵ شعبان کی برکتوں اور مغفرت والی رات کو برصغیر اور عالمِ اسلام میں عام طور پر کیا کہا جاتا ہے؟",
      roman: "15 Sha'ban ki maghfirat wali raat ko aam tor par kya kehte hain?"
    },
    options: {
      en: ["Shab-e-Bara'at / Laylat an-Nisf min Sha'ban", "Shab-e-Qadr", "Shab-e-Miraj", "Yawm an-Nahr"],
      ur: ["شبِ برات (لیلۃ النصف من شعبان)", "شبِ قدر", "شبِ معراج", "یومِ نحر"],
      roman: ["Shab-e-Bara'at / Nisf Sha'ban", "Shab-e-Qadr", "Shab-e-Miraj", "Yawm-un-Nahr"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sunan Ibn Majah (Hadith 1389)",
      ur: "سنن ابن ماجہ، کتاب اقامۃ الصلاۃ، حدیث ۱۳۸۹",
      roman: "Sunan Ibn Majah 1389"
    },
    explanation: {
      en: "The Prophet ﷺ mentioned that Allah gazes down with abundant mercy on the middle night of Sha'ban, forgiving believers.",
      ur: "حدیث مبارکہ میں ہے کہ پندرہویں شعبان کی رات اللہ تعالیٰ کثرت سے اپنے بندوں کی مغفرت فرماتا ہے۔",
      roman: "Shab-e-Bara'at 15 Sha'ban ki mubarak raat hai."
    }
  },
  {
    id: 919,
    categoryId: 9,
    difficulty: 'medium',
    question: {
      en: "Which Islamic month comes between Shawwal and Dhul Hijjah, being one of the sacred months?",
      ur: "ماہِ شوال اور ماہِ ذوالحجہ کے درمیان آنے والا حرمت والا گیارہواں اسلامی مہینہ کون سا ہے؟",
      roman: "Shawwal aur Zilhajj ke darmiyan konsa hurmat wala maheena aata hai?"
    },
    options: {
      en: ["Dhul Qa'dah", "Safar", "Rabi' al-Thani", "Jumada al-Awwal"],
      ur: ["ذوالقعدہ (ذوالقعدۃ الحرام)", "صفر", "ربیع الثانی", "جمادی الاول"],
      roman: ["Dhul Qa'dah (Zilqad)", "Safar", "Rabi-us-Sani", "Jumada al-Awwal"]
    },
    correctAnswer: 0,
    reference: {
      en: "Islamic Lunar Calendar & Hadith",
      ur: "ترتیبِ اشہرِ ہجریہ و سنن نسائی",
      roman: "Islamic Calendar sequence"
    },
    explanation: {
      en: "Dhul Qa'dah is the 11th month where Arabs historically sat (Qa'adah) and refrained from warfare to allow pilgrims safe passage.",
      ur: "ذوالقعدہ میں جنگ و جدل ممنوع تھی تاکہ حجاج کرام امن و سکون کے ساتھ بیت اللہ کا سفر کر سکیں۔",
      roman: "Dhul Qa'dah 11wan maheena hai."
    }
  },
  {
    id: 920,
    categoryId: 9,
    difficulty: 'hard',
    question: {
      en: "What is the Dua taught by the Prophet ﷺ upon sighting the new crescent moon (Hilal)?",
      ur: "نیا چاند دیکھ کر رسول اللہ ﷺ کیا مسنون دعا مانگا کرتے تھے؟",
      roman: "Naya chand dekh kar Huzoor ﷺ konsi masnoon dua parhte the?"
    },
    options: {
      en: [
        "Allahu Akbar, Allahumma ahillahu 'alayna bil-amni wal-iman was-salamati wal-Islam",
        "Rabbana atina fid-dunya hasanah",
        "Subhana Rabbiyal A'la",
        "Bismillahi tawakkaltu 'alallah"
      ],
      ur: [
        "اللَّهُمَّ أَهِلَّهُ عَلَيْنَا بِالأَمْنِ وَالإِيمَانِ وَالسَّلَامَةِ وَالإِسْلَامِ رَبِّي وَرَبُّكَ اللَّهُ",
        "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً",
        "سُبْحَانَ رَبِّيَ الأَعْلَى",
        "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ"
      ],
      roman: [
        "Allahumma ahillahu alaina bil-amni wal-iman was-salamati wal-Islam, Rabbi wa Rabbukallah",
        "Rabbana aatina",
        "Subhana Rabbiyal A'la",
        "Bismillahi tawakkaltu"
      ]
    },
    correctAnswer: 0,
    reference: {
      en: "Jami at-Tirmidhi (Hadith 3451)",
      ur: "جامع ترمذی، ابواب الدعوات، دعاء رؤیۃ الہلال، حدیث ۳۴۵۱",
      roman: "Jami at-Tirmidhi 3451"
    },
    explanation: {
      en: "The Prophet ﷺ supplicated for peace, faith, safety, and Islam upon seeing the new crescent, addressing the moon: 'My Lord and your Lord is Allah.'",
      ur: "چاند دیکھ کر دعا مانگی جاتی ہے کہ اے اللہ! اس چاند کو ہم پر امن، ایمان، سلامتی اور اسلام کے ساتھ طلوع فرما۔",
      roman: "Naya chand dekhne par aman wa salamati ki dua mangna sunnat hai."
    }
  },
  {
    id: 921,
    categoryId: 9,
    difficulty: 'expert',
    question: {
      en: "Which Islamic month was historically called 'Rajab al-Murajjab' and is isolated from the three consecutive sacred months?",
      ur: "تین متصل حرمت والے مہینوں سے الگ تنہا آنے والا وہ کون سا مہینہ ہے جسے 'رجب المرجب' کہا جاتا ہے؟",
      roman: "Akele aane wala hurmat wala maheena konsa hai jise 'Rajab al-Murajjab' kehte hain?"
    },
    options: {
      en: ["Rajab (The 7th Month)", "Safar", "Shawwal", "Rabi' al-Awwal"],
      ur: ["ماہِ رجب (ساتواں مہینہ)", "ماہِ صفر", "شوال", "ربیع الاول"],
      roman: ["Rajab (7th Month)", "Safar", "Shawwal", "Rabi-ul-Awwal"]
    },
    correctAnswer: 0,
    reference: {
      en: "Sahih Bukhari (Book 59, Hadith 3197)",
      ur: "صحیح بخاری، حدیث ۳۱۹۷، 'ورجب مضر الذي بين جمادى وشعبان'",
      roman: "Sahih Bukhari, Hadith 3197"
    },
    explanation: {
      en: "The Prophet ﷺ specified: 'And Rajab of Mudar, which is between Jumada and Sha'ban.' It stands apart as the 7th month.",
      ur: "رسول اللہ ﷺ نے فرمایا: اور رجبِ مضر جو جمادی اور شعبان کے درمیان واقع ہے۔",
      roman: "Rajab jumada aur sha'ban ke darmiyan aane wala hurmat wala maheena hai."
    }
  }
];
