import { Question, Difficulty } from '../../types/quiz';
import { quranQuestions } from './quran';
import { hadithQuestions } from './hadith';
import { seeratQuestions } from './seerat';
import { historyQuestions } from './history';
import { prophetsQuestions } from './prophets';
import { generalQuestions } from './general';
import { sahabaQuestions } from './sahaba';
import { pillarsQuestions } from './pillars';
import { monthsQuestions } from './months';
import { basicQuestions } from './basic';

export const allQuestions: Question[] = [
  ...quranQuestions,
  ...hadithQuestions,
  ...seeratQuestions,
  ...historyQuestions,
  ...prophetsQuestions,
  ...generalQuestions,
  ...sahabaQuestions,
  ...pillarsQuestions,
  ...monthsQuestions,
  ...basicQuestions,
];

/**
 * Synchronously shuffles the 4 options for a question across all supported languages (en, ur, roman)
 * using Fisher-Yates shuffle, and updates `correctAnswer` to point to the new index of the original correct answer.
 * Preserves question and option meaning, ensuring exact consistency across languages.
 */
export function shuffleQuestionOptions(q: Question): Question {
  // Create an array of indices [0, 1, 2, 3] and shuffle using Fisher-Yates
  const indices = [0, 1, 2, 3];
  for (let i = indices.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [indices[i], indices[j]] = [indices[j], indices[i]];
  }

  // Identify new index of the question's original correct answer
  const originalCorrectIndex = q.correctAnswer;
  const newCorrectAnswer = indices.indexOf(originalCorrectIndex);

  return {
    ...q,
    options: {
      en: indices.map(idx => q.options.en[idx] ?? ''),
      ur: indices.map(idx => q.options.ur[idx] ?? ''),
      roman: indices.map(idx => q.options.roman[idx] ?? ''),
    },
    correctAnswer: newCorrectAnswer,
  };
}

/**
 * Filter questions by Category and optional difficulty, with randomized answer positions
 */
export function getQuestionsByCategory(categoryId: number, difficulty?: Difficulty): Question[] {
  let list = allQuestions.filter(q => q.categoryId === categoryId);
  if (difficulty) {
    list = list.filter(q => q.difficulty === difficulty);
  }
  return shuffleArray(list).map(shuffleQuestionOptions);
}

/**
 * Deterministic pseudo-random question generator for Daily Islamic Challenge
 * Using date string (e.g. "2026-11-07") as seed so every player gets the exact same 10 questions on that day!
 * Each question has its 4 answer options randomly shuffled.
 */
export function getDailyQuestions(dateString: string): Question[] {
  let hash = 0;
  for (let i = 0; i < dateString.length; i++) {
    hash = (hash << 5) - hash + dateString.charCodeAt(i);
    hash |= 0;
  }
  hash = Math.abs(hash);

  // Group by category to ensure rich diversity (1 question per category!)
  const selected: Question[] = [];
  for (let catId = 1; catId <= 10; catId++) {
    const catQuestions = allQuestions.filter(q => q.categoryId === catId);
    if (catQuestions.length > 0) {
      const index = (hash + catId * 17) % catQuestions.length;
      selected.push(catQuestions[index]);
    }
  }

  return selected.map(shuffleQuestionOptions);
}

/**
 * Generate 10-question set for a quick play quiz with randomized answer positions
 */
export function getQuickPlayQuestions(count: number = 10, difficulty?: Difficulty): Question[] {
  let pool = difficulty ? allQuestions.filter(q => q.difficulty === difficulty) : allQuestions;
  if (pool.length < count) pool = allQuestions;
  return shuffleArray(pool).slice(0, count).map(shuffleQuestionOptions);
}

/**
 * Utility to shuffle array
 */
export function shuffleArray<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

