import React from 'react';
import { Lock, Star, Play, CheckCircle2, ArrowLeft, Trophy } from 'lucide-react';
import { levels } from '../data/levels';
import { Language, UserStats } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';

interface LevelsViewProps {
  language: Language;
  stats: UserStats;
  onPlayLevel: (levelNum: number) => void;
  onBack: () => void;
}

export const LevelsView: React.FC<LevelsViewProps> = ({
  language,
  stats,
  onPlayLevel,
  onBack,
}) => {
  const t = translations[language];
  const isUrdu = language === 'ur';

  // Group levels by tier
  const tiers = [
    { id: 'beginner', title: isUrdu ? "مبتدی (لیول ۱)" : "Level 1: Beginner", range: [1] },
    { id: 'basic', title: isUrdu ? "بنیادی اسلامی معلومات (لیولز ۲ تا ۵)" : "Levels 2–5: Basic Islamic Knowledge", range: [2, 3, 4, 5] },
    { id: 'intermediate', title: isUrdu ? "متوسط اسلامی معلومات (لیولز ۶ تا ۱۰)" : "Levels 6–10: Intermediate", range: [6, 7, 8, 9, 10] },
    { id: 'advanced', title: isUrdu ? "اعلیٰ اسلامی معلومات (لیولز ۱۱ تا ۱۵)" : "Levels 11–15: Advanced", range: [11, 12, 13, 14, 15] },
    { id: 'expert', title: isUrdu ? "ماہرانہ و فقہی معلومات (لیولز ۱۶ تا ۲۰)" : "Levels 16–20: Expert", range: [16, 17, 18, 19, 20] },
  ];

  const totalStars = Object.values(stats.levelProgress).reduce((acc, curr) => acc + (curr.stars || 0), 0);
  const completedCount = Object.values(stats.levelProgress).filter(l => l.completed).length;

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6 sm:py-8 flex flex-col animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => {
            soundService.playButtonClick();
            onBack();
          }}
          className="flex items-center gap-1.5 text-xs text-amber-300 hover:text-amber-100 px-3 py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-500/30 transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <div className="text-center">
          <h2 className="text-xl sm:text-2xl font-extrabold text-amber-100">
            {t.levels}
          </h2>
          <span className="text-xs text-emerald-300/80">
            {completedCount} / 20 Completed
          </span>
        </div>

        {/* Total Stars Counter */}
        <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-amber-950/60 border border-amber-500/40 text-amber-300 text-xs font-bold tabular-nums">
          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          <span>{totalStars} / 60</span>
        </div>
      </div>

      {/* Tier Sections */}
      <div className="space-y-6 sm:space-y-8">
        {tiers.map(tier => {
          const tierLevels = levels.filter(l => tier.range.includes(l.level));

          return (
            <div key={tier.id} className="rounded-3xl bg-emerald-950/30 border border-emerald-700/20 p-4 sm:p-5">
              <h3 className="text-xs sm:text-sm font-bold text-amber-300 uppercase tracking-wider mb-3.5 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                {tier.title}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {tierLevels.map(levelCfg => {
                  const progress = stats.levelProgress[levelCfg.level] || {
                    level: levelCfg.level,
                    unlocked: levelCfg.level === 1,
                    completed: false,
                    stars: 0,
                    highScore: 0
                  };

                  const isUnlocked = progress.unlocked;
                  const isCompleted = progress.completed;

                  return (
                    <button
                      key={levelCfg.level}
                      disabled={!isUnlocked}
                      onClick={() => {
                        soundService.playButtonClick();
                        onPlayLevel(levelCfg.level);
                      }}
                      className={`relative p-4 rounded-2xl border text-left transition-all duration-200 cursor-pointer ${
                        isUnlocked
                          ? 'bg-gradient-to-br from-[#063928] to-[#021f15] border-amber-500/40 hover:border-amber-400 hover:scale-[1.02] shadow-lg shadow-emerald-950/40'
                          : 'bg-stone-900/40 border-stone-800 text-stone-600 opacity-60 cursor-not-allowed'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className={`text-base font-extrabold ${isUnlocked ? 'text-amber-400 font-cinzel' : 'text-stone-500'}`}>
                            {levelCfg.level < 10 ? `0${levelCfg.level}` : levelCfg.level}
                          </span>
                          {isCompleted && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          )}
                        </div>

                        {/* Lock / Play Icon */}
                        {isUnlocked ? (
                          <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center">
                            <Play className="w-3.5 h-3.5 fill-amber-300 translate-x-0.5" />
                          </div>
                        ) : (
                          <div className="w-7 h-7 rounded-lg bg-stone-800 text-stone-500 flex items-center justify-center">
                            <Lock className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </div>

                      {/* Level Title */}
                      <div className={`font-bold text-xs sm:text-sm line-clamp-1 mb-1.5 ${isUnlocked ? 'text-amber-100' : 'text-stone-500'}`}>
                        {levelCfg.title[language] || levelCfg.title.en}
                      </div>

                      {/* Stars and score */}
                      <div className="flex items-center justify-between text-[11px] pt-1 border-t border-emerald-900/40">
                        <div className="flex items-center gap-1">
                          {[1, 2, 3].map(s => (
                            <Star
                              key={s}
                              className={`w-3 h-3 ${
                                s <= progress.stars
                                  ? 'text-amber-400 fill-amber-400'
                                  : 'text-stone-700'
                              }`}
                            />
                          ))}
                        </div>
                        {progress.highScore > 0 && (
                          <span className="text-emerald-400/90 font-mono font-medium">
                            {progress.highScore} pts
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
