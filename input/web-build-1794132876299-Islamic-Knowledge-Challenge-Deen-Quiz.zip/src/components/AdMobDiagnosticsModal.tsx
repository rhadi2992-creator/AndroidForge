import React, { useState, useEffect } from 'react';
import {
  X,
  Activity,
  CheckCircle2,
  XCircle,
  Wifi,
  WifiOff,
  RefreshCw,
  Play,
  Award,
  Layers,
  Sparkles,
  Smartphone,
  Eye,
  Sliders,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';
import { adMobService, AdMobDiagnostics } from '../services/adMobService';
import { soundService } from '../services/soundService';

interface AdMobDiagnosticsModalProps {
  onClose: () => void;
  onTriggerTestAd: (type: 'banner' | 'appOpen' | 'interstitial' | 'native' | 'rewarded') => void;
}

export const AdMobDiagnosticsModal: React.FC<AdMobDiagnosticsModalProps> = ({
  onClose,
  onTriggerTestAd,
}) => {
  const [diag, setDiag] = useState<AdMobDiagnostics>(adMobService.getDiagnostics());
  const config = adMobService.getConfig();

  const refresh = () => {
    setDiag(adMobService.getDiagnostics());
  };

  useEffect(() => {
    const timer = setInterval(refresh, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleToggleMode = (mode: 'production' | 'test') => {
    soundService.playButtonClick();
    adMobService.setMode(mode);
    refresh();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'READY':
      case 'RENDERED':
      case 'INITIALIZED':
        return <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono font-bold flex items-center gap-1"><CheckCircle2 className="w-3 h-3 text-emerald-400" /> READY</span>;
      case 'LOADING':
      case 'INITIALIZING':
        return <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-bold animate-pulse">LOADING</span>;
      case 'COOLDOWN':
        return <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[10px] font-mono font-bold">COOLDOWN</span>;
      case 'FAILED':
      default:
        return <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-mono font-bold flex items-center gap-1"><XCircle className="w-3 h-3 text-rose-400" /> FAILED</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-[#05291d] via-[#021d14] to-[#01140e] border border-amber-500/50 p-5 sm:p-7 shadow-2xl text-amber-50">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-emerald-800/40 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Activity className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base sm:text-lg text-amber-100">
                  AdMob Internal Diagnostics Console
                </h3>
                <span className="text-[10px] bg-emerald-950 px-2 py-0.5 rounded border border-emerald-600/40 text-emerald-300 font-mono">
                  v23.0.0 SDK
                </span>
              </div>
              <span className="text-xs text-emerald-300/80">
                Real-Time Delivery & Health Verification
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              soundService.playButtonClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-emerald-950/70 border border-emerald-700/40 text-stone-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs">
          {/* Top Health Status Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40">
              <span className="text-[10px] text-stone-400 uppercase font-mono block">SDK Status</span>
              <div className="mt-1">{getStatusBadge(diag.initializationStatus)}</div>
            </div>

            <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40">
              <span className="text-[10px] text-stone-400 uppercase font-mono block">Platform</span>
              <span className="text-xs font-bold text-amber-200 mt-1 block">
                {diag.platform === 'native_android' ? 'Android Native' : 'Web Simulator'}
              </span>
            </div>

            <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40">
              <span className="text-[10px] text-stone-400 uppercase font-mono block">Network</span>
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-300 mt-1">
                {diag.networkOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-400" /> : <WifiOff className="w-3.5 h-3.5 text-rose-400" />}
                <span>{diag.networkOnline ? 'Online' : 'Offline'}</span>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40">
              <span className="text-[10px] text-stone-400 uppercase font-mono block">Ad Mode</span>
              <div className="mt-1 flex gap-1">
                <button
                  onClick={() => handleToggleMode('production')}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold font-mono transition cursor-pointer ${
                    diag.adMode === 'production'
                      ? 'bg-amber-400 text-stone-950'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Prod
                </button>
                <button
                  onClick={() => handleToggleMode('test')}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold font-mono transition cursor-pointer ${
                    diag.adMode === 'test'
                      ? 'bg-emerald-500 text-stone-950'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Test
                </button>
              </div>
            </div>
          </div>

          {/* App ID Verification Card */}
          <div className="p-3 rounded-2xl bg-black/40 border border-amber-500/30 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-stone-400 font-mono block">CONFIGURED ADMOB APP ID</span>
              <span className="text-xs font-mono font-bold text-amber-300 select-all">{config.appId}</span>
            </div>
            <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-700/40 font-mono font-bold">
              ✓ Verified in Manifest
            </span>
          </div>

          {/* Individual Ad Formats Matrix */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-amber-300 block">
              Ad Format Status & Independent Testing:
            </span>

            {/* 1. Banner Ad */}
            <div className="p-3 rounded-2xl bg-emerald-950/50 border border-emerald-800/40 flex items-center justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-bold text-amber-100">1. Adaptive Banner</span>
                  {getStatusBadge(diag.bannerStatus)}
                </div>
                <span className="text-[10px] font-mono text-stone-400 truncate block">{config.bannerAdUnitId}</span>
                <span className="text-[10px] text-emerald-300/80 mt-0.5 block">
                  Req: {diag.requestCounts.banner} • Impr: {diag.impressionCounts.banner}
                </span>
              </div>
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onTriggerTestAd('banner');
                }}
                className="px-3 py-1.5 rounded-xl bg-emerald-900 border border-emerald-600/40 text-amber-300 hover:bg-emerald-800 text-xs font-bold transition shrink-0 cursor-pointer"
              >
                Test Banner
              </button>
            </div>

            {/* 2. App Open Ad */}
            <div className="p-3 rounded-2xl bg-emerald-950/50 border border-emerald-800/40 flex items-center justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-bold text-amber-100">2. App Open Ad</span>
                  {getStatusBadge(diag.appOpenStatus)}
                </div>
                <span className="text-[10px] font-mono text-stone-400 truncate block">{config.appOpenAdUnitId}</span>
                <span className="text-[10px] text-emerald-300/80 mt-0.5 block">
                  Req: {diag.requestCounts.appOpen} • Impr: {diag.impressionCounts.appOpen}
                </span>
              </div>
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onTriggerTestAd('appOpen');
                }}
                className="px-3 py-1.5 rounded-xl bg-amber-500 text-stone-950 hover:bg-amber-400 text-xs font-bold transition shrink-0 cursor-pointer"
              >
                Test App Open
              </button>
            </div>

            {/* 3. Interstitial Ad */}
            <div className="p-3 rounded-2xl bg-emerald-950/50 border border-emerald-800/40 flex items-center justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-bold text-amber-100">3. Interstitial Ad</span>
                  {getStatusBadge(diag.interstitialStatus)}
                </div>
                <span className="text-[10px] font-mono text-stone-400 truncate block">{config.interstitialAdUnitId}</span>
                <span className="text-[10px] text-emerald-300/80 mt-0.5 block">
                  Req: {diag.requestCounts.interstitial} • Impr: {diag.impressionCounts.interstitial}
                </span>
              </div>
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onTriggerTestAd('interstitial');
                }}
                className="px-3 py-1.5 rounded-xl bg-amber-500 text-stone-950 hover:bg-amber-400 text-xs font-bold transition shrink-0 cursor-pointer"
              >
                Test Interstitial
              </button>
            </div>

            {/* 4. Native Ad */}
            <div className="p-3 rounded-2xl bg-emerald-950/50 border border-emerald-800/40 flex items-center justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-bold text-amber-100">4. Native Advanced</span>
                  {getStatusBadge(diag.nativeStatus)}
                </div>
                <span className="text-[10px] font-mono text-stone-400 truncate block">{config.nativeAdUnitId}</span>
                <span className="text-[10px] text-emerald-300/80 mt-0.5 block">
                  Req: {diag.requestCounts.native} • Impr: {diag.impressionCounts.native}
                </span>
              </div>
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onTriggerTestAd('native');
                }}
                className="px-3 py-1.5 rounded-xl bg-emerald-900 border border-emerald-600/40 text-amber-300 hover:bg-emerald-800 text-xs font-bold transition shrink-0 cursor-pointer"
              >
                Preview Native
              </button>
            </div>

            {/* 5. Rewarded Ad */}
            <div className="p-3 rounded-2xl bg-emerald-950/50 border border-emerald-800/40 flex items-center justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-bold text-amber-100">5. Rewarded Video</span>
                  {getStatusBadge(diag.rewardedStatus)}
                </div>
                <span className="text-[10px] font-mono text-stone-400 truncate block">{config.rewardedAdUnitId}</span>
                <span className="text-[10px] text-emerald-300/80 mt-0.5 block">
                  Req: {diag.requestCounts.rewarded} • Impr: {diag.impressionCounts.rewarded} • Verified Rewards: {diag.rewardGrantedCount}
                </span>
              </div>
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onTriggerTestAd('rewarded');
                }}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-stone-950 hover:brightness-110 text-xs font-bold transition shrink-0 cursor-pointer"
              >
                Test Rewarded
              </button>
            </div>
          </div>

          {/* Error Log Console */}
          <div className="p-3 rounded-2xl bg-black/60 border border-emerald-800/40">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] text-stone-400 font-mono">LAST AD ERROR LOG</span>
              <button
                onClick={() => {
                  adMobService.resetDiagnostics();
                  refresh();
                }}
                className="text-[10px] text-stone-400 hover:text-amber-300 flex items-center gap-1 transition"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Counters</span>
              </button>
            </div>
            {diag.lastError ? (
              <div className="text-[11px] font-mono text-rose-300 bg-rose-950/40 p-2 rounded-lg border border-rose-500/30">
                <span className="text-stone-400">[{diag.lastError.timestamp}]</span> {diag.lastError.adType}: {diag.lastError.message}
              </div>
            ) : (
              <div className="text-[11px] font-mono text-emerald-400/90 bg-emerald-950/30 p-2 rounded-lg border border-emerald-800/30">
                ✓ No errors reported. Ad delivery pipelines operational.
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-5 flex gap-2">
          <button
            onClick={refresh}
            className="flex-1 py-2.5 rounded-xl bg-emerald-950/80 border border-emerald-700/40 text-stone-300 hover:text-white font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Diagnostics</span>
          </button>
          <button
            onClick={() => {
              soundService.playButtonClick();
              onClose();
            }}
            className="flex-1 py-2.5 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs hover:bg-amber-400 transition cursor-pointer"
          >
            Close Console
          </button>
        </div>
      </div>
    </div>
  );
};
