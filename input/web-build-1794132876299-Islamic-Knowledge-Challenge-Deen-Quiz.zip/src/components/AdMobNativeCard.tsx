import React from 'react';
import { Sparkles, ExternalLink, ShieldCheck, HeartHandshake } from 'lucide-react';
import { adMobService } from '../services/adMobService';

interface AdMobNativeCardProps {
  className?: string;
}

export const AdMobNativeCard: React.FC<AdMobNativeCardProps> = ({ className = '' }) => {
  const config = adMobService.getConfig();
  const mode = adMobService.getMode();

  return (
    <div className={`w-full rounded-2xl bg-gradient-to-br from-[#063a2a]/90 via-[#032419]/90 to-[#021811]/90 border border-amber-500/35 p-4 shadow-xl backdrop-blur-sm ${className}`}>
      {/* Top Meta: Sponsored Badge & Ad Unit */}
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-emerald-800/30">
        <div className="flex items-center gap-2">
          <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase tracking-wider font-mono">
            Sponsored Ad
          </span>
          <span className="text-[10px] text-emerald-300/80 font-medium">
            Google AdMob Native Advanced
          </span>
        </div>
        <span className="text-[9px] font-mono text-stone-400 truncate max-w-[150px]" title={config.nativeAdUnitId}>
          {config.nativeAdUnitId}
        </span>
      </div>

      {/* Content Layout */}
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 p-0.5 flex-shrink-0 shadow-md">
          <div className="w-full h-full rounded-[10px] bg-[#021c13] flex items-center justify-center text-amber-400">
            <HeartHandshake className="w-6 h-6" />
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <h4 className="font-bold text-sm text-amber-100 leading-snug">
            Muslim Relief & Islamic Education
          </h4>
          <p className="text-[11px] text-emerald-200/80 line-clamp-2 mt-0.5 leading-relaxed">
            Support authentic Islamic learning and humanitarian causes around the globe. Share barakah today.
          </p>
        </div>
      </div>

      {/* Call To Action */}
      <div className="mt-3 pt-2 flex items-center justify-between border-t border-emerald-800/20">
        <span className="text-[10px] text-stone-400 flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Verified Partner</span>
        </span>
        <button
          onClick={() => {
            // Simulated ad click interaction
          }}
          className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs transition shadow cursor-pointer flex items-center gap-1"
        >
          <span>Learn More</span>
          <ExternalLink className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
