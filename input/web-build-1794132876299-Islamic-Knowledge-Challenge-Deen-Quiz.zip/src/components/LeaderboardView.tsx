import React from 'react';
import { Award, Trophy, Star, Target, CheckCircle, Flame, ArrowLeft, BookOpen } from 'lucide-react';
import { UserStats, Language } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';
import { categories } from '../data/categories';

interface LeaderboardViewProps {
  stats: UserStats;
  language: Language;
  onBack: () => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  stats,
  language,
  onBack,
}) => {
  const t = translations[language];
  const isUrdu = language === 'ur';

  // Overall accuracy
  const overallAccuracy = stats.totalQuestionsAnswered > 0
    ? Math.round((stats.totalCorrectAnswers / stats.totalQuestionsAnswered) * 100)
    : 0;

  // Determine Islamic Knowledge Rank
  const getRank = () => {
    const completedLevels = Object.values(stats.levelProgress).filter(l => l.completed).length;
    if (completedLevels >= 16) {
      return { title: t.masterOfDeen, badge: "★★★★", tier: "Level 16–20", color: "text-amber-400" };
    } else if (completedLevels >= 11) {
      return { title: t.knowledgeableScholar, badge: "★★★", tier: "Level 11–15", color: "text-amber-300" };
    } else if (completedLevels >= 6) {
      return { title: t.seekerOfTruth, badge: "★★", tier: "Level 6–10", color: "text-emerald-300" };
    } else {
      return { title: t.studentOfKnowledge, badge: "★", tier: "Level 1–5", color: "text-emerald-200" };
    }
  };

  const rank = getRank();
  const totalStars = Object.values(stats.levelProgress).reduce((acc, curr) => acc + (curr.stars || 0), 0);

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-6 sm:py-8 flex flex-col animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => {
            soundService.playButtonClick();
            onBack();
          }}
          className="flex items-center gap-1.5 text-xs text-amber-300 hover:text-amber-100 px-3 py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-500/30 transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h2 className="text-xl sm:text-2xl font-extrabold text-amber-100">
          {t.leaderboard}
        </h2>

        <div className="w-16" />
      </div>

      {/* Honor Rank Crest Card */}
      <div className="rounded-3xl bg-gradient-to-b from-[#063e2c] to-[#022016] border border-amber-500/40 p-6 sm:p-7 text-center shadow-xl mb-6 relative overflow-hidden">
        <div className="w-16 h-16 rounded-full bg-amber-500/20 border border-amber-400/40 mx-auto flex items-center justify-center text-amber-300 mb-3 shadow-inner">
          <Trophy className="w-8 h-8 text-amber-400" />
        </div>

        <div className="text-[11px] font-bold text-amber-400/80 uppercase tracking-widest mb-1">
          {t.rankTitle}
        </div>
        <h3 className={`text-xl sm:text-2xl font-extrabold ${rank.color} mb-1 ${isUrdu ? 'font-urdu' : ''}`}>
          {rank.title}
        </h3>
        <span className="text-xs text-emerald-300/80 font-mono">
          {rank.tier} · {rank.badge}
        </span>
      </div>

      {/* Overview Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-600/30 text-center">
          <div className="text-[11px] text-emerald-300/80 font-semibold uppercase mb-1">
            {t.score}
          </div>
          <div className="text-xl font-extrabold text-amber-300 tabular-nums">
            {stats.totalScore}
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-600/30 text-center">
          <div className="text-[11px] text-emerald-300/80 font-semibold uppercase mb-1">
            {t.highScore}
          </div>
          <div className="text-xl font-extrabold text-amber-300 tabular-nums">
            {stats.highScore}
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-600/30 text-center">
          <div className="text-[11px] text-emerald-300/80 font-semibold uppercase mb-1">
            {t.accuracy}
          </div>
          <div className="text-xl font-extrabold text-emerald-300 tabular-nums">
            {overallAccuracy}%
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-600/30 text-center">
          <div className="text-[11px] text-emerald-300/80 font-semibold uppercase mb-1">
            {t.starsEarned}
          </div>
          <div className="text-xl font-extrabold text-amber-400 tabular-nums flex items-center justify-center gap-1">
            <Star className="w-4 h-4 fill-amber-400" />
            <span>{totalStars}</span>
          </div>
        </div>
      </div>

      {/* Additional Stats Breakdown */}
      <div className="rounded-2xl bg-emerald-950/40 border border-emerald-700/30 p-4 sm:p-5 mb-6">
        <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-3">
          {t.stats}
        </h4>

        <div className="space-y-2.5 text-xs">
          <div className="flex items-center justify-between py-1 border-b border-emerald-900/40">
            <span className="text-emerald-200">{t.totalQuizzes}:</span>
            <span className="font-bold text-amber-300 font-mono tabular-nums">{stats.totalQuizzesPlayed}</span>
          </div>

          <div className="flex items-center justify-between py-1 border-b border-emerald-900/40">
            <span className="text-emerald-200">{t.totalAnswered}:</span>
            <span className="font-bold text-amber-300 font-mono tabular-nums">{stats.totalQuestionsAnswered}</span>
          </div>

          <div className="flex items-center justify-between py-1 border-b border-emerald-900/40">
            <span className="text-emerald-200">{t.correctAnswers}:</span>
            <span className="font-bold text-emerald-400 font-mono tabular-nums">{stats.totalCorrectAnswers}</span>
          </div>

          <div className="flex items-center justify-between py-1">
            <span className="text-emerald-200">{t.dailyStreak} (Best):</span>
            <span className="font-bold text-amber-400 font-mono tabular-nums">{stats.bestStreak} {t.days}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
