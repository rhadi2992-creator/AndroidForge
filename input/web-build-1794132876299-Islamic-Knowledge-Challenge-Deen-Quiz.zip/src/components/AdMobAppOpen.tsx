import React, { useState, useEffect } from 'react';
import { X, Sparkles, BookOpen, Compass, ArrowRight } from 'lucide-react';
import { adMobService } from '../services/adMobService';
import { soundService } from '../services/soundService';

interface AdMobAppOpenProps {
  onDismiss: () => void;
}

export const AdMobAppOpen: React.FC<AdMobAppOpenProps> = ({ onDismiss }) => {
  const [countdown, setCountdown] = useState(4);
  const [canSkip, setCanSkip] = useState(false);
  const config = adMobService.getConfig();
  const mode = adMobService.getMode();

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          setCanSkip(true);
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleClose = () => {
    soundService.playButtonClick();
    adMobService.recordAppOpenShown();
    onDismiss();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-gradient-to-b from-[#052b1e] via-[#031d14] to-[#01140e] border border-amber-500/40 p-6 shadow-2xl text-amber-50 relative flex flex-col items-center text-center">
        {/* Top Header: AdMob Badge & Countdown */}
        <div className="w-full flex items-center justify-between pb-3 border-b border-emerald-800/40 mb-4">
          <div className="flex flex-col items-start text-left">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-amber-500/25 text-amber-300 border border-amber-500/40 uppercase font-mono tracking-wider">
                AdMob App Open Ad
              </span>
              <span className="text-[10px] text-stone-400">
                {mode === 'production' ? 'Production' : 'Test'}
              </span>
            </div>
            <span className="text-[9px] font-mono text-stone-400 truncate max-w-[200px]" title={config.appOpenAdUnitId}>
              {config.appOpenAdUnitId}
            </span>
          </div>

          {canSkip ? (
            <button
              onClick={handleClose}
              className="p-1 rounded-full bg-emerald-950/80 border border-amber-400/40 text-amber-300 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <span className="text-xs font-mono font-bold text-amber-400/90 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
              Skip in {countdown}s
            </span>
          )}
        </div>

        {/* Ad Body Hero */}
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 p-1 mb-3 shadow-xl flex items-center justify-center animate-pulse">
          <div className="w-full h-full rounded-[14px] bg-[#042017] flex items-center justify-center">
            <Compass className="w-10 h-10 text-amber-400" />
          </div>
        </div>

        <span className="text-[10px] text-amber-400/80 uppercase tracking-widest font-bold">
          Sponsored App
        </span>
        <h3 className="font-extrabold text-lg text-amber-100 mt-1 mb-2">
          Holy Quran & Daily Azkar
        </h3>
        <p className="text-xs text-emerald-200/80 mb-6 leading-relaxed">
          Recite the Holy Quran with authentic Urdu & English translation, Qibla compass, and prayer notifications.
        </p>

        {/* Action Button */}
        <div className="w-full">
          {canSkip ? (
            <button
              onClick={handleClose}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-stone-950 font-bold text-xs hover:scale-[1.02] active:scale-95 transition shadow-lg cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>Continue to Deen Quiz</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <div className="w-full py-2.5 rounded-xl bg-stone-900/70 border border-emerald-800/40 text-xs text-stone-400 font-mono">
              Loading quiz experience in {countdown}s...
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
