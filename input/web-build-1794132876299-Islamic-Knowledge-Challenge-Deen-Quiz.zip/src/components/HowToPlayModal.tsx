import React from 'react';
import { X, CheckCircle, HelpCircle, Flame, Star, ShieldCheck, Percent, Hourglass } from 'lucide-react';
import { Language } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';

interface HowToPlayModalProps {
  language: Language;
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({
  language,
  onClose,
}) => {
  const t = translations[language];
  const isUrdu = language === 'ur';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-lg max-h-[88vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-[#063e2c] to-[#022016] border border-amber-500/40 p-5 sm:p-7 shadow-2xl text-amber-50">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-emerald-800/40 mb-4">
          <div className="flex items-center gap-2 text-amber-400">
            <HelpCircle className="w-6 h-6" />
            <h3 className="font-extrabold text-lg sm:text-xl text-amber-100">
              {t.howToPlay}
            </h3>
          </div>
          <button
            onClick={() => {
              soundService.playButtonClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-emerald-950/60 border border-emerald-700/40 text-stone-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content sections */}
        <div className="space-y-4 text-xs sm:text-sm text-emerald-100/90 leading-relaxed" dir={isUrdu ? 'rtl' : 'ltr'}>
          {/* Section 1: Gameplay */}
          <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-amber-400" />
              {isUrdu ? "کوئز کے بنیادی اصول" : "1. Core Rules & Scoring"}
            </h4>
            <p className={isUrdu ? 'font-urdu' : ''}>
              {isUrdu
                ? "ہر سوال کے چار ممکنہ جوابات ہیں۔ درست جواب منتخب کرنے پر ۱۰ بنیادی پوائنٹس اور جلد جواب دینے پر اضافی وقت بونس ملتا ہے۔ غلط جواب پر منفی نمبر نہیں ہیں۔"
                : "Each question has 4 multiple-choice options. A correct answer yields +10 points plus a speed time bonus. Wrong answers have zero penalty."}
            </p>
          </div>

          {/* Section 2: Streak Multipliers */}
          <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
              {isUrdu ? "مسلسل درست جوابات کا بونس" : "2. Consecutive Streak Bonus"}
            </h4>
            <p className={isUrdu ? 'font-urdu' : ''}>
              {isUrdu
                ? "مسلسل درست جوابات دینے پر اسٹریک بونس بڑھتا جاتا ہے (+۲، +۴، +۶ پوائنٹس)۔ روزانہ کوئز کھیلنے سے روزانہ حاضری کا اسٹریک قائم رہتا ہے۔"
                : "Answering consecutive questions correctly activates a streak multiplier bonus (+2, +4, +6 extra points per streak)."}
            </p>
          </div>

          {/* Section 3: Lifelines */}
          <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <h4 className="font-bold text-amber-300 mb-1.5 flex items-center gap-2">
              <Percent className="w-4 h-4 text-amber-400" />
              {t.lifelines}
            </h4>
            <ul className="space-y-1.5 text-xs text-emerald-200/90">
              <li><strong>50:50:</strong> {isUrdu ? "دو غلط جوابات کو ختم کر دیتا ہے" : "Eliminates 2 incorrect choices."}</li>
              <li><strong>{t.hint}:</strong> {isUrdu ? "قرآنی یا حدیثی پس منظر کا اشارہ دیتا ہے" : "Reveals authentic context to assist your decision."}</li>
              <li><strong>+15s:</strong> {isUrdu ? "سوچنے کے لیے پندرہ سیکنڈ کا اضافی وقت" : "Adds 15 seconds to the timer."}</li>
            </ul>
          </div>

          {/* Section 4: 20 Levels */}
          <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-2">
              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
              {isUrdu ? "۲۰ درجات (لیولز) کا نظام" : "4. 20 Level Unlock System"}
            </h4>
            <p className={isUrdu ? 'font-urdu' : ''}>
              {isUrdu
                ? "لیول ۱ سے آغاز کریں اور ۷۰ فیصد یا زائد نمبر حاصل کر کے اگلا لیول کھولیں۔ کارکردگی کے مطابق ۱ تا ۳ ستارے حاصل کریں۔"
                : "Pass each level with 70%+ score to unlock the next level and earn up to 3 stars per level."}
            </p>
          </div>

          {/* Section 5: Authentic Sources */}
          <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/30">
            <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              {isUrdu ? "مستند اسلامی ذرائع" : "5. Verified Authentic Knowledge"}
            </h4>
            <p className={`text-xs text-amber-100/90 ${isUrdu ? 'font-urdu' : ''}`}>
              {t.rulesDisclaimer}
            </p>
          </div>
        </div>

        {/* Close Button */}
        <button
          onClick={() => {
            soundService.playButtonClick();
            onClose();
          }}
          className="mt-5 w-full py-2.5 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs hover:bg-amber-400 transition cursor-pointer"
        >
          {t.close}
        </button>
      </div>
    </div>
  );
};
