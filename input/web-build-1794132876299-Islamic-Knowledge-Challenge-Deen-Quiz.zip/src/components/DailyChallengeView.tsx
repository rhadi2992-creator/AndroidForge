import React from 'react';
import { Calendar, Flame, Award, Play, CheckCircle2, ArrowLeft, Sparkles, Gift } from 'lucide-react';
import { Language, UserStats } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';

interface DailyChallengeViewProps {
  language: Language;
  stats: UserStats;
  onStartDailyQuiz: () => void;
  onBack: () => void;
}

export const DailyChallengeView: React.FC<DailyChallengeViewProps> = ({
  language,
  stats,
  onStartDailyQuiz,
  onBack,
}) => {
  const t = translations[language];
  const isUrdu = language === 'ur';

  const today = new Date().toISOString().split('T')[0];
  const todayRecord = stats.dailyHistory[today];
  const isCompletedToday = !!todayRecord && todayRecord.completed;

  // Format today's date in Gregorian and approximate Hijri
  const dateFormatted = new Date().toLocaleDateString(language === 'ur' ? 'ur-PK' : 'en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-6 sm:py-8 flex flex-col items-center animate-fade-in">
      {/* Header */}
      <div className="w-full flex items-center justify-between mb-6">
        <button
          onClick={() => {
            soundService.playButtonClick();
            onBack();
          }}
          className="flex items-center gap-1.5 text-xs text-amber-300 hover:text-amber-100 px-3 py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-500/30 transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h2 className="text-xl sm:text-2xl font-extrabold text-amber-100">
          {t.dailyChallenge}
        </h2>

        <div className="w-16" />
      </div>

      {/* Date & Streak Card */}
      <div className="w-full rounded-3xl bg-gradient-to-b from-[#063e2c] to-[#021f15] border border-amber-500/40 p-6 sm:p-8 text-center shadow-2xl relative overflow-hidden mb-6">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Calendar className="w-40 h-40 text-amber-400" />
        </div>

        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold mb-3">
          <Calendar className="w-4 h-4 text-amber-400" />
          <span>{dateFormatted}</span>
        </div>

        <h3 className="text-2xl sm:text-3xl font-extrabold text-amber-100 mb-2">
          {isUrdu ? "آج کا ایمانی چیلنج" : "Today's Islamic Quest"}
        </h3>
        <p className="text-xs sm:text-sm text-emerald-200/80 max-w-md mx-auto mb-6">
          {isUrdu
            ? "قرآن، حدیث، سیرت اور تاریخ سے چنے گئے ۱۰ منفرد سوالات جو روزانہ تبدیل ہوتے ہیں"
            : "10 handpicked questions covering Quran, Hadith, Seerat, and Islamic heritage that refresh every single day."}
        </p>

        {/* Streak Stats */}
        <div className="grid grid-cols-2 gap-3 max-w-sm mx-auto mb-6">
          <div className="p-3 rounded-2xl bg-emerald-950/70 border border-emerald-600/30 text-center">
            <div className="flex items-center justify-center gap-1.5 text-amber-400 mb-1">
              <Flame className="w-4 h-4 fill-amber-400" />
              <span className="text-xs font-bold uppercase">{t.dailyStreak}</span>
            </div>
            <div className="text-xl font-extrabold text-amber-200 tabular-nums">
              {stats.currentStreak} {t.days}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-emerald-950/70 border border-emerald-600/30 text-center">
            <div className="flex items-center justify-center gap-1.5 text-emerald-400 mb-1">
              <Sparkles className="w-4 h-4" />
              <span className="text-xs font-bold uppercase">Daily Bonus</span>
            </div>
            <div className="text-xl font-extrabold text-emerald-200 tabular-nums">
              +50 Noor Pts
            </div>
          </div>
        </div>

        {/* Start / Completed Button */}
        {isCompletedToday ? (
          <div className="flex flex-col items-center gap-2">
            <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-emerald-600/30 border border-emerald-400 text-emerald-200 font-bold text-sm">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span>{t.todayChallengeCompleted}</span>
            </div>
            <span className="text-xs text-amber-300/80 font-mono">
              Score: {todayRecord.score} pts ({todayRecord.accuracy}%)
            </span>
          </div>
        ) : (
          <button
            onClick={() => {
              soundService.playButtonClick();
              onStartDailyQuiz();
            }}
            className="w-full max-w-sm py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-stone-950 font-extrabold text-base flex items-center justify-center gap-2.5 shadow-xl shadow-amber-950/50 hover:scale-[1.02] active:scale-95 transition cursor-pointer"
          >
            <Play className="w-5 h-5 fill-stone-950" />
            <span>{t.startDailyChallenge}</span>
          </button>
        )}
      </div>
    </div>
  );
};
