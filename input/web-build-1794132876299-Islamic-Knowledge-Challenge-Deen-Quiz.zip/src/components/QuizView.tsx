import React, { useState, useEffect, useRef } from 'react';
import {
  Clock,
  Sparkles,
  Flame,
  CheckCircle,
  XCircle,
  BookOpen,
  ArrowRight,
  HelpCircle,
  Hourglass,
  Percent,
  Play,
  RotateCcw
} from 'lucide-react';
import { Question, Language, GameMode, QuizSummary, QuizQuestionResult } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';
import { storageService } from '../services/storageService';

interface QuizViewProps {
  questions: Question[];
  language: Language;
  mode: GameMode;
  categoryTitle?: string;
  levelNumber?: number;
  onFinishQuiz: (summary: QuizSummary) => void;
  onExitQuiz: () => void;
  onWatchAdForLifeline: (type: 'fiftyFifty' | 'hint' | 'extraTime') => void;
}

export const QuizView: React.FC<QuizViewProps> = ({
  questions,
  language,
  mode,
  categoryTitle,
  levelNumber,
  onFinishQuiz,
  onExitQuiz,
  onWatchAdForLifeline,
}) => {
  const t = translations[language];
  const isUrdu = language === 'ur';

  // State
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [consecutiveStreak, setConsecutiveStreak] = useState(0);
  const [timeLeft, setTimeLeft] = useState(25); // 25 seconds per question
  const [timerActive, setTimerActive] = useState(true);
  const [quizResults, setQuizResults] = useState<QuizQuestionResult[]>([]);
  const [timeSpentTotal, setTimeSpentTotal] = useState(0);

  // Lifelines state
  const [eliminatedOptions, setEliminatedOptions] = useState<number[]>([]);
  const [showHintModal, setShowHintModal] = useState(false);
  const [availableLifelines, setAvailableLifelines] = useState(storageService.getStats().lifelines);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const currentQuestion = questions[currentIndex];

  // Refresh lifelines count from storage
  useEffect(() => {
    setAvailableLifelines(storageService.getStats().lifelines);
  }, []);

  // Timer effect
  useEffect(() => {
    if (!timerActive || isAnswered) return;

    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          handleTimeOut();
          return 0;
        }
        return prev - 1;
      });
      setTimeSpentTotal(t => t + 1);
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timerActive, isAnswered, currentIndex]);

  // Handle Timeout
  const handleTimeOut = () => {
    if (isAnswered) return;
    setIsAnswered(true);
    setTimerActive(false);
    setSelectedOption(null);
    setConsecutiveStreak(0);
    soundService.playIncorrect();
    soundService.duckAudio();

    const result: QuizQuestionResult = {
      question: currentQuestion,
      selectedOption: null,
      isCorrect: false,
      timeSpentSeconds: 25,
      pointsEarned: 0
    };
    setQuizResults(prev => [...prev, result]);
  };

  // Handle Answer Selection
  const handleSelectOption = (index: number) => {
    if (isAnswered || eliminatedOptions.includes(index)) return;

    if (timerRef.current) clearInterval(timerRef.current);
    setIsAnswered(true);
    setTimerActive(false);
    setSelectedOption(index);

    const isCorrect = index === currentQuestion.correctAnswer;
    const timeBonus = Math.max(0, Math.floor(timeLeft / 5)); // up to +5 points for quick speed
    const streakBonus = consecutiveStreak >= 2 ? (consecutiveStreak * 2) : 0;
    const pointsEarned = isCorrect ? (10 + timeBonus + streakBonus) : 0;

    if (isCorrect) {
      soundService.playCorrect();
      setScore(prev => prev + pointsEarned);
      setConsecutiveStreak(prev => prev + 1);
    } else {
      soundService.playIncorrect();
      setConsecutiveStreak(0);
    }

    // Lower background music during answer feedback review
    soundService.duckAudio();

    const result: QuizQuestionResult = {
      question: currentQuestion,
      selectedOption: index,
      isCorrect,
      timeSpentSeconds: 25 - timeLeft,
      pointsEarned
    };
    setQuizResults(prev => [...prev, result]);
  };

  // Next Question or Finish
  const handleNext = () => {
    soundService.playButtonClick();
    soundService.unduckAudio();

    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
      setTimeLeft(25);
      setTimerActive(true);
      setEliminatedOptions([]);
    } else {
      // Quiz complete!
      const correctCount = quizResults.filter(r => r.isCorrect).length;
      const totalQ = questions.length;
      const accuracy = Math.round((correctCount / totalQ) * 100);

      let stars = 0;
      if (accuracy >= 90) stars = 3;
      else if (accuracy >= 70) stars = 2;
      else if (accuracy >= 50) stars = 1;

      const summary: QuizSummary = {
        mode,
        categoryTitle,
        levelNumber,
        totalQuestions: totalQ,
        correctCount,
        incorrectCount: totalQ - correctCount,
        totalScore: score,
        accuracyPercentage: accuracy,
        starsEarned: stars,
        timeSpentSeconds: timeSpentTotal,
        results: quizResults
      };

      onFinishQuiz(summary);
    }
  };

  // Lifeline: 50-50
  const handleUse5050 = () => {
    if (isAnswered || eliminatedOptions.length > 0) return;
    if (availableLifelines.fiftyFifty <= 0) {
      onWatchAdForLifeline('fiftyFifty');
      return;
    }

    soundService.playButtonClick();
    storageService.useLifeline('fiftyFifty');
    setAvailableLifelines(storageService.getStats().lifelines);

    const wrongIndexes = [0, 1, 2, 3].filter(idx => idx !== currentQuestion.correctAnswer);
    // Shuffle and pick 2 to eliminate
    const shuffledWrong = wrongIndexes.sort(() => Math.random() - 0.5);
    setEliminatedOptions([shuffledWrong[0], shuffledWrong[1]]);
  };

  // Lifeline: Hint
  const handleUseHint = () => {
    if (isAnswered) return;
    if (availableLifelines.hint <= 0) {
      onWatchAdForLifeline('hint');
      return;
    }

    soundService.playButtonClick();
    storageService.useLifeline('hint');
    setAvailableLifelines(storageService.getStats().lifelines);
    setShowHintModal(true);
  };

  // Lifeline: Extra Time (+15s)
  const handleUseExtraTime = () => {
    if (isAnswered) return;
    if (availableLifelines.extraTime <= 0) {
      onWatchAdForLifeline('extraTime');
      return;
    }

    soundService.playButtonClick();
    storageService.useLifeline('extraTime');
    setAvailableLifelines(storageService.getStats().lifelines);
    setTimeLeft(prev => prev + 15);
  };

  // Progress percentage
  const progressPercent = Math.round(((currentIndex + (isAnswered ? 1 : 0)) / questions.length) * 100);

  // Option letters
  const optionLetters = isUrdu ? ['۱', '۲', '۳', '۴'] : ['A', 'B', 'C', 'D'];

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-4 sm:py-6 flex flex-col">
      {/* Top Header Bar: Mode Badge, Progress, Timer, Score */}
      <div className="flex items-center justify-between gap-3 mb-4">
        {/* Category / Level Name */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              soundService.playButtonClick();
              soundService.unduckAudio();
              onExitQuiz();
            }}
            className="text-xs text-amber-300 hover:text-amber-100 px-2 py-1 rounded-lg bg-emerald-950/60 border border-emerald-500/20 transition cursor-pointer"
          >
            ← {t.back}
          </button>
          <span className="text-xs font-semibold text-amber-200 truncate max-w-[150px] sm:max-w-xs">
            {categoryTitle || (levelNumber ? `${t.levelTitle} ${levelNumber}` : t.quickPlay)}
          </span>
        </div>

        {/* Timer, Streak & Score HUD */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Consecutive Streak Flame */}
          {consecutiveStreak >= 2 && (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-bold animate-bounce">
              <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>+{consecutiveStreak * 2}</span>
            </div>
          )}

          {/* Countdown Timer */}
          <div
            className={`flex items-center gap-1 px-2.5 py-1 rounded-xl border text-xs font-bold tabular-nums transition-colors ${
              timeLeft <= 5
                ? 'bg-rose-950/80 border-rose-500/50 text-rose-300 animate-pulse'
                : 'bg-emerald-950/70 border-emerald-500/30 text-amber-300'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{timeLeft}s</span>
          </div>

          {/* Score */}
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-950/60 border border-amber-500/40 text-amber-300 text-xs font-bold tabular-nums">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{score}</span>
          </div>
        </div>
      </div>

      {/* Progress Bar & Question Counter */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-xs text-emerald-300/80 mb-1.5 font-medium">
          <span>
            {t.question} {currentIndex + 1} {t.of} {questions.length}
          </span>
          <span className="capitalize text-amber-400/90 font-semibold">
            {t[currentQuestion.difficulty] || currentQuestion.difficulty}
          </span>
        </div>
        <div className="w-full h-2 rounded-full bg-emerald-950/80 border border-emerald-800/40 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-amber-400 via-amber-500 to-emerald-400 transition-all duration-300 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Main Question Card */}
      <div className="relative rounded-3xl bg-gradient-to-b from-[#063324] to-[#032016] border border-amber-500/30 p-5 sm:p-7 shadow-2xl backdrop-blur-md mb-4 sm:mb-6">
        {/* Subtle Islamic corner watermark */}
        <div className="absolute top-2 right-3 text-amber-400/10 text-3xl font-serif pointer-events-none">
          ☪
        </div>

        <h3
          className={`text-base sm:text-xl font-bold text-amber-50 leading-relaxed ${
            isUrdu ? 'font-urdu text-right leading-loose' : 'text-left'
          }`}
          dir={isUrdu ? 'rtl' : 'ltr'}
        >
          {currentQuestion.question[language] || currentQuestion.question.en}
        </h3>
      </div>

      {/* Four Multiple-Choice Options */}
      <div className="grid grid-cols-1 gap-2.5 sm:gap-3 mb-4">
        {currentQuestion.options[language]?.map((optionText, idx) => {
          const isCorrect = idx === currentQuestion.correctAnswer;
          const isSelected = selectedOption === idx;
          const isEliminated = eliminatedOptions.includes(idx);

          // State styling
          let buttonStyle = 'bg-emerald-950/50 border-emerald-700/30 text-amber-100 hover:border-amber-400/40 hover:bg-emerald-900/40';

          if (isAnswered) {
            if (isCorrect) {
              buttonStyle = 'bg-emerald-600/30 border-emerald-400 text-emerald-100 shadow-md shadow-emerald-900/40 font-bold';
            } else if (isSelected && !isCorrect) {
              buttonStyle = 'bg-rose-950/60 border-rose-500/80 text-rose-200';
            } else {
              buttonStyle = 'opacity-40 border-stone-800 text-stone-400';
            }
          } else if (isEliminated) {
            buttonStyle = 'opacity-20 pointer-events-none line-through border-transparent text-stone-600';
          }

          return (
            <button
              key={idx}
              disabled={isAnswered || isEliminated}
              onClick={() => handleSelectOption(idx)}
              className={`w-full p-3.5 sm:p-4 rounded-2xl border transition-all duration-200 flex items-center justify-between text-left cursor-pointer active:scale-[0.99] ${buttonStyle}`}
              dir={isUrdu ? 'rtl' : 'ltr'}
            >
              <div className="flex items-center gap-3 w-full">
                {/* Letter Index Badge */}
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                    isAnswered && isCorrect
                      ? 'bg-emerald-500 text-stone-950'
                      : isAnswered && isSelected
                      ? 'bg-rose-500 text-stone-950'
                      : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {optionLetters[idx]}
                </div>

                {/* Option Text */}
                <span className={`text-sm sm:text-base flex-1 ${isUrdu ? 'font-urdu text-right' : 'text-left'}`}>
                  {optionText}
                </span>

                {/* Feedback Icons */}
                {isAnswered && isCorrect && (
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                )}
                {isAnswered && isSelected && !isCorrect && (
                  <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Answer Feedback & Authentic Islamic Reference Box */}
      {isAnswered && (
        <div className="rounded-2xl bg-gradient-to-r from-emerald-950/90 via-emerald-900/90 to-emerald-950/90 border border-amber-400/40 p-4 mb-4 shadow-xl animate-fade-in">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div className="flex-1" dir={isUrdu ? 'rtl' : 'ltr'}>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  {t.reference}:
                </span>
                <span className="text-xs font-semibold text-amber-100">
                  {currentQuestion.reference[language] || currentQuestion.reference.en}
                </span>
              </div>
              <p className={`text-xs text-emerald-100/90 leading-relaxed ${isUrdu ? 'font-urdu text-right' : 'text-left'}`}>
                {currentQuestion.explanation[language] || currentQuestion.explanation.en}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Lifelines Toolbar & Next Button */}
      <div className="flex items-center justify-between gap-3 pt-2">
        {/* Lifelines (disabled after answer is selected) */}
        <div className="flex items-center gap-2">
          {/* 50:50 Lifeline */}
          <button
            disabled={isAnswered || eliminatedOptions.length > 0}
            onClick={handleUse5050}
            title={availableLifelines.fiftyFifty > 0 ? t.fiftyFifty : t.watchAdForHint}
            className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
              availableLifelines.fiftyFifty > 0
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 hover:bg-amber-500/25 active:scale-95'
                : 'bg-emerald-950/40 border-emerald-800/40 text-amber-400/80 hover:bg-amber-500/15'
            } ${isAnswered ? 'opacity-30 pointer-events-none' : ''}`}
          >
            <Percent className="w-3.5 h-3.5" />
            <span>50:50</span>
            <span className="text-[10px] opacity-75 font-mono">({availableLifelines.fiftyFifty})</span>
          </button>

          {/* Context Hint */}
          <button
            disabled={isAnswered}
            onClick={handleUseHint}
            title={availableLifelines.hint > 0 ? t.hint : t.watchAdForHint}
            className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
              availableLifelines.hint > 0
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 hover:bg-amber-500/25 active:scale-95'
                : 'bg-emerald-950/40 border-emerald-800/40 text-amber-400/80 hover:bg-amber-500/15'
            } ${isAnswered ? 'opacity-30 pointer-events-none' : ''}`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>{t.hint}</span>
            <span className="text-[10px] opacity-75 font-mono">({availableLifelines.hint})</span>
          </button>

          {/* Extra Time (+15s) */}
          <button
            disabled={isAnswered}
            onClick={handleUseExtraTime}
            title={availableLifelines.extraTime > 0 ? t.extraTime : t.watchAdForHint}
            className={`hidden sm:flex px-3 py-2 rounded-xl border text-xs font-bold items-center gap-1.5 transition cursor-pointer ${
              availableLifelines.extraTime > 0
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 hover:bg-amber-500/25 active:scale-95'
                : 'bg-emerald-950/40 border-emerald-800/40 text-amber-400/80 hover:bg-amber-500/15'
            } ${isAnswered ? 'opacity-30 pointer-events-none' : ''}`}
          >
            <Hourglass className="w-3.5 h-3.5" />
            <span>+15s</span>
            <span className="text-[10px] opacity-75 font-mono">({availableLifelines.extraTime})</span>
          </button>
        </div>

        {/* Next Question Button */}
        {isAnswered && (
          <button
            onClick={handleNext}
            className="px-5 sm:px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-stone-950 font-bold text-sm flex items-center gap-2 shadow-lg shadow-amber-900/40 hover:scale-105 active:scale-95 transition cursor-pointer"
          >
            <span>{currentIndex + 1 < questions.length ? t.nextQuestion : t.finishQuiz}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Hint Modal */}
      {showHintModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm rounded-2xl bg-gradient-to-b from-[#063e2c] to-[#022016] border border-amber-400/40 p-5 shadow-2xl">
            <div className="flex items-center gap-2 mb-3 text-amber-400">
              <HelpCircle className="w-5 h-5" />
              <h4 className="font-bold text-base text-amber-100">
                {t.hint}
              </h4>
            </div>
            <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed mb-4" dir={isUrdu ? 'rtl' : 'ltr'}>
              {currentQuestion.explanation[language] || currentQuestion.explanation.en}
            </p>
            <button
              onClick={() => setShowHintModal(false)}
              className="w-full py-2 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs hover:bg-amber-400 transition cursor-pointer"
            >
              {t.close}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
