import React, { useState } from 'react';
import {
  Play,
  Calendar,
  Layers,
  Award,
  BookOpen,
  HelpCircle,
  Settings,
  Sparkles,
  Flame,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
  Gift,
  Download
} from 'lucide-react';
import { Language, UserStats } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';
import { storageService } from '../services/storageService';
import { AdMobNativeCard } from './AdMobNativeCard';
import confetti from 'canvas-confetti';

interface HomeScreenProps {
  language: Language;
  stats: UserStats;
  onStartQuickPlay: () => void;
  onOpenDailyChallenge: () => void;
  onOpenLevels: () => void;
  onOpenCategories: () => void;
  onOpenLeaderboard: () => void;
  onOpenHowToPlay: () => void;
  onOpenSettings: () => void;
  onOpenApkGuide: () => void;
  onOpenDownloadProject?: () => void;
  onStatsUpdated: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  language,
  stats,
  onStartQuickPlay,
  onOpenDailyChallenge,
  onOpenLevels,
  onOpenCategories,
  onOpenLeaderboard,
  onOpenHowToPlay,
  onOpenSettings,
  onOpenApkGuide,
  onOpenDownloadProject,
  onStatsUpdated,
}) => {
  const t = translations[language];
  const isUrdu = language === 'ur';

  // Check if daily reward can be claimed today
  const today = new Date().toISOString().split('T')[0];
  const lastRewardDate = localStorage.getItem('deen_quiz_last_daily_bonus_date');
  const canClaimDailyReward = lastRewardDate !== today;
  const [claimedReward, setClaimedReward] = useState(!canClaimDailyReward);

  const handleClaimDailyReward = () => {
    soundService.playDailyReward();
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#fbbf24', '#f59e0b', '#10b981', '#34d399']
    });
    localStorage.setItem('deen_quiz_last_daily_bonus_date', today);
    storageService.saveStats({ coins: stats.coins + 25 });
    storageService.addLifelines('fiftyFifty', 1);
    setClaimedReward(true);
    onStatsUpdated();
  };

  // Calculate completed levels
  const completedLevelsCount = Object.values(stats.levelProgress).filter(l => l.completed).length;

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6 sm:py-8 flex flex-col items-center">
      {/* Bismillah Islamic Calligraphy Header */}
      <div className="text-center mb-4 sm:mb-6 animate-fade-in">
        <p className="font-amiri text-lg sm:text-2xl text-amber-300/90 tracking-wide select-none">
          بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
        </p>
        <p className="text-[11px] sm:text-xs text-emerald-300/70 mt-0.5">
          {t.bismillah}
        </p>
      </div>

      {/* Main Game Brand Emblem & Title */}
      <div className="flex flex-col items-center text-center mb-6 sm:mb-8">
        <div className="relative mb-3 group cursor-pointer" onClick={onStartQuickPlay}>
          {/* Glowing Aura Ring */}
          <div className="absolute -inset-2 bg-gradient-to-r from-amber-500/20 via-emerald-500/30 to-amber-500/20 rounded-full blur-xl animate-pulse" />

          {/* Central Golden Emblem */}
          <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 p-1 shadow-2xl shadow-amber-950/60 transform group-hover:scale-105 transition-transform duration-300">
            <div className="w-full h-full rounded-full bg-gradient-to-b from-[#063e2c] to-[#021c13] flex flex-col items-center justify-center border border-amber-400/40">
              <span className="text-3xl sm:text-4xl text-amber-300 drop-shadow-md">☪</span>
              <span className="text-[9px] font-bold text-amber-200 tracking-widest uppercase mt-0.5 font-cinzel">
                DEEN
              </span>
            </div>
          </div>
        </div>

        <h1 className="text-2xl sm:text-4xl font-extrabold text-amber-100 tracking-tight leading-tight">
          {t.appName}
        </h1>
        <div className="flex items-center gap-2 mt-1">
          <span className="h-[1px] w-6 bg-amber-500/50" />
          <h2 className="text-sm sm:text-lg font-bold text-amber-400 tracking-wider font-cinzel uppercase">
            {t.appSubtitle}
          </h2>
          <span className="h-[1px] w-6 bg-amber-500/50" />
        </div>
        <p className="text-xs sm:text-sm text-emerald-200/80 max-w-md mt-1.5 px-2">
          {t.tagline}
        </p>
      </div>

      {/* Daily Streak & Bonus Card */}
      <div className="w-full max-w-lg mb-6 bg-gradient-to-r from-amber-950/40 via-emerald-950/50 to-amber-950/40 border border-amber-500/30 rounded-2xl p-4 shadow-lg backdrop-blur-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
              <Flame className="w-6 h-6 text-amber-400 fill-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-amber-300 uppercase tracking-wider">
                  {t.dailyStreak}
                </span>
                <span className="text-xs text-emerald-300 font-bold">
                  {stats.currentStreak} {t.days}
                </span>
              </div>
              <p className="text-[11px] text-emerald-200/70">
                {stats.highScore > 0 ? `${t.highScore}: ${stats.highScore}` : "Start your Islamic learning journey"}
              </p>
            </div>
          </div>

          {!claimedReward ? (
            <button
              onClick={handleClaimDailyReward}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-stone-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-900/40 hover:scale-105 active:scale-95 transition cursor-pointer"
            >
              <Gift className="w-4 h-4" />
              <span>{t.claimDailyReward}</span>
            </button>
          ) : (
            <div className="flex items-center gap-1 text-emerald-400 text-xs font-medium px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-500/20">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Claimed</span>
            </div>
          )}
        </div>
      </div>

      {/* Primary Action Buttons Hub */}
      <div className="w-full max-w-lg flex flex-col gap-3 sm:gap-3.5">
        {/* DOWNLOAD COMPLETE PROJECT ZIP BUTTON (User Request) */}
        {onOpenDownloadProject && (
          <button
            onClick={() => {
              soundService.playButtonClick();
              onOpenDownloadProject();
            }}
            className="group w-full relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-800 via-teal-700 to-emerald-900 border-2 border-amber-400/70 p-3.5 sm:p-4 flex items-center justify-between text-amber-50 hover:border-amber-300 hover:scale-[1.01] active:scale-[0.98] transition-all shadow-xl shadow-emerald-950/70 cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-stone-950 flex items-center justify-center font-bold shadow-md shrink-0">
                <Download className="w-6 h-6 text-stone-950 group-hover:translate-y-0.5 transition-transform" />
              </div>
              <div className="text-left">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-sm sm:text-base text-amber-200 group-hover:text-amber-100">
                    Download Complete Project ZIP
                  </span>
                  <span className="text-[10px] bg-amber-400 text-stone-950 font-black px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                    15 MB
                  </span>
                </div>
                <div className="text-[11px] sm:text-xs text-emerald-200/90 font-medium mt-0.5">
                  Source Code • Naat Audio • AdMob • Android Files
                </div>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-amber-300 group-hover:translate-x-1 transition-transform shrink-0" />
          </button>
        )}

        {/* Play Quiz (Quick Play) */}
        <button
          onClick={() => {
            soundService.playButtonClick();
            onStartQuickPlay();
          }}
          className="group w-full relative overflow-hidden rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 p-0.5 shadow-xl shadow-amber-950/40 hover:shadow-amber-500/20 transition-all duration-300 active:scale-[0.98] cursor-pointer"
        >
          <div className="w-full h-full py-4 px-5 rounded-[15px] bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 flex items-center justify-between text-stone-950">
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-stone-950/15 flex items-center justify-center">
                <Play className="w-6 h-6 text-stone-950 fill-stone-950 translate-x-0.5" />
              </div>
              <div className="text-left">
                <div className="font-extrabold text-lg sm:text-xl tracking-wide">
                  {t.playQuiz}
                </div>
                <div className="text-xs font-medium text-stone-900/80">
                  {isUrdu ? "فوری ۱۰ سوالات کا جامع ٹیسٹ" : "10 Quick Mixed Questions"}
                </div>
              </div>
            </div>
            <ChevronRight className="w-6 h-6 text-stone-950/70 group-hover:translate-x-1 transition-transform" />
          </div>
        </button>

        {/* Daily Islamic Challenge Button */}
        <button
          onClick={() => {
            soundService.playButtonClick();
            onOpenDailyChallenge();
          }}
          className="group w-full rounded-2xl bg-gradient-to-r from-emerald-900/80 via-emerald-800/80 to-teal-900/80 border border-emerald-500/40 p-4 flex items-center justify-between text-amber-50 hover:border-amber-400/50 hover:bg-emerald-800/90 transition shadow-lg active:scale-[0.98] cursor-pointer"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-amber-400/15 border border-amber-400/30 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-amber-300" />
            </div>
            <div className="text-left">
              <div className="font-bold text-base sm:text-lg text-amber-100 group-hover:text-amber-200">
                {t.dailyChallenge}
              </div>
              <div className="text-xs text-emerald-300/80">
                {isUrdu ? "آج کے ۱۰ مخصوص سوالات و بونس" : "Today's Curated 10 Questions"}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-amber-400 font-semibold bg-amber-500/15 px-2.5 py-0.5 rounded-full border border-amber-500/30">
              +25 Bonus
            </span>
            <ChevronRight className="w-5 h-5 text-emerald-400 group-hover:translate-x-1 transition-transform" />
          </div>
        </button>

        {/* 20 Unlockable Levels Mode */}
        <button
          onClick={() => {
            soundService.playButtonClick();
            onOpenLevels();
          }}
          className="group w-full rounded-2xl bg-gradient-to-r from-stone-900/90 via-emerald-950/90 to-stone-900/90 border border-amber-500/30 p-4 flex items-center justify-between text-amber-50 hover:border-amber-400/50 transition shadow-lg active:scale-[0.98] cursor-pointer"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center">
              <Layers className="w-5 h-5 text-amber-400" />
            </div>
            <div className="text-left">
              <div className="font-bold text-base sm:text-lg text-amber-100 group-hover:text-amber-200">
                {t.levels}
              </div>
              <div className="text-xs text-emerald-300/80">
                {isUrdu ? `مکمل شدہ: ${completedLevelsCount} از ۲۰ لیولز` : `${completedLevelsCount} of 20 Levels Completed`}
              </div>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-amber-400/70 group-hover:translate-x-1 transition-transform" />
        </button>

        {/* Categories Explorer (10 categories) */}
        <button
          onClick={() => {
            soundService.playButtonClick();
            onOpenCategories();
          }}
          className="group w-full rounded-2xl bg-emerald-950/60 border border-emerald-600/30 p-4 flex items-center justify-between text-amber-50 hover:border-amber-400/40 hover:bg-emerald-900/40 transition active:scale-[0.98] cursor-pointer"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-emerald-300" />
            </div>
            <div className="text-left">
              <div className="font-bold text-base sm:text-lg text-amber-100 group-hover:text-amber-200">
                {t.categories}
              </div>
              <div className="text-xs text-emerald-300/80">
                {isUrdu ? "۱۰ موضوعات: قرآن، حدیث، سیرت، تاریخ" : "10 Authentic Knowledge Domains"}
              </div>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-emerald-400/70 group-hover:translate-x-1 transition-transform" />
        </button>

        {/* Native Ad Placement: Home Screen (Requirement #7) */}
        <div className="pt-1">
          <AdMobNativeCard />
        </div>

        {/* Secondary Grid (Leaderboard, How to Play, Settings) */}
        <div className="grid grid-cols-3 gap-2.5 pt-1">
          {/* Leaderboard / Rank */}
          <button
            onClick={() => {
              soundService.playButtonClick();
              onOpenLeaderboard();
            }}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-emerald-950/50 border border-emerald-700/30 hover:border-amber-400/40 hover:bg-emerald-900/40 transition active:scale-95 cursor-pointer text-center"
          >
            <Award className="w-5 h-5 text-amber-400 mb-1" />
            <span className="text-xs font-semibold text-amber-200">
              {t.leaderboard}
            </span>
          </button>

          {/* How to Play */}
          <button
            onClick={() => {
              soundService.playButtonClick();
              onOpenHowToPlay();
            }}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-emerald-950/50 border border-emerald-700/30 hover:border-amber-400/40 hover:bg-emerald-900/40 transition active:scale-95 cursor-pointer text-center"
          >
            <HelpCircle className="w-5 h-5 text-emerald-300 mb-1" />
            <span className="text-xs font-semibold text-amber-200">
              {t.howToPlay}
            </span>
          </button>

          {/* Settings */}
          <button
            onClick={() => {
              soundService.playButtonClick();
              onOpenSettings();
            }}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-emerald-950/50 border border-emerald-700/30 hover:border-amber-400/40 hover:bg-emerald-900/40 transition active:scale-95 cursor-pointer text-center"
          >
            <Settings className="w-5 h-5 text-amber-300 mb-1" />
            <span className="text-xs font-semibold text-amber-200">
              {t.settings}
            </span>
          </button>
        </div>

        {/* Android APK & AdMob Integration Info button */}
        <button
          onClick={() => {
            soundService.playButtonClick();
            onOpenApkGuide();
          }}
          className="mt-2 text-[11px] text-amber-400/80 hover:text-amber-300 underline underline-offset-4 flex items-center justify-center gap-1.5 transition py-1 cursor-pointer"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>{t.apkPackagingGuide}</span>
        </button>
      </div>

      {/* Verified Authentic Content Trust Marker */}
      <div className="mt-8 text-center max-w-md px-4 py-2.5 rounded-xl bg-emerald-950/30 border border-emerald-800/20 text-[11px] text-emerald-300/70">
        <span className="text-amber-400 font-semibold">✓ Verified Islamic Content: </span>
        {t.rulesDisclaimer}
      </div>
    </div>
  );
};
