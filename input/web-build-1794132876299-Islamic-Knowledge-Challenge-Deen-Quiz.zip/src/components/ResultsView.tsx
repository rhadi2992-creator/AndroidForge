import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Star,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Home,
  BookOpen,
  ArrowRight,
  Share2,
  Sparkles,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { QuizSummary, Language } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';
import confetti from 'canvas-confetti';

interface ResultsViewProps {
  summary: QuizSummary;
  language: Language;
  onRetry: () => void;
  onNextLevel?: () => void;
  onGoHome: () => void;
  hasNextLevel: boolean;
}

export const ResultsView: React.FC<ResultsViewProps> = ({
  summary,
  language,
  onRetry,
  onNextLevel,
  onGoHome,
  hasNextLevel,
}) => {
  const t = translations[language];
  const isUrdu = language === 'ur';
  const [showReview, setShowReview] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);

  useEffect(() => {
    // Triumphant sound effect and golden confetti
    soundService.playQuizCompleted();
    if (summary.accuracyPercentage >= 70) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#fbbf24', '#f59e0b', '#10b981', '#34d399', '#fef08a']
      });
    }
  }, [summary.accuracyPercentage]);

  const handleShare = async () => {
    soundService.playButtonClick();
    const shareText = `☪ ${t.appName} - ${t.appSubtitle}\nScore: ${summary.totalScore} | Accuracy: ${summary.accuracyPercentage}%\nPassed with ${summary.starsEarned} Stars! Alhamdulillah!`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: t.appName,
          text: shareText,
          url: window.location.href,
        });
        return;
      } catch {}
    }

    try {
      await navigator.clipboard.writeText(shareText);
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 2500);
    } catch {}
  };

  // Encouraging message determination
  const getEncouragement = () => {
    if (summary.accuracyPercentage >= 80) {
      return {
        title: t.alhamdulillah,
        subtitle: t.excellentPerformance,
        color: 'text-amber-300'
      };
    } else if (summary.accuracyPercentage >= 50) {
      return {
        title: t.mashallah,
        subtitle: t.goodEffort,
        color: 'text-emerald-300'
      };
    } else {
      return {
        title: t.keepLearning,
        subtitle: t.rulesDisclaimer,
        color: 'text-emerald-200'
      };
    }
  };

  const encouragement = getEncouragement();

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-6 sm:py-8 flex flex-col items-center animate-fade-in">
      {/* Trophy & Star Rating Header */}
      <div className="relative mb-3 flex flex-col items-center">
        <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-tr from-amber-500 via-amber-400 to-amber-600 p-1 shadow-2xl shadow-amber-950/60 flex items-center justify-center">
          <div className="w-full h-full rounded-full bg-gradient-to-b from-[#063e2c] to-[#021f15] flex items-center justify-center border border-amber-300/40">
            <Trophy className="w-10 h-10 sm:w-12 sm:h-12 text-amber-400 drop-shadow-md" />
          </div>
        </div>

        {/* 3 Golden Stars */}
        <div className="flex items-center gap-1.5 mt-3">
          {[1, 2, 3].map(starNum => {
            const isEarned = starNum <= summary.starsEarned;
            return (
              <Star
                key={starNum}
                className={`w-7 h-7 sm:w-8 sm:h-8 transition-transform duration-300 ${
                  isEarned
                    ? 'text-amber-400 fill-amber-400 scale-110 drop-shadow-md'
                    : 'text-stone-700/60 fill-stone-800'
                }`}
              />
            );
          })}
        </div>
      </div>

      {/* Encouragement Headline */}
      <div className="text-center mb-6 max-w-lg">
        <h2 className={`text-2xl sm:text-3xl font-extrabold ${encouragement.color} mb-1.5 font-amiri`}>
          {encouragement.title}
        </h2>
        <p className={`text-xs sm:text-sm text-emerald-100/90 leading-relaxed ${isUrdu ? 'font-urdu' : ''}`}>
          {encouragement.subtitle}
        </p>
      </div>

      {/* Level Unlocked Banner (if passed) */}
      {summary.unlockedNextLevel && (
        <div className="w-full mb-5 py-2.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-emerald-500/20 to-amber-500/20 border border-amber-400/40 text-center animate-pulse">
          <span className="text-xs sm:text-sm font-bold text-amber-300 flex items-center justify-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            {t.levelUnlocked}
            <Sparkles className="w-4 h-4 text-amber-400" />
          </span>
        </div>
      )}

      {/* Metrics Score Card Grid */}
      <div className="w-full grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 mb-6">
        {/* Score */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#063324] to-[#021f15] border border-emerald-600/30 text-center">
          <div className="text-[11px] text-emerald-300/80 font-semibold uppercase tracking-wider mb-1">
            {t.score}
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-amber-300 tabular-nums">
            +{summary.totalScore}
          </div>
        </div>

        {/* Accuracy */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#063324] to-[#021f15] border border-emerald-600/30 text-center">
          <div className="text-[11px] text-emerald-300/80 font-semibold uppercase tracking-wider mb-1">
            {t.accuracy}
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-300 tabular-nums">
            {summary.accuracyPercentage}%
          </div>
        </div>

        {/* Correct Answers */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#063324] to-[#021f15] border border-emerald-600/30 text-center">
          <div className="text-[11px] text-emerald-300/80 font-semibold uppercase tracking-wider mb-1">
            {t.correctAnswers}
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-400 tabular-nums flex items-center justify-center gap-1">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{summary.correctCount}</span>
          </div>
        </div>

        {/* Incorrect Answers */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#063324] to-[#021f15] border border-emerald-600/30 text-center">
          <div className="text-[11px] text-emerald-300/80 font-semibold uppercase tracking-wider mb-1">
            {t.wrongAnswers}
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-rose-400 tabular-nums flex items-center justify-center gap-1">
            <XCircle className="w-4 h-4 text-rose-400" />
            <span>{summary.incorrectCount}</span>
          </div>
        </div>
      </div>

      {/* Action Buttons: Retry, Next Level, Home, Share */}
      <div className="w-full flex flex-col gap-2.5 sm:gap-3 mb-6">
        {hasNextLevel && summary.correctCount >= 7 && onNextLevel && (
          <button
            onClick={() => {
              soundService.playButtonClick();
              onNextLevel();
            }}
            className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-600 text-stone-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-950/40 hover:scale-[1.02] active:scale-95 transition cursor-pointer"
          >
            <span>{t.nextLevel}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}

        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={() => {
              soundService.playButtonClick();
              onRetry();
            }}
            className="py-3 px-4 rounded-xl bg-emerald-900/60 border border-emerald-500/30 text-amber-100 font-bold text-xs flex items-center justify-center gap-2 hover:bg-emerald-800/60 active:scale-95 transition cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
            <span>{t.playAgain}</span>
          </button>

          <button
            onClick={() => {
              soundService.playButtonClick();
              onGoHome();
            }}
            className="py-3 px-4 rounded-xl bg-emerald-950/70 border border-emerald-600/30 text-amber-100 font-bold text-xs flex items-center justify-center gap-2 hover:bg-emerald-900/60 active:scale-95 transition cursor-pointer"
          >
            <Home className="w-4 h-4 text-emerald-400" />
            <span>{t.home}</span>
          </button>
        </div>

        <button
          onClick={handleShare}
          className="w-full py-2.5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-300 font-semibold text-xs flex items-center justify-center gap-2 hover:bg-amber-900/40 transition cursor-pointer"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span>{shareSuccess ? "Scorecard Copied to Clipboard!" : t.share}</span>
        </button>
      </div>

      {/* Review All Questions Toggle */}
      <div className="w-full">
        <button
          onClick={() => {
            soundService.playButtonClick();
            setShowReview(!showReview);
          }}
          className="w-full py-3 px-4 rounded-xl bg-emerald-950/50 border border-emerald-700/30 text-xs font-bold text-amber-300 flex items-center justify-between hover:bg-emerald-900/40 transition cursor-pointer"
        >
          <span className="flex items-center gap-2">
            <BookOpen className="w-4 h-4" />
            {t.reviewAnswers} ({summary.results.length})
          </span>
          {showReview ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {/* Detailed Question Review List */}
        {showReview && (
          <div className="mt-3 space-y-3 animate-fade-in">
            {summary.results.map((res, i) => {
              const q = res.question;
              const isCorrect = res.isCorrect;
              const options = q.options[language] || q.options.en;

              return (
                <div
                  key={i}
                  className={`p-4 rounded-2xl border transition-all ${
                    isCorrect
                      ? 'bg-emerald-950/40 border-emerald-600/30'
                      : 'bg-rose-950/30 border-rose-600/30'
                  }`}
                  dir={isUrdu ? 'rtl' : 'ltr'}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-xs font-bold text-amber-400">
                      #{i + 1}
                    </span>
                    {isCorrect ? (
                      <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Correct (+{res.pointsEarned})
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[11px] text-rose-400 font-semibold">
                        <XCircle className="w-3.5 h-3.5" /> Incorrect
                      </span>
                    )}
                  </div>

                  <p className={`text-xs sm:text-sm font-semibold text-amber-100 mb-2.5 ${isUrdu ? 'font-urdu text-right' : 'text-left'}`}>
                    {q.question[language] || q.question.en}
                  </p>

                  {/* Answers summary */}
                  <div className="space-y-1.5 text-xs mb-3">
                    {res.selectedOption !== null && !isCorrect && (
                      <div className="flex items-center gap-2 text-rose-300">
                        <span className="font-semibold">{t.yourAnswer}:</span>
                        <span>{options[res.selectedOption]}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2 text-emerald-300">
                      <span className="font-semibold">{t.correctAnswer}:</span>
                      <span>{options[q.correctAnswer]}</span>
                    </div>
                  </div>

                  {/* Reference */}
                  <div className="text-[11px] text-amber-400/90 pt-2 border-t border-emerald-800/30 flex items-center gap-1.5">
                    <BookOpen className="w-3 h-3 text-amber-400" />
                    <span className="font-semibold">{t.reference}:</span>
                    <span>{q.reference[language] || q.reference.en}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
