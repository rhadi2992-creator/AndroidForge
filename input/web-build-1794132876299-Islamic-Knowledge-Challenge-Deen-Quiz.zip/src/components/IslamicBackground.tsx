import React from 'react';

interface IslamicBackgroundProps {
  theme?: 'emerald' | 'gold' | 'midnight';
}

export const IslamicBackground: React.FC<IslamicBackgroundProps> = ({ theme = 'emerald' }) => {
  const getThemeGradients = () => {
    switch (theme) {
      case 'gold':
        return {
          base: 'bg-[#1a1202]',
          radialTop: 'rgba(217, 119, 6, 0.18)',
          radialBottom: 'rgba(180, 83, 9, 0.12)',
          starFill: '#fbbf24',
          silhouette: '#0f0a01'
        };
      case 'midnight':
        return {
          base: 'bg-[#031122]',
          radialTop: 'rgba(14, 116, 144, 0.22)',
          radialBottom: 'rgba(30, 58, 138, 0.2)',
          starFill: '#38bdf8',
          silhouette: '#020b17'
        };
      case 'emerald':
      default:
        return {
          base: 'bg-[#042017]',
          radialTop: 'rgba(5, 150, 105, 0.25)',
          radialBottom: 'rgba(217, 119, 6, 0.12)',
          starFill: '#f59e0b',
          silhouette: '#02130d'
        };
    }
  };

  const colors = getThemeGradients();

  return (
    <div className={`fixed inset-0 pointer-events-none -z-10 overflow-hidden ${colors.base}`}>
      {/* Radial soft lighting */}
      <div
        className="absolute inset-0 opacity-70"
        style={{
          background: `radial-gradient(circle at 50% 0%, ${colors.radialTop} 0%, transparent 65%),
                       radial-gradient(circle at 100% 100%, ${colors.radialBottom} 0%, transparent 50%)`
        }}
      />

      {/* Islamic 8-Point Star and Arabesque Grid Pattern */}
      <svg
        className="absolute inset-0 w-full h-full opacity-[0.045]"
        xmlns="http://www.w3.org/2000/svg"
        width="100"
        height="100"
      >
        <pattern id="islamic-star-pattern" width="60" height="60" patternUnits="userSpaceOnUse">
          {/* 8-point Rub el Hizb geometric star */}
          <polygon
            points="30,8 37,23 52,23 40,33 44,48 30,39 16,48 20,33 8,23 23,23"
            fill="none"
            stroke="#fbbf24"
            strokeWidth="0.8"
          />
          <circle cx="30" cy="30" r="14" fill="none" stroke="#fbbf24" strokeWidth="0.5" />
          <line x1="0" y1="30" x2="60" y2="30" stroke="#fbbf24" strokeWidth="0.4" strokeDasharray="2,2" />
          <line x1="30" y1="0" x2="30" y2="60" stroke="#fbbf24" strokeWidth="0.4" strokeDasharray="2,2" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#islamic-star-pattern)" />
      </svg>

      {/* Decorative Crescent Moon and Stars in Header Area */}
      <div className="absolute top-4 right-6 opacity-35 transition-opacity duration-1000">
        <svg width="120" height="120" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Crescent */}
          <path
            d="M50 15 A35 35 0 1 0 85 65 A40 40 0 0 1 50 15 Z"
            fill="url(#crescentGold)"
          />
          {/* Surrounding Islamic 8-point stars */}
          <polygon
            points="68,32 72,40 80,40 74,46 76,54 68,49 60,54 62,46 56,40 64,40"
            fill="#fef08a"
          />
          <polygon
            points="40,22 42,27 47,27 43,31 44,36 40,33 36,36 37,31 33,27 38,27"
            fill="#fde047"
            opacity="0.8"
          />
          <circle cx="78" cy="20" r="1.5" fill="#fef08a" />
          <circle cx="28" cy="45" r="1" fill="#fef08a" />
          <defs>
            <linearGradient id="crescentGold" x1="20" y1="15" x2="85" y2="65" gradientUnits="userSpaceOnUse">
              <stop stopColor="#fef08a" />
              <stop offset="0.5" stopColor="#f59e0b" />
              <stop offset="1" stopColor="#b45309" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Bottom Mosque Skyline Silhouette */}
      <div className="absolute bottom-0 left-0 right-0 h-44 opacity-25">
        <svg
          viewBox="0 0 1200 240"
          preserveAspectRatio="none"
          className="w-full h-full"
          fill={colors.silhouette}
        >
          {/* Left Minaret */}
          <rect x="40" y="50" width="16" height="190" rx="3" />
          <polygon points="48,20 36,52 60,52" />
          <rect x="36" y="80" width="24" height="6" rx="2" />
          <rect x="36" y="130" width="24" height="6" rx="2" />

          {/* Small Dome Left */}
          <path d="M110,240 L110,140 Q150,75 190,140 L190,240 Z" />
          <circle cx="150" cy="72" r="3" fill="#fbbf24" opacity="0.6" />

          {/* Center Grand Dome & Crescent */}
          <path d="M480,240 L480,110 C480,30 720,30 720,110 L720,240 Z" />
          <path d="M598,30 L598,15 L602,15 L602,30 Z" />
          <circle cx="600" cy="12" r="5" fill="none" stroke="#fbbf24" strokeWidth="2" opacity="0.7" />

          {/* Central Flanking Minarets */}
          <rect x="450" y="30" width="18" height="210" rx="3" />
          <polygon points="459,6 445,32 473,32" />
          <rect x="732" y="30" width="18" height="210" rx="3" />
          <polygon points="741,6 727,32 755,32" />

          {/* Secondary Dome Right */}
          <path d="M1010,240 L1010,140 Q1050,75 1090,140 L1090,240 Z" />
          <circle cx="1050" cy="72" r="3" fill="#fbbf24" opacity="0.6" />

          {/* Right Minaret */}
          <rect x="1140" y="50" width="16" height="190" rx="3" />
          <polygon points="1148,20 1136,52 1160,52" />

          {/* Base foundation horizon */}
          <rect x="0" y="210" width="1200" height="30" />
        </svg>
      </div>
    </div>
  );
};
