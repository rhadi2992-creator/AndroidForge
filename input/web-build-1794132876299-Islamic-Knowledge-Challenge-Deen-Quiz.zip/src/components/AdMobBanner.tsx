import React from 'react';
import { Info, Sparkles } from 'lucide-react';
import { adMobService } from '../services/adMobService';

interface AdMobBannerProps {
  onOpenGuide?: () => void;
  className?: string;
}

export const AdMobBanner: React.FC<AdMobBannerProps> = ({ onOpenGuide, className = '' }) => {
  const config = adMobService.getConfig();
  const mode = adMobService.getMode();

  return (
    <div className={`w-full flex justify-center py-2 px-4 pointer-events-auto ${className}`}>
      <div className="relative w-full max-w-[360px] h-[54px] bg-[#031d14]/95 border border-amber-500/35 rounded-xl flex items-center justify-between px-3 overflow-hidden shadow-lg backdrop-blur-sm">
        {/* AdMob Label & Unit ID */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded uppercase tracking-wider font-mono ${
                mode === 'production'
                  ? 'bg-amber-500/25 text-amber-300 border border-amber-500/40'
                  : 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/40'
              }`}>
                {mode === 'production' ? 'AdMob Live' : 'AdMob Test'}
              </span>
              <span className="text-[10px] text-amber-200/90 font-semibold truncate">
                Ad by Google • Banner 320x50
              </span>
            </div>
            <span className="text-[9px] text-stone-400 font-mono truncate max-w-[220px]" title={config.bannerAdUnitId}>
              {config.bannerAdUnitId}
            </span>
          </div>
        </div>

        {/* Info button */}
        {onOpenGuide && (
          <button
            onClick={onOpenGuide}
            title="AdMob Integration & APK Setup"
            className="p-1.5 rounded-lg bg-emerald-950/70 text-stone-400 hover:text-amber-300 transition hover:bg-emerald-900/60 cursor-pointer flex-shrink-0"
          >
            <Info className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
