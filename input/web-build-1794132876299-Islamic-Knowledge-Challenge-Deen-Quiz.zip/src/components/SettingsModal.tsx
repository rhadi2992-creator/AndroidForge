import React, { useState } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Music,
  Bell,
  Globe,
  Palette,
  RotateCcw,
  AlertTriangle,
  Play,
  Pause,
  Shield,
  HelpCircle,
  Sparkles,
  Check,
  Download,
  FolderArchive,
  Activity
} from 'lucide-react';
import { Language, AudioSettings } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';
import { storageService } from '../services/storageService';
import { adMobService, ADMOB_PRODUCTION_CONFIG, ADMOB_TEST_CONFIG } from '../services/adMobService';

interface SettingsModalProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onThemeChange: (theme: 'emerald' | 'gold' | 'midnight') => void;
  currentTheme: 'emerald' | 'gold' | 'midnight';
  onClose: () => void;
  onResetConfirmed: () => void;
  onOpenPrivacyPolicy?: () => void;
  onOpenGuide?: () => void;
  onOpenDownloadProject?: () => void;
  onOpenDiagnostics?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  language,
  onLanguageChange,
  onThemeChange,
  currentTheme,
  onClose,
  onResetConfirmed,
  onOpenPrivacyPolicy,
  onOpenGuide,
  onOpenDownloadProject,
  onOpenDiagnostics,
}) => {
  const t = translations[language];
  const isUrdu = language === 'ur';

  const [audioSettings, setAudioSettings] = useState<AudioSettings>(soundService.getSettings());
  const [isPlaying, setIsPlaying] = useState<boolean>(soundService.isPlaying());
  const [adMode, setAdMode] = useState<'production' | 'test'>(adMobService.getMode());
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [customUrlInput, setCustomUrlInput] = useState(audioSettings.customAudioUrl || '');
  const [customNameInput, setCustomNameInput] = useState(audioSettings.customAudioName || '');

  const handleToggleMusic = () => {
    soundService.playButtonClick();
    const updated = !audioSettings.musicEnabled;
    soundService.saveSettings({ musicEnabled: updated });
    setAudioSettings(soundService.getSettings());
    setIsPlaying(soundService.isPlaying());
  };

  const handlePlayPause = () => {
    soundService.playButtonClick();
    if (isPlaying) {
      soundService.pauseMusic();
      setIsPlaying(false);
    } else {
      soundService.resumeMusic();
      setIsPlaying(true);
    }
  };

  const handleMusicVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    soundService.saveSettings({ musicVolume: val });
    setAudioSettings(soundService.getSettings());
  };

  const handleToggleSfx = () => {
    const updated = !audioSettings.sfxEnabled;
    soundService.saveSettings({ sfxEnabled: updated });
    setAudioSettings(soundService.getSettings());
    if (updated) soundService.playButtonClick();
  };

  const handleSelectTrack = (track: 'naat_mp3' | 'ambient_nasheed' | 'meditation_drone') => {
    soundService.playButtonClick();
    soundService.saveSettings({ musicTrack: track });
    soundService.startMusic();
    setAudioSettings(soundService.getSettings());
    setIsPlaying(true);
  };

  const handleCustomAudioSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customUrlInput.trim()) return;
    soundService.setCustomAudio(customUrlInput.trim(), customNameInput.trim() || 'Custom Naat');
    setAudioSettings(soundService.getSettings());
    setIsPlaying(true);
  };

  const handleSwitchAdMode = (newMode: 'production' | 'test') => {
    soundService.playButtonClick();
    adMobService.setMode(newMode);
    storageService.savePreferences({ adMobMode: newMode });
    setAdMode(newMode);
  };

  const handleResetExecute = () => {
    soundService.playButtonClick();
    storageService.resetAllProgress();
    setShowResetConfirm(false);
    onResetConfirmed();
  };

  const currentConfig = adMobService.getConfig();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-[#063e2c] via-[#032419] to-[#01160e] border border-amber-500/40 p-5 sm:p-7 shadow-2xl text-amber-50">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-emerald-800/40 mb-5">
          <h3 className="font-extrabold text-lg sm:text-xl text-amber-100">
            {t.settings}
          </h3>
          <button
            onClick={() => {
              soundService.playButtonClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-emerald-950/60 border border-emerald-700/40 text-stone-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-5 text-xs sm:text-sm">
          {/* Background Naat Player (Part 2 of requirements) */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0a4834]/80 to-[#022216]/90 border border-amber-500/40 shadow-md">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-amber-300 font-bold">
                <Music className="w-4 h-4 text-amber-400" />
                <span>Background Naat / Nasheed</span>
              </div>
              <div className="flex items-center gap-2">
                {audioSettings.musicEnabled && (
                  <button
                    onClick={handlePlayPause}
                    className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition cursor-pointer"
                    title={isPlaying ? "Pause" : "Play"}
                  >
                    {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  </button>
                )}
                <button
                  onClick={handleToggleMusic}
                  className={`px-3 py-1 rounded-full text-xs font-bold border transition cursor-pointer ${
                    audioSettings.musicEnabled
                      ? 'bg-emerald-500 text-stone-950 border-emerald-400'
                      : 'bg-stone-800 text-stone-400 border-stone-700'
                  }`}
                >
                  {audioSettings.musicEnabled ? 'ON' : 'OFF'}
                </button>
              </div>
            </div>

            {/* Current Track Banner */}
            <div className="p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-700/40 mb-3 flex items-center justify-between">
              <div className="min-w-0 pr-2">
                <span className="text-[10px] text-amber-400/80 uppercase font-bold block">
                  Now Selected
                </span>
                <span className="text-xs font-bold text-amber-100 truncate block">
                  {soundService.getTrackTitle()}
                </span>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                audioSettings.musicEnabled && isPlaying
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse'
                  : 'bg-stone-800 text-stone-400'
              }`}>
                {audioSettings.musicEnabled && isPlaying ? 'Playing' : 'Paused'}
              </span>
            </div>

            {/* Volume slider */}
            {audioSettings.musicEnabled && (
              <div className="space-y-3 pt-1">
                <div>
                  <div className="flex items-center justify-between text-xs text-emerald-200/80 mb-1">
                    <span>{t.volume}</span>
                    <span className="font-mono text-amber-300 font-bold">{Math.round(audioSettings.musicVolume * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={audioSettings.musicVolume}
                    onChange={handleMusicVolumeChange}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                </div>

                {/* Audio Track Selector */}
                <div>
                  <label className="text-xs text-emerald-300/80 font-semibold block mb-1.5">
                    Select Audio Atmosphere
                  </label>
                  <div className="space-y-2">
                    {/* Official Naat */}
                    <button
                      onClick={() => handleSelectTrack('naat_mp3')}
                      className={`w-full p-2.5 rounded-xl border text-xs font-bold text-left transition cursor-pointer flex items-center justify-between ${
                        audioSettings.musicTrack === 'naat_mp3'
                          ? 'bg-amber-400 text-stone-950 border-amber-400 shadow-md'
                          : 'bg-emerald-950/70 border-emerald-700/30 text-amber-200/90 hover:bg-emerald-900/40'
                      }`}
                    >
                      <div>
                        <span className="block font-extrabold">Meri Baat Ban Gayi Hai (Official Naat)</span>
                        <span className={`text-[10px] ${audioSettings.musicTrack === 'naat_mp3' ? 'text-stone-800' : 'text-stone-400'}`}>
                          Recited by Ghulam Mustafa Qadri • Continuous Loop
                        </span>
                      </div>
                      {audioSettings.musicTrack === 'naat_mp3' && <Check className="w-4 h-4 text-stone-950" />}
                    </button>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => handleSelectTrack('ambient_nasheed')}
                        className={`p-2 rounded-xl border text-[11px] font-bold text-left transition cursor-pointer ${
                          audioSettings.musicTrack === 'ambient_nasheed'
                            ? 'bg-amber-400 text-stone-950 border-amber-400'
                            : 'bg-emerald-950/70 border-emerald-700/30 text-amber-200/80'
                        }`}
                      >
                        {t.peaceNasheed}
                      </button>
                      <button
                        onClick={() => handleSelectTrack('meditation_drone')}
                        className={`p-2 rounded-xl border text-[11px] font-bold text-left transition cursor-pointer ${
                          audioSettings.musicTrack === 'meditation_drone'
                            ? 'bg-amber-400 text-stone-950 border-amber-400'
                            : 'bg-emerald-950/70 border-emerald-700/30 text-amber-200/80'
                        }`}
                      >
                        {t.spiritualDrone}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Optional Custom Audio */}
                <form onSubmit={handleCustomAudioSubmit} className="pt-2 border-t border-emerald-800/30">
                  <span className="text-[11px] text-amber-300/80 font-semibold block mb-1.5">
                    Custom Audio Stream URL (Optional)
                  </span>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      placeholder="https://example.com/audio.mp3"
                      value={customUrlInput}
                      onChange={e => setCustomUrlInput(e.target.value)}
                      className="flex-1 bg-emerald-950/80 border border-emerald-700/40 rounded-xl px-2.5 py-1.5 text-xs text-amber-100 placeholder:text-stone-500 focus:outline-none focus:border-amber-400"
                    />
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs hover:bg-amber-400 transition cursor-pointer"
                    >
                      Apply
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>

          {/* Google AdMob Configuration Section (Part 3 of requirements) */}
          <div className="p-4 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-amber-300 font-bold">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Google AdMob Integration</span>
              </div>
              <div className="flex items-center gap-1.5 bg-emerald-950 p-1 rounded-xl border border-emerald-700/40">
                <button
                  onClick={() => handleSwitchAdMode('production')}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold font-mono transition cursor-pointer ${
                    adMode === 'production'
                      ? 'bg-amber-400 text-stone-950 shadow'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Live Production
                </button>
                <button
                  onClick={() => handleSwitchAdMode('test')}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold font-mono transition cursor-pointer ${
                    adMode === 'test'
                      ? 'bg-emerald-500 text-stone-950 shadow'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  AdMob Test
                </button>
              </div>
            </div>

            {/* Configured IDs Breakdown */}
            <div className="space-y-1.5 font-mono text-[10px] bg-black/40 p-3 rounded-xl border border-emerald-800/40">
              <div className="flex justify-between items-center text-amber-200/90">
                <span className="text-stone-400">APP ID:</span>
                <span className="truncate max-w-[210px]">{currentConfig.appId}</span>
              </div>
              <div className="flex justify-between items-center text-stone-300">
                <span className="text-stone-400">BANNER:</span>
                <span className="truncate max-w-[210px]">{currentConfig.bannerAdUnitId}</span>
              </div>
              <div className="flex justify-between items-center text-stone-300">
                <span className="text-stone-400">APP OPEN:</span>
                <span className="truncate max-w-[210px]">{currentConfig.appOpenAdUnitId}</span>
              </div>
              <div className="flex justify-between items-center text-stone-300">
                <span className="text-stone-400">INTERSTITIAL:</span>
                <span className="truncate max-w-[210px]">{currentConfig.interstitialAdUnitId}</span>
              </div>
              <div className="flex justify-between items-center text-stone-300">
                <span className="text-stone-400">NATIVE:</span>
                <span className="truncate max-w-[210px]">{currentConfig.nativeAdUnitId}</span>
              </div>
              <div className="flex justify-between items-center text-stone-300">
                <span className="text-stone-400">REWARDED:</span>
                <span className="truncate max-w-[210px]">{currentConfig.rewardedAdUnitId}</span>
              </div>
            </div>

            {/* Internal AdMob Diagnostics & Test Console (User Requirement #11) */}
            {onOpenDiagnostics && (
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onOpenDiagnostics();
                }}
                className="mt-2.5 w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500/20 to-emerald-500/20 border border-amber-500/50 text-amber-300 hover:bg-amber-500/30 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer shadow-sm"
              >
                <Activity className="w-4 h-4 text-amber-400 animate-pulse" />
                <span>AdMob Diagnostics & Live Test Console</span>
              </button>
            )}

            {onOpenGuide && (
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onOpenGuide();
                }}
                className="mt-2 w-full py-2 rounded-xl bg-emerald-900/40 border border-emerald-700/40 text-stone-300 hover:text-amber-200 text-xs font-medium flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>View Full APK & AdMob Integration Guide</span>
              </button>
            )}
          </div>

          {/* Language Selection */}
          <div className="p-4 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <div className="flex items-center gap-2 mb-3 text-amber-300 font-bold">
              <Globe className="w-4 h-4 text-amber-400" />
              <span>{t.languageSelect}</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(['en', 'ur', 'roman'] as Language[]).map(langCode => (
                <button
                  key={langCode}
                  onClick={() => {
                    soundService.playButtonClick();
                    onLanguageChange(langCode);
                  }}
                  className={`py-2 px-3 rounded-xl border font-bold text-xs transition cursor-pointer ${
                    language === langCode
                      ? 'bg-amber-400 text-stone-950 border-amber-400 shadow-md'
                      : 'bg-emerald-950/80 border-emerald-700/40 text-amber-200/80 hover:bg-emerald-900/40'
                  }`}
                >
                  {langCode === 'en' ? 'English' : langCode === 'ur' ? 'اردو' : 'Roman Urdu'}
                </button>
              ))}
            </div>
          </div>

          {/* Visual Theme Selection */}
          <div className="p-4 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <div className="flex items-center gap-2 mb-3 text-amber-300 font-bold">
              <Palette className="w-4 h-4 text-amber-400" />
              <span>{t.theme}</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onThemeChange('emerald');
                }}
                className={`py-2 px-2.5 rounded-xl border text-[11px] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  currentTheme === 'emerald'
                    ? 'bg-emerald-600/40 border-emerald-400 text-emerald-200 shadow-md'
                    : 'bg-emerald-950/60 border-emerald-800/40 text-emerald-300/70'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span>{t.emeraldTheme}</span>
              </button>

              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onThemeChange('gold');
                }}
                className={`py-2 px-2.5 rounded-xl border text-[11px] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  currentTheme === 'gold'
                    ? 'bg-amber-600/40 border-amber-400 text-amber-200 shadow-md'
                    : 'bg-emerald-950/60 border-emerald-800/40 text-amber-300/70'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                <span>{t.goldTheme}</span>
              </button>

              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onThemeChange('midnight');
                }}
                className={`py-2 px-2.5 rounded-xl border text-[11px] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  currentTheme === 'midnight'
                    ? 'bg-cyan-900/40 border-cyan-400 text-cyan-200 shadow-md'
                    : 'bg-emerald-950/60 border-emerald-800/40 text-cyan-300/70'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
                <span>{t.midnightTheme}</span>
              </button>
            </div>
          </div>

          {/* Sound Effects (SFX) */}
          <div className="p-4 rounded-2xl bg-emerald-950/50 border border-emerald-700/30 flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-300 font-bold">
              <Bell className="w-4 h-4 text-amber-400" />
              <span>{t.soundEffects}</span>
            </div>
            <button
              onClick={handleToggleSfx}
              className={`px-3 py-1 rounded-full text-xs font-bold border transition cursor-pointer ${
                audioSettings.sfxEnabled
                  ? 'bg-emerald-500 text-stone-950 border-emerald-400'
                  : 'bg-stone-800 text-stone-400 border-stone-700'
              }`}
            >
              {audioSettings.sfxEnabled ? 'ON' : 'OFF'}
            </button>
          </div>

          {/* Download Complete Project ZIP (User Request) */}
          {onOpenDownloadProject && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/90 via-teal-950/80 to-emerald-950/90 border border-amber-500/40 flex items-center justify-between shadow-md">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Download className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-amber-200 text-xs sm:text-sm block">
                    Export Project ZIP (15 MB)
                  </span>
                  <span className="text-[11px] text-stone-400">
                    Source code, Naat audio, AdMob & Android files
                  </span>
                </div>
              </div>
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onOpenDownloadProject();
                }}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-stone-950 hover:from-amber-300 hover:to-amber-500 text-xs font-bold transition shadow cursor-pointer"
              >
                Download
              </button>
            </div>
          )}

          {/* Privacy Policy Link */}
          {onOpenPrivacyPolicy && (
            <div className="p-4 rounded-2xl bg-emerald-950/50 border border-emerald-700/30 flex items-center justify-between">
              <div className="flex items-center gap-2 text-amber-300 font-bold">
                <Shield className="w-4 h-4 text-amber-400" />
                <span>Privacy Policy & Consent</span>
              </div>
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  onOpenPrivacyPolicy();
                }}
                className="px-3 py-1.5 rounded-xl bg-emerald-900/60 border border-emerald-600/40 text-amber-200 hover:text-white text-xs font-bold transition cursor-pointer"
              >
                Read Policy
              </button>
            </div>
          )}

          {/* Reset All Progress (With Confirmation) */}
          <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-500/20">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-rose-300 text-xs sm:text-sm block">
                  {t.resetProgress}
                </span>
                <span className="text-[11px] text-stone-400">
                  Resets high scores, levels, and daily streak
                </span>
              </div>
              <button
                onClick={() => setShowResetConfirm(true)}
                className="px-3 py-1.5 rounded-xl bg-rose-950 border border-rose-500/40 text-rose-300 hover:bg-rose-900/40 text-xs font-bold transition cursor-pointer"
              >
                {t.resetProgress}
              </button>
            </div>
          </div>
        </div>

        {/* Close Button */}
        <button
          onClick={() => {
            soundService.playButtonClick();
            onClose();
          }}
          className="mt-6 w-full py-2.5 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs hover:bg-amber-400 transition cursor-pointer"
        >
          {t.close}
        </button>
      </div>

      {/* Confirmation Modal for Reset */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-sm rounded-2xl bg-[#031c13] border border-rose-500/50 p-5 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-base text-rose-200 mb-2">
              {t.resetConfirmTitle}
            </h4>
            <p className="text-xs text-stone-300 mb-5 leading-relaxed">
              {t.resetConfirmMessage}
            </p>
            <div className="flex gap-2.5">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2 rounded-xl bg-emerald-950 border border-emerald-700/40 text-stone-300 text-xs font-semibold hover:bg-emerald-900 transition cursor-pointer"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleResetExecute}
                className="flex-1 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-500 transition cursor-pointer"
              >
                {t.confirmReset}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
