import React, { useState } from 'react';
import {
  BookOpen,
  ScrollText,
  HeartHandshake,
  Landmark,
  Flame,
  Globe2,
  Users,
  ShieldCheck,
  MoonStar,
  Compass,
  ArrowLeft,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { categories } from '../data/categories';
import { Language, Difficulty } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';

import { AdMobNativeCard } from './AdMobNativeCard';

interface CategoriesViewProps {
  language: Language;
  onPlayCategory: (categoryId: number, difficulty: Difficulty) => void;
  onBack: () => void;
  onOpenGuide?: () => void;
}

export const CategoriesView: React.FC<CategoriesViewProps> = ({
  language,
  onPlayCategory,
  onBack,
  onOpenGuide,
}) => {
  const t = translations[language];
  const isUrdu = language === 'ur';
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty>('medium');

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'BookOpen': return <BookOpen className="w-5 h-5" />;
      case 'ScrollText': return <ScrollText className="w-5 h-5" />;
      case 'HeartHandshake': return <HeartHandshake className="w-5 h-5" />;
      case 'Landmark': return <Landmark className="w-5 h-5" />;
      case 'Flame': return <Flame className="w-5 h-5" />;
      case 'Globe2': return <Globe2 className="w-5 h-5" />;
      case 'Users': return <Users className="w-5 h-5" />;
      case 'ShieldCheck': return <ShieldCheck className="w-5 h-5" />;
      case 'MoonStar': return <MoonStar className="w-5 h-5" />;
      case 'Compass':
      default: return <Compass className="w-5 h-5" />;
    }
  };

  const difficulties: Difficulty[] = ['easy', 'medium', 'hard', 'expert'];

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6 sm:py-8 flex flex-col animate-fade-in pb-24">
      {/* Top Header */}
      <div className="flex items-center justify-between mb-5">
        <button
          onClick={() => {
            soundService.playButtonClick();
            onBack();
          }}
          className="flex items-center gap-1.5 text-xs text-amber-300 hover:text-amber-100 px-3 py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-500/30 transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <div className="text-center">
          <h2 className="text-xl sm:text-2xl font-extrabold text-amber-100">
            {t.categories}
          </h2>
          <span className="text-xs text-emerald-300/80">
            10 Authentic Domains
          </span>
        </div>

        <div className="w-16" />
      </div>

      {/* Difficulty Segmented Control Filter */}
      <div className="mb-6 p-1.5 rounded-2xl bg-emerald-950/70 border border-emerald-700/30 flex items-center justify-between gap-1 max-w-md mx-auto w-full">
        {difficulties.map(diff => (
          <button
            key={diff}
            onClick={() => {
              soundService.playButtonClick();
              setSelectedDifficulty(diff);
            }}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
              selectedDifficulty === diff
                ? 'bg-amber-400 text-stone-950 shadow-md font-extrabold'
                : 'text-amber-200/70 hover:text-amber-100 hover:bg-emerald-900/40'
            }`}
          >
            {t[diff]}
          </button>
        ))}
      </div>

      {/* Native Ad Placement: Category Screen (Part 7 of requirements) */}
      <div className="mb-5">
        <AdMobNativeCard />
      </div>

      {/* Categories Grid (10 categories) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4 mb-6">
        {categories.map(cat => {
          return (
            <button
              key={cat.id}
              onClick={() => {
                soundService.playButtonClick();
                onPlayCategory(cat.id, selectedDifficulty);
              }}
              className="group p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#063928] to-[#021f15] border border-amber-500/30 hover:border-amber-400/60 hover:scale-[1.01] transition-all duration-200 text-left flex items-start justify-between gap-3 shadow-lg shadow-emerald-950/50 cursor-pointer"
              dir={isUrdu ? 'rtl' : 'ltr'}
            >
              <div className="flex items-start gap-3.5">
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border border-amber-500/30 shadow-md"
                  style={{ backgroundColor: `${cat.accentColor}20`, color: cat.accentColor }}
                >
                  {getCategoryIcon(cat.iconName)}
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold text-amber-400/80 font-mono">
                      #{cat.id < 10 ? `0${cat.id}` : cat.id}
                    </span>
                    <h3 className={`font-extrabold text-sm sm:text-base text-amber-100 group-hover:text-amber-300 transition-colors ${isUrdu ? 'font-urdu' : ''}`}>
                      {cat.name[language] || cat.name.en}
                    </h3>
                  </div>

                  <p className={`text-xs text-emerald-200/70 line-clamp-2 leading-relaxed ${isUrdu ? 'font-urdu' : ''}`}>
                    {cat.description[language] || cat.description.en}
                  </p>
                </div>
              </div>

              <ChevronRight className="w-5 h-5 text-amber-400/60 group-hover:text-amber-300 group-hover:translate-x-1 transition-all shrink-0 mt-3" />
            </button>
          );
        })}
      </div>
    </div>
  );
};
