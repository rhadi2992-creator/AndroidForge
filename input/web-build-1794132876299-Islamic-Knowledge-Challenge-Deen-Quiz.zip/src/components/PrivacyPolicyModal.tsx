import React, { useState } from 'react';
import { X, Shield, Lock, Eye, FileText, CheckCircle2 } from 'lucide-react';
import { soundService } from '../services/soundService';

interface PrivacyPolicyModalProps {
  onClose: () => void;
}

export const PrivacyPolicyModal: React.FC<PrivacyPolicyModalProps> = ({ onClose }) => {
  const [personalizedAds, setPersonalizedAds] = useState(true);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-lg max-h-[88vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-[#063b2a] via-[#032217] to-[#01140e] border border-amber-500/40 p-5 sm:p-7 shadow-2xl text-amber-50">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-emerald-800/40 mb-4">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-amber-400" />
            <h3 className="font-extrabold text-base sm:text-lg text-amber-100">
              Privacy Policy & AdMob Disclosure
            </h3>
          </div>
          <button
            onClick={() => {
              soundService.playButtonClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-emerald-950/70 border border-emerald-700/40 text-stone-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
          {/* Section 1 */}
          <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <h4 className="font-bold text-amber-300 text-xs sm:text-sm flex items-center gap-1.5 mb-1.5">
              <Lock className="w-4 h-4 text-amber-400" />
              1. Information Collection & Storage
            </h4>
            <p className="text-stone-300 text-xs leading-relaxed">
              Islamic Knowledge Challenge – Deen Quiz values your privacy. We do not require account registration or collect personal identifiable information (PII) such as your name, email, or physical location. Your quiz progress, high scores, unlockable levels, streaks, and audio settings are stored locally on your device using browser <span className="font-mono text-amber-200">localStorage</span>.
            </p>
          </div>

          {/* Section 2: Google AdMob */}
          <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <h4 className="font-bold text-amber-300 text-xs sm:text-sm flex items-center gap-1.5 mb-1.5">
              <Eye className="w-4 h-4 text-amber-400" />
              2. Google AdMob Advertising
            </h4>
            <p className="text-stone-300 text-xs leading-relaxed mb-2">
              This application uses Google AdMob (Google Mobile Ads SDK) to serve banner, interstitial, app open, native, and rewarded advertisements. AdMob may collect and process device identifiers, cookies, and diagnostic data to deliver advertisements compliant with Google policies.
            </p>
            <div className="text-[11px] text-amber-300/80 font-mono bg-emerald-950/80 p-2 rounded-lg border border-emerald-800/40">
              Official AdMob App ID: ca-app-pub-3133971041724338~1043785552
            </div>
          </div>

          {/* Section 3: GDPR & CCPA Consent */}
          <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <h4 className="font-bold text-amber-300 text-xs sm:text-sm flex items-center gap-1.5 mb-1.5">
              <FileText className="w-4 h-4 text-amber-400" />
              3. GDPR & CCPA Compliance
            </h4>
            <p className="text-stone-300 text-xs leading-relaxed mb-3">
              Users within the European Economic Area (EEA), UK, and California have rights regarding personal data. You can choose whether to allow personalized advertising or non-personalized advertising below:
            </p>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-900/30 border border-emerald-700/30">
              <span className="text-xs text-amber-200 font-semibold">
                Personalized Advertising Consent
              </span>
              <button
                onClick={() => {
                  soundService.playButtonClick();
                  setPersonalizedAds(prev => !prev);
                }}
                className={`px-3 py-1 rounded-full text-[11px] font-bold border transition cursor-pointer ${
                  personalizedAds
                    ? 'bg-emerald-500 text-stone-950 border-emerald-400'
                    : 'bg-stone-800 text-stone-400 border-stone-700'
                }`}
              >
                {personalizedAds ? 'Consented' : 'Non-Personalized'}
              </button>
            </div>
          </div>

          {/* Section 4: Islamic Audio Ethics */}
          <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <h4 className="font-bold text-amber-300 text-xs sm:text-sm flex items-center gap-1.5 mb-1.5">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              4. Respectful Audio Experience
            </h4>
            <p className="text-stone-300 text-xs leading-relaxed">
              Background Naat playback ("Meri Baat Ban Gayi Hai") is provided respectfully for an uplifting spiritual ambience. You can pause, adjust volume, or turn off audio anytime from Settings.
            </p>
          </div>
        </div>

        {/* Close Button */}
        <button
          onClick={() => {
            soundService.playButtonClick();
            onClose();
          }}
          className="mt-5 w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-stone-950 font-bold text-xs hover:scale-[1.01] active:scale-95 transition shadow-lg cursor-pointer"
        >
          Understood & Accept
        </button>
      </div>
    </div>
  );
};
