import React from 'react';
import { X, Smartphone, Code, ShieldCheck, ExternalLink, Terminal, Download } from 'lucide-react';
import { Language } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';

interface AdMobGuideModalProps {
  language: Language;
  onClose: () => void;
  onOpenDownloadProject?: () => void;
}

export const AdMobGuideModal: React.FC<AdMobGuideModalProps> = ({
  language,
  onClose,
  onOpenDownloadProject,
}) => {
  const t = translations[language];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-xl max-h-[88vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-[#063e2c] to-[#022016] border border-amber-500/40 p-5 sm:p-7 shadow-2xl text-amber-50">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-emerald-800/40 mb-4">
          <div className="flex items-center gap-2 text-amber-400">
            <Smartphone className="w-6 h-6" />
            <h3 className="font-extrabold text-lg sm:text-xl text-amber-100">
              Android APK & AdMob Integration
            </h3>
          </div>
          <button
            onClick={() => {
              soundService.playButtonClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-emerald-950/60 border border-emerald-700/40 text-stone-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
          {/* Step 1: Capacitor Setup */}
          <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-amber-400" />
              1. Convert into Android APK with Capacitor
            </h4>
            <p className="mb-2 text-xs text-stone-300">
              Run these commands in your project terminal to generate the native Android Studio project:
            </p>
            <pre className="p-2.5 rounded-xl bg-stone-950 font-mono text-[11px] text-amber-300 overflow-x-auto">
{`# 1. Install Capacitor CLI & Android platform
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Initialize Capacitor
npx cap init "Deen Quiz" "com.deenquiz.islamicchallenge" --web-dir=dist

# 3. Build Web Bundle
npm run build

# 4. Add Android Platform
npx cap add android

# 5. Open in Android Studio to generate release APK / AAB
npx cap open android`}
            </pre>
          </div>

          {/* Step 2: AdMob Integration */}
          <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/30">
            <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-2">
              <Code className="w-4 h-4 text-amber-400" />
              2. Add Official Google AdMob SDK
            </h4>
            <p className="mb-2 text-xs text-stone-300">
              Install the community AdMob plugin for Capacitor:
            </p>
            <pre className="p-2.5 rounded-xl bg-stone-950 font-mono text-[11px] text-amber-300 overflow-x-auto mb-2">
{`npm install @capacitor-community/admob
npx cap sync android`}
            </pre>
            <p className="text-xs text-stone-300 mb-2">
              In <code className="text-amber-300">android/app/src/main/AndroidManifest.xml</code>, insert your configured AdMob App ID:
            </p>
            <pre className="p-2.5 rounded-xl bg-stone-950 font-mono text-[11px] text-amber-300 overflow-x-auto">
{`<!-- Google AdMob Application ID -->
<meta-data
  android:name="com.google.android.gms.ads.APPLICATION_ID"
  android:value="ca-app-pub-3133971041724338~1043785552"/>

<!-- Ad Unit IDs configured in this project -->
<!-- BANNER:       ca-app-pub-3133971041724338/3478377206 -->
<!-- APP OPEN:     ca-app-pub-3133971041724338/7226050527 -->
<!-- INTERSTITIAL: ca-app-pub-3133971041724338/2416576970 -->
<!-- NATIVE:       ca-app-pub-3133971041724338/8955879258 -->
<!-- REWARDED:     ca-app-pub-3133971041724338/3018166024 -->`}
            </pre>
          </div>

          {/* Step 3: Google Play Store Signing */}
          <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/30">
            <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              3. Generate Signed APK / AAB for Play Store
            </h4>
            <p className="text-xs text-amber-100/90">
              In Android Studio, click <strong>Build → Generate Signed Bundle / APK</strong>, choose <strong>Android App Bundle (AAB)</strong>, create your keystore, and upload directly to Google Play Console.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-5 flex gap-2.5">
          {onOpenDownloadProject && (
            <button
              onClick={() => {
                soundService.playButtonClick();
                onOpenDownloadProject();
              }}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-stone-950 font-bold text-xs hover:scale-[1.02] active:scale-95 transition shadow-lg flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Download className="w-4 h-4 text-stone-950" />
              <span>Download Project ZIP</span>
            </button>
          )}

          <button
            onClick={() => {
              soundService.playButtonClick();
              onClose();
            }}
            className={`py-2.5 rounded-xl font-bold text-xs transition cursor-pointer ${
              onOpenDownloadProject
                ? 'px-4 bg-emerald-950/80 border border-emerald-700/40 text-stone-300 hover:text-white'
                : 'w-full bg-amber-500 text-stone-950 hover:bg-amber-400'
            }`}
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
