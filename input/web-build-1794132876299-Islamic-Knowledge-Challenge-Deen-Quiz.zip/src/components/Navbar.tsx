import React from 'react';
import { Volume2, VolumeX, Settings, Globe, Flame, Sparkles, HelpCircle, Download } from 'lucide-react';
import { Language } from '../types/quiz';
import { translations } from '../data/translations';
import { soundService } from '../services/soundService';

interface NavbarProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenSettings: () => void;
  onOpenHowToPlay: () => void;
  onGoHome: () => void;
  onOpenDownloadProject?: () => void;
  currentStreak: number;
  coins: number;
  musicEnabled: boolean;
  onToggleMusic: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onLanguageChange,
  onOpenSettings,
  onOpenHowToPlay,
  onGoHome,
  onOpenDownloadProject,
  currentStreak,
  coins,
  musicEnabled,
  onToggleMusic,
}) => {
  const t = translations[language];
  const isRTL = language === 'ur';

  const handleLangToggle = () => {
    soundService.playButtonClick();
    if (language === 'en') onLanguageChange('ur');
    else if (language === 'ur') onLanguageChange('roman');
    else onLanguageChange('en');
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-[#042017]/85 border-b border-amber-500/20 px-3 sm:px-6 py-2.5 transition-all">
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand Zone */}
        <button
          onClick={() => {
            soundService.playButtonClick();
            onGoHome();
          }}
          className="flex items-center gap-2 group text-left cursor-pointer transition focus:outline-none"
        >
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 p-0.5 shadow-md shadow-amber-900/30 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-[#042017] rounded-[10px] flex items-center justify-center">
              <span className="text-amber-400 font-bold text-base sm:text-lg">☪</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm sm:text-base text-amber-100 tracking-wide group-hover:text-amber-300 transition-colors">
                {t.appName}
              </span>
            </div>
            <span className="text-[11px] text-amber-400/80 font-medium">
              {t.appSubtitle}
            </span>
          </div>
        </button>

        {/* Center/Stats Zone */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Daily Streak Indicator */}
          <div
            title={`${t.dailyStreak}: ${currentStreak} ${t.days}`}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-950/60 border border-amber-600/30 text-amber-300 text-xs font-semibold tabular-nums shadow-inner"
          >
            <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse fill-amber-400" />
            <span>{currentStreak} {t.days}</span>
          </div>

          {/* Coins / Points Indicator */}
          <div
            title="Earned Noor Points & Coins"
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-semibold tabular-nums shadow-inner"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>{coins}</span>
          </div>
        </div>

        {/* Action Controls Zone */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Background Audio Button */}
          <button
            onClick={() => {
              soundService.playButtonClick();
              onToggleMusic();
            }}
            title={musicEnabled ? "Mute Background Nasheed" : "Play Peaceful Nasheed"}
            className={`p-2 rounded-xl border transition-all cursor-pointer ${
              musicEnabled
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 hover:bg-amber-500/25'
                : 'bg-emerald-950/40 border-emerald-800/40 text-emerald-400/60 hover:text-emerald-200'
            }`}
          >
            {musicEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Quick Language Toggle */}
          <button
            onClick={handleLangToggle}
            title={t.languageSelect}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs font-bold hover:bg-amber-500/15 transition cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span className="uppercase tracking-wider">
              {language === 'en' ? 'EN' : language === 'ur' ? 'اردو' : 'ROMAN'}
            </span>
          </button>

          {/* How to play / info */}
          <button
            onClick={() => {
              soundService.playButtonClick();
              onOpenHowToPlay();
            }}
            title={t.howToPlay}
            className="hidden md:flex p-2 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-emerald-300 hover:text-amber-200 hover:bg-emerald-900/40 transition cursor-pointer"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* Download Complete Project ZIP */}
          {onOpenDownloadProject && (
            <button
              onClick={() => {
                soundService.playButtonClick();
                onOpenDownloadProject();
              }}
              title="Download Complete Project ZIP (Full Source Code & Naat Audio)"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-stone-950 font-bold text-xs hover:brightness-110 active:scale-95 transition shadow-md shadow-amber-950/40 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-stone-950" />
              <span className="hidden sm:inline font-extrabold">Download ZIP</span>
            </button>
          )}

          {/* Settings modal */}
          <button
            onClick={() => {
              soundService.playButtonClick();
              onOpenSettings();
            }}
            title={t.settings}
            className="p-2 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-emerald-300 hover:text-amber-200 hover:bg-emerald-900/40 transition cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
