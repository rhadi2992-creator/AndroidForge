import React, { useState, useEffect } from 'react';
import { X, Sparkles, ShieldCheck, Heart, AlertCircle, Award } from 'lucide-react';
import { soundService } from '../services/soundService';
import { adMobService } from '../services/adMobService';

interface AdMobInterstitialProps {
  isRewarded?: boolean;
  rewardType?: 'fiftyFifty' | 'hint' | 'extraTime';
  onRewardEarned?: (type: 'fiftyFifty' | 'hint' | 'extraTime') => void;
  onClose: () => void;
}

export const AdMobInterstitial: React.FC<AdMobInterstitialProps> = ({
  isRewarded = false,
  rewardType = 'hint',
  onRewardEarned,
  onClose,
}) => {
  const initialDuration = isRewarded ? 10 : 5; // 10s for Rewarded Ad, 5s for Interstitial
  const [countdown, setCountdown] = useState(initialDuration);
  const [completed, setCompleted] = useState(false);
  const [showExitConfirm, setShowExitConfirm] = useState(false);

  const config = adMobService.getConfig();
  const mode = adMobService.getMode();
  const currentUnitId = isRewarded ? config.rewardedAdUnitId : config.interstitialAdUnitId;

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          setCompleted(true);
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleFinish = () => {
    soundService.playButtonClick();
    if (isRewarded && completed && onRewardEarned) {
      soundService.playDailyReward();
      onRewardEarned(rewardType);
    } else {
      adMobService.recordInterstitialShown();
    }
    onClose();
  };

  const handleAttemptClose = () => {
    if (isRewarded && !completed) {
      // Warn user they will lose reward
      setShowExitConfirm(true);
    } else {
      handleFinish();
    }
  };

  const progressPercent = Math.min(100, Math.round(((initialDuration - countdown) / initialDuration) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-gradient-to-b from-[#063324] via-[#021f15] to-[#01140e] border border-amber-500/40 p-6 shadow-2xl text-amber-50 relative flex flex-col items-center text-center">
        {/* Top Header: AdMob Type & Unit ID */}
        <div className="w-full flex items-center justify-between pb-3 border-b border-emerald-800/40 mb-3">
          <div className="flex flex-col items-start text-left">
            <div className="flex items-center gap-1.5">
              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded uppercase font-mono tracking-wider ${
                isRewarded
                  ? 'bg-amber-500/30 text-amber-300 border border-amber-500/50'
                  : 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/50'
              }`}>
                {isRewarded ? "AdMob Rewarded Video" : "AdMob Interstitial Ad"}
              </span>
              <span className="text-[10px] text-stone-400">
                {mode === 'production' ? 'Live' : 'Test'}
              </span>
            </div>
            <span className="text-[9px] font-mono text-stone-400 truncate max-w-[210px]" title={currentUnitId}>
              {currentUnitId}
            </span>
          </div>

          <button
            onClick={handleAttemptClose}
            className="p-1 rounded-full bg-emerald-950/80 border border-amber-400/40 text-amber-300 hover:text-white transition cursor-pointer"
            title={completed ? "Close" : "Exit"}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Progress Bar for Rewarded / Interstitial Video */}
        <div className="w-full bg-stone-900 rounded-full h-1.5 mb-4 overflow-hidden border border-emerald-800/40">
          <div
            className="bg-gradient-to-r from-amber-400 to-amber-600 h-1.5 transition-all duration-1000 ease-linear rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Ad Body Showcase */}
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 p-1 mb-3 shadow-lg flex items-center justify-center">
          <div className="w-full h-full rounded-[14px] bg-[#042017] flex items-center justify-center">
            {isRewarded ? (
              <Award className="w-10 h-10 text-amber-400" />
            ) : (
              <Heart className="w-10 h-10 text-amber-400 fill-amber-400" />
            )}
          </div>
        </div>

        <h3 className="font-extrabold text-base sm:text-lg text-amber-100 mb-1">
          {isRewarded ? "Islamic Lifeline Sponsor" : "Support Islamic Education Worldwide"}
        </h3>
        <p className="text-xs text-emerald-200/80 mb-5 leading-relaxed px-2">
          {isRewarded
            ? completed
              ? `You completed the video! Claim your free ${rewardType === 'fiftyFifty' ? '50:50 Lifeline' : rewardType === 'extraTime' ? 'Extra Time' : 'Context Hint'} now.`
              : `Watch completely to receive your free ${rewardType === 'fiftyFifty' ? '50:50 Lifeline' : rewardType === 'extraTime' ? 'Extra Time' : 'Context Hint'}.`
            : "Engage with verified Islamic educational initiatives, daily prayers, and Quranic recitation."}
        </p>

        {/* CTA Button */}
        <div className="w-full">
          {completed ? (
            <button
              onClick={handleFinish}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-stone-950 font-bold text-xs hover:scale-[1.02] active:scale-95 transition shadow-lg cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>{isRewarded ? "Claim Lifeline & Resume Quiz" : "Close & Continue"}</span>
            </button>
          ) : (
            <div className="w-full py-2.5 rounded-xl bg-stone-900/60 border border-emerald-800/40 text-xs text-stone-400 font-mono">
              {isRewarded ? `Reward unlocking in ${countdown}s...` : `Skip allowed in ${countdown}s...`}
            </div>
          )}
        </div>
      </div>

      {/* Early Exit Confirmation for Rewarded Ads */}
      {showExitConfirm && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-xs rounded-2xl bg-[#041c13] border border-amber-500/40 p-5 text-center shadow-2xl">
            <AlertCircle className="w-10 h-10 text-amber-400 mx-auto mb-2" />
            <h4 className="font-bold text-sm text-amber-100 mb-1">
              Leave without Lifeline?
            </h4>
            <p className="text-xs text-stone-300 mb-4 leading-relaxed">
              If you exit now before the video ends, your reward will not be credited.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-2 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs hover:bg-amber-400 transition cursor-pointer"
              >
                Resume Video
              </button>
              <button
                onClick={() => {
                  setShowExitConfirm(false);
                  onClose();
                }}
                className="flex-1 py-2 rounded-xl bg-emerald-950 border border-emerald-700/40 text-stone-400 text-xs hover:text-white transition cursor-pointer"
              >
                Exit Anyway
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
