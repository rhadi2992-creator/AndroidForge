/**
 * TypeScript interfaces and types for Islamic Knowledge Challenge – Deen Quiz
 */

export type Language = 'en' | 'ur' | 'roman';

export type Difficulty = 'easy' | 'medium' | 'hard' | 'expert';

export type GameMode = 'quick' | 'category' | 'level' | 'daily';

export interface LocalizedString {
  en: string;
  ur: string;
  roman: string;
}

export interface LocalizedArray {
  en: string[];
  ur: string[];
  roman: string[];
}

export interface Question {
  id: number;
  categoryId: number;
  difficulty: Difficulty;
  question: LocalizedString;
  options: LocalizedArray;
  correctAnswer: number; // 0, 1, 2, or 3
  reference: LocalizedString; // Authentic Quran or Hadith citation
  explanation: LocalizedString; // Educational context
}

export interface Category {
  id: number;
  name: LocalizedString;
  description: LocalizedString;
  iconName: string;
  gradient: string;
  accentColor: string;
}

export interface LevelConfig {
  level: number;
  title: LocalizedString;
  tier: 'beginner' | 'basic' | 'intermediate' | 'advanced' | 'expert';
  difficulty: Difficulty;
  requiredStarsToUnlock: number;
  targetScoreToPass: number; // e.g. 7 out of 10
  questionIds: number[];
}

export interface LevelProgress {
  level: number;
  unlocked: boolean;
  completed: boolean;
  stars: number; // 0 to 3
  highScore: number;
}

export interface DailyChallengeRecord {
  date: string; // YYYY-MM-DD
  completed: boolean;
  score: number;
  accuracy: number;
}

export interface UserStats {
  totalScore: number;
  highScore: number;
  totalQuizzesPlayed: number;
  totalQuestionsAnswered: number;
  totalCorrectAnswers: number;
  coins: number;
  currentStreak: number;
  bestStreak: number;
  lastPlayedDate: string;
  categoryScores: Record<number, { attempted: number; correct: number }>;
  levelProgress: Record<number, LevelProgress>;
  dailyHistory: Record<string, DailyChallengeRecord>;
  lifelines: {
    fiftyFifty: number;
    hint: number;
    extraTime: number;
  };
}

export interface AudioSettings {
  musicEnabled: boolean;
  musicVolume: number; // 0.0 to 1.0
  sfxEnabled: boolean;
  sfxVolume: number; // 0.0 to 1.0
  musicTrack: 'naat_mp3' | 'ambient_nasheed' | 'meditation_drone' | 'custom';
  customAudioUrl?: string;
  customAudioName?: string;
}

export interface UserPreferences {
  language: Language;
  theme: 'emerald' | 'gold' | 'midnight';
  showAdPlaceholders: boolean;
  adMobMode: 'production' | 'test';
}

export interface QuizQuestionResult {
  question: Question;
  selectedOption: number | null; // null if timed out
  isCorrect: boolean;
  timeSpentSeconds: number;
  pointsEarned: number;
}

export interface QuizSummary {
  mode: GameMode;
  categoryTitle?: string;
  levelNumber?: number;
  totalQuestions: number;
  correctCount: number;
  incorrectCount: number;
  totalScore: number;
  accuracyPercentage: number;
  starsEarned: number;
  timeSpentSeconds: number;
  results: QuizQuestionResult[];
  unlockedNextLevel?: boolean;
}
