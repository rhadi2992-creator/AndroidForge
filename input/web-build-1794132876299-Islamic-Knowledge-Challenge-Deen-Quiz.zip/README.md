# Islamic Knowledge Challenge – Deen Quiz ☪️

A premium, full-featured Islamic Quiz Game built with React 19, TypeScript, Tailwind CSS, Lucide Icons, and Google AdMob.

## Features
- **200+ Verified Authentic Questions** across 10 authentic categories (Quran, Hadith, Seerat, Islamic History, Prophets, General Knowledge, Sahaba, Five Pillars, Islamic Months, Basic Education).
- **Randomized Answer Positions**: Fisher-Yates shuffled options distributed fairly across A, B, C, and D.
- **Background Naat Audio**: "Meri Baat Ban Gayi Hai" by Ghulam Mustafa Qadri playing continuously with volume slider, play/pause, and auto-ducking during question feedback.
- **Google AdMob Integration**: Preconfigured with adaptive Banner, App Open, Interstitial, Native, and Rewarded video ads.
- **20 Unlockable Levels**: Tiered progression from Beginner to Expert.
- **Daily Islamic Challenge**: Date-synchronized 10 questions with streak counter and daily bonuses.
- **Multilingual Support**: English, Urdu (اردو with Nastaliq typography and RTL), and Roman Urdu.

## Running Locally

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start the development server**:
   ```bash
   npm run dev
   ```
   Open http://localhost:3000 in your browser.

3. **Build for production**:
   ```bash
   npm run build
   ```

## Android APK Packaging (Capacitor)

1. Install Capacitor:
   ```bash
   npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor-community/admob
   npx cap init "Deen Quiz" "com.islamic.deenquiz" --web-dir=dist
   npm run build
   npx cap add android
   npx cap sync android
   ```

2. Open Android Studio:
   ```bash
   npx cap open android
   ```

3. Build Signed Bundle / APK in Android Studio:
   **Build → Generate Signed Bundle / APK**
