# AndroidForge build entry point

This ZIP is arranged so the Android Gradle build is at the workspace root.

Run the release build with the working directory set to the directory containing
`settings.gradle.kts` (this directory), then execute:

```bash
gradle assembleRelease
```

The settings file includes `:app`. This project uses the Android Gradle Plugin
8.7.2 and Kotlin Android plugin 2.0.21. Use JDK 17.

The original archive did not contain Gradle Wrapper files (`gradlew`,
`gradlew.bat`, or `gradle/wrapper/*`). AndroidForge's logged command invokes
the installed `gradle` executable directly, so wrapper files are not needed
for that exact command. No wrapper was fabricated.

The app loads `file:///android_asset/index.html`. The source archive did not
contain `app/src/main/assets/index.html`; follow `README_ANDROID.md` to run
the Vite web build and copy `dist/*` into `app/src/main/assets/` before
packaging an app that should launch the bundled game UI.
