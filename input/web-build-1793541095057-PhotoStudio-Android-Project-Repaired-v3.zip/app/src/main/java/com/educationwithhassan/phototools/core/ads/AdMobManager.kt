package com.educationwithhassan.phototools.core.ads

import android.app.Activity
import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.educationwithhassan.phototools.BuildConfig
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.util.Date
import java.util.concurrent.atomic.AtomicBoolean

/**
 * AdMobManager
 * Enterprise-grade controller for Google Mobile Ads SDK in Photo Studio.
 * Real AdMob IDs provided by Rana Hassan:
 * App ID: ca-app-pub-3133971041724338~9005687005
 * Banner: ca-app-pub-3133971041724338/3865488076
 * Interstitial: ca-app-pub-3133971041724338/5890558170
 * App Open: ca-app-pub-3133971041724338/4681418283
 * Native Advanced: ca-app-pub-3133971041724338/1973374792
 * Rewarded: ca-app-pub-3133971041724338/4986998055
 */
object AdMobManager {
    private const val TAG = "AdMobManager"

    // Production Unit IDs
    const val REAL_APP_ID = "ca-app-pub-3133971041724338~9005687005"
    private const val PROD_APP_OPEN_ID = "ca-app-pub-3133971041724338/4681418283"
    private const val PROD_BANNER_ID = "ca-app-pub-3133971041724338/3865488076"
    private const val PROD_INTERSTITIAL_ID = "ca-app-pub-3133971041724338/5890558170"
    private const val PROD_NATIVE_ID = "ca-app-pub-3133971041724338/1973374792"
    private const val PROD_REWARDED_ID = "ca-app-pub-3133971041724338/4986998055"

    // Official Google Test IDs (Used automatically in debug builds)
    private const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257399415"
    private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    private const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    private const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    private const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    fun getAppOpenUnitId(): String = if (BuildConfig.DEBUG) TEST_APP_OPEN_ID else PROD_APP_OPEN_ID
    fun getBannerUnitId(): String = if (BuildConfig.DEBUG) TEST_BANNER_ID else PROD_BANNER_ID
    fun getInterstitialUnitId(): String = if (BuildConfig.DEBUG) TEST_INTERSTITIAL_ID else PROD_INTERSTITIAL_ID
    fun getNativeUnitId(): String = if (BuildConfig.DEBUG) TEST_NATIVE_ID else PROD_NATIVE_ID
    fun getRewardedUnitId(): String = if (BuildConfig.DEBUG) TEST_REWARDED_ID else PROD_REWARDED_ID

    // App Open Ad State
    private var appOpenAd: AppOpenAd? = null
    private var isAppOpenLoading = false
    private var appOpenLoadTime: Long = 0
    private var isShowingAppOpen = false

    // Interstitial Ad State
    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false
    private var lastInterstitialShowTime: Long = 0
    private const val INTERSTITIAL_COOLDOWN_MS = 45_000L // 45 seconds cooldown

    // Rewarded Ad State
    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    private val isInitialized = AtomicBoolean(false)

    fun initialize(context: Context, onComplete: () -> Unit = {}) {
        if (isInitialized.compareAndSet(false, true)) {
            MobileAds.initialize(context) { status ->
                Log.d(TAG, "AdMob MobileAds initialized. Preloading ad inventory...")
                preloadAds(context)
                onComplete()
            }
        }
    }

    fun preloadAds(context: Context) {
        loadAppOpenAd(context)
        loadInterstitial(context)
        loadRewardedAd(context)
    }

    // ==================== APP OPEN ADS ====================
    fun loadAppOpenAd(context: Context) {
        if (isAppOpenLoading || isAppOpenAdAvailable()) return
        isAppOpenLoading = true

        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            context,
            getAppOpenUnitId(),
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    isAppOpenLoading = false
                    appOpenLoadTime = Date().time
                    Log.d(TAG, "App Open Ad loaded successfully.")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    isAppOpenLoading = false
                    appOpenAd = null
                    Log.w(TAG, "App Open Ad failed to load: ${loadAdError.message}")
                }
            }
        )
    }

    fun isAppOpenAdAvailable(): Boolean {
        val numHours = (Date().time - appOpenLoadTime) / (3600000)
        return appOpenAd != null && numHours < 4
    }

    fun showAppOpenAdIfAvailable(activity: Activity, onDismissed: () -> Unit = {}) {
        if (isShowingAppOpen) {
            onDismissed()
            return
        }

        if (!isAppOpenAdAvailable()) {
            loadAppOpenAd(activity)
            onDismissed()
            return
        }

        appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                isShowingAppOpen = true
            }

            override fun onAdDismissedFullScreenContent() {
                appOpenAd = null
                isShowingAppOpen = false
                loadAppOpenAd(activity)
                onDismissed()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                appOpenAd = null
                isShowingAppOpen = false
                loadAppOpenAd(activity)
                onDismissed()
            }
        }

        appOpenAd?.show(activity)
    }

    // ==================== INTERSTITIAL ADS ====================
    fun loadInterstitial(context: Context) {
        if (isInterstitialLoading || interstitialAd != null) return
        isInterstitialLoading = true

        val request = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            getInterstitialUnitId(),
            request,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    Log.d(TAG, "Interstitial Ad loaded.")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                    Log.w(TAG, "Interstitial failed to load: ${loadAdError.message}")
                }
            }
        )
    }

    fun showInterstitialIfReady(activity: Activity, onClosed: () -> Unit) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInterstitialShowTime < INTERSTITIAL_COOLDOWN_MS) {
            // Frequency capped
            onClosed()
            return
        }

        val ad = interstitialAd
        if (ad == null) {
            loadInterstitial(activity)
            onClosed()
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                lastInterstitialShowTime = SystemClock.elapsedRealtime()
                loadInterstitial(activity)
                onClosed()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                interstitialAd = null
                loadInterstitial(activity)
                onClosed()
            }
        }

        ad.show(activity)
    }

    // ==================== REWARDED ADS ====================
    fun loadRewardedAd(context: Context) {
        if (isRewardedLoading || rewardedAd != null) return
        isRewardedLoading = true

        val request = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            getRewardedUnitId(),
            request,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    Log.d(TAG, "Rewarded Ad loaded and ready.")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                    Log.w(TAG, "Rewarded Ad failed to load: ${loadAdError.message}")
                }
            }
        )
    }

    fun isRewardedAdReady(): Boolean = rewardedAd != null

    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: (RewardItem) -> Unit,
        onAdClosed: (Boolean) -> Unit
    ) {
        val ad = rewardedAd
        if (ad == null) {
            loadRewardedAd(activity)
            onAdClosed(false)
            return
        }

        var rewardGranted = false

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                loadRewardedAd(activity)
                onAdClosed(rewardGranted)
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                rewardedAd = null
                loadRewardedAd(activity)
                onAdClosed(false)
            }
        }

        ad.show(activity) { rewardItem ->
            if (!rewardGranted) {
                rewardGranted = true
                onRewardEarned(rewardItem)
            }
        }
    }

    // ==================== NATIVE ADVANCED ADS ====================
    fun loadNativeAd(context: Context, onAdLoaded: (NativeAd) -> Unit, onAdFailed: () -> Unit = {}) {
        val builder = AdLoader.Builder(context, getNativeUnitId())
            .forNativeAd { nativeAd ->
                onAdLoaded(nativeAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.w(TAG, "Native ad failed to load: ${loadAdError.message}")
                    onAdFailed()
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
                    .build()
            )

        builder.build().loadAd(AdRequest.Builder().build())
    }
}