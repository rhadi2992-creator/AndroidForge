pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Not required by any current dependency (PdfBox-Android ships on Maven Central
        // directly), kept here only in case you add a JitPack-hosted library later.
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "SmartPdfAI"
include(":app")
