import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Loads keystore.properties from the project root if it exists. This file is
// gitignored on purpose — see keystore.properties.template for setup instructions.
// If the file is missing (e.g. a fresh clone, or CI without secrets), release
// builds simply fall back to being unsigned rather than failing the whole build.
val keystorePropertiesFile = rootProject.file("keystore.properties")
val keystoreProperties = Properties()
val hasSigningConfig = keystorePropertiesFile.exists()
if (hasSigningConfig) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    namespace = "com.educationwithhassan.smartpdfai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.educationwithhassan.smartpdfai"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        // Toggle AdMob module at build time. false = ads module fully disabled, no network calls.
        buildConfigField("boolean", "ENABLE_ADS", "false")
        // Official Google test ad unit IDs (safe to ship in debug, NEVER use in release).
        buildConfigField("String", "ADMOB_APP_ID", "\"ca-app-pub-3940256099942544~3347511713\"")
        buildConfigField("String", "ADMOB_BANNER_TEST_ID", "\"ca-app-pub-3940256099942544/9214589741\"")
    }

    signingConfigs {
        if (hasSigningConfig) {
            create("release") {
                storeFile = rootProject.file(keystoreProperties.getProperty("storeFile"))
                storePassword = keystoreProperties.getProperty("storePassword")
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            buildConfigField("boolean", "ENABLE_ADS", "false")
        }
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Flip to "true" once you have added your OWN production AdMob app ID
            // in AndroidManifest.xml and replaced the test ad unit ID below.
            buildConfigField("boolean", "ENABLE_ADS", "false")
            // Only attaches a signing config if keystore.properties exists (see above).
            // Without it, `./gradlew assembleRelease` still builds, just unsigned —
            // OPPO/Google Play will reject an unsigned build, so you MUST set this up
            // before submitting. See README.md > Stage 6 > Release Signing.
            if (hasSigningConfig) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Core / Compose
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.11.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.4")

    // Lightweight image loading for thumbnails (Image to PDF picker)
    implementation("io.coil-kt:coil-compose:2.7.0")

    // DataStore for Recent Files history + settings (no SQL needed)
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // PDF creation / merge / split / compress / text extraction (Apache 2.0 license)
    // Published on Maven Central under this group (NOT the old JitPack coordinate).
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")

    // Optional AdMob module (only loaded if ENABLE_ADS = true at runtime/build)
    implementation("com.google.android.gms:play-services-ads:23.5.0")

    // Testing
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.11.00"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
