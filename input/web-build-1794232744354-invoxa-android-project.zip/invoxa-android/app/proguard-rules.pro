# Invoxa Proguard Rules for Release Build

# Room Database
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# Google Play Services & AdMob
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.ads.** { *; }
-dontwarn com.google.android.gms.ads.**

# Keep Data Models & Entities
-keep class com.educationwithhassan.invoxa.data.local.entity.** { *; }
-keep class com.educationwithhassan.invoxa.data.model.** { *; }
