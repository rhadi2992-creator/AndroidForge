package com.educationwithhassan.invoxa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.educationwithhassan.invoxa.ui.screens.*
import com.educationwithhassan.invoxa.ui.theme.InvoxaTheme
import com.educationwithhassan.invoxa.ui.viewmodel.InvoiceViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as InvoxaApp

        setContent {
            var isDarkMode by remember { mutableStateOf(false) }

            InvoxaTheme(darkTheme = isDarkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    val viewModel: InvoiceViewModel = viewModel(
                        factory = InvoiceViewModel.provideFactory(app.repository)
                    )

                    NavHost(navController = navController, startDestination = "dashboard") {
                        composable("dashboard") {
                            DashboardScreen(navController = navController, viewModel = viewModel)
                        }
                        composable("create_invoice") {
                            CreateInvoiceScreen(navController = navController, viewModel = viewModel)
                        }
                        composable("invoice_history") {
                            InvoiceHistoryScreen(navController = navController, viewModel = viewModel)
                        }
                        composable("create_receipt") {
                            CreateReceiptScreen(navController = navController, viewModel = viewModel)
                        }
                        composable("customers") {
                            CustomerManagementScreen(navController = navController, viewModel = viewModel)
                        }
                        composable("products") {
                            ProductManagementScreen(navController = navController, viewModel = viewModel)
                        }
                        composable("settings") {
                            SettingsScreen(
                                navController = navController,
                                isDarkTheme = isDarkMode,
                                onToggleTheme = { isDarkMode = !isDarkMode }
                            )
                        }
                    }
                }
            }
        }
    }
}
