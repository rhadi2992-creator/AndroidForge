package com.educationwithhassan.invoxa.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.educationwithhassan.invoxa.data.local.entity.ReceiptEntity
import com.educationwithhassan.invoxa.pdf.PdfReceiptGenerator
import com.educationwithhassan.invoxa.ui.viewmodel.InvoiceViewModel
import com.educationwithhassan.invoxa.util.CurrencyFormatter
import com.educationwithhassan.invoxa.util.FileUtil
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateReceiptScreen(
    navController: NavController,
    viewModel: InvoiceViewModel
) {
    val context = LocalContext.current
    val receipts by viewModel.receipts.collectAsState()

    var customerName by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("Bank Transfer") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Receipts & Payments") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Issue New Payment Receipt", fontWeight = FontWeight.Bold)

            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it },
                label = { Text("Customer Name") },
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Amount Received") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = paymentMethod,
                    onValueChange = { paymentMethod = it },
                    label = { Text("Method") },
                    modifier = Modifier.weight(1f)
                )
            }

            Button(
                onClick = {
                    val parsed = amount.toDoubleOrNull() ?: 0.0
                    val receipt = ReceiptEntity(
                        id = UUID.randomUUID().toString(),
                        receiptNumber = "REC-${System.currentTimeMillis().toString().takeLast(6)}",
                        businessName = "Apex Studio",
                        customerName = customerName.ifBlank { "Client" },
                        paymentDate = "2026-11-09",
                        paymentMethod = paymentMethod,
                        amountReceived = parsed,
                        currencyCode = "USD",
                        transactionReference = "TXN-${System.currentTimeMillis().toString().takeLast(4)}",
                        notes = "Payment received with thanks."
                    )
                    viewModel.saveReceipt(receipt)
                    val pdf = PdfReceiptGenerator.generateReceiptPdf(context, receipt)
                    FileUtil.sharePdf(context, pdf)
                    customerName = ""
                    amount = ""
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save & Share PDF Receipt")
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("Past Receipts (${receipts.size})", fontWeight = FontWeight.Bold)

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(receipts) { r ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(r.receiptNumber, fontWeight = FontWeight.Bold)
                                Text(r.customerName, style = MaterialTheme.typography.bodyMedium)
                                Text(r.paymentDate, style = MaterialTheme.typography.labelSmall)
                            }
                            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                                Text(
                                    CurrencyFormatter.format(r.amountReceived, r.currencyCode),
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                IconButton(onClick = {
                                    val pdf = PdfReceiptGenerator.generateReceiptPdf(context, r)
                                    FileUtil.sharePdf(context, pdf)
                                }) {
                                    Icon(Icons.Default.Share, contentDescription = "Share")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
