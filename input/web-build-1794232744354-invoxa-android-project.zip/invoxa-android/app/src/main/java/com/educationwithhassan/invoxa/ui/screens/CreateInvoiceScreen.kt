package com.educationwithhassan.invoxa.ui.screens

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.educationwithhassan.invoxa.ads.AdMobManager
import com.educationwithhassan.invoxa.data.local.entity.InvoiceEntity
import com.educationwithhassan.invoxa.pdf.PdfInvoiceGenerator
import com.educationwithhassan.invoxa.ui.viewmodel.InvoiceViewModel
import com.educationwithhassan.invoxa.util.FileUtil
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateInvoiceScreen(
    navController: NavController,
    viewModel: InvoiceViewModel
) {
    val context = LocalContext.current
    val activity = context as? Activity

    var invoiceNumber by remember { mutableStateOf("INV-${System.currentTimeMillis().toString().takeLast(6)}") }
    var customerName by remember { mutableStateOf("") }
    var customerEmail by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var customerAddress by remember { mutableStateOf("") }
    var invoiceDate by remember { mutableStateOf("2026-11-09") }
    var dueDate by remember { mutableStateOf("2026-11-23") }
    var currencyCode by remember { mutableStateOf("USD") }
    var amount by remember { mutableStateOf("1250.00") }
    var taxRate by remember { mutableStateOf("10") }
    var notes by remember { mutableStateOf("Thank you for your business. Due in 14 days.") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Create Invoice") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        val parsedAmount = amount.toDoubleOrNull() ?: 0.0
                        val parsedTax = (parsedAmount * ((taxRate.toDoubleOrNull() ?: 0.0) / 100.0))
                        val grandTotal = parsedAmount + parsedTax

                        val invoice = InvoiceEntity(
                            id = UUID.randomUUID().toString(),
                            invoiceNumber = invoiceNumber,
                            invoiceDate = invoiceDate,
                            dueDate = dueDate,
                            currencyCode = currencyCode,
                            templateId = "modern_blue",
                            status = "UNPAID",
                            customerId = "cust_local",
                            customerName = customerName.ifBlank { "Client" },
                            customerEmail = customerEmail,
                            customerPhone = customerPhone,
                            customerAddress = customerAddress,
                            itemsJson = "[]",
                            subtotal = parsedAmount,
                            totalDiscount = 0.0,
                            totalTax = parsedTax,
                            grandTotal = grandTotal,
                            amountPaid = 0.0,
                            remainingBalance = grandTotal,
                            paymentTerms = "Net 14 Days",
                            notes = notes
                        )
                        viewModel.saveInvoice(invoice)
                        if (activity != null) {
                            AdMobManager.showInterstitial(activity) {
                                navController.popBackStack()
                            }
                        } else {
                            navController.popBackStack()
                        }
                    }) {
                        Icon(Icons.Default.Save, contentDescription = "Save Invoice")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = invoiceNumber,
                onValueChange = { invoiceNumber = it },
                label = { Text("Invoice Number") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it },
                label = { Text("Customer Name *") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = customerEmail,
                onValueChange = { customerEmail = it },
                label = { Text("Customer Email") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = customerAddress,
                onValueChange = { customerAddress = it },
                label = { Text("Customer Address") },
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = invoiceDate,
                    onValueChange = { invoiceDate = it },
                    label = { Text("Issue Date") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = dueDate,
                    onValueChange = { dueDate = it },
                    label = { Text("Due Date") },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = currencyCode,
                    onValueChange = { currencyCode = it },
                    label = { Text("Currency") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Subtotal Amount") },
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes & Terms") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val parsedAmount = amount.toDoubleOrNull() ?: 0.0
                    val dummyInvoice = InvoiceEntity(
                        id = "temp_preview",
                        invoiceNumber = invoiceNumber,
                        invoiceDate = invoiceDate,
                        dueDate = dueDate,
                        currencyCode = currencyCode,
                        templateId = "modern_blue",
                        status = "UNPAID",
                        customerId = "cust_preview",
                        customerName = customerName.ifBlank { "Client Preview" },
                        customerEmail = customerEmail,
                        customerPhone = customerPhone,
                        customerAddress = customerAddress,
                        itemsJson = "[]",
                        subtotal = parsedAmount,
                        totalDiscount = 0.0,
                        totalTax = 0.0,
                        grandTotal = parsedAmount,
                        amountPaid = 0.0,
                        remainingBalance = parsedAmount,
                        paymentTerms = "Net 14 Days",
                        notes = notes
                    )
                    val pdfFile = PdfInvoiceGenerator.generateInvoicePdf(context, dummyInvoice)
                    FileUtil.sharePdf(context, pdfFile)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate & Share PDF")
            }
        }
    }
}
