# Smart PDF AI – PDF Tools

A privacy-first, fully offline Android PDF toolkit, built with Kotlin + Jetpack Compose.
Developer brand: **Education With Hassan**.

---

## 1. What's included (Stage 2 deliverable)

```
SmartPdfAI/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── .gitignore
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── kotlin/com/educationwithhassan/smartpdfai/
│       │   ├── MainActivity.kt
│       │   ├── navigation/AppNavGraph.kt
│       │   ├── ui/theme/ (Color.kt, Type.kt, Theme.kt)
│       │   ├── ui/home/HomeScreen.kt
│       │   ├── ui/reader/PdfReaderScreen.kt
│       │   ├── ui/imagetopdf/ImageToPdfScreen.kt
│       │   ├── ui/merge/MergeScreen.kt
│       │   ├── ui/split/SplitScreen.kt
│       │   ├── ui/compress/CompressScreen.kt
│       │   ├── ui/pdftoimages/PdfToImagesScreen.kt
│       │   ├── ui/pdftotext/PdfToTextScreen.kt
│       │   ├── ui/summarizer/SummarizerScreen.kt
│       │   ├── ui/recent/RecentFilesScreen.kt
│       │   ├── ui/settings/ (SettingsScreen.kt, InfoScreens.kt)
│       │   ├── core/pdf/PdfEngine.kt
│       │   ├── core/summarizer/ExtractiveSummarizer.kt
│       │   ├── core/storage/ (RecentFilesStore.kt, FileUtils.kt)
│       │   ├── core/data/RecentFileEntry.kt
│       │   └── ads/AdsModule.kt   (optional, disabled by default)
│       └── res/ (launcher icon, strings, theme XML)
└── docs/
    ├── PRIVACY_POLICY.md
    └── THIRD_PARTY_LICENSES.md
```

**Every feature listed in the brief is implemented with real, working code** — PDF
reading, image-to-PDF, merge, split (page range), compress (genuine image re-encoding
with real before/after sizes), PDF-to-images, PDF-to-text, an offline extractive
summarizer, Recent Files history, and Settings/About/Help/Privacy/Terms screens.

**One honest limitation:** PDF-to-Text only extracts text that already exists inside
the PDF. Scanned PDFs (pages that are really just photos of text) have no such text
layer — the app detects this and tells the user clearly, rather than faking a result.
Adding OCR later (e.g. with ML Kit Text Recognition) is possible but was intentionally
left out to keep this build dependency-light and fully offline, as requested.

---

## 1.5 Can't install Android Studio right now? Get a real APK without it

I (the AI) cannot compile this project myself — my sandbox doesn't have the Android
SDK or access to Google's dependency servers. But you don't have to install Android
Studio either if you just want to **test a working APK quickly**. This project
includes `.github/workflows/build-apk.yml`, which builds a real debug APK for you
automatically using GitHub's free servers:

1. Create a free account at `github.com` if you don't have one.
2. Create a new **public or private repository** (any name, e.g. `smartpdfai`).
3. Upload this entire `SmartPdfAI` folder's contents into that repository (on
   github.com you can drag-and-drop files/folders directly in the browser — no git
   command-line needed — using the "Add file > Upload files" button).
4. Go to the repo's **Actions** tab. A workflow called "Build Debug APK" will have
   started automatically (or click "Run workflow" if it didn't).
5. Wait 3–5 minutes for it to finish (green checkmark).
6. Click into the finished run → scroll to **Artifacts** → download
   `SmartPdfAI-debug-apk` → unzip it → you now have a real, installable
   `app-debug.apk` on your computer. Transfer it to your phone and tap to install.

This still only produces a **debug APK** (fine for testing on your own phone) — it is
NOT signed for store submission. For that, you still need Section 5's release-signing
steps, done locally in Android Studio where your keystore password stays private
(never put real keystore passwords into a workflow file like this without using
GitHub's encrypted Secrets feature).

---

## 2. Stage 3 — Dependency / compatibility review

| Item | Value | Why |
|---|---|---|
| AGP (Android Gradle Plugin) | 8.6.1 | Current stable, matches Studio Ladybug+ |
| Kotlin | 2.0.21 | Required for the Compose Compiler Gradle plugin |
| compileSdk / targetSdk | 35 (Android 15) | Current stable target |
| minSdk | 24 (Android 7.0) | ~98%+ device coverage, good beginner default |
| Jetpack Compose BOM | 2024.11.00 | Keeps all Compose libs on compatible versions |
| PdfBox-Android | 2.0.27.0 (via JitPack) | Actively maintained, Apache 2.0 license |
| Google Mobile Ads SDK | 23.5.0 | Latest at time of writing; only loads if `ENABLE_ADS=true` |

All versions above are mutually compatible as of this writing. If Android Studio's
IDE suggests a newer stable version when you open the project, it is safe to accept —
just re-sync Gradle afterward.

**Permissions check:** the manifest requests **zero** runtime permissions. Every file
operation goes through the system file picker (Storage Access Framework), as required
by the brief.

---

## 3. Stage 4 — Build & install a debug APK (step by step)

### Step 1 — Install Android Studio
Download and install Android Studio (latest stable) from
`developer.android.com/studio`. It bundles the JDK you need.

### Step 2 — Open the project
1. Launch Android Studio → **File > Open**.
2. Select the `SmartPdfAI` folder (the one containing `settings.gradle.kts`).
3. Wait for the initial Gradle sync to finish (bottom status bar). First sync can take
   a few minutes while it downloads dependencies — this requires an internet connection.

### Step 3 — Let Gradle sync successfully
If the sync shows errors, see the "Common first-sync issues" section below before
continuing.

### Step 4 — Build the debug APK
Two options:

**Option A — via the IDE (easiest for beginners):**
1. Menu: **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
2. When it finishes, click the "locate" link in the notification, or find the file at:
   `app/build/outputs/apk/debug/app-debug.apk`

**Option B — via terminal (inside the project folder):**
```
# macOS/Linux
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```
Output lands at the same path: `app/build/outputs/apk/debug/app-debug.apk`

### Step 5 — Install on your phone
1. On your Android phone: **Settings > About phone** → tap "Build number" 7 times to
   enable Developer Options.
2. **Settings > Developer Options** → enable **USB debugging**.
3. Connect your phone via USB, accept the "Allow USB debugging?" prompt.
4. In Android Studio, click the green **Run ▶** button with your device selected in
   the dropdown — it will install and launch the app automatically.

*(Alternative: copy `app-debug.apk` to your phone and tap it to install directly —
you'll need to allow "install unknown apps" for your file manager once.)*

### Common first-sync issues
- **"SDK location not found"** → Android Studio will prompt to auto-create
  `local.properties` pointing at your installed SDK. Accept it.
- **JitPack dependency fails to resolve (PdfBox-Android)** → check your internet
  connection; JitPack can be briefly slow on first fetch — retry the sync.
- **"Unsupported Gradle JDK"** → in Android Studio, go to
  **Settings > Build, Execution, Deployment > Build Tools > Gradle** and set
  "Gradle JDK" to the embedded JDK 17.

---

## 4. Stage 5 — If you hit a build error

Copy the **full, exact error text** from Android Studio's "Build" panel (not just the
red summary line) and send it over — mention which step above you were on. Most
first-time errors are SDK-path or JDK-version related and are quick fixes.

---

## 5. Stage 6 — Release signing (required before any store submission)

Google Play and OPPO App Market both reject unsigned/debug builds. Here's exactly
how to produce a real, signed release build with this project.

### Step 1 — Generate your keystore (do this ONCE, keep it forever)

Run this in a terminal (works on macOS/Linux/Windows — `keytool` ships with the JDK
that comes bundled in Android Studio):

```
keytool -genkeypair -v -keystore smartpdfai-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias smartpdfai
```

It will ask for:
- A keystore password (remember this — you cannot recover it if lost)
- Your name, organization, city, country (for the certificate — can be your dev brand)
- A key password (can be the same as the keystore password)

Put the resulting `smartpdfai-release.jks` file in your **project root** (next to
`settings.gradle.kts`), alongside this README.

**⚠️ CRITICAL:** Back this file up somewhere safe (password manager, encrypted drive).
If you lose it, you can NEVER publish an update to the same app listing again — you'd
have to publish as a brand-new app. Never commit it to GitHub (it's already excluded
in `.gitignore`).

### Step 2 — Fill in your keystore credentials

1. Copy `keystore.properties.template` → rename the copy to `keystore.properties`
   (same folder, project root).
2. Open it and replace the 4 placeholder values with what you used in Step 1.
3. This file is already gitignored — it will never be committed or uploaded.

The project's `app/build.gradle.kts` is already wired to read this file automatically
(see the top of the file and the `signingConfigs` block) — no further code changes
needed.

### Step 3 — Build the signed release

**Option A — Android Studio:**
**Build > Generate Signed App Bundle / APK** → choose **Android App Bundle (AAB)**
(preferred for stores) or **APK** → select your keystore file, enter the passwords
→ choose **release** → Finish.

**Option B — terminal:**
```
# macOS/Linux
./gradlew bundleRelease     # produces .aab (recommended)
./gradlew assembleRelease   # produces .apk

# Windows
gradlew.bat bundleRelease
gradlew.bat assembleRelease
```

Output:
- AAB: `app/build/outputs/bundle/release/app-release.aab`
- APK: `app/build/outputs/apk/release/app-release.apk`

If `keystore.properties` is missing, the release build will still compile but will
be **unsigned** — Gradle won't error out, but neither OPPO nor Google Play will
accept that file. Always confirm Step 2 is done before building what you'll submit.

### Step 4 — Verify it's actually signed (optional but reassuring)
```
apksigner verify --verbose app/build/outputs/apk/release/app-release.apk
```
(`apksigner` ships in `<Android SDK>/build-tools/<version>/`.) You should see
"Verified using v2/v3 scheme" with no errors.

---

## 6. Stage 6 — Remaining steps

1. ✅ Release signing — done above.
2. **Hosting the privacy policy** — turn `docs/PRIVACY_POLICY.md` into a public URL
   (e.g. free GitHub Pages: create a public repo, enable Pages in repo Settings,
   point it at this file).
3. **AdMob setup** — register your own app + ad units in YOUR AdMob console, then
   flip `ENABLE_ADS` to `true` in `app/build.gradle.kts` and replace the test IDs
   with your own production ones — only after your own testing.
4. **OPPO App Market submission** — register at developers.oppomobile.com, verify
   your developer identity, then submit the signed AAB/APK from Step 3 above along
   with your icon, screenshots, and the privacy policy URL from step 2.

---

## 6. Important honesty notes

- This project has **not** been built or tested by the assistant that generated it —
  I (the AI) cannot run Android Studio. Please build it yourself following Section 3
  and report back any errors.
- No claim is made that this app is or will be approved by Google Play or the OPPO
  App Market — approval is solely at those platforms' discretion.
- AdMob is **disabled by default** (`ENABLE_ADS = false`). Do not flip it on and ship
  to real users until you've set up your own AdMob account (Stage 6).
