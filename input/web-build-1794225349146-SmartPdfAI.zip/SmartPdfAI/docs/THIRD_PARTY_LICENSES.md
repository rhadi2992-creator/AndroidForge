# Third-Party Libraries & Licenses

This app is built with the following open-source libraries. All are redistribution-safe
for a commercial/public app, provided their license notices are preserved (standard for
Apache 2.0, which every library below uses).

| Library | Purpose | License |
|---|---|---|
| AndroidX Core, Compose, Navigation, Lifecycle, Activity | UI framework | Apache License 2.0 |
| AndroidX DataStore | Local Recent Files history & settings | Apache License 2.0 |
| AndroidX DocumentFile | Folder-based image export (PDF to Images) | Apache License 2.0 |
| PdfBox-Android (TomRoush) | PDF create/merge/split/compress/text-extract | Apache License 2.0 |
| Coil (coil-kt) | Image thumbnail loading | Apache License 2.0 |
| Google Mobile Ads SDK (play-services-ads) | Optional banner ads (disabled by default) | Google Play Services Terms |
| Kotlin Coroutines | Background PDF processing | Apache License 2.0 |

Android's built-in `android.graphics.pdf.PdfRenderer` (used for the PDF Reader and
PDF-to-Images rendering) is part of the Android SDK itself and requires no separate
license entry.

Full license texts:
- Apache License 2.0: https://www.apache.org/licenses/LICENSE-2.0
- Google Play Services Terms: https://developers.google.com/android/guides/opensource

Before submitting to OPPO App Market or Google Play, most stores expect an in-app
"Open Source Licenses" screen or this file to be reachable from your store listing —
this document can be linked directly or copied into an in-app screen if required.
