# Privacy Policy — Smart PDF AI – PDF Tools

**Developer:** Education With Hassan
**Last updated:** _(fill in the date you publish this app)_

This is the same text shown inside the app (Settings > Privacy Policy). Host this file
(or its content) at a public URL before submitting to any app store — Google Play and
OPPO App Market both require a working, publicly reachable privacy policy link.

## 1. What we collect
We do not collect, store, or transmit your documents. All PDF processing (reading,
merging, splitting, compressing, converting, and summarizing) happens entirely on your
device. Your files are never uploaded to any server operated by us or any third party.

## 2. Local history
The "Recent Files" list is stored only on your device using Android's local DataStore
storage. It is never synced or uploaded. You can clear it at any time from the Recent
Files screen.

## 3. Permissions
This app does not request broad storage, camera, or contacts permissions. Files are
accessed only through Android's Storage Access Framework (the system file picker),
meaning you explicitly choose every file the app can read or write.

## 4. Advertising (if enabled)
If the optional advertising module is enabled in a future update, it will use Google's
Mobile Ads SDK and may collect data as described in Google's own privacy policy. Ads,
if shown, will never appear while you are selecting, viewing, or processing a document.
Users will be shown an in-app consent flow before any ad-related data processing begins,
in line with applicable consent requirements (e.g. Google's EU User Consent Policy and
UMP SDK).

## 5. Third-party libraries
This app uses open-source libraries that run locally and do not transmit your data
externally. See THIRD_PARTY_LICENSES.md for the full list.

## 6. Children's privacy
This app does not knowingly collect data from children and has no account or sign-in
system.

## 7. Changes to this policy
If this policy changes, the updated version will be published within the app and at
this hosted URL.

## 8. Contact
For questions about this policy, contact: _(insert your developer contact email here)_

---
**Before publishing:** replace both placeholder fields above (date, contact email),
host this content at a stable URL (e.g. a free GitHub Pages page), and put that URL
into your Google Play Console / OPPO Developer Console listing.
