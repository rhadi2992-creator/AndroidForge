package com.educationwithhassan.smartpdfai.core.storage

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.educationwithhassan.smartpdfai.core.data.RecentFileEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.recentFilesDataStore by preferencesDataStore(name = "recent_files")

/**
 * Persists the "Recent Files" history locally on-device via Jetpack DataStore.
 * Nothing here is ever uploaded anywhere.
 */
class RecentFilesStore(private val context: Context) {

    private val key = stringSetPreferencesKey("entries")

    val recentFiles: Flow<List<RecentFileEntry>> = context.recentFilesDataStore.data.map { prefs ->
        val raw = prefs[key] ?: emptySet()
        raw.mapNotNull { RecentFileEntry.decode(it) }
            .sortedByDescending { it.timestampMillis }
    }

    suspend fun addEntry(entry: RecentFileEntry) {
        context.recentFilesDataStore.edit { prefs ->
            val current = (prefs[key] ?: emptySet()).toMutableSet()
            current.add(RecentFileEntry.encode(entry))
            prefs[key] = current
        }
    }

    suspend fun removeEntry(entry: RecentFileEntry) {
        context.recentFilesDataStore.edit { prefs ->
            val current = (prefs[key] ?: emptySet()).toMutableSet()
            current.removeAll { RecentFileEntry.decode(it)?.id == entry.id }
            prefs[key] = current
        }
    }

    suspend fun clearAll() {
        context.recentFilesDataStore.edit { prefs -> prefs[key] = emptySet() }
    }
}
