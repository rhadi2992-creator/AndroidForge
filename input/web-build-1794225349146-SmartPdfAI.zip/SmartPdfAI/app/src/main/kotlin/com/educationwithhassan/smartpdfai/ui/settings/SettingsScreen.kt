package com.educationwithhassan.smartpdfai.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.educationwithhassan.smartpdfai.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            ListItem(
                headlineContent = { Text("About") },
                leadingContent = { Icon(Icons.Default.Info, contentDescription = null) },
                modifier = Modifier.clickableNav { onNavigate(Routes.ABOUT) }
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Help") },
                leadingContent = { Icon(Icons.Default.HelpOutline, contentDescription = null) },
                modifier = Modifier.clickableNav { onNavigate(Routes.HELP) }
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Privacy Policy") },
                leadingContent = { Icon(Icons.Default.PrivacyTip, contentDescription = null) },
                modifier = Modifier.clickableNav { onNavigate(Routes.PRIVACY) }
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Terms of Use") },
                leadingContent = { Icon(Icons.Default.Description, contentDescription = null) },
                modifier = Modifier.clickableNav { onNavigate(Routes.TERMS) }
            )
            HorizontalDivider()
        }
    }
}

private fun Modifier.clickableNav(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
