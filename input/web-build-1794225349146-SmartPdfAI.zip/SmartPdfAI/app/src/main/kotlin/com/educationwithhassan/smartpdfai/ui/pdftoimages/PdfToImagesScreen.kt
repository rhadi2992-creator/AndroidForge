package com.educationwithhassan.smartpdfai.ui.pdftoimages

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.educationwithhassan.smartpdfai.core.data.RecentFileEntry
import com.educationwithhassan.smartpdfai.core.pdf.PdfEngine
import com.educationwithhassan.smartpdfai.core.storage.FileUtils
import com.educationwithhassan.smartpdfai.core.storage.RecentFilesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfToImagesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recentStore = remember { RecentFilesStore(context) }

    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var sourceName by remember { mutableStateOf("") }
    var pageCount by remember { mutableIntStateOf(0) }
    var selectedPages by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var isProcessing by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var cachedSourceFile by remember { mutableStateOf<File?>(null) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            sourceUri = uri
            sourceName = FileUtils.queryDisplayName(context, uri)
            resultMessage = null
            scope.launch {
                val cached = withContext(Dispatchers.IO) { FileUtils.copyUriToCacheFile(context, uri, sourceName) }
                cachedSourceFile = cached
                pageCount = withContext(Dispatchers.IO) { PdfEngine.getPageCount(cached) }
                selectedPages = (0 until pageCount).toSet() // default: select all pages
            }
        }
    }

    // Lets the user pick a folder (tree Uri) to export multiple images into.
    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            val cached = cachedSourceFile ?: return@rememberLauncherForActivityResult
            scope.launch {
                isProcessing = true
                errorMessage = null
                resultMessage = null
                try {
                    val outputDir = File(context.cacheDir, "pdf_images_${System.currentTimeMillis()}")
                    outputDir.mkdirs()
                    val images = withContext(Dispatchers.IO) {
                        PdfEngine.pdfToImages(cached, selectedPages.sorted(), outputDir)
                    }
                    val docTree = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, treeUri)
                    var savedCount = 0
                    withContext(Dispatchers.IO) {
                        for (img in images) {
                            val newFile = docTree?.createFile("image/jpeg", img.nameWithoutExtension)
                            if (newFile != null) {
                                FileUtils.writeFileToUri(context, img, newFile.uri)
                                savedCount++
                            }
                        }
                    }
                    recentStore.addEntry(
                        RecentFileEntry(
                            id = UUID.randomUUID().toString(),
                            displayName = "$savedCount images from $sourceName",
                            toolName = "PDF to Images",
                            uri = treeUri.toString(),
                            timestampMillis = System.currentTimeMillis(),
                            fileSizeBytes = images.sumOf { it.length() }
                        )
                    )
                    resultMessage = "Saved $savedCount image(s) to the selected folder."
                } catch (e: Exception) {
                    errorMessage = "Failed to export images: ${e.message}"
                } finally {
                    isProcessing = false
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PDF to Images") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Button(onClick = { filePicker.launch(arrayOf("application/pdf")) }) {
                Icon(Icons.Default.FolderOpen, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Choose PDF")
            }
            Spacer(Modifier.height(12.dp))

            if (sourceUri != null) {
                Text(sourceName, style = MaterialTheme.typography.titleMedium)
                Text("$pageCount pages — tap to select/deselect pages to export", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(10.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(pageCount) { index ->
                        val selected = index in selectedPages
                        FilterChip(
                            selected = selected,
                            onClick = {
                                selectedPages = if (selected) selectedPages - index else selectedPages + index
                            },
                            label = { Text("${index + 1}") }
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error); Spacer(Modifier.height(8.dp)) }
                resultMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary); Spacer(Modifier.height(8.dp)) }

                Button(
                    onClick = { folderPicker.launch(null) },
                    enabled = selectedPages.isNotEmpty() && !isProcessing,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("Export ${selectedPages.size} Page(s) as Images")
                }
            } else {
                Spacer(Modifier.height(24.dp))
                Text("Choose a PDF to begin.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
