package com.educationwithhassan.smartpdfai.ui.compress

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.educationwithhassan.smartpdfai.core.data.RecentFileEntry
import com.educationwithhassan.smartpdfai.core.pdf.PdfEngine
import com.educationwithhassan.smartpdfai.core.storage.FileUtils
import com.educationwithhassan.smartpdfai.core.storage.RecentFilesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompressScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recentStore = remember { RecentFilesStore(context) }

    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var sourceName by remember { mutableStateOf("") }
    var originalSize by remember { mutableLongStateOf(0L) }
    var quality by remember { mutableFloatStateOf(0.5f) }
    var isProcessing by remember { mutableStateOf(false) }
    var compressResult by remember { mutableStateOf<PdfEngine.CompressResult?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var pendingOutputFile by remember { mutableStateOf<File?>(null) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            sourceUri = uri
            sourceName = FileUtils.queryDisplayName(context, uri)
            originalSize = FileUtils.queryFileSize(context, uri)
            compressResult = null
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { destUri: Uri? ->
        val cacheFile = pendingOutputFile
        if (destUri != null && cacheFile != null) {
            scope.launch {
                withContext(Dispatchers.IO) { FileUtils.writeFileToUri(context, cacheFile, destUri) }
                recentStore.addEntry(
                    RecentFileEntry(
                        id = UUID.randomUUID().toString(),
                        displayName = FileUtils.queryDisplayName(context, destUri),
                        toolName = "Compress PDF",
                        uri = destUri.toString(),
                        timestampMillis = System.currentTimeMillis(),
                        fileSizeBytes = cacheFile.length()
                    )
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Compress PDF") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Button(onClick = { filePicker.launch(arrayOf("application/pdf")) }) {
                Icon(Icons.Default.FolderOpen, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Choose PDF")
            }
            Spacer(Modifier.height(16.dp))

            if (sourceUri != null) {
                Text(sourceName, style = MaterialTheme.typography.titleMedium)
                Text(
                    "Original size: ${FileUtils.humanReadableSize(originalSize)}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(20.dp))

                Text("Compression level", style = MaterialTheme.typography.titleMedium)
                Text(
                    when {
                        quality < 0.4f -> "Smaller file, lower image quality"
                        quality > 0.7f -> "Larger file, higher image quality"
                        else -> "Balanced"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(value = quality, onValueChange = { quality = it }, valueRange = 0.1f..0.9f)

                Spacer(Modifier.height(16.dp))
                errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error); Spacer(Modifier.height(8.dp)) }

                compressResult?.let { result ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Compression complete", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            Text("Before: ${FileUtils.humanReadableSize(result.originalBytes)}")
                            Text("After: ${FileUtils.humanReadableSize(result.compressedBytes)}")
                            Text(
                                "Saved ${result.savedPercent}%",
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }

                Button(
                    onClick = {
                        scope.launch {
                            isProcessing = true
                            errorMessage = null
                            try {
                                val uri = sourceUri ?: return@launch
                                val cached = withContext(Dispatchers.IO) {
                                    FileUtils.copyUriToCacheFile(context, uri, sourceName)
                                }
                                val outputFile = File(context.cacheDir, "compressed_${System.currentTimeMillis()}.pdf")
                                val result = withContext(Dispatchers.IO) {
                                    PdfEngine.compressPdf(cached, outputFile, quality)
                                }
                                compressResult = result
                                pendingOutputFile = outputFile
                            } catch (e: Exception) {
                                errorMessage = "Compression failed: ${e.message}"
                            } finally {
                                isProcessing = false
                            }
                        }
                    },
                    enabled = !isProcessing,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("Compress")
                }

                if (compressResult != null) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { saveLauncher.launch("Compressed_${sourceName}") },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save Compressed PDF") }
                }
            } else {
                Spacer(Modifier.height(24.dp))
                Text("Choose a PDF to compress.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
