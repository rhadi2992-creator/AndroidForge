package com.educationwithhassan.smartpdfai.ui.merge

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.educationwithhassan.smartpdfai.core.data.RecentFileEntry
import com.educationwithhassan.smartpdfai.core.pdf.PdfEngine
import com.educationwithhassan.smartpdfai.core.storage.FileUtils
import com.educationwithhassan.smartpdfai.core.storage.RecentFilesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MergeScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recentStore = remember { RecentFilesStore(context) }

    var selectedPdfs by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var isProcessing by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var pendingOutputFile by remember { mutableStateOf<File?>(null) }

    val pdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> selectedPdfs = selectedPdfs + uris }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { destUri: Uri? ->
        val cacheFile = pendingOutputFile
        if (destUri != null && cacheFile != null) {
            scope.launch {
                withContext(Dispatchers.IO) { FileUtils.writeFileToUri(context, cacheFile, destUri) }
                recentStore.addEntry(
                    RecentFileEntry(
                        id = UUID.randomUUID().toString(),
                        displayName = FileUtils.queryDisplayName(context, destUri),
                        toolName = "Merge PDF",
                        uri = destUri.toString(),
                        timestampMillis = System.currentTimeMillis(),
                        fileSizeBytes = cacheFile.length()
                    )
                )
                resultMessage = "Merged PDF saved successfully."
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Merge PDF") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(
                "Select two or more PDF files. They will be combined in the order shown below — use the arrows to reorder.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { pdfPicker.launch(arrayOf("application/pdf")) }) {
                Icon(Icons.Default.NoteAdd, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add PDF Files")
            }
            Spacer(Modifier.height(16.dp))

            if (selectedPdfs.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("No PDFs selected yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(modifier = Modifier.weight(1f)) {
                    itemsIndexed(selectedPdfs) { index, uri ->
                        val name = remember(uri) { FileUtils.queryDisplayName(context, uri) }
                        ListItem(
                            headlineContent = { Text(name) },
                            supportingContent = { Text("Position ${index + 1}") },
                            trailingContent = {
                                Row {
                                    IconButton(
                                        onClick = {
                                            if (index > 0) selectedPdfs = selectedPdfs.toMutableList().apply {
                                                val item = removeAt(index); add(index - 1, item)
                                            }
                                        },
                                        enabled = index > 0
                                    ) { Icon(Icons.Default.ArrowUpward, contentDescription = "Move up") }
                                    IconButton(
                                        onClick = {
                                            if (index < selectedPdfs.lastIndex) selectedPdfs = selectedPdfs.toMutableList().apply {
                                                val item = removeAt(index); add(index + 1, item)
                                            }
                                        },
                                        enabled = index < selectedPdfs.lastIndex
                                    ) { Icon(Icons.Default.ArrowDownward, contentDescription = "Move down") }
                                    IconButton(onClick = {
                                        selectedPdfs = selectedPdfs.toMutableList().apply { removeAt(index) }
                                    }) { Icon(Icons.Default.Delete, contentDescription = "Remove") }
                                }
                            }
                        )
                        HorizontalDivider()
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error); Spacer(Modifier.height(8.dp)) }
            resultMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary); Spacer(Modifier.height(8.dp)) }

            Button(
                onClick = {
                    scope.launch {
                        isProcessing = true
                        errorMessage = null
                        resultMessage = null
                        try {
                            val cacheFiles = withContext(Dispatchers.IO) {
                                selectedPdfs.mapIndexed { i, uri ->
                                    FileUtils.copyUriToCacheFile(context, uri, "merge_in_$i.pdf")
                                }
                            }
                            val outputFile = File(context.cacheDir, "merged_${System.currentTimeMillis()}.pdf")
                            withContext(Dispatchers.IO) { PdfEngine.mergePdfs(cacheFiles, outputFile) }
                            pendingOutputFile = outputFile
                            saveLauncher.launch("Merged_Document.pdf")
                        } catch (e: Exception) {
                            errorMessage = "Failed to merge PDFs: ${e.message}"
                        } finally {
                            isProcessing = false
                        }
                    }
                },
                enabled = selectedPdfs.size >= 2 && !isProcessing,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Text("Merge ${selectedPdfs.size} PDFs")
            }
        }
    }
}
