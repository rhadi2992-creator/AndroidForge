package com.educationwithhassan.smartpdfai.ui.pdftotext

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.educationwithhassan.smartpdfai.core.data.RecentFileEntry
import com.educationwithhassan.smartpdfai.core.pdf.PdfEngine
import com.educationwithhassan.smartpdfai.core.storage.FileUtils
import com.educationwithhassan.smartpdfai.core.storage.RecentFilesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfToTextScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val recentStore = remember { RecentFilesStore(context) }

    var sourceName by remember { mutableStateOf("") }
    var extractedText by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var noTextFound by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            sourceName = FileUtils.queryDisplayName(context, uri)
            scope.launch {
                isProcessing = true
                errorMessage = null
                noTextFound = false
                extractedText = ""
                try {
                    val cached = withContext(Dispatchers.IO) { FileUtils.copyUriToCacheFile(context, uri, sourceName) }
                    val text = withContext(Dispatchers.IO) { PdfEngine.extractText(cached) }
                    if (text.isBlank()) {
                        noTextFound = true
                    } else {
                        extractedText = text
                    }
                } catch (e: Exception) {
                    errorMessage = "Failed to extract text: ${e.message}"
                } finally {
                    isProcessing = false
                }
            }
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { destUri: Uri? ->
        if (destUri != null && extractedText.isNotBlank()) {
            scope.launch {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(destUri)?.use {
                        it.write(extractedText.toByteArray())
                    }
                }
                recentStore.addEntry(
                    RecentFileEntry(
                        id = UUID.randomUUID().toString(),
                        displayName = FileUtils.queryDisplayName(context, destUri),
                        toolName = "PDF to Text",
                        uri = destUri.toString(),
                        timestampMillis = System.currentTimeMillis(),
                        fileSizeBytes = extractedText.toByteArray().size.toLong()
                    )
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PDF to Text") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } },
                actions = {
                    if (extractedText.isNotBlank()) {
                        IconButton(onClick = {
                            clipboardManager.setText(AnnotatedString(extractedText))
                        }) { Icon(Icons.Default.ContentCopy, contentDescription = "Copy text") }
                        IconButton(onClick = { saveLauncher.launch("${sourceName}_text.txt") }) {
                            Icon(Icons.Default.Save, contentDescription = "Save as .txt")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Button(onClick = { filePicker.launch(arrayOf("application/pdf")) }) {
                Icon(Icons.Default.FolderOpen, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Choose PDF")
            }
            Spacer(Modifier.height(16.dp))

            when {
                isProcessing -> CircularProgressIndicator()
                errorMessage != null -> Text(errorMessage ?: "", color = MaterialTheme.colorScheme.error)
                noTextFound -> Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text(
                        "No selectable text was found in this PDF. This usually means it's a scanned " +
                            "document made of images, not real text. OCR (reading text from scanned images) " +
                            "is not currently supported by this app.",
                        modifier = Modifier.padding(16.dp)
                    )
                }
                extractedText.isNotBlank() -> Text(
                    extractedText,
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    style = MaterialTheme.typography.bodyMedium
                )
                else -> Text("Choose a PDF to extract its text.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
