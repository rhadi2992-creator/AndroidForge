package com.educationwithhassan.smartpdfai.core.summarizer

import java.util.Locale

/**
 * A fully offline, local, non-AI extractive summarizer.
 *
 * How it works (word-frequency sentence scoring — a classic, explainable NLP technique,
 * NOT a neural/generative model, NOT an API call):
 *  1. Split the text into sentences.
 *  2. Build a word-frequency table, ignoring common "stop words" (the, is, and, etc).
 *  3. Score each sentence by summing the frequency of its significant words.
 *  4. Return the top-N highest scoring sentences, in their ORIGINAL order.
 *
 * This genuinely finds the most "information-dense" sentences in the source text.
 * It does not generate new sentences or paraphrase — it selects and reorders existing ones,
 * which is what "extractive" (as opposed to "abstractive") summarization means.
 */
object ExtractiveSummarizer {

    private val STOP_WORDS = setOf(
        "the", "is", "at", "which", "on", "a", "an", "and", "or", "but", "in", "with",
        "to", "for", "of", "as", "by", "that", "this", "it", "are", "was", "were", "be",
        "been", "being", "have", "has", "had", "do", "does", "did", "will", "would",
        "could", "should", "may", "might", "can", "from", "about", "into", "over",
        "after", "before", "between", "not", "no", "so", "than", "then", "there",
        "their", "they", "them", "he", "she", "his", "her", "its", "we", "our", "you",
        "your", "i", "my", "me", "if", "when", "where", "who", "what", "how", "all",
        "also", "such", "these", "those", "its"
    )

    /**
     * @param text full source text (already extracted from the PDF).
     * @param sentenceCount how many sentences the summary should contain.
     */
    fun summarize(text: String, sentenceCount: Int = 5): String {
        if (text.isBlank()) return ""

        val sentences = splitIntoSentences(text)
        if (sentences.size <= sentenceCount) return sentences.joinToString(" ")

        val wordFrequency = buildWordFrequency(sentences)

        val scoredSentences = sentences.mapIndexed { index, sentence ->
            val words = tokenize(sentence)
            val score = words.sumOf { wordFrequency[it] ?: 0 }
            // Normalize by sentence length so long sentences don't win purely on word count.
            val normalizedScore = if (words.isNotEmpty()) score.toDouble() / words.size else 0.0
            Triple(index, sentence, normalizedScore)
        }

        val topSentences = scoredSentences
            .sortedByDescending { it.third }
            .take(sentenceCount)
            .sortedBy { it.first } // restore original reading order

        return topSentences.joinToString(" ") { it.second.trim() }
    }

    private fun splitIntoSentences(text: String): List<String> {
        // Split on sentence-ending punctuation followed by whitespace, keep it simple and dependency-free.
        return text
            .replace(Regex("\\s+"), " ")
            .split(Regex("(?<=[.!?])\\s+"))
            .map { it.trim() }
            .filter { it.length > 15 } // drop fragments/headers that are too short to be real sentences
    }

    private fun tokenize(sentence: String): List<String> {
        return sentence.lowercase(Locale.getDefault())
            .replace(Regex("[^a-z0-9\\s]"), "")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() && it !in STOP_WORDS && it.length > 2 }
    }

    private fun buildWordFrequency(sentences: List<String>): Map<String, Int> {
        val freq = mutableMapOf<String, Int>()
        for (sentence in sentences) {
            for (word in tokenize(sentence)) {
                freq[word] = (freq[word] ?: 0) + 1
            }
        }
        return freq
    }
}
