package com.educationwithhassan.smartpdfai.ui.summarizer

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.educationwithhassan.smartpdfai.core.pdf.PdfEngine
import com.educationwithhassan.smartpdfai.core.storage.FileUtils
import com.educationwithhassan.smartpdfai.core.summarizer.ExtractiveSummarizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SummarizerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var sourceName by remember { mutableStateOf("") }
    var fullText by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }
    var sentenceCount by remember { mutableFloatStateOf(5f) }
    var isProcessing by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var noTextFound by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            sourceName = FileUtils.queryDisplayName(context, uri)
            scope.launch {
                isProcessing = true
                errorMessage = null
                noTextFound = false
                summary = ""
                try {
                    val cached = withContext(Dispatchers.IO) { FileUtils.copyUriToCacheFile(context, uri, sourceName) }
                    val text = withContext(Dispatchers.IO) { PdfEngine.extractText(cached) }
                    if (text.isBlank()) {
                        noTextFound = true
                    } else {
                        fullText = text
                        summary = withContext(Dispatchers.Default) {
                            ExtractiveSummarizer.summarize(text, sentenceCount.toInt())
                        }
                    }
                } catch (e: Exception) {
                    errorMessage = "Failed to read PDF: ${e.message}"
                } finally {
                    isProcessing = false
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Offline Summarizer") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(
                "Picks the most information-dense sentences from your PDF, fully on-device. " +
                    "No internet connection or AI API is used — this is a local keyword-frequency algorithm, " +
                    "not generative AI, so it works offline and never sends your document anywhere.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { filePicker.launch(arrayOf("application/pdf")) }) {
                Icon(Icons.Default.FolderOpen, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Choose PDF")
            }
            Spacer(Modifier.height(16.dp))

            if (fullText.isNotBlank()) {
                Text("Summary length: ${sentenceCount.toInt()} sentences")
                Slider(
                    value = sentenceCount,
                    onValueChange = {
                        sentenceCount = it
                        summary = ExtractiveSummarizer.summarize(fullText, it.toInt())
                    },
                    valueRange = 3f..15f,
                    steps = 11
                )
                Spacer(Modifier.height(12.dp))
            }

            when {
                isProcessing -> CircularProgressIndicator()
                errorMessage != null -> Text(errorMessage ?: "", color = MaterialTheme.colorScheme.error)
                noTextFound -> Text(
                    "No selectable text was found in this PDF (it may be a scanned document), " +
                        "so it cannot be summarized.",
                    color = MaterialTheme.colorScheme.error
                )
                summary.isNotBlank() -> Card {
                    Text(summary, modifier = Modifier.padding(16.dp).verticalScroll(rememberScrollState()))
                }
                else -> Text("Choose a PDF to generate an offline summary.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
