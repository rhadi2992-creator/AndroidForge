package com.educationwithhassan.smartpdfai.ui.theme

import androidx.compose.ui.graphics.Color

// Primary brand blues
val BluePrimary = Color(0xFF1565C0)
val BluePrimaryDark = Color(0xFF0D47A1)
val BlueLight = Color(0xFF42A5F5)
val BlueSurfaceTint = Color(0xFFE3F2FD)

// Neutrals
val White = Color(0xFFFFFFFF)
val OffWhite = Color(0xFFF7F9FC)
val TextDark = Color(0xFF1A1C1E)
val TextMuted = Color(0xFF5C6773)

// Status colors
val SuccessGreen = Color(0xFF2E7D32)
val ErrorRed = Color(0xFFC62828)
val WarningAmber = Color(0xFFEF6C00)

// Dark theme variants
val DarkBackground = Color(0xFF0F1417)
val DarkSurface = Color(0xFF1A2027)
