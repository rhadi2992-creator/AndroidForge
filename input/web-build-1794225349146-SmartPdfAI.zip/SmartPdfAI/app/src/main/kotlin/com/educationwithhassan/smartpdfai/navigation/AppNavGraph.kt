package com.educationwithhassan.smartpdfai.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.educationwithhassan.smartpdfai.ui.compress.CompressScreen
import com.educationwithhassan.smartpdfai.ui.home.HomeScreen
import com.educationwithhassan.smartpdfai.ui.imagetopdf.ImageToPdfScreen
import com.educationwithhassan.smartpdfai.ui.merge.MergeScreen
import com.educationwithhassan.smartpdfai.ui.pdftoimages.PdfToImagesScreen
import com.educationwithhassan.smartpdfai.ui.pdftotext.PdfToTextScreen
import com.educationwithhassan.smartpdfai.ui.reader.PdfReaderScreen
import com.educationwithhassan.smartpdfai.ui.recent.RecentFilesScreen
import com.educationwithhassan.smartpdfai.ui.settings.AboutScreen
import com.educationwithhassan.smartpdfai.ui.settings.HelpScreen
import com.educationwithhassan.smartpdfai.ui.settings.PrivacyPolicyScreen
import com.educationwithhassan.smartpdfai.ui.settings.SettingsScreen
import com.educationwithhassan.smartpdfai.ui.settings.TermsScreen
import com.educationwithhassan.smartpdfai.ui.split.SplitScreen
import com.educationwithhassan.smartpdfai.ui.summarizer.SummarizerScreen

object Routes {
    const val HOME = "home"
    const val READER = "reader"
    const val IMAGE_TO_PDF = "image_to_pdf"
    const val MERGE = "merge"
    const val SPLIT = "split"
    const val COMPRESS = "compress"
    const val PDF_TO_IMAGES = "pdf_to_images"
    const val PDF_TO_TEXT = "pdf_to_text"
    const val SUMMARIZER = "summarizer"
    const val RECENT = "recent"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
    const val HELP = "help"
    const val PRIVACY = "privacy"
    const val TERMS = "terms"
}

@Composable
fun AppNavGraph(navController: NavHostController, openedPdfUri: String? = null) {
    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen(
                onNavigate = { route -> navController.navigate(route) }
            )
        }
        composable(Routes.READER) {
            PdfReaderScreen(
                initialUri = openedPdfUri,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.IMAGE_TO_PDF) {
            ImageToPdfScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.MERGE) {
            MergeScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.SPLIT) {
            SplitScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.COMPRESS) {
            CompressScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.PDF_TO_IMAGES) {
            PdfToImagesScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.PDF_TO_TEXT) {
            PdfToTextScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.SUMMARIZER) {
            SummarizerScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.RECENT) {
            RecentFilesScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onNavigate = { route -> navController.navigate(route) }
            )
        }
        composable(Routes.ABOUT) {
            AboutScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.HELP) {
            HelpScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.PRIVACY) {
            PrivacyPolicyScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.TERMS) {
            TermsScreen(onBack = { navController.popBackStack() })
        }
    }
}
