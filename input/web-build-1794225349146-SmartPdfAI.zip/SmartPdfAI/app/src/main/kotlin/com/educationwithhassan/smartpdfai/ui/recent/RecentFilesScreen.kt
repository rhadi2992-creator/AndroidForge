package com.educationwithhassan.smartpdfai.ui.recent

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.educationwithhassan.smartpdfai.core.data.RecentFileEntry
import com.educationwithhassan.smartpdfai.core.storage.FileUtils
import com.educationwithhassan.smartpdfai.core.storage.RecentFilesStore
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecentFilesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recentStore = remember { RecentFilesStore(context) }
    val entries by recentStore.recentFiles.collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Recent Files") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } },
                actions = {
                    if (entries.isNotEmpty()) {
                        TextButton(onClick = { scope.launch { recentStore.clearAll() } }) { Text("Clear All") }
                    }
                }
            )
        }
    ) { padding ->
        if (entries.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(10.dp))
                Text("No recent files yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Files you create will appear here.", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
                items(entries, key = { it.id }) { entry ->
                    RecentFileRow(
                        entry = entry,
                        onOpen = { openUri(context, entry.uri) },
                        onRemove = { scope.launch { recentStore.removeEntry(entry) } }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun RecentFileRow(entry: RecentFileEntry, onOpen: () -> Unit, onRemove: () -> Unit) {
    ListItem(
        headlineContent = { Text(entry.displayName) },
        supportingContent = {
            Column {
                Text(entry.toolName, style = MaterialTheme.typography.bodySmall)
                Text(
                    "${FileUtils.humanReadableSize(entry.fileSizeBytes)} • " +
                        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                            .format(Date(entry.timestampMillis)),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        trailingContent = {
            IconButton(onClick = onRemove) { Icon(Icons.Default.Delete, contentDescription = "Remove from history") }
        },
        modifier = Modifier.clickableRow(onOpen)
    )
}

private fun Modifier.clickableRow(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))

private fun openUri(context: android.content.Context, uriString: String) {
    try {
        val uri = Uri.parse(uriString)
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // Silently ignore: the file may have been moved/deleted by the user outside the app,
        // or no app is installed that can open it. The entry stays in history either way.
    }
}
