package com.educationwithhassan.smartpdfai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.educationwithhassan.smartpdfai.navigation.AppNavGraph
import com.educationwithhassan.smartpdfai.ui.theme.SmartPdfAITheme
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // PdfBox-Android requires this one-time init before any PDF operation.
        PDFBoxResourceLoader.init(applicationContext)

        // If the app was opened via "Open with Smart PDF AI" on a .pdf file,
        // grab that URI so we can jump straight into the reader.
        val openedPdfUri = intent?.data

        setContent {
            SmartPdfAIApp(startUri = openedPdfUri?.toString())
        }
    }
}

@Composable
fun SmartPdfAIApp(startUri: String? = null) {
    SmartPdfAITheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            val navController = rememberNavController()
            AppNavGraph(navController = navController, openedPdfUri = startUri)
        }
    }
}
