package com.educationwithhassan.smartpdfai.ui.imagetopdf

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.educationwithhassan.smartpdfai.core.data.RecentFileEntry
import com.educationwithhassan.smartpdfai.core.pdf.PdfEngine
import com.educationwithhassan.smartpdfai.core.storage.FileUtils
import com.educationwithhassan.smartpdfai.core.storage.RecentFilesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageToPdfScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recentStore = remember { RecentFilesStore(context) }

    var selectedImages by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var isProcessing by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var pendingOutputFile by remember { mutableStateOf<File?>(null) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris -> selectedImages = selectedImages + uris }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { destUri: Uri? ->
        val cacheFile = pendingOutputFile
        if (destUri != null && cacheFile != null) {
            scope.launch {
                withContext(Dispatchers.IO) { FileUtils.writeFileToUri(context, cacheFile, destUri) }
                recentStore.addEntry(
                    RecentFileEntry(
                        id = UUID.randomUUID().toString(),
                        displayName = FileUtils.queryDisplayName(context, destUri),
                        toolName = "Image to PDF",
                        uri = destUri.toString(),
                        timestampMillis = System.currentTimeMillis(),
                        fileSizeBytes = cacheFile.length()
                    )
                )
                resultMessage = "PDF saved successfully."
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Image to PDF") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(
                "Select images, drag to reorder using the arrows, then create your PDF.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { imagePicker.launch("image/*") }) {
                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add Images")
            }
            Spacer(Modifier.height(16.dp))

            if (selectedImages.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("No images selected yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyRow(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(selectedImages) { index, uri ->
                        ImageThumbnail(
                            uri = uri,
                            index = index,
                            total = selectedImages.size,
                            onMoveLeft = {
                                if (index > 0) selectedImages = selectedImages.toMutableList().apply {
                                    val item = removeAt(index); add(index - 1, item)
                                }
                            },
                            onMoveRight = {
                                if (index < selectedImages.lastIndex) selectedImages = selectedImages.toMutableList().apply {
                                    val item = removeAt(index); add(index + 1, item)
                                }
                            },
                            onRemove = {
                                selectedImages = selectedImages.toMutableList().apply { removeAt(index) }
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            if (errorMessage != null) {
                Text(errorMessage ?: "", color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(8.dp))
            }
            if (resultMessage != null) {
                Text(resultMessage ?: "", color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
            }

            Button(
                onClick = {
                    scope.launch {
                        isProcessing = true
                        errorMessage = null
                        resultMessage = null
                        try {
                            val cacheFiles = withContext(Dispatchers.IO) {
                                selectedImages.mapIndexed { i, uri ->
                                    FileUtils.copyUriToCacheFile(context, uri, "img_$i.jpg")
                                }
                            }
                            val outputFile = File(context.cacheDir, "images_to_pdf_${System.currentTimeMillis()}.pdf")
                            withContext(Dispatchers.IO) { PdfEngine.imagesToPdf(cacheFiles, outputFile) }
                            pendingOutputFile = outputFile
                            saveLauncher.launch("Converted_Images.pdf")
                        } catch (e: Exception) {
                            errorMessage = "Failed to create PDF: ${e.message}"
                        } finally {
                            isProcessing = false
                        }
                    }
                },
                enabled = selectedImages.isNotEmpty() && !isProcessing,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Text("Create PDF (${selectedImages.size} pages)")
            }
        }
    }
}

@Composable
private fun ImageThumbnail(
    uri: Uri,
    index: Int,
    total: Int,
    onMoveLeft: () -> Unit,
    onMoveRight: () -> Unit,
    onRemove: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(110.dp)) {
        Box(
            modifier = Modifier
                .size(110.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
        ) {
            AsyncImage(
                model = uri,
                contentDescription = "Selected image ${index + 1}",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Text("Page ${index + 1}", style = MaterialTheme.typography.labelLarge)
        Row {
            IconButton(onClick = onMoveLeft, enabled = index > 0) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Move left", modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = onRemove) {
                Icon(Icons.Default.Delete, contentDescription = "Remove", modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = onMoveRight, enabled = index < total - 1) {
                Icon(Icons.Default.ArrowForward, contentDescription = "Move right", modifier = Modifier.size(18.dp))
            }
        }
    }
}
