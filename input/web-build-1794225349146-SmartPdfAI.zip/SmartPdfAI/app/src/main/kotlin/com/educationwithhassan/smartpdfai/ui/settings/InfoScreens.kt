package com.educationwithhassan.smartpdfai.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InfoScaffold(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) { content() }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun SectionBody(text: String) {
    Text(text, style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(18.dp))
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    InfoScaffold("About", onBack) {
        SectionTitle("Smart PDF AI – PDF Tools")
        SectionBody(
            "Version 1.0.0\nDeveloped by Education With Hassan.\n\n" +
                "Smart PDF AI is a privacy-first PDF toolkit that works entirely on your device. " +
                "It lets you read, merge, split, compress, and convert PDFs without uploading your " +
                "documents anywhere, and includes a fully offline text summarizer."
        )
        SectionTitle("Why offline-first?")
        SectionBody(
            "Your documents often contain personal or sensitive information. Every PDF operation in " +
                "this app runs locally using the device's own processor — nothing is sent to a server, " +
                "and no account or sign-in is required."
        )
        SectionTitle("Open-source libraries used")
        SectionBody(
            "• Android Jetpack Compose (Apache 2.0)\n" +
                "• PdfBox-Android by TomRoush (Apache 2.0)\n" +
                "• Coil image loading (Apache 2.0)\n" +
                "• Google Mobile Ads SDK (optional, disabled by default)\n\n" +
                "Full license texts are listed in the project's THIRD_PARTY_LICENSES file."
        )
    }
}

@Composable
fun HelpScreen(onBack: () -> Unit) {
    InfoScaffold("Help", onBack) {
        SectionTitle("How do I open a PDF?")
        SectionBody("From the Home screen, tap 'PDF Reader', then tap the folder icon and pick a PDF from your device.")

        SectionTitle("How does Compress PDF work?")
        SectionBody(
            "It re-encodes the images inside your PDF at a lower quality/resolution, which reduces " +
                "file size. Text and vector graphics are left untouched. Scanned PDFs (which are " +
                "really just one big image per page) will shrink the most."
        )

        SectionTitle("Why does PDF to Text say 'no text found'?")
        SectionBody(
            "Some PDFs are scanned images of pages rather than real text. This app extracts existing " +
                "selectable text — it does not perform OCR (optical character recognition) to read text " +
                "out of scanned images, so those documents cannot be converted to text yet."
        )

        SectionTitle("Is an internet connection required?")
        SectionBody(
            "No. Every tool in this app works fully offline. The only thing that would ever use the " +
                "internet is an optional, clearly-separated advertising module, which can be fully disabled."
        )

        SectionTitle("Where are my files saved?")
        SectionBody(
            "You choose the save location yourself every time, using Android's standard file picker. " +
                "The app does not write to storage without your explicit confirmation."
        )
    }
}

@Composable
fun PrivacyPolicyScreen(onBack: () -> Unit) {
    InfoScaffold("Privacy Policy", onBack) {
        SectionTitle("Privacy Policy for Smart PDF AI – PDF Tools")
        SectionBody("Developer: Education With Hassan\nLast updated: (fill in the date you publish this app)")

        SectionTitle("1. What we collect")
        SectionBody(
            "We do not collect, store, or transmit your documents. All PDF processing (reading, " +
                "merging, splitting, compressing, converting, and summarizing) happens entirely on your " +
                "device. Your files are never uploaded to any server operated by us or any third party."
        )

        SectionTitle("2. Local history")
        SectionBody(
            "The 'Recent Files' list is stored only on your device using Android's local DataStore " +
                "storage. It is never synced or uploaded. You can clear it at any time from the Recent " +
                "Files screen."
        )

        SectionTitle("3. Permissions")
        SectionBody(
            "This app does not request broad storage, camera, or contacts permissions. Files are " +
                "accessed only through Android's Storage Access Framework (the system file picker), " +
                "meaning you explicitly choose every file the app can read or write."
        )

        SectionTitle("4. Advertising (if enabled)")
        SectionBody(
            "If the optional advertising module is enabled in a future update, it will use Google's " +
                "Mobile Ads SDK and may collect data as described in Google's own privacy policy. Ads, " +
                "if shown, will never appear while you are selecting, viewing, or processing a document. " +
                "You will be notified via an in-app consent flow before any ad-related data processing " +
                "begins, in line with applicable consent requirements (e.g. Google's EU User Consent Policy)."
        )

        SectionTitle("5. Third-party libraries")
        SectionBody(
            "This app uses open-source libraries (listed in About > Open-source libraries) that run " +
                "locally and do not transmit your data externally."
        )

        SectionTitle("6. Children's privacy")
        SectionBody("This app does not knowingly collect data from children and has no account or sign-in system.")

        SectionTitle("7. Changes to this policy")
        SectionBody(
            "If this policy changes, the updated version will be published within the app and, once " +
                "publicly hosted, at the developer's chosen policy URL."
        )

        SectionTitle("8. Contact")
        SectionBody("For questions about this policy, contact: (insert your developer contact email here)")
    }
}

@Composable
fun TermsScreen(onBack: () -> Unit) {
    InfoScaffold("Terms of Use", onBack) {
        SectionTitle("Terms of Use for Smart PDF AI – PDF Tools")
        SectionBody("Developer: Education With Hassan\nLast updated: (fill in the date you publish this app)")

        SectionTitle("1. Acceptance")
        SectionBody("By installing and using this app, you agree to these terms.")

        SectionTitle("2. License")
        SectionBody(
            "You are granted a personal, non-exclusive, non-transferable license to use this app " +
                "for its intended purpose: viewing and processing PDF files on your own device."
        )

        SectionTitle("3. Your content")
        SectionBody(
            "You retain all rights to the documents you process with this app. We do not claim any " +
                "ownership over your files, and as described in our Privacy Policy, we never see them."
        )

        SectionTitle("4. No warranty")
        SectionBody(
            "This app is provided 'as is'. While we aim for accurate PDF processing, we do not " +
                "guarantee the app is error-free or fit for every purpose. Always keep a backup of " +
                "important original documents before merging, splitting, or compressing them."
        )

        SectionTitle("5. Limitation of liability")
        SectionBody(
            "To the extent permitted by law, the developer is not liable for any data loss or damages " +
                "resulting from the use of this app."
        )

        SectionTitle("6. Changes")
        SectionBody("These terms may be updated from time to time; continued use after changes means you accept the updated terms.")

        SectionTitle("7. Contact")
        SectionBody("For questions about these terms, contact: (insert your developer contact email here)")
    }
}
