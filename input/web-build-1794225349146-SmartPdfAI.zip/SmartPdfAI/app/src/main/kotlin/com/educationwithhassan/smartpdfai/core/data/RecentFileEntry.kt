package com.educationwithhassan.smartpdfai.core.data

/**
 * One entry in the "Recent Files" history list.
 * [uri] is the content:// or file:// location of the RESULT file (e.g. the merged PDF).
 */
data class RecentFileEntry(
    val id: String,
    val displayName: String,
    val toolName: String,
    val uri: String,
    val timestampMillis: Long,
    val fileSizeBytes: Long
) {
    companion object {
        private const val DELIMITER = "\u0001" // unit separator, won't appear in normal text

        fun encode(entry: RecentFileEntry): String = listOf(
            entry.id, entry.displayName, entry.toolName, entry.uri,
            entry.timestampMillis.toString(), entry.fileSizeBytes.toString()
        ).joinToString(DELIMITER)

        fun decode(raw: String): RecentFileEntry? {
            val parts = raw.split(DELIMITER)
            if (parts.size != 6) return null
            return try {
                RecentFileEntry(
                    id = parts[0],
                    displayName = parts[1],
                    toolName = parts[2],
                    uri = parts[3],
                    timestampMillis = parts[4].toLong(),
                    fileSizeBytes = parts[5].toLong()
                )
            } catch (e: NumberFormatException) {
                null
            }
        }
    }
}
