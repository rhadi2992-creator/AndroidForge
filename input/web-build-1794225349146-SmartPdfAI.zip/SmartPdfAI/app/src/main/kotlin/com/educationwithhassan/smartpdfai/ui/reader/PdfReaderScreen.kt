package com.educationwithhassan.smartpdfai.ui.reader

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.educationwithhassan.smartpdfai.core.pdf.PdfEngine
import com.educationwithhassan.smartpdfai.core.storage.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(initialUri: String?, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var localFile by remember { mutableStateOf<File?>(null) }
    var pageBitmaps by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }

    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                isLoading = true
                error = null
                try {
                    val name = FileUtils.queryDisplayName(context, uri)
                    val cached = withContext(Dispatchers.IO) {
                        FileUtils.copyUriToCacheFile(context, uri, name)
                    }
                    localFile = cached
                    pageBitmaps = withContext(Dispatchers.IO) { renderAllPages(cached) }
                } catch (e: Exception) {
                    error = "Could not open this PDF: ${e.message}"
                } finally {
                    isLoading = false
                }
            }
        }
    }

    // Auto-open if launched via "Open with" intent
    LaunchedEffect(initialUri) {
        if (initialUri != null && localFile == null) {
            isLoading = true
            try {
                val uri = Uri.parse(initialUri)
                val name = FileUtils.queryDisplayName(context, uri)
                val cached = withContext(Dispatchers.IO) { FileUtils.copyUriToCacheFile(context, uri, name) }
                localFile = cached
                pageBitmaps = withContext(Dispatchers.IO) { renderAllPages(cached) }
            } catch (e: Exception) {
                error = "Could not open this PDF: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PDF Reader") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    IconButton(onClick = { pickerLauncher.launch(arrayOf("application/pdf")) }) {
                        Icon(Icons.Default.FolderOpen, contentDescription = "Open PDF")
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when {
                isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                error != null -> Text(
                    error ?: "", modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    color = MaterialTheme.colorScheme.error
                )
                pageBitmaps.isEmpty() -> EmptyReaderState(
                    onPick = { pickerLauncher.launch(arrayOf("application/pdf")) }
                )
                else -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTransformGestures { _, _, gestureZoom, _ ->
                                    zoom = (zoom * gestureZoom).coerceIn(0.5f, 3f)
                                }
                            },
                        contentPadding = PaddingValues(8.dp)
                    ) {
                        items(pageBitmaps) { bitmap ->
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "PDF page",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .scale(zoom)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyReaderState(onPick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text("Open a PDF to start reading", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onPick) { Text("Choose PDF file") }
    }
}

private fun renderAllPages(file: File): List<Bitmap> {
    val bitmaps = mutableListOf<Bitmap>()
    PdfEngine.openRenderer(file).use { renderer ->
        for (i in 0 until renderer.pageCount) {
            bitmaps.add(PdfEngine.renderPage(renderer, i, targetWidthPx = 1080))
        }
    }
    return bitmaps
}
