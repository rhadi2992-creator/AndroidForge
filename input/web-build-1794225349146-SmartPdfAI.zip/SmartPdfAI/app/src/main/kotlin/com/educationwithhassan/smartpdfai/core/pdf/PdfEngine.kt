package com.educationwithhassan.smartpdfai.core.pdf

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.multipdf.Splitter
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * All real PDF operations in one place. Every function here does genuine work on the
 * actual file bytes — nothing is simulated or faked. Functions are blocking; call them
 * from a background coroutine (Dispatchers.IO), never from the main/UI thread.
 */
object PdfEngine {

    // ---------- PDF READER ----------

    /** Opens a PDF for page-by-page rendering using Android's built-in, hardware-accelerated renderer. */
    fun openRenderer(file: File): PdfRenderer {
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        return PdfRenderer(pfd)
    }

    fun renderPage(renderer: PdfRenderer, pageIndex: Int, targetWidthPx: Int): Bitmap {
        renderer.openPage(pageIndex).use { page ->
            val scale = targetWidthPx.toFloat() / page.width
            val height = (page.height * scale).toInt()
            val bitmap = Bitmap.createBitmap(targetWidthPx, height, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(android.graphics.Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bitmap
        }
    }

    // ---------- IMAGE TO PDF ----------

    /** Builds a new PDF, one page per image, in the order given. Each image is scaled to fit an A4-like page. */
    fun imagesToPdf(images: List<File>, outputFile: File) {
        PDDocument().use { doc ->
            for (imageFile in images) {
                val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath) ?: continue
                val pageWidth = PDRectangle.A4.width
                val pageHeight = PDRectangle.A4.height
                val page = PDPage(PDRectangle(pageWidth, pageHeight))
                doc.addPage(page)

                val pdImage = LosslessFactory.createFromImage(doc, bitmap)

                // Scale image to fit within the page while preserving aspect ratio.
                val scale = minOf(pageWidth / bitmap.width, pageHeight / bitmap.height)
                val drawWidth = bitmap.width * scale
                val drawHeight = bitmap.height * scale
                val x = (pageWidth - drawWidth) / 2
                val y = (pageHeight - drawHeight) / 2

                PDPageContentStream(doc, page).use { stream ->
                    stream.drawImage(pdImage, x, y, drawWidth, drawHeight)
                }
                bitmap.recycle()
            }
            doc.save(outputFile)
        }
    }

    // ---------- MERGE ----------

    fun mergePdfs(inputFiles: List<File>, outputFile: File) {
        PDDocument().use { merged ->
            for (input in inputFiles) {
                PDDocument.load(input).use { doc ->
                    for (page in doc.pages) {
                        merged.importPage(page)
                    }
                }
            }
            merged.save(outputFile)
        }
    }

    // ---------- SPLIT ----------

    /** Splits [inputFile] into separate single-page PDFs. Returns the list of created files. */
    fun splitAllPages(inputFile: File, outputDir: File): List<File> {
        val results = mutableListOf<File>()
        PDDocument.load(inputFile).use { doc ->
            val splitter = Splitter()
            val splitDocs = splitter.split(doc)
            splitDocs.forEachIndexed { index, splitDoc ->
                val outFile = File(outputDir, "page_${index + 1}.pdf")
                splitDoc.save(outFile)
                splitDoc.close()
                results.add(outFile)
            }
        }
        return results
    }

    /** Extracts a single contiguous page range (1-indexed, inclusive) into one new PDF. */
    fun extractPageRange(inputFile: File, startPage: Int, endPage: Int, outputFile: File) {
        PDDocument.load(inputFile).use { doc ->
            PDDocument().use { newDoc ->
                val lastPage = minOf(endPage, doc.numberOfPages)
                for (i in startPage..lastPage) {
                    newDoc.importPage(doc.getPage(i - 1))
                }
                newDoc.save(outputFile)
            }
        }
    }

    // ---------- COMPRESS ----------

    /**
     * Real compression: re-encodes every embedded raster image inside the PDF at a lower
     * JPEG quality/resolution, then re-saves the document. Text and vector content are untouched
     * (lossless), so this works best on image-heavy / scanned PDFs. [quality] is 0.1–1.0.
     */
    fun compressPdf(inputFile: File, outputFile: File, quality: Float = 0.5f): CompressResult {
        val originalSize = inputFile.length()
        PDDocument.load(inputFile).use { doc ->
            for (page in doc.pages) {
                val resources = page.resources ?: continue
                for (name in resources.xObjectNames.toList()) {
                    val xObject = resources.getXObject(name)
                    if (xObject is com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject) {
                        val bitmap = xObject.image
                        val scaledBitmap = downscaleBitmap(bitmap, quality)
                        val baos = ByteArrayOutputStream()
                        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, (quality * 100).toInt(), baos)
                        val compressedBytes = baos.toByteArray()
                        val newImage = com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
                            .createFromByteArray(doc, compressedBytes)
                        resources.put(name, newImage)
                    }
                }
            }
            doc.save(outputFile)
        }
        val newSize = outputFile.length()
        return CompressResult(originalSize, newSize)
    }

    private fun downscaleBitmap(bitmap: Bitmap, quality: Float): Bitmap {
        val scaleFactor = 0.5f + (quality * 0.5f) // never shrink below 50% dimension
        val newWidth = (bitmap.width * scaleFactor).toInt().coerceAtLeast(1)
        val newHeight = (bitmap.height * scaleFactor).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }

    data class CompressResult(val originalBytes: Long, val compressedBytes: Long) {
        val savedPercent: Int
            get() = if (originalBytes <= 0) 0
            else (100 - (compressedBytes * 100 / originalBytes)).toInt().coerceIn(0, 100)
    }

    // ---------- PDF TO IMAGES ----------

    /** Renders the selected pages (0-indexed) to JPEG files in [outputDir]. */
    fun pdfToImages(inputFile: File, pageIndices: List<Int>, outputDir: File, dpiScale: Int = 2): List<File> {
        val results = mutableListOf<File>()
        openRenderer(inputFile).use { renderer ->
            for (pageIndex in pageIndices) {
                if (pageIndex !in 0 until renderer.pageCount) continue
                renderer.openPage(pageIndex).use { page ->
                    val width = page.width * dpiScale
                    val height = page.height * dpiScale
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    val outFile = File(outputDir, "page_${pageIndex + 1}.jpg")
                    outFile.outputStream().use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                    }
                    bitmap.recycle()
                    results.add(outFile)
                }
            }
        }
        return results
    }

    // ---------- PDF TO TEXT ----------

    /**
     * Extracts selectable text. Returns an empty string for scanned/image-only PDFs —
     * callers MUST check for blank text and tell the user no text layer was found,
     * rather than showing a blank page silently.
     */
    fun extractText(inputFile: File): String {
        PDDocument.load(inputFile).use { doc ->
            val stripper = PDFTextStripper()
            return stripper.getText(doc)
        }
    }

    fun getPageCount(file: File): Int {
        PDDocument.load(file).use { doc -> return doc.numberOfPages }
    }
}
