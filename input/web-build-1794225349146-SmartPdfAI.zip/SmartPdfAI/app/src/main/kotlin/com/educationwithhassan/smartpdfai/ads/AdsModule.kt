package com.educationwithhassan.smartpdfai.ads

import android.content.Context
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.educationwithhassan.smartpdfai.BuildConfig
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

/**
 * OPTIONAL advertising module. Kept fully isolated from the PDF tools:
 *  - It is only initialized / shown when BuildConfig.ENABLE_ADS == true (set in app/build.gradle.kts).
 *  - It must NEVER be placed on a screen while a file is being selected, read, processed, or saved
 *    (see the "Never show ads during document actions" rule in README.md / the AdMob setup guide).
 *  - It uses Google's official shared TEST ad unit ID by default. Replace ADMOB_BANNER_TEST_ID with
 *    your OWN production ad unit ID (from your own AdMob account) only in a signed release build,
 *    and only after reading docs/ADMOB_SETUP.md.
 *  - If an ad fails to load, the app continues to function normally — ad failures are swallowed,
 *    never surfaced as app errors.
 */
object AdsModule {

    private var initialized = false

    fun initializeIfEnabled(context: Context) {
        if (!BuildConfig.ENABLE_ADS || initialized) return
        MobileAds.initialize(context.applicationContext) { initialized = true }
    }
}

/**
 * A banner ad composable. Renders nothing at all if ads are disabled — safe to drop into any
 * screen (ideally only Home or Settings, never a tool-in-progress screen) without extra checks.
 */
@Composable
fun OptionalBannerAd(modifier: Modifier = Modifier) {
    if (!BuildConfig.ENABLE_ADS) return

    val context = LocalContext.current
    var loadFailed by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { AdsModule.initializeIfEnabled(context) }

    if (loadFailed) return // app keeps working normally; we simply show no ad

    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = BuildConfig.ADMOB_BANNER_TEST_ID // TEST ID — see class doc above
                adListener = object : com.google.android.gms.ads.AdListener() {
                    override fun onAdFailedToLoad(error: com.google.android.gms.ads.LoadAdError) {
                        loadFailed = true
                    }
                }
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}
