package com.educationwithhassan.smartpdfai.core.storage

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/**
 * Small helpers for working with content:// Uris returned by the system file picker
 * (Storage Access Framework). We never request broad storage permissions; every
 * file we touch is one the user explicitly picked or explicitly chose a save location for.
 */
object FileUtils {

    fun queryDisplayName(context: Context, uri: Uri): String {
        var name = "document.pdf"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) {
                name = cursor.getString(nameIndex) ?: name
            }
        }
        return name
    }

    fun queryFileSize(context: Context, uri: Uri): Long {
        var size = 0L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst() && sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                size = cursor.getLong(sizeIndex)
            }
        }
        return size
    }

    /** Copies a picked content:// Uri into the app's private cache dir so PdfBox can work with a real File. */
    fun copyUriToCacheFile(context: Context, uri: Uri, suggestedName: String): File {
        val outFile = File(context.cacheDir, "${System.currentTimeMillis()}_$suggestedName")
        context.contentResolver.openInputStream(uri)?.use { input: InputStream ->
            FileOutputStream(outFile).use { output -> input.copyTo(output) }
        }
        return outFile
    }

    /** Writes bytes from a local cache File into a destination content:// Uri the user chose via ACTION_CREATE_DOCUMENT. */
    fun writeFileToUri(context: Context, sourceFile: File, destUri: Uri) {
        context.contentResolver.openOutputStream(destUri)?.use { output ->
            sourceFile.inputStream().use { input -> input.copyTo(output) }
        }
    }

    fun humanReadableSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        var value = bytes.toDouble()
        var unitIndex = 0
        while (value >= 1024 && unitIndex < units.size - 1) {
            value /= 1024
            unitIndex++
        }
        return String.format("%.1f %s", value, units[unitIndex])
    }
}
