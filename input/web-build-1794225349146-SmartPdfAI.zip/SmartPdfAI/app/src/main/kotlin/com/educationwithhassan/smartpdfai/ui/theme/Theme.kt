package com.educationwithhassan.smartpdfai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = BluePrimary,
    onPrimary = White,
    primaryContainer = BlueSurfaceTint,
    onPrimaryContainer = BluePrimaryDark,
    secondary = BlueLight,
    background = OffWhite,
    onBackground = TextDark,
    surface = White,
    onSurface = TextDark,
    surfaceVariant = BlueSurfaceTint,
    onSurfaceVariant = TextMuted,
    error = ErrorRed
)

private val DarkColors = darkColorScheme(
    primary = BlueLight,
    onPrimary = DarkBackground,
    primaryContainer = BluePrimaryDark,
    onPrimaryContainer = BlueSurfaceTint,
    secondary = BlueLight,
    background = DarkBackground,
    onBackground = White,
    surface = DarkSurface,
    onSurface = White,
    surfaceVariant = DarkSurface,
    onSurfaceVariant = TextMuted,
    error = ErrorRed
)

@Composable
fun SmartPdfAITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = AppTypography,
        content = content
    )
}
