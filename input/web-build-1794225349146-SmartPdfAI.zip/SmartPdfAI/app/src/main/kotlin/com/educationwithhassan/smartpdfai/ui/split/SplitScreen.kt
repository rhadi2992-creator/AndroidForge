package com.educationwithhassan.smartpdfai.ui.split

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.educationwithhassan.smartpdfai.core.data.RecentFileEntry
import com.educationwithhassan.smartpdfai.core.pdf.PdfEngine
import com.educationwithhassan.smartpdfai.core.storage.FileUtils
import com.educationwithhassan.smartpdfai.core.storage.RecentFilesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SplitScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recentStore = remember { RecentFilesStore(context) }

    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var sourceName by remember { mutableStateOf("") }
    var pageCount by remember { mutableIntStateOf(0) }
    var startPage by remember { mutableStateOf("1") }
    var endPage by remember { mutableStateOf("1") }
    var isProcessing by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var pendingOutputFile by remember { mutableStateOf<File?>(null) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            sourceUri = uri
            sourceName = FileUtils.queryDisplayName(context, uri)
            scope.launch {
                val cached = withContext(Dispatchers.IO) { FileUtils.copyUriToCacheFile(context, uri, sourceName) }
                pageCount = withContext(Dispatchers.IO) { PdfEngine.getPageCount(cached) }
                endPage = pageCount.toString()
            }
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { destUri: Uri? ->
        val cacheFile = pendingOutputFile
        if (destUri != null && cacheFile != null) {
            scope.launch {
                withContext(Dispatchers.IO) { FileUtils.writeFileToUri(context, cacheFile, destUri) }
                recentStore.addEntry(
                    RecentFileEntry(
                        id = UUID.randomUUID().toString(),
                        displayName = FileUtils.queryDisplayName(context, destUri),
                        toolName = "Split PDF",
                        uri = destUri.toString(),
                        timestampMillis = System.currentTimeMillis(),
                        fileSizeBytes = cacheFile.length()
                    )
                )
                resultMessage = "Split PDF saved successfully."
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Split PDF") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Button(onClick = { filePicker.launch(arrayOf("application/pdf")) }) {
                Icon(Icons.Default.FolderOpen, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Choose PDF")
            }
            Spacer(Modifier.height(12.dp))

            if (sourceUri != null) {
                Text(sourceName, style = MaterialTheme.typography.titleMedium)
                Text("$pageCount pages", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(16.dp))

                Text("Export page range:", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = startPage,
                        onValueChange = { startPage = it.filter { c -> c.isDigit() } },
                        label = { Text("From page") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endPage,
                        onValueChange = { endPage = it.filter { c -> c.isDigit() } },
                        label = { Text("To page") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(20.dp))
                errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error); Spacer(Modifier.height(8.dp)) }
                resultMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary); Spacer(Modifier.height(8.dp)) }

                Button(
                    onClick = {
                        val start = startPage.toIntOrNull() ?: 1
                        val end = endPage.toIntOrNull() ?: pageCount
                        if (start < 1 || end > pageCount || start > end) {
                            errorMessage = "Enter a valid range between 1 and $pageCount."
                            return@Button
                        }
                        scope.launch {
                            isProcessing = true
                            errorMessage = null
                            resultMessage = null
                            try {
                                val uri = sourceUri ?: return@launch
                                val cached = withContext(Dispatchers.IO) {
                                    FileUtils.copyUriToCacheFile(context, uri, sourceName)
                                }
                                val outputFile = File(context.cacheDir, "split_${System.currentTimeMillis()}.pdf")
                                withContext(Dispatchers.IO) {
                                    PdfEngine.extractPageRange(cached, start, end, outputFile)
                                }
                                pendingOutputFile = outputFile
                                saveLauncher.launch("Split_pages_${start}-$end.pdf")
                            } catch (e: Exception) {
                                errorMessage = "Failed to split PDF: ${e.message}"
                            } finally {
                                isProcessing = false
                            }
                        }
                    },
                    enabled = !isProcessing,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("Export Pages $startPage–$endPage")
                }
            } else {
                Spacer(Modifier.height(24.dp))
                Text("Choose a PDF to begin.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
