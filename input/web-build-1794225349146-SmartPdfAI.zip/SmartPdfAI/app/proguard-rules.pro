# Add project specific ProGuard rules here.
# PdfBox-Android needs its resources kept
-keep class com.tom_roush.pdfbox.** { *; }
-dontwarn com.tom_roush.pdfbox.**
-keep class com.google.android.gms.ads.** { *; }
