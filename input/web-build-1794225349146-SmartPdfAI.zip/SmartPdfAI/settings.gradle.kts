pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Required for PdfBox-Android (tom-roush)
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "SmartPdfAI"
include(":app")
